<?php
require_once 'includes/db.php';

echo "--- Schema for employee_details1 ---\n";
$res = $mysqli->query("DESCRIBE employee_details1");
while ($row = $res->fetch_assoc()) {
    echo $row['Field'] . " - " . $row['Type'] . "\n";
}

echo "\n--- Searching for Principal ---\n";
$res = $mysqli->query("SELECT * FROM employee_details1 WHERE DESIGNATION LIKE '%Principal%' LIMIT 5");
while ($row = $res->fetch_assoc()) {
    print_r($row);
}
?>
