<?php
// test_ai.php
// A simple web-based test for the AI engine

$url = 'http://localhost/antigravity/ai/ai_engine.php';

function test_query($query, $userType = 'public')
{
    global $url;

    $data = json_encode(['question' => $query, 'user_context' => $userType]);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    echo "<h3>Query: '$query' ($userType)</h3>";
    echo "<strong>HTTP Code:</strong> $httpCode<br>";
    echo "<strong>Response:</strong> ";

    if ($httpCode == 200) {
        $json = json_decode($response, true);
        if ($json) {
            echo "<pre>" . json_encode($json, JSON_PRETTY_PRINT) . "</pre>";
        }
        else {
            echo "Invalid JSON: " . htmlspecialchars($response);
        }
    }
    else {
        echo "Error: " . htmlspecialchars($response);
    }
    echo "<hr>";
}

?>
<!DOCTYPE html>
<html>
<head><title>AI Engine Test</title></head>
<body>
<h1>AI Engine Test Suite</h1>
<?php
// 1. General Greeting
test_query('Hello');

// 2. Course Info (Database)
test_query('What courses are offered?');

// 3. Faculty Search (New Feature)
test_query('search faculty Harsha');

// 4. Privacy Check (Public User - Should Block)
test_query('give me student phone number');

// 5. Privacy Check (Student User - Should Block)
test_query('give me student phone number', 'student');

// 6. Bonafide (Student User - Should Access)
test_query('apply for bonafide', 'student');

// 7. Bonafide (Public User - Should Block)
test_query('apply for bonafide', 'public');
// 8. Principal Search
test_query('who is principal');

// 9. Ambiguity Test (Phase 1: Ask name)
test_query('who is Harsha');

// 10. Ambiguity Test (Phase 2: Answer faculty)
// Note: This relies on session, might need manual check in browser
test_query('faculty');

// 11. Ambiguity Test (Phase 3: Answer student)
// Note: This relies on session, might need manual check in browser
test_query('student');
// 12. Role Search (HOD)
test_query('who is the HOD of Biotech?');

// 13. Role Search (Dean)
test_query('who is the Dean?');
?>
</body>
</html>
