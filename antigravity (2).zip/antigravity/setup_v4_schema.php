<?php
// setup_v4_schema.php
require_once 'includes/config.php';
require_once 'includes/db.php';

echo "<h1>VEL AI Enterprise v4.0 - Schema Setup</h1>";

$tables = [
    'ai_metrics' => "CREATE TABLE IF NOT EXISTS ai_metrics (
        id INT AUTO_INCREMENT PRIMARY KEY,
        date DATE UNIQUE NOT NULL,
        total_queries INT DEFAULT 0,
        successful_responses INT DEFAULT 0,
        local_responses INT DEFAULT 0,
        ai_responses INT DEFAULT 0,
        avg_response_time FLOAT DEFAULT 0,
        user_types JSON NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    'ai_chat_history' => "CREATE TABLE IF NOT EXISTS ai_chat_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(50),
        user_type VARCHAR(20),
        message TEXT,
        reply TEXT,
        source VARCHAR(50),
        confidence FLOAT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    'ai_unanswered_questions' => "CREATE TABLE IF NOT EXISTS ai_unanswered_questions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        question TEXT,
        user_type VARCHAR(20),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    'ai_logs' => "CREATE TABLE IF NOT EXISTS ai_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(50),
        message TEXT,
        response TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    'ai_pending_ai_answers' => "CREATE TABLE IF NOT EXISTS ai_pending_ai_answers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        question TEXT,
        proposed_answer TEXT,
        user_type VARCHAR(20),
        source_model VARCHAR(50),
        confidence FLOAT,
        status VARCHAR(20) DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    'ai_synonyms' => "CREATE TABLE IF NOT EXISTS ai_synonyms (
        id INT AUTO_INCREMENT PRIMARY KEY,
        keyword VARCHAR(100),
        mapped_keyword VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    'ai_patterns' => "CREATE TABLE IF NOT EXISTS ai_patterns (
        id INT AUTO_INCREMENT PRIMARY KEY,
        pattern_text VARCHAR(255),
        intent VARCHAR(50),
        priority INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )"
];

// Data Population for NLP
$nlp_data = [
    'ai_synonyms' => [
        "INSERT INTO ai_synonyms (keyword, mapped_keyword) VALUES ('tution', 'tuition')",
        "INSERT INTO ai_synonyms (keyword, mapped_keyword) VALUES ('accomodation', 'hostel')",
        "INSERT INTO ai_synonyms (keyword, mapped_keyword) VALUES ('fees', 'fee')",
        "INSERT INTO ai_synonyms (keyword, mapped_keyword) VALUES ('placement', 'recruit')",
        "INSERT INTO ai_synonyms (keyword, mapped_keyword) VALUES ('certificate', 'bonafide')"
    ],
    'ai_patterns' => [
        "INSERT INTO ai_patterns (pattern_text, intent, priority) VALUES ('fee structure', 'fee_structure', 10)",
        "INSERT INTO ai_patterns (pattern_text, intent, priority) VALUES ('hostel fee', 'hostel_fee', 10)",
        "INSERT INTO ai_patterns (pattern_text, intent, priority) VALUES ('bus route', 'transport', 5)",
        "INSERT INTO ai_patterns (pattern_text, intent, priority) VALUES ('apply bonafide', 'bonafide_apply', 10)"
    ]
];

foreach ($tables as $name => $sql) {
    echo "Checking table <strong>$name</strong>... ";
    if ($mysqli->query($sql)) {
        echo "<span style='color:green'>OK (Created/Exists)</span><br>";
    }
    else {
        echo "<span style='color:red'>ERROR: " . $mysqli->error . "</span><br>";
    }
}

// Populate Data if empty
foreach ($nlp_data as $table => $inserts) {
    $res = $mysqli->query("SELECT COUNT(*) as cnt FROM $table");
    if ($res && $row = $res->fetch_assoc()) {
        if ($row['cnt'] == 0) {
            echo "Populating <strong>$table</strong>... ";
            foreach ($inserts as $sql) {
                $mysqli->query($sql);
            }
            echo "<span style='color:blue'>Data Inserted</span><br>";
        }
    }
}

echo "<hr>";
echo "<h3>Setup Complete.</h3>";
echo "<p>You can now access the <a href='admin/admin_ai_dashboard.php'>Admin Dashboard</a>.</p>";
?>
