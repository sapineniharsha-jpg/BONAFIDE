<?php
$content = file_get_contents('e:/antigravity/velai.php');
if (preg_match('/<script>(.*?)<\/script>/s', $content, $matches)) {
    $js = $matches[1];
    $open = substr_count($js, '{');
    $close = substr_count($js, '}');
    echo "JS Braces: {=$open, }=$close\n";

    // Optional: closer look at each function
    $lines = explode("\n", $js);
    $depth = 0;
    foreach ($lines as $i => $line) {
        $prev_depth = $depth;
        $depth += substr_count($line, '{');
        $depth -= substr_count($line, '}');
        if ($depth < 0) {
            echo "NEGATIVE DEPTH at Script Line " . ($i + 1) . ": $line\n";
            $depth = 0;
        }
    }
    if ($depth > 0) {
        echo "UNCLOSED BRACES: $depth at end of script\n";
    }
}
else {
    echo "No script block found\n";
}
?>
