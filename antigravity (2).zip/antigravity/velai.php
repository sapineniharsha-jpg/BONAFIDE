<?php
// velai.php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

// Security Headers
// header("X-Frame-Options: DENY"); // Removed to allow iframe integration
header("X-Content-Type-Options: nosniff");
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/velai_error.log');

// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// College TNEA Code
$tneaCode = '1122';

// ---------------------------------------------------------
// LOGIC: FETCH VISION & MISSION (INSTITUTION + DEPARTMENT)
// ---------------------------------------------------------
$user_id = $_SESSION['user_id'];
$dept_key = null;
$dept_raw_name = "";

// 1. Always Fetch Institution Data First (Cached)
$cacheInstFile = __DIR__ . '/cache/inst_vm.json';
if (!is_dir(__DIR__ . '/cache'))
    mkdir(__DIR__ . '/cache', 0755, true);

$inst_data = null;
if (file_exists($cacheInstFile) && (time() - filemtime($cacheInstFile) < 600)) {
    $inst_data = json_decode(file_get_contents($cacheInstFile), true);
}
else {
    $inst_res = $mysqli->query("SELECT vision, mission FROM ai_vision_mission WHERE category = 'Institution' LIMIT 1");
    if ($inst_res && $row = $inst_res->fetch_assoc()) {
        $inst_data = $row;
        file_put_contents($cacheInstFile, json_encode($inst_data));
    }
}

// 2. Helper to map DB Dept Codes to Vision Table Categories
function mapDeptToCategory($code)
{
    $code = strtolower(trim($code));

    if (strpos($code, 'structural') !== false)
        return 'Structural';
    if (strpos($code, 'aiml') !== false || strpos($code, 'machine learning') !== false || $code === 'ml' || strpos($code, 'cse-aiml') !== false)
        return 'CSE-AIML';
    if (strpos($code, 'aids') !== false || strpos($code, 'ai&ds') !== false || strpos($code, 'data science') !== false || strpos($code, 'artificial intelligence') !== false)
        return 'AI&DS';
    if (strpos($code, 'cse') !== false || strpos($code, 'computer science') !== false)
        return 'CSE';
    if (strpos($code, 'ece') !== false || strpos($code, 'electronics') !== false)
        return 'ECE';
    if (strpos($code, 'mech') !== false || strpos($code, 'mechanical') !== false)
        return 'Mechanical';
    if (strpos($code, 'civil') !== false)
        return 'Civil';
    if ($code === 'it' || strpos($code, 'information technology') !== false)
        return 'IT';
    if (strpos($code, 'bio') !== false || strpos($code, 'biotech') !== false)
        return 'Biotechnology';
    if (strpos($code, 'chem') !== false || strpos($code, 'chemical') !== false)
        return 'Chemical';
    if (strpos($code, 'mba') !== false)
        return 'MBA';
    if (strpos($code, 's&h') !== false || $code === 'sh' || strpos($code, 'science and humanities') !== false || strpos($code, 'first year') !== false)
        return 'Science and Humanities';

    return null;
}

// 3. Determine User Department
$stmt = $mysqli->prepare("SELECT DEPARTMENT FROM employee_details WHERE ID_NO = ?");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows > 0) {
    $row = $res->fetch_assoc();
    $dept_raw_name = $row['DEPARTMENT'];
}
else {
    $stmt = $mysqli->prepare("SELECT Dept FROM students_login_master WHERE IDNo = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $dept_raw_name = $row['Dept'];
    }
}

// 4. Resolve the Department Key
if (!empty($dept_raw_name)) {
    $mapped = mapDeptToCategory($dept_raw_name);
    $dept_key = $mapped ?: trim($dept_raw_name);
}

// 5. Fetch Department Vision/Mission (Cached)
$dept_data = null;
if ($dept_key) {
    $cacheDeptFile = __DIR__ . '/cache/dept_vm_' . md5($dept_key) . '.json';
    if (file_exists($cacheDeptFile) && (time() - filemtime($cacheDeptFile) < 600)) {
        $dept_data = json_decode(file_get_contents($cacheDeptFile), true);
    }
    else {
        $stmt = $mysqli->prepare("SELECT vision, mission FROM ai_vision_mission WHERE category = ? LIMIT 1");
        $stmt->bind_param("s", $dept_key);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows > 0) {
            $dept_data = $res->fetch_assoc();
            file_put_contents($cacheDeptFile, json_encode($dept_data));
        }
    }
}

// 6. FETCH DAILY TIRUKKURAL
$daily_kural = null;
$today_date = date('Y-m-d');

$qk = $mysqli->prepare("SELECT t.kural_no, t.section, t.tamil, t.english FROM user_daily_kural u JOIN tirukkural t ON u.kural_no = t.kural_no WHERE u.user_id = ? AND u.shown_date = ?");
$qk->bind_param("ss", $user_id, $today_date);
$qk->execute();
$rk = $qk->get_result();

if ($rk->num_rows > 0) {
    $daily_kural = $rk->fetch_assoc();
}
else {
    $rand_k = $mysqli->query("SELECT * FROM tirukkural ORDER BY RAND() LIMIT 1");
    if ($rand_k && $row_k = $rand_k->fetch_assoc()) {
        $daily_kural = $row_k;
        $ins_k = $mysqli->prepare("INSERT INTO user_daily_kural (user_id, kural_no, shown_date) VALUES (?, ?, ?)");
        $ins_k->bind_param("sis", $user_id, $row_k['kural_no'], $today_date);
        $ins_k->execute();
    }
}

// Fee Structure Data
$feeStructure = [
    'UG 2025-26' => [
        'B.E Civil Engineering (30)' => ['swc' => 50000, 'mq' => 95000],
        'B.E Computer Science and Engineering (180)' => ['swc' => 50000, 'mq' => 95000],
        'B.E CSE (Artificial Intelligence and Machine Learning) (120)' => ['swc' => 50000, 'mq' => 95000],
        'B.E Electronics & Communication Engineering (120)' => ['swc' => 55000, 'mq' => 97000],
        'B.E Mechanical Engineering (60)' => ['swc' => 50000, 'mq' => 95000],
        'B.Tech Artificial Intelligence and Data Science (180)' => ['swc' => 50000, 'mq' => 95000],
        'B.Tech Biotechnology (60)' => ['swc' => 55000, 'mq' => 97000],
        'B.Tech Chemical Engineering (60)' => ['swc' => 55000, 'mq' => 97000],
        'B.Tech Information Technology (120)' => ['swc' => 55000, 'mq' => 97000],
    ],
    'PG 2025-26' => [
        'M.E Structural Engineering (18)' => ['swc' => 50000, 'mq' => 50000],
        'Master of Business Administration (60)' => ['swc' => 35000, 'mq' => 45000],
    ]
];

// TNEA Contacts
$tneaContacts = [
    'Helpline' => '044-2235 1414',
    'Toll Free' => '1800-425-3948',
    'Email' => 'tnea@annauniv.edu',
];

// Management Contacts
$managementContacts = [
    'Admissions' => '7358020151',
    'Helpline' => '7358701998',
    'Email' => 'admissions@velhightech.com',
];

// Autonomous Status
$isAutonomous = true; // Set based on actual college status
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>VEL AI - Intelligent Assistant</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#bc1888">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        :root {
            --instagram-gradient: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
            --glass-bg: rgba(255, 255, 255, 0.95);
            --glass-border: rgba(255, 255, 255, 0.3);
            --shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            --primary: #bc1888;
            --user-msg: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        body {
            background: var(--instagram-gradient);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 15px;
            position: relative;
            animation: gradientBG 15s ease infinite;
            background-size: 200% 200%;
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* SaaS UI Upgrade */
        body.dark-mode {
            background: #121212;
            color: #fff;
        }

        .ai-floating {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            background: var(--instagram-gradient);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            box-shadow: 0 10px 20px rgba(188, 24, 136, 0.4);
            cursor: pointer;
            z-index: 1000;
            transition: transform 0.3s;
        }
        .ai-floating:hover {
            transform: scale(1.1) rotate(10deg);
        }

        .ai-suggestions {
            margin-top: 10px;
            display: flex;
            flex-wrap: wrap;
            gap: 5px;
        }
        .ai-suggestions button {
            background: linear-gradient(45deg, #ff6a00, #ee0979);
            border: none;
            border-radius: 20px;
            padding: 6px 14px;
            color: white;
            cursor: pointer;
            font-size: 13px;
            transition: opacity 0.2s;
        }
        .ai-suggestions button:hover {
            opacity: 0.9;
        }

        .app-container {
            width: 100%;
            max-width: 1400px;
            height: 95vh;
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid var(--glass-border);
            border-radius: 32px;
            box-shadow: var(--shadow);
            display: flex;
            overflow: hidden;
            position: relative;
        }

        /* Sidebar */
        .sidebar {
            width: 300px;
            background: var(--glass-bg);
            backdrop-filter: blur(12px);
            border-right: 1px solid rgba(255,255,255,0.3);
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 25px;
            background: linear-gradient(135deg, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0.1) 100%);
            border-bottom: 1px solid rgba(255,255,255,0.3);
            position: relative;
        }

        .tnea-badge {
            position: absolute;
            top: 20px;
            right: 20px;
            background: var(--instagram-gradient);
            color: white;
            padding: 5px 12px;
            border-radius: 30px;
            font-size: 0.8rem;
            font-weight: 600;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .autonomous-badge {
            position: absolute;
            top: 20px;
            left: 20px;
            background: #10b981;
            color: white;
            padding: 5px 12px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .sidebar-header h2 {
            font-size: 1.8rem;
            font-weight: 700;
            background: var(--instagram-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-top: 25px;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            color: #666;
            font-size: 0.9rem;
        }

        .user-profile {
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            background: rgba(255,255,255,0.5);
            border-bottom: 1px solid rgba(255,255,255,0.3);
        }

        .avatar {
            width: 50px;
            height: 50px;
            background: var(--instagram-gradient);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 1.2rem;
            box-shadow: 0 4px 10px rgba(188, 24, 136, 0.3);
        }

        .user-info {
            flex: 1;
        }

        .user-info .name {
            font-weight: 600;
            color: #333;
            margin-bottom: 3px;
        }

        .user-info .role {
            font-size: 0.75rem;
            color: #666;
        }

        .suggestions-section {
            padding: 20px;
            flex: 1;
        }

        .section-title {
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #666;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .section-title i {
            color: #bc1888;
        }

        .suggestion-grid {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .suggestion-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: rgba(255,255,255,0.7);
            border-radius: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid transparent;
        }

        .suggestion-item:hover {
            background: white;
            border-color: #bc1888;
            transform: translateX(5px);
            box-shadow: 0 4px 15px rgba(188, 24, 136, 0.1);
        }

        .suggestion-icon {
            width: 40px;
            height: 40px;
            background: var(--instagram-gradient);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
        }

        .suggestion-text h4 {
            font-size: 1rem;
            color: #333;
            margin-bottom: 3px;
        }

        .suggestion-text p {
            font-size: 0.75rem;
            color: #666;
        }

        .logout-btn {
            margin: 20px;
            padding: 12px;
            background: rgba(255,255,255,0.7);
            border: none;
            border-radius: 30px;
            color: #dc2743;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .logout-btn:hover {
            background: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(220, 39, 67, 0.2);
        }

        /* Main Chat Area */
        .main-chat {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
        }

        .chat-header {
            padding: 20px 25px;
            background: linear-gradient(90deg, #ff6a00, #ee0979); /* Gradient Header */
            color: white;
            border-bottom: 1px solid rgba(255,255,255,0.3);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .menu-toggle {
            display: none;
            font-size: 1.3rem;
            color: #333;
            cursor: pointer;
        }

        .header-left h3 {
            color: white; /* Gradient Header Text */
            font-size: 1.2rem;
            font-weight: bold;
        }

        .status {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 0.8rem;
            color: #10b981;
        }

        .status-dot {
            width: 8px;
            height: 8px;
            background: #10b981;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.2); opacity: 0.7; }
        }

        /* Messages Area */
        .messages-area {
            flex: 1;
            overflow-y: auto;
            padding: 25px;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .message {
            max-width: 75%;
            padding: 15px 20px;
            border-radius: 20px;
            font-size: 0.95rem;
            line-height: 1.6;
            position: relative;
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .message.bot {
            align-self: flex-start;
            background: white;
            color: #333;
            border-bottom-left-radius: 4px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .message.user {
            align-self: flex-end;
            background: var(--user-msg);
            color: white;
            border-bottom-right-radius: 4px;
        }

        .message-time {
            font-size: 0.7rem;
            margin-top: 5px;
            opacity: 0.6;
        }

        /* Typing Indicator */
        .typing-indicator {
            align-self: flex-start;
            background: white;
            padding: 15px 20px;
            border-radius: 20px;
            border-bottom-left-radius: 4px;
            display: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .typing-dots {
            display: flex;
            gap: 4px;
        }

        .typing-dots span {
            width: 8px;
            height: 8px;
            background: #bc1888;
            border-radius: 50%;
            animation: bounce 1.4s infinite ease-in-out;
        }

        .typing-dots span:nth-child(1) { animation-delay: -0.32s; }
        .typing-dots span:nth-child(2) { animation-delay: -0.16s; }

        @keyframes bounce {
            0%, 80%, 100% { transform: scale(0); }
            40% { transform: scale(1); }
        }

        /* Input Area */
        .input-area {
            padding: 20px 25px;
            background: rgba(255,255,255,0.5);
            border-top: 1px solid rgba(255,255,255,0.3);
        }

        .input-wrapper {
            display: flex;
            gap: 10px;
            background: white;
            padding: 5px 5px 5px 20px;
            border-radius: 30px;
            border: 1px solid rgba(0,0,0,0.05);
            transition: all 0.3s ease;
        }

        .input-wrapper:focus-within {
            border-color: #bc1888;
            box-shadow: 0 0 0 3px rgba(188, 24, 136, 0.1);
        }

        .input-field {
            flex: 1;
            border: none;
            padding: 12px 0;
            font-size: 16px; /* Optimized for mobile */
            background: transparent;
            outline: none;
        }

        .send-btn {
            width: 45px;
            height: 45px;
            background: var(--instagram-gradient);
            border: none;
            border-radius: 50%;
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(188, 24, 136, 0.3);
        }

        .send-btn:hover {
            transform: scale(1.05) rotate(45deg);
        }

        /* Message Styling Enhancements */
        .message strong { font-weight: 700; color: inherit; }
        .message em { font-style: italic; }
        .message ul, .message ol { margin: 8px 0; padding-left: 20px; }
        .message li { margin-bottom: 4px; }
        .message code { background: rgba(0,0,0,0.1); padding: 2px 5px; border-radius: 4px; font-family: monospace; font-size: 0.9em; }
        
        /* Copy Button */
        .copy-btn {
            position: absolute;
            top: 5px;
            right: 5px;
            background: rgba(0,0,0,0.05);
            border: none;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            font-size: 12px;
            color: #666;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: all 0.2s ease;
        }
        .message:hover .copy-btn { opacity: 1; }
        .copy-btn:hover { background: rgba(0,0,0,0.1); color: #bc1888; }
        .copy-btn.copied { color: #10b981; }

        /* Clear Chat Button */
        .clear-chat-btn {
            background: none;
            border: none;
            color: #666;
            cursor: pointer;
            font-size: 0.9rem;
            padding: 8px;
            border-radius: 50%;
            transition: all 0.2s;
            margin-right: 10px;
        }
        .clear-chat-btn:hover { background: rgba(0,0,0,0.05); color: #dc2743; }

        /* Kural Widget */
        .kural-widget {
            background: white;
            border-radius: 16px;
            padding: 15px;
            margin-bottom: 20px;
            border-left: 4px solid #bc1888;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .kural-widget .kural-title {
            font-size: 0.8rem;
            color: #bc1888;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .kural-widget .kural-tamil {
            font-size: 1.1rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }

        .kural-widget .kural-english {
            font-size: 0.9rem;
            color: #666;
            font-style: italic;
        }

        /* Vision Mission Tables */
        .vm-section {
            margin-bottom: 30px;
        }

        .vm-title {
            font-size: 0.9rem;
            font-weight: 600;
            color: #bc1888;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .vm-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .vm-table th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .vm-table td {
            padding: 15px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 0.9rem;
            line-height: 1.5;
        }

        .vm-table tr:last-child td {
            border-bottom: none;
        }

        /* Fee Table */
        .fee-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            margin: 10px 0;
        }

        .fee-table th {
            background: #f8f9fa;
            padding: 10px;
            font-weight: 600;
            color: #666;
            font-size: 0.8rem;
            border-bottom: 2px solid #e9ecef;
        }

        .fee-table td {
            padding: 10px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 0.85rem;
        }

        .fee-table tr:hover {
            background: linear-gradient(90deg, rgba(188,24,136,0.05) 0%, rgba(220,39,67,0.05) 100%);
        }

        .fee-amount {
            font-weight: 600;
            color: #10b981;
        }

        /* Contact Cards */
        .contact-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin: 15px 0;
        }

        .contact-card {
            background: white;
            border-radius: 16px;
            padding: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            border: 1px solid #f0f0f0;
        }

        .contact-card h4 {
            color: #bc1888;
            margin-bottom: 12px;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .contact-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 0;
            border-bottom: 1px solid #f0f0f0;
            font-size: 0.9rem;
        }

        .contact-item:last-child {
            border-bottom: none;
        }

        .contact-item i {
            color: #bc1888;
            width: 20px;
        }

        .contact-item a {
            color: #333;
            text-decoration: none;
        }

        .contact-item a:hover {
            color: #bc1888;
        }

        /* Info Card */
        .info-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px;
            border-radius: 16px;
            margin: 10px 0;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .app-container {
                height: 100vh;
                border-radius: 0;
                padding: 0;
            }

            .sidebar {
                position: fixed;
                left: -100%;
                top: 0;
                bottom: 0;
                bottom: 0;
                width: 100%;
                z-index: 1000;
                transition: left 0.3s ease;
            }

            .sidebar.active {
                left: 0;
            }

            .menu-toggle {
                display: block;
            }

            .message {
                max-width: 85%;
            }

            .contact-grid {
                grid-template-columns: 1fr;
            }
        }

        /* Answer Cards */
        .answer-card {
            background: white;
            border-radius: 16px;
            padding: 20px;
            margin: 10px 0;
            border-left: 4px solid #bc1888;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .answer-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #bc1888;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .course-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .course-category {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 12px;
        }

        .course-category h5 {
            color: #667eea;
            margin-bottom: 10px;
            font-size: 0.95rem;
        }

        .course-category ul {
            list-style: none;
            padding: 0;
        }

        .course-category li {
            padding: 5px 0;
            font-size: 0.85rem;
            border-bottom: 1px dashed #e0e0e0;
        }

        .course-category li:last-child {
            border-bottom: none;
        }

        .stat-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin: 15px 0;
        }

        .stat-item {
            background: #f8f9fa;
            padding: 12px;
            border-radius: 12px;
            text-align: center;
        }

        .stat-label {
            font-size: 0.7rem;
            color: #666;
        }

        .stat-value {
            font-size: 1.2rem;
            font-weight: 700;
            color: #10b981;
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <?php if ($isAutonomous): ?>
                <div class="autonomous-badge">
                    <i class="fas fa-check-circle"></i> Autonomous
                </div>
                <?php
endif; ?>
                <div class="tnea-badge">TNEA: <?php echo $tneaCode; ?></div>
                <h2>VEL AI</h2>
                <p>Intelligent Assistant</p>
            </div>

            <div class="user-profile">
                <div class="avatar">
                    <?php echo strtoupper(substr($_SESSION['name'] ?? 'U', 0, 1)); ?>
                </div>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($_SESSION['name'] ?? 'Guest'); ?></div>
                    <div class="role"><?php echo htmlspecialchars($_SESSION['role'] ?? 'User'); ?></div>
                </div>
            </div>

            <div class="suggestions-section">
                <div class="section-title">
                    <i class="fas fa-lightbulb"></i> Suggested Topics
                </div>
                <div class="suggestion-grid">
                    <div class="suggestion-item" onclick="sendSuggestion('What courses are offered?')">
                        <div class="suggestion-icon">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <div class="suggestion-text">
                            <h4>Courses Offered</h4>
                            <p>UG, PG programs & specializations</p>
                        </div>
                    </div>

                    <div class="suggestion-item" onclick="sendSuggestion('Tell me about hostel facilities')">
                        <div class="suggestion-icon">
                            <i class="fas fa-building"></i>
                        </div>
                        <div class="suggestion-text">
                            <h4>Hostel Details</h4>
                            <p>Facilities, fees & accommodation</p>
                        </div>
                    </div>

                    <div class="suggestion-item" onclick="sendSuggestion('What is the admission process?')">
                        <div class="suggestion-icon">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <div class="suggestion-text">
                            <h4>Admission Process</h4>
                            <p>TNEA counselling & management quota</p>
                        </div>
                    </div>

                    <div class="suggestion-item" onclick="sendSuggestion('How are the placements?')">
                        <div class="suggestion-icon">
                            <i class="fas fa-briefcase"></i>
                        </div>
                        <div class="suggestion-text">
                            <h4>Placements</h4>
                            <p>Statistics, recruiters & training</p>
                        </div>
                    </div>
                    
                    <div class="suggestion-item" onclick="sendSuggestion('Is the college autonomous?')">
                        <div class="suggestion-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="suggestion-text">
                            <h4>Autonomous Status</h4>
                            <p>College autonomy & benefits</p>
                        </div>
                    </div>
                </div>
            </div>

            <a href="auth/logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> Log Out
            </a>
        </div>

        <!-- Main Chat Area -->
        <div class="main-chat" onclick="closeSidebarOnMobile()">
            <div class="chat-header">
                <div class="header-left">
                    <i class="fas fa-bars menu-toggle" onclick="toggleSidebar()"></i>
                    <h3>VEL AI Assistant</h3>
                </div>
                <div style="display: flex; align-items: center;">
                    <button class="clear-chat-btn" onclick="clearChat()" title="Clear Chat">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                    <div class="status" id="connectionStatus">
                        <span class="status-dot"></span>
                        <span id="statusText">Online</span>
                    </div>
                </div>
            </div>

            <div class="messages-area" id="messagesArea">
                <!-- Daily Kural -->
                <?php if ($daily_kural): ?>
                <div class="kural-widget">
                    <div class="kural-title">📜 Daily Wisdom • Kural #<?php echo $daily_kural['kural_no']; ?></div>
                    <div class="kural-tamil"><?php echo nl2br(htmlspecialchars($daily_kural['tamil'])); ?></div>
                    <div class="kural-english">"<?php echo htmlspecialchars($daily_kural['english']); ?>"</div>
                </div>
                <?php
endif; ?>

                <!-- Institution Vision & Mission -->
                <div class="vm-section">
                    <div class="vm-title">🏛️ Institution Vision & Mission</div>
                    <table class="vm-table">
                        <tr>
                            <th>VISION</th>
                            <th>MISSION</th>
                        </tr>
                        <tr>
                            <td><?php echo nl2br(htmlspecialchars($inst_data['vision'])); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($inst_data['mission'])); ?></td>
                        </tr>
                    </table>
                </div>

                <!-- Department Vision & Mission -->
                <?php if ($dept_data): ?>
                <div class="vm-section">
                    <div class="vm-title">📚 Department of <?php echo htmlspecialchars($dept_key); ?></div>
                    <table class="vm-table">
                        <tr>
                            <th>VISION</th>
                            <th>MISSION</th>
                        </tr>
                        <tr>
                            <td><?php echo nl2br(htmlspecialchars($dept_data['vision'])); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($dept_data['mission'])); ?></td>
                        </tr>
                    </table>
                </div>
                <?php
endif; ?>

                <!-- Welcome Message -->
                <div class="message bot">
                    <strong>Hello <?php echo htmlspecialchars($_SESSION['name']); ?>! 👋</strong><br><br>
                    
                    <?php if ($isAutonomous): ?>
                    <div class="info-card">
                        <i class="fas fa-check-circle"></i> <strong>Autonomous Institution</strong> - Affiliated to Anna University
                    </div>
                    <?php
endif; ?>
                    
                    I'm VEL AI, your intelligent assistant. I can help you with:
                    <ul style="margin-top: 8px; padding-left: 20px;">
                        <li>Course information & fee structure</li>
                        <li>Hostel facilities & accommodation</li>
                        <li>Admission process (TNEA Code: <?php echo $tneaCode; ?>)</li>
                        <li>Placement statistics & training</li>
                        <li>College autonomous status & benefits</li>
                    </ul>
                    <div class="message-time">Just now</div>
                </div>

            <!-- Typing Indicator -->
                <div class="typing-indicator" id="typingIndicator">
                    <div class="typing-dots">
                        <span></span><span></span><span></span>
                    </div>
                </div>
            </div>

            <div class="input-area">
                <div class="input-wrapper">
                    <input type="text" id="userInput" class="input-field" placeholder="Ask me anything..." autocomplete="off">
                    <button id="micBtn" class="mic-btn" onclick="toggleVoice()">
                        <i class="fas fa-microphone"></i>
                    </button>
                    <button class="send-btn" onclick="sendMessage()">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <style>
        .mic-btn {
            background: none;
            border: none;
            color: #bc1888;
            font-size: 1.2rem;
            cursor: pointer;
            padding: 0 10px;
            transition: all 0.3s ease;
            position: relative;
        }
        .mic-btn:hover {
            transform: scale(1.1);
        }
        .mic-active {
            color: #dc2743;
            animation: pulse-red 1.5s infinite;
        }
        @keyframes pulse-red {
            0% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.2); opacity: 0.7; }
            100% { transform: scale(1); opacity: 1; }
        }
    </style>

    <style>
        /* Mobile Optimization */
        @media (max-width: 768px) {
            body {
                animation: none;
                background: linear-gradient(135deg, #f09433 0%, #bc1888 100%);
                background-attachment: fixed;
            }
            .ai-suggestions {
                gap: 8px;
            }
            .app-container {
                height: 100vh; /* Ensure full viewport height */
            }
        }
    </style>
    <script>
        // DOM Elements
        const sidebar = document.getElementById('sidebar');
        const messagesArea = document.getElementById('messagesArea');
        const userInput = document.getElementById('userInput');
        const typingIndicator = document.getElementById('typingIndicator');
        const statusText = document.getElementById('statusText');
        const statusDot = document.querySelector('.status-dot');
        const micBtn = document.getElementById('micBtn');

        // Simple Markdown Parser
        function parseMarkdown(text) {
            // Bold (**text**)
            text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
            // Italic (*text*)
            text = text.replace(/\*(.*?)\*/g, '<em>$1</em>');
            // Inline Code (`text`)
            text = text.replace(/`(.*?)`/g, '<code>$1</code>');
            // Lists (- item)
            if (text.includes('- ')) {
                let lines = text.split('\n');
                let inList = false;
                let newText = '';
                
                lines.forEach(line => {
                    if (line.trim().startsWith('- ')) {
                        if (!inList) {
                            newText += '<ul>';
                            inList = true;
                        }
                        newText += '<li>' + line.trim().substring(2) + '</li>';
                    } else {
                        if (inList) {
                            newText += '</ul>';
                            inList = false;
                        }
                        newText += line + '<br>';
                    }
                });
                if (inList) newText += '</ul>';
                text = newText;
            } else {
                text = text.replace(/\n/g, '<br>');
            }
            return text;
        }

        // Copy to Clipboard
        function copyToClipboard(button, text) {
            navigator.clipboard.writeText(text).then(() => {
                const originalIcon = button.innerHTML;
                button.innerHTML = '<i class="fas fa-check"></i>';
                button.classList.add('copied');
                setTimeout(() => {
                    button.innerHTML = originalIcon;
                    button.classList.remove('copied');
                }, 2000);
            });
        }

        // Clear Chat
        function clearChat() {
            if(confirm('Are you sure you want to clear the chat history?')) {
                location.reload(); 
            }
        }

        // Voice Recognition Setup
        let recognition = null;
        if ('webkitSpeechRecognition' in window) {
            recognition = new webkitSpeechRecognition();
            recognition.continuous = false;
            recognition.interimResults = false;
            recognition.lang = 'en-US';

            recognition.onstart = function() {
                micBtn.classList.add('mic-active');
                userInput.placeholder = "Listening...";
            };

            recognition.onend = function() {
                micBtn.classList.remove('mic-active');
                userInput.placeholder = "Ask me anything...";
            };

            recognition.onresult = function(event) {
                const transcript = event.results[0][0].transcript;
                userInput.value = transcript;
                sendMessage();
            };

            recognition.onerror = function(event) {
                micBtn.classList.remove('mic-active');
                console.error('Speech recognition error', event.error);
                userInput.placeholder = "Error. Try again.";
            };
        } else {
            micBtn.style.display = 'none'; // Hide if not supported
        }

        function toggleVoice() {
            if (recognition) {
                if (micBtn.classList.contains('mic-active')) {
                    recognition.stop();
                } else {
                    recognition.start();
                }
            } else {
                alert("Voice input is not supported in this browser.");
            }
        }

        // Connection monitoring
        function updateConnectionStatus() {
            if (navigator.onLine) {
                statusText.textContent = 'Online';
                statusDot.style.background = '#10b981';
            } else {
                statusText.textContent = 'Offline';
                statusDot.style.background = '#ef4444';
                addMessage('📶 You are offline. Please check your internet connection.', 'bot');
            }
        }

        window.addEventListener('online', updateConnectionStatus);
        window.addEventListener('offline', updateConnectionStatus);
        updateConnectionStatus();

        // Toggle sidebar on mobile
        function toggleSidebar() {
            sidebar.classList.toggle('active');
        }

        function closeSidebarOnMobile() {
            if (window.innerWidth <= 768 && sidebar.classList.contains('active')) {
                sidebar.classList.remove('active');
            }
        }

        // Send suggestion
        function sendSuggestion(text) {
            userInput.value = text;
            sendMessage();
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('active');
            }
        }

        // Send message
        async function sendMessage() {
            const message = userInput.value.trim();
            if (!message) return;

            // Add user message
            addMessage(message, 'user');
            userInput.value = '';

            // Show typing indicator
            typingIndicator.style.display = 'block';
            scrollToBottom();

            // Check if online
            if (!navigator.onLine) {
                typingIndicator.style.display = 'none';
                addMessage('📶 You are offline. Please check your internet connection.', 'bot');
                return;
            }

            try {
                // Try to connect to AI engine with timeout
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 5000);

                const response = await fetch('ai/ai_engine.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        question: message,
                        user_context: '<?php echo $_SESSION['role'] ?? 'public'; ?>' 
                    }),
                    signal: controller.signal
                });

                clearTimeout(timeoutId);

                if (!response.ok) {
                    throw new Error('Server error');
                }

                // Debugging: Log raw response
                const text = await response.text();
                // console.log('Raw AI Response:', text); // Uncomment for debugging

                let data;
                try {
                    data = JSON.parse(text);
                } catch (e) {
                    console.error('JSON Parse Error:', e);
                    console.error('Raw Response was:', text);
                    // Explicitly handle the error by throwing it to the catch block
                    throw new Error('Invalid JSON response from server');
                }

                typingIndicator.style.display = 'none';

                if (data.status === 'success' && data.reply) {
                    // Format response based on query type
                    const formattedReply = formatResponse(message, data.reply);
                    addMessage(formattedReply, 'bot', data.reply);
                } else {
                    // Use fallback if AI engine returns no reply
                    fallbackResponse(message);
                }
            } catch (error) {
                typingIndicator.style.display = 'none';
                console.error('Error:', error);
                
                // Visible Error Banner
                const errorBanner = document.createElement('div');
                errorBanner.style.cssText = 'background: #fee2e2; color: #dc2626; padding: 10px; border-radius: 8px; margin: 10px 0; font-size: 0.9rem; text-align: center; border: 1px solid #fca5a5;';
                errorBanner.innerText = '⚠️ AI temporarily unavailable. Using offline mode.';
                messagesArea.insertBefore(errorBanner, typingIndicator);
                setTimeout(() => errorBanner.remove(), 5000);

                // Use fallback responses
                fallbackResponse(message);
            }
        }

        // New Helper for Suggestion Chips
        function askAI(question) {
            userInput.value = question;
            sendMessage();
        }

        // Fallback responses (when AI engine is unavailable)
        function fallbackResponse(message) {
            const q = message.toLowerCase();
            let reply = '';

            if (q.includes('autonomous')) {
                reply = `✅ **Yes, Vel Tech High Tech is an Autonomous Institution**

**Benefits of Autonomous Status:**
• Academic freedom to design our own curriculum
• Flexibility in teaching and learning processes
• Modern and industry-relevant syllabus
• Continuous internal assessment system
• Degrees awarded by Anna University

**Accreditation:**
• NAAC Accredited with 'A' Grade (CGPA 3.27)
• NBA Accredited programs: ECE, Biotechnology, Chemical Engineering, IT

This status helps us provide quality education with industry-relevant curriculum.`;
            }
            else if (q.includes('course') || q.includes('program')) {
                reply = `📚 **Courses Offered 2025-26**

**UG Programs (B.E/B.Tech):**
• Computer Science and Engineering (180 seats)
• CSE (Artificial Intelligence and Machine Learning) (120 seats)
• Artificial Intelligence and Data Science (180 seats)
• Information Technology (120 seats)
• Electronics and Communication Engineering (120 seats)
• Mechanical Engineering (60 seats)
• Civil Engineering (30 seats)
• Biotechnology (60 seats)
• Chemical Engineering (60 seats)

**PG Programs:**
• M.E Structural Engineering (18 seats)
• Master of Business Administration (60 seats)

All programs are approved by AICTE and affiliated to Anna University.`;
            }
            else if (q.includes('hostel')) {
                reply = `🏠 **Hostel Facilities**

**Boys Hostel - Titans:**
• Well-furnished rooms (Single/Double sharing)
• 24/7 Wi-Fi connectivity
• Hygienic mess with vegetarian & non-vegetarian options
• RO purified drinking water
• 24/7 security and warden supervision
• Recreation room with TV & indoor games

**Girls Hostel - Padmavathy:**
• Safe and secure environment with CCTV surveillance
• Well-furnished rooms
• 24/7 Wi-Fi and security
• Mess facility with quality food
• Wardens available round the clock
• Study rooms and recreational facilities

💰 **Hostel Fee:** ₹90,000 per annum (approx)
📍 Separate hostels for boys and girls within campus`;
            }
            else if (q.includes('admission')) {
                reply = `🎓 **Admission Process 2025-26**

**TNEA Code: 1122**

📞 **TNEA Counselling Contacts:**
• Helpline: 044-2235 1414
• Toll Free: 1800-425-3948
• Email: tnea@annauniv.edu

📋 **Management Quota Contacts:**
• Admissions Office: 7358020151
• Helpline: 7358701998
• Email: admissions@velhightech.com

**Required Documents:**
• SSLC Mark Sheet (10th)
• HSC Mark Sheet (12th)
• Transfer Certificate (TC)
• Community Certificate (if applicable)
• Passport size photographs (3 copies)
• Nativity Certificate (for other state candidates)

**Steps to Apply:**
1. Obtain application form from college office (Rs. 500/-)
2. Fill the form with required details
3. Submit with necessary documents
4. Attend counselling (for TNEA candidates)
5. Confirm admission by paying fees`;
            }
            else if (q.includes('placement')) {
                reply = `💼 **Placement Statistics 2024-25**

**Highlights:**
• Highest Package: ₹12 LPA
• Average Package: ₹3.5 - 5 LPA
• Placement Rate: 85%+
• Recruiting Companies: 100+

**Top Recruiters:**
TCS, Infosys, Wipro, Cognizant, HCL, Capgemini, L&T, Zoho, Accenture, Tech Mahindra, IBM, Amazon, Deloitte

**Training & Preparation:**
• Dedicated Training and Placement Cell
• Pre-placement training and aptitude coaching
• Mock interviews and soft skills training
• Internship opportunities from 2nd year onwards

For detailed placement reports, contact the Training and Placement Cell.`;
            }
            else if (q.includes('fee')) {
                reply = `💰 **Fee Structure 2025-26**

**UG Programs (B.E/B.Tech):**
• SWC Quota: ₹50,000 - ₹55,000 per year
• Management Quota: ₹80,000 - ₹97,000 per year
• Caution Deposit: ₹5,000 (one-time, refundable)

**PG Programs:**
• M.E Structural Engineering: ₹50,000 (SWC) / ₹50,000 (MQ)
• MBA: ₹35,000 (SWC) / ₹45,000 (MQ)

**Additional Fees:**
• Hostel Fee: ₹90,000 per year
• Transport Fee: As per route
• Exam Fees: As per university norms

Note: Fees are subject to change as per college policies. Please confirm at the time of admission.`;
            }
            else if (q.includes('tnea') || q.includes('counselling')) {
                reply = `📞 **TNEA Counselling**

**TNEA Code: 1122**

**Contact Information:**
• Helpline: 044-2235 1414
• Toll Free: 1800-425-3948
• Email: tnea@annauniv.edu
• Website: https://tnea.annauniv.edu

**Counselling Process:**
1. Online registration on TNEA website
2. Certificate verification at designated centers
3. Choice filling and locking
4. Seat allotment based on rank and choices
5. Payment of fees and confirmation

For management quota admissions, please contact the college directly.`;
            }
            else if (q.includes('management') || q.includes('quota')) {
                reply = `📋 **Management Quota Admissions**

**Contact Information:**
• Admissions Office: 7358020151
• Helpline: 7358701998
• Email: admissions@velhightech.com

**Office Hours:**
Monday to Saturday: 9:00 AM - 5:00 PM

**Location:**
Vel Tech High Tech Dr.Rangarajan Dr.Sakunthala Engineering College
Avadi, Chennai - 600062

For management quota admissions, please contact the office directly for:
• Seat availability
• Fee structure
• Application process
• Document requirements`;
            }
            else if (q.includes('bonafide') || q.includes('certificate')) {
                reply = `📜 **Bonafide Certificate Services**

**How to Apply:**
1. Login to your student portal
2. Go to **Department** > **Bonafide Certificate**
3. Select Certificate Type (General, Fee Structure, Internship, etc.)
4. Enter Purpose and Submit

**Certificate Types:**
• General Bonafide
• Fee Structure
• Internship Permission
• Project Work Permission

**Processing Time:**
• Normal: 3-5 working days
• Urgent: Contact HOD/Principal

**Note:** You can track your application status in the same portal.`;
            }
            else {
                reply = `I can help you with:

• Is the college autonomous? (Yes, we are autonomous!)
• Courses offered (UG/PG programs with seat matrix)
• Hostel facilities and fees
• Admission process (TNEA Code: 1122)
• Management quota contacts
• Placement statistics
• Fee structure

What would you like to know?`;
            }

            addMessage(reply, 'bot');
        }

        // Add message to chat
        function addMessage(content, type, rawText = null) {
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${type}`;
            
            const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            
            // Allow raw HTML for cards, otherwise parse Markdown
            let htmlContent = content;
            if (!content.includes('<div class="answer-card"') && !content.includes('<br>')) { // Added check for existing <br>
                htmlContent = parseMarkdown(content);
            }
            
            let buttons = '';
            if (type === 'bot') {
                 // Use rawText for copy if available, else try to strip HTML
                let textToCopy = rawText || content.replace(/<[^>]*>?/gm, '');
                // Escape single quotes for the onclick attribute
                textToCopy = textToCopy.replace(/'/g, "&apos;").replace(/"/g, '&quot;').replace(/\n/g, '\\n');
                buttons = `<button class="copy-btn" onclick="copyToClipboard(this, '${textToCopy}')" title="Copy"><i class="fas fa-copy"></i></button>`;
            }

            messageDiv.innerHTML = `
                ${htmlContent}
                ${buttons}
                
                ${type === 'bot' && !content.includes('I can help you with') ? `
                <div class="ai-rating" style="margin-top: 8px; font-size: 0.8rem; color: #888;">
                    Rate: 
                    <span style="cursor:pointer; color:#ccc;" onclick="rateAI(this, 1, '${content.substring(0,20).replace(/['\"`\n\r]/g, " ")}...')">★</span>
                    <span style="cursor:pointer; color:#ccc;" onclick="rateAI(this, 2, '${content.substring(0,20).replace(/['\"`\n\r]/g, " ")}...')">★</span>
                    <span style="cursor:pointer; color:#ccc;" onclick="rateAI(this, 3, '${content.substring(0,20).replace(/['\"`\n\r]/g, " ")}...')">★</span>
                    <span style="cursor:pointer; color:#ccc;" onclick="rateAI(this, 4, '${content.substring(0,20).replace(/['\"`\n\r]/g, " ")}...')">★</span>
                    <span style="cursor:pointer; color:#ccc;" onclick="rateAI(this, 5, '${content.substring(0,20).replace(/['\"`\n\r]/g, " ")}...')">★</span>
                </div>` : ''}
                
                <div class="message-time">${time}</div>
            `;
            
            // Append Suggestion Chips for Bot Messages
            if (type === 'bot' && !content.includes('I can help you with')) {
                 const suggestionsDiv = document.createElement('div');
                 suggestionsDiv.className = 'ai-suggestions';
                 suggestionsDiv.innerHTML = `
                    <button onclick="askAI('Show CSE Faculty')">CSE Faculty</button>
                    <button onclick="askAI('Who is Principal')">Principal</button>
                    <button onclick="askAI('Bonafide Status')">Bonafide Status</button>
                    <button onclick="askAI('Upcoming Events')">Events</button>
                 `;
                 messageDiv.appendChild(suggestionsDiv);
            }
            
            
            
            // Note: messagesArea.insertBefore logic was moved inside loop processing in prior versions, ensuring only one instance logic here.
            messagesArea.insertBefore(messageDiv, typingIndicator);
            scrollToBottom();
            
            // Speak response if bot
            if (type === 'bot' && !content.includes('<div class="answer-card"')) {
                speak(content.replace(/<[^>]*>?/gm, ''));
            }
        }
        
        // Rate AI Response
        function rateAI(btn, rating, question) {
            // Visual feedback
            const parent = btn.parentElement;
            const stars = parent.querySelectorAll('span');
            stars.forEach((s, index) => {
                s.style.color = index < rating ? '#ffc107' : '#ccc';
            });
            
            // Send to backend
            fetch('ai/ai_engine.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    action: 'rate_answer',
                    question: question,
                    rating: rating 
                })
            }).then(res => res.json())
              .then(data => {
                  const thank = document.createElement('span');
                  thank.className = 'ms-2 text-success small';
                  thank.innerText = ' Thanks!';
                  parent.appendChild(thank);
                  setTimeout(() => thank.remove(), 2000);
              });
        }
        
        // Text to Speech
        function speak(text) {
            if ('speechSynthesis' in window) {
                const utterance = new SpeechSynthesisUtterance(text);
                utterance.lang = 'en-IN';
                window.speechSynthesis.speak(utterance);
            }
        }

        // Format response based on query (for AI engine responses)
        function formatResponse(query, reply) {
            const q = query.toLowerCase();
            
            if (q.includes('course') || q.includes('program')) {
                return formatCoursesResponse();
            }
            if (q.includes('hostel')) {
                return formatHostelResponse();
            }
            if (q.includes('admission')) {
                return formatAdmissionResponse();
            }
            if (q.includes('placement')) {
                return formatPlacementResponse();
            }
            if (q.includes('fee')) {
                return formatFeeResponse();
            }
            if (q.includes('tnea') || q.includes('counselling')) {
                return formatTNEAResponse();
            }
            if (q.includes('management') || q.includes('quota')) {
                return formatManagementResponse();
            }
            if (q.includes('autonomous')) {
                return formatAutonomousResponse();
            }
            
            return reply;
        }

        // Format Courses Response
        function formatCoursesResponse() {
            return `
                <div class="answer-card">
                    <div class="answer-title">
                        <i class="fas fa-graduation-cap"></i> Courses Offered 2025-26
                    </div>
                    <div class="course-grid">
                        <div class="course-category">
                            <h5>UG Programs (B.E/B.Tech)</h5>
                            <ul>
                                <li>Computer Science and Engineering (180)</li>
                                <li>CSE (AI & ML) (120)</li>
                                <li>Artificial Intelligence & Data Science (180)</li>
                                <li>Information Technology (120)</li>
                                <li>Electronics & Communication (120)</li>
                                <li>Mechanical Engineering (60)</li>
                                <li>Civil Engineering (30)</li>
                                <li>Biotechnology (60)</li>
                                <li>Chemical Engineering (60)</li>
                            </ul>
                        </div>
                        <div class="course-category">
                            <h5>PG Programs</h5>
                            <ul>
                                <li>M.E Structural Engineering (18)</li>
                                <li>MBA (60)</li>
                            </ul>
                        </div>
                    </div>
                    <p style="margin-top: 10px; font-size: 0.8rem; color: #666;">* Seats shown in brackets</p>
                </div>
            `;
        }

        // Format Hostel Response
        function formatHostelResponse() {
            return `
                <div class="answer-card">
                    <div class="answer-title">
                        <i class="fas fa-building"></i> Hostel Facilities
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 12px;">
                            <h5 style="color: #667eea; margin-bottom: 10px;">Boys Hostel - Titans</h5>
                            <ul style="padding-left: 20px;">
                                <li>Well-furnished rooms</li>
                                <li>24/7 Wi-Fi</li>
                                <li>Hygienic mess</li>
                                <li>RO water</li>
                                <li>24/7 security</li>
                                <li>Recreation room</li>
                            </ul>
                        </div>
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 12px;">
                            <h5 style="color: #764ba2;">Girls Hostel - Padmavathy</h5>
                            <ul style="padding-left: 20px;">
                                <li>Safe & secure</li>
                                <li>24/7 security</li>
                                <li>CCTV surveillance</li>
                                <li>Quality mess</li>
                                <li>Study rooms</li>
                                <li>Warden available</li>
                            </ul>
                        </div>
                    </div>
                    <p style="margin-top: 15px;"><strong>💰 Fee:</strong> ₹90,000 per annum (approx)</p>
                </div>
            `;
        }

        // Format Admission Response
        function formatAdmissionResponse() {
            return `
                <div class="answer-card">
                    <div class="answer-title">
                        <i class="fas fa-file-alt"></i> Admission Process 2025-26
                    </div>
                    <p><strong>TNEA Code: 1122</strong></p>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 15px 0;">
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 12px;">
                            <h5 style="color: #667eea;">📞 TNEA Counselling</h5>
                            <div>📱 044-2235 1414</div>
                            <div>📱 1800-425-3948</div>
                            <div>✉️ tnea@annauniv.edu</div>
                        </div>
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 12px;">
                            <h5 style="color: #764ba2;">📋 Management Quota</h5>
                            <div>📱 7358020151</div>
                            <div>📱 7358701998</div>
                            <div>✉️ admissions@velhightech.com</div>
                        </div>
                    </div>
                    
                    <details style="margin-top: 10px;">
                        <summary style="color: #bc1888; cursor: pointer;">📋 Required Documents</summary>
                        <ul style="margin-top: 10px; padding-left: 20px;">
                            <li>SSLC & HSC Mark Sheets</li>
                            <li>Transfer Certificate</li>
                            <li>Community Certificate</li>
                            <li>Passport size photos (3)</li>
                            <li>Nativity Certificate (if applicable)</li>
                        </ul>
                    </details>
                </div>
            `;
        }

        // Format Placement Response
        function formatPlacementResponse() {
            return `
                <div class="answer-card">
                    <div class="answer-title">
                        <i class="fas fa-briefcase"></i> Placement Statistics
                    </div>
                    
                    <div class="stat-grid">
                        <div class="stat-item">
                            <div class="stat-label">Highest Package</div>
                            <div class="stat-value">12 LPA</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-label">Average Package</div>
                            <div class="stat-value">3.5-5 LPA</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-label">Placement Rate</div>
                            <div class="stat-value">85%+</div>
                        </div>
                    </div>
                    
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 12px;">
                        <h5 style="color: #667eea; margin-bottom: 10px;">Top Recruiters</h5>
                        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                            <span style="background: white; padding: 5px 12px; border-radius: 20px;">TCS</span>
                            <span style="background: white; padding: 5px 12px; border-radius: 20px;">Infosys</span>
                            <span style="background: white; padding: 5px 12px; border-radius: 20px;">Wipro</span>
                            <span style="background: white; padding: 5px 12px; border-radius: 20px;">Cognizant</span>
                            <span style="background: white; padding: 5px 12px; border-radius: 20px;">Zoho</span>
                            <span style="background: white; padding: 5px 12px; border-radius: 20px;">HCL</span>
                        </div>
                    </div>
                </div>
            `;
        }

        // Format Fee Response
        function formatFeeResponse() {
            return `
                <div class="answer-card">
                    <div class="answer-title">
                        <i class="fas fa-rupee-sign"></i> Fee Structure 2025-26
                    </div>
                    
                    <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px;">
                        <tr style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                            <th style="padding: 10px; text-align: left;">Program</th>
                            <th style="padding: 10px; text-align: right;">SWC (₹)</th>
                            <th style="padding: 10px; text-align: right;">MQ (₹)</th>
                        </tr>
                        <?php
$count = 0;
foreach ($feeStructure['UG 2025-26'] as $program => $fees):
    if ($count++ >= 5)
        break;
?>
                        <tr style="border-bottom: 1px solid #f0f0f0;">
                            <td style="padding: 8px;"><?php echo htmlspecialchars(substr($program, 0, 30)) . '...'; ?></td>
                            <td style="padding: 8px; text-align: right; font-weight: 600; color: #10b981;"><?php echo number_format($fees['swc']); ?></td>
                            <td style="padding: 8px; text-align: right; font-weight: 600; color: #10b981;"><?php echo number_format($fees['mq']); ?></td>
                        </tr>
                        <?php
endforeach; ?>
                    </table>
                    
                    <p style="font-size: 0.85rem;"><i>💰 Caution Deposit: ₹5,000 (refundable) for all programs</i></p>
                    <p style="font-size: 0.85rem;"><i>🏠 Hostel Fee: ₹90,000 per annum (approx)</i></p>
                </div>
            `;
        }

        // Format TNEA Response
        function formatTNEAResponse() {
            return `
                <div class="answer-card">
                    <div class="answer-title">
                        <i class="fas fa-phone-alt"></i> TNEA Counselling
                    </div>
                    <p><strong>TNEA Code: 1122</strong></p>
                    
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 12px;">
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <i class="fas fa-phone" style="color: #667eea;"></i>
                            <span><strong>Helpline:</strong> 044-2235 1414</span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <i class="fas fa-phone" style="color: #667eea;"></i>
                            <span><strong>Toll Free:</strong> 1800-425-3948</span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-envelope" style="color: #667eea;"></i>
                            <span><strong>Email:</strong> tnea@annauniv.edu</span>
                        </div>
                    </div>
                    
                    <p style="margin-top: 10px;">🌐 <a href="https://tnea.annauniv.edu" target="_blank" style="color: #bc1888;">tnea.annauniv.edu</a></p>
                </div>
            `;
        }

        // Format Management Response
        function formatManagementResponse() {
            return `
                <div class="answer-card">
                    <div class="answer-title">
                        <i class="fas fa-clipboard-list"></i> Management Quota
                    </div>
                    
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 12px;">
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <i class="fas fa-building" style="color: #764ba2;"></i>
                            <span><strong>Admissions:</strong> 7358020151</span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <i class="fas fa-phone" style="color: #764ba2;"></i>
                            <span><strong>Helpline:</strong> 7358701998</span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-envelope" style="color: #764ba2;"></i>
                            <span><strong>Email:</strong> admissions@velhightech.com</span>
                        </div>
                    </div>
                    
                    <p style="margin-top: 10px;"><strong>Office Hours:</strong> Mon-Sat: 9:00 AM - 5:00 PM</p>
                </div>
            `;
        }

        // Format Autonomous Response
        function formatAutonomousResponse() {
            return `
                <div class="answer-card">
                    <div class="answer-title">
                        <i class="fas fa-check-circle"></i> Autonomous Status
                    </div>
                    
                    <p>✅ <strong>Yes, Vel Tech High Tech is an Autonomous Institution</strong></p>
                    
                    <h5 style="color: #667eea; margin: 15px 0 10px;">Benefits:</h5>
                    <ul style="padding-left: 20px;">
                        <li>Academic freedom to design our own curriculum</li>
                        <li>Flexibility in teaching and learning processes</li>
                        <li>Modern and industry-relevant syllabus</li>
                        <li>Continuous internal assessment system</li>
                        <li>Degrees awarded by Anna University</li>
                    </ul>
                    
                    <h5 style="color: #764ba2; margin: 15px 0 10px;">Accreditation:</h5>
                    <ul style="padding-left: 20px;">
                        <li>NAAC Accredited with 'A' Grade (CGPA 3.27)</li>
                        <li>NBA Accredited programs: ECE, Biotechnology, Chemical Engineering, IT</li>
                    </ul>
                </div>
            `;
        }

        // Scroll to bottom
        function scrollToBottom() {
            messagesArea.scrollTop = messagesArea.scrollHeight;
        }

        // Enter key to send
        userInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                sendMessage();
            }
        });

        // Focus input
        userInput.focus();
    </script>
    <!-- Floating AI Widget (Removed to use existing integration) -->
</body>
</html>
