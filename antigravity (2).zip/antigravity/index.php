<?php
// Entry point redirect
header('Location: /login.php');
exit;
?>
