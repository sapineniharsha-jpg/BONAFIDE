<?php
$file = 'e:/antigravity/ai/ai_engine.php';
$content = file_get_contents($file);

// Normalize line endings
$content = str_replace("\r\n", "\n", $content);

// 1. Add Include
$searchInc = "require_once \$dbPath;\n\n\$dbConn = null;";
$replaceInc = "require_once \$dbPath;\nrequire_once __DIR__ . '/ai_helpers.php';\n\n\$dbConn = null;";

if (strpos($content, 'ai_helpers.php') === false) {
    $content = str_replace($searchInc, $replaceInc, $content);
    // Fallback if strict replace failed
    if (strpos($content, 'ai_helpers.php') === false) {
        $content = preg_replace('/require_once \$dbPath;\s+\$dbConn = null;/', "require_once \$dbPath;\nrequire_once __DIR__ . '/ai_helpers.php';\n\n\$dbConn = null;", $content);
    }
}

// 2. Main Logic Replacement
$chunkSearch = <<<'EOD'
// Greeting quick response
if (preg_match('/^(hi|hello|hey|vanakkam|good morning|good afternoon|good evening)\b/i', $normalizedQuestion)) {
    $name = (string) ($_SESSION['name'] ?? $_SESSION['NAME'] ?? 'there');
    $answer = "Hello {$name}. I am VEL AI. You can ask about academics, attendance, circulars, hostel, scholarships, admissions and institutional services.";
    ai_reply_with_audit($db, $userId, $userType, $question, $answer, 'structured', 'greeting', 0.99, true, $start);
}

// Local answer pipeline
$local = null;
if ($userType === 'public') {
    // Public users get only curated QA by sector_access policy.
    $local = ai_db_exact_or_keyword($db, $normalizedQuestion, $userType);
} else {
    $local = ai_structured_response($db, $normalizedQuestion);
    if (!$local) {
        $local = ai_db_exact_or_keyword($db, $normalizedQuestion, $userType);
    }
    if (!$local) {
        $local = ai_knowledge_base_match($db, $normalizedQuestion, $userType);
    }
}
EOD;

$chunkReplace = <<<'EOD'
// 2. Main Logic Update: General Language AI (Greetings, Small Talk)
if (class_exists('GeneralLanguageAI')) {
    $genAI = new GeneralLanguageAI(['user_type' => $userType]);
    $genResult = $genAI->handle($normalizedQuestion);
    if (!empty($genResult['confidence']) && $genResult['confidence'] > 50) {
        ai_reply_with_audit(
            $db,
            $userId,
            $userType,
            $question,
            (string) ($genResult['reply'] ?? ''),
            (string) ($genResult['source'] ?? 'General AI'),
            'conversation',
            (float) ($genResult['confidence'] / 100),
            true,
            $start
        );
    }
}

// Local answer pipeline (Unified for all users)
$local = ai_structured_response($db, $normalizedQuestion);

if (!$local) {
    // Knowledge Base Check (handles sector/public access internally)
    $local = ai_knowledge_base_match($db, $normalizedQuestion, $userType);
}
if (!$local) {
    // Database QA Check (handles sector/public access internally)
    $local = ai_db_exact_or_keyword($db, $normalizedQuestion, $userType);
}
EOD;

$chunkSearch = str_replace("\r\n", "\n", $chunkSearch);
$chunkReplace = str_replace("\r\n", "\n", $chunkReplace);

$content = str_replace($chunkSearch, $chunkReplace, $content);

file_put_contents($file, $content);
echo "Patched successfully " . strlen($content) . " bytes.";
?>
