<?php
ini_set('display_errors', 0); 
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', '../logs/dept_errors.log');
ob_start();
session_start();
require_once '../includes/db.php';

$ref = isset($_GET['ref']) ? $_GET['ref'] : '';

if (!empty($ref)) {
    $cert_result = $mysqli->query("SELECT * FROM bonafide_certificates WHERE ref_number = '$ref'");
    if ($cert_result && $cert_result->num_rows > 0) {
        $certificate = $cert_result->fetch_assoc();
    }
}

// Set headers for printing
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Certificate - <?php echo $certificate['ref_number'] ?? 'Certificate'; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @media print {
            @page { margin: 0; size: A4 portrait; }
            body { margin: 0; padding: 0; }
            .no-print { display: none !important; }
        }
        
        body { 
            font-family: 'Times New Roman', serif; 
            margin: 0; 
            padding: 15mm 20mm; 
            background: white; 
            color: #000; 
        }
        
        .print-actions { 
            position: fixed; 
            top: 20px; 
            right: 20px; 
            z-index: 1000; 
            background: white; 
            padding: 10px; 
            border-radius: 10px; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.2); 
        }
        
        .btn-print { 
            background: linear-gradient(45deg, #f09433 0%, #dc2743 100%); 
            color: white; 
            border: none; 
            padding: 10px 20px; 
            border-radius: 25px; 
            font-weight: 600; 
            cursor: pointer; 
            display: flex; 
            align-items: center; 
            gap: 8px; 
        }
        
        /* ENHANCED HEADER STYLING FOR PRINT */
        .enhanced-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: flex-start; 
            padding: 10px 0; 
            border-bottom: 2px solid #1a237e; 
            margin-bottom: 15px;
            page-break-inside: avoid;
        }
        
        .enhanced-logo { flex: 0 0 70px; padding: 5px; }
        .enhanced-logo-img { height: 70px; width: auto; object-fit: contain; }
        
        .enhanced-college { flex: 1; text-align: center; padding: 0 15px; }
        .enhanced-college-name { 
            font-size: 24px; 
            font-weight: 900; 
            color: #1a237e; 
            margin-bottom: 3px; 
            text-transform: uppercase; 
            line-height: 1.1; 
        }
        
        .enhanced-college-sub { 
            font-size: 14px; 
            font-weight: 700; 
            color: #0d47a1; 
            margin-bottom: 3px; 
            line-height: 1.1; 
        }
        
        .enhanced-college-details { 
            font-size: 10px; 
            color: #37474f; 
            line-height: 1.3; 
        }
        
        .enhanced-accreditation { 
            font-size: 9px; 
            font-weight: 600; 
            color: #00695c; 
            margin-top: 2px; 
            line-height: 1.2; 
        }
        
        .enhanced-contact { 
            flex: 0 0 160px; 
            text-align: right; 
            font-size: 9px; 
            line-height: 1.3; 
            padding: 5px; 
        }
        
        .paper-ref { 
            display: flex; 
            justify-content: space-between; 
            margin: 10px 0; 
            font-size: 10px; 
            padding-bottom: 8px; 
            border-bottom: 1px dashed #ccc; 
        }
        
        .paper-title { 
            text-align: center; 
            font-size: 14pt; 
            font-weight: bold; 
            text-decoration: underline; 
            margin: 15px 0 10px; 
            text-transform: uppercase; 
        }
        
        .paper-content { 
            font-size: 12pt; 
            line-height: 1.6; 
            text-align: justify; 
            min-height: 250px;
        }
        
        .paper-footer { 
            margin-top: 40px; 
            display: flex; 
            justify-content: space-between; 
            align-items: flex-end; 
            position: relative;
        }
        
        .paper-qr { 
            width: 70px; 
            height: 70px; 
            background: white; 
            border: 1px solid #ddd;
            padding: 3px;
        }
        
        .paper-qr img { width: 100%; height: auto; }
        
        .paper-sign { 
            text-align: right; 
            font-weight: bold; 
            font-size: 13pt; 
        }
        
        .watermark { 
            position: absolute; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            width: 350px; 
            opacity: 0.05; 
            z-index: 0; 
        }
        
        .fee-table { 
            border-collapse: collapse; 
            width: 100%; 
            margin: 10px 0; 
            font-size: 10pt; 
        }
        
        .fee-table th { 
            background: #f1f5f9; 
            padding: 6px; 
            text-align: left; 
            border: 1px solid #000; 
            font-weight: bold; 
        }
        
        .fee-table td { 
            padding: 6px; 
            border: 1px solid #000; 
        }
        
        .fee-table .amount { 
            text-align: right; 
            font-family: 'Courier New', monospace; 
            font-weight: bold; 
        }
        
        .fee-table .total-row { 
            background: #e7f5ff; 
            font-weight: bold; 
        }
        
        /* FORCE PAGE BREAKS */
        .page-break { page-break-before: always; }
        
        /* OPTIMIZE FOR PRINT */
        h1, h2, h3, h4, h5, h6 { page-break-after: avoid; }
        table, figure { page-break-inside: avoid; }
        p { widows: 3; orphans: 3; }
    </style>
    <script>
        window.onload = function() {
            // Auto-print after 1 second
            setTimeout(function() {
                window.print();
                // Close window after print (optional)
                // setTimeout(function() { window.close(); }, 1000);
            }, 1000);
        };
    </script>
</head>
<body>
    <?php if(isset($certificate)): ?>
    
    <div class="print-actions no-print">
        <button onclick="window.print()" class="btn-print">
            <i class="fas fa-print"></i> Print Now
        </button>
    </div>
    
    <img src="https://www.velhightech.com/LP/logo.png" class="watermark">
    
    <!-- ENHANCED HEADER -->
    <div class="enhanced-header">
        <div class="enhanced-logo">
            <img src="https://www.velhightech.com/LP/logo.png" alt="Vel Tech Logo" class="enhanced-logo-img">
        </div>
        
        <div class="enhanced-college">
            <div class="enhanced-college-name">Vel Tech High Tech</div>
            <div class="enhanced-college-sub">Dr. Rangarajan Dr. Sakunthala Engineering College</div>
            
            <div class="enhanced-college-details">
                <span>An Autonomous Institution</span><br>
                <span>(Approved by AICTE, New Delhi, Affiliated to Anna University, Chennai)</span>
            </div>
            
            <div class="enhanced-accreditation">
                <span>Accredited by NAAC with 'A' Grade</span>
            </div>
        </div>
        
        <div class="enhanced-contact">
            <div><strong>Tel:</strong> 044-26840181</div>
            <div><strong>Mobile:</strong> 9789037651</div>
            <div><strong>Email:</strong> principal@velhightech.com</div>
        </div>
    </div>

    <!-- REFERENCE AND DATE -->
    <div class="paper-ref">
        <span style="color: #b71c1c; font-weight: 700;"><?php echo $certificate['ref_number']; ?></span>
        <span>Date: <?php echo date('d M Y', strtotime($certificate['bonafide_date'])); ?></span>
    </div>
    
    <div class="paper-title">
        <?php
        switch($certificate['certificate_type']) {
            case 'Fee Structure': echo 'BONAFIDE CERTIFICATE (FEE STRUCTURE)'; break;
            case 'Fee Paid': echo 'BONAFIDE CERTIFICATE FOR FEE PAID'; break;
            case 'Alumni': echo 'ALUMNI CERTIFICATE'; break;
            case 'Internship': echo 'INTERNSHIP CERTIFICATE'; break;
            case 'Project': echo 'PROJECT CERTIFICATE'; break;
            case 'Bank Loan': echo 'BONAFIDE CERTIFICATE FOR BANK LOAN'; break;
            case 'Passport': echo 'BONAFIDE CERTIFICATE FOR PASSPORT'; break;
            case 'Scholarship': echo 'SCHOLARSHIP CERTIFICATE'; break;
            default: echo 'BONAFIDE CERTIFICATE';
        }
        ?>
    </div>
    
    <div class="paper-content">
        <?php if($certificate['certificate_type'] == 'Alumni'): ?>
            <p>This is to certify that <strong><?php echo $certificate['student_prefix'] . ' ' . strtoupper($certificate['student_name']); ?></strong> 
            (Register No: <strong><?php echo $certificate['register_number']; ?></strong>), 
            <?php echo ($certificate['student_prefix'] == 'Mr.' ? 'son' : 'daughter'); ?> of 
            <strong><?php echo $certificate['parent_prefix'] . ' ' . strtoupper($certificate['father_name']); ?></strong>, 
            was a bonafide student of <strong>Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College (Autonomous)</strong> 
            and successfully completed the <strong><?php echo $certificate['department']; ?></strong> degree program during the academic years 
            <strong><?php echo $certificate['batch_completed'] ?? '2021-2025'; ?></strong>.</p>
            
            <?php if($certificate['cgpa'] > 0): ?>
            <p>The student has secured a CGPA of <strong><?php echo number_format($certificate['cgpa'], 2); ?></strong> on a 10-point scale.</p>
            <?php endif; ?>
            
            <?php if($certificate['include_moi'] == 'Yes'): ?>
            <p>The Medium of Instruction and Evaluation for the above-mentioned programme followed by the Institute is English.</p>
            <?php endif; ?>
            
            <?php if($certificate['include_conversion'] == 'Yes' && $certificate['cgpa'] > 0): ?>
            <p><strong>CGPA to Percentage Conversion:</strong><br>
            CGPA: <?php echo number_format($certificate['cgpa'], 2); ?> × Conversion Grade (10) = 
            <strong><?php echo number_format($certificate['cgpa'] * 10, 2); ?>%</strong></p>
            <?php endif; ?>
            
            <?php if($certificate['original_certificate_status'] == 'Yes'): ?>
            <p>Degree Certificate will be issued in due course of time as per University norms.</p>
            <?php endif; ?>
            
            <p>This certificate is issued upon request for the purpose of <strong><?php echo $certificate['purpose']; ?></strong>.</p>
            
        <?php elseif($certificate['certificate_type'] == 'Fee Structure' || $certificate['certificate_type'] == 'Fee Paid'): ?>
            <p>This is to certify that <strong><?php echo $certificate['student_prefix'] . ' ' . strtoupper($certificate['student_name']); ?></strong> 
            (Register No: <strong><?php echo $certificate['register_number']; ?></strong>), 
            <?php echo ($certificate['student_prefix'] == 'Mr.' ? 'son' : 'daughter'); ?> of 
            <strong><?php echo $certificate['parent_prefix'] . ' ' . strtoupper($certificate['father_name']); ?></strong>, 
            pursuing <strong><?php echo $certificate['year_pursuing']; ?></strong> Year <?php echo $certificate['degree_name']; ?> in 
            <strong><?php echo $certificate['department']; ?></strong> is a bonafide student of this college in the academic year 
            <strong><?php echo $certificate['academic_year']; ?></strong>.</p>
            
            <p>The fee structure for the academic year is detailed below:</p>
            
            <table class="fee-table">
                <thead>
                    <tr>
                        <th class="text-left">Particulars</th>
                        <th class="amount">Annual Amount (₹)</th>
                        <?php if($certificate['certificate_type'] == 'Fee Paid'): ?>
                        <th class="amount">Paid Amount (₹)</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="text-left">Tuition Fee</td>
                        <td class="amount"><?php echo number_format($certificate['tuition_fee'], 2); ?></td>
                        <?php if($certificate['certificate_type'] == 'Fee Paid'): ?>
                        <td class="amount"><?php echo number_format($certificate['paid_tuition_fee'], 2); ?></td>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <td class="text-left">Other Fees</td>
                        <td class="amount"><?php echo number_format($certificate['other_fee'], 2); ?></td>
                        <?php if($certificate['certificate_type'] == 'Fee Paid'): ?>
                        <td class="amount"><?php echo number_format($certificate['paid_other_fee'], 2); ?></td>
                        <?php endif; ?>
                    </tr>
                    <?php if($certificate['hostel_fee'] > 0): ?>
                    <tr>
                        <td class="text-left"><?php echo $certificate['facility_option']; ?> Fee</td>
                        <td class="amount"><?php echo number_format($certificate['hostel_fee'], 2); ?></td>
                        <?php if($certificate['certificate_type'] == 'Fee Paid'): ?>
                        <td class="amount"><?php echo number_format($certificate['paid_hostel_fee'], 2); ?></td>
                        <?php endif; ?>
                    </tr>
                    <?php endif; ?>
                    <tr class="total-row">
                        <td class="text-left"><strong>TOTAL</strong></td>
                        <td class="amount"><strong><?php echo number_format($certificate['tuition_fee'] + $certificate['other_fee'] + $certificate['hostel_fee'], 2); ?></strong></td>
                        <?php if($certificate['certificate_type'] == 'Fee Paid'): ?>
                        <td class="amount"><strong><?php echo number_format($certificate['paid_tuition_fee'] + $certificate['paid_other_fee'] + $certificate['paid_hostel_fee'], 2); ?></strong></td>
                        <?php endif; ?>
                    </tr>
                </tbody>
            </table>
            
        <?php elseif($certificate['certificate_type'] == 'Internship'): ?>
            <p>This is to certify that <strong><?php echo $certificate['student_prefix'] . ' ' . strtoupper($certificate['student_name']); ?></strong> 
            (Register No: <strong><?php echo $certificate['register_number']; ?></strong>), 
            <?php echo ($certificate['student_prefix'] == 'Mr.' ? 'son' : 'daughter'); ?> of 
            <strong><?php echo $certificate['parent_prefix'] . ' ' . strtoupper($certificate['father_name']); ?></strong>, 
            pursuing <strong><?php echo $certificate['year_pursuing']; ?></strong> Year <?php echo $certificate['degree_name']; ?> in 
            <strong><?php echo $certificate['department']; ?></strong> is a bonafide student of this college in the academic year 
            <strong><?php echo $certificate['academic_year']; ?></strong>.</p>
            
            <p>This certificate is issued on request for the purpose of applying for <strong><?php echo $certificate['purpose']; ?></strong>. 
            The above student will abide by all the rules, regulations and terms and conditions of your organization during the internship period.</p>
            
        <?php elseif($certificate['certificate_type'] == 'Project'): ?>
            <p>This is to certify that <strong><?php echo $certificate['student_prefix'] . ' ' . strtoupper($certificate['student_name']); ?></strong> 
            (Register No: <strong><?php echo $certificate['register_number']; ?></strong>), 
            <?php echo ($certificate['student_prefix'] == 'Mr.' ? 'son' : 'daughter'); ?> of 
            <strong><?php echo $certificate['parent_prefix'] . ' ' . strtoupper($certificate['father_name']); ?></strong>, 
            pursuing <strong><?php echo $certificate['year_pursuing']; ?></strong> Year <?php echo $certificate['degree_name']; ?> in 
            <strong><?php echo $certificate['department']; ?></strong> is a bonafide student of this college in the academic year 
            <strong><?php echo $certificate['academic_year']; ?></strong>.</p>
            
            <p>We kindly request you to permit the student to undertake <strong>Project Work</strong> in your esteemed organization.</p>
            
            <p>During the period of Project Work, the student will abide by the rules and regulations of your organization.
            You may please send us the duly signed attendance and periodic review / evaluation results of Project Work.</p>
            
        <?php else: ?>
            <p>This is to certify that <strong><?php echo $certificate['student_prefix'] . ' ' . strtoupper($certificate['student_name']); ?></strong> 
            (Register No: <strong><?php echo $certificate['register_number']; ?></strong>), 
            <?php echo ($certificate['student_prefix'] == 'Mr.' ? 'son' : 'daughter'); ?> of 
            <strong><?php echo $certificate['parent_prefix'] . ' ' . strtoupper($certificate['father_name']); ?></strong>, 
            is a bonafide student of our Institution, pursuing <strong><?php echo $certificate['year_pursuing']; ?></strong> Year 
            <?php echo $certificate['degree_name']; ?> in <strong><?php echo $certificate['department']; ?></strong> during the academic year 
            <strong><?php echo $certificate['academic_year']; ?></strong>.</p>
            
            <p style="margin-top: 15px;">This certificate is issued on request for <strong><?php echo $certificate['purpose']; ?></strong>.</p>
        <?php endif; ?>
    </div>
    
    <div class="paper-footer">
        <div class="paper-sign">
            <div style="font-size: 9px; color: #666; margin-bottom: 5px;">Date: <?php echo date('d M Y', strtotime($certificate['bonafide_date'])); ?></div>
            <div>PRINCIPAL</div>
            <div style="font-size: 8px; font-weight: normal; margin-top: 3px;">
                Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College
            </div>
        </div>
        <div class="paper-sign" style="text-align: left;">
            <div style="font-size: 9px; font-weight: normal; margin-bottom: 10px;">
                <strong>For Verification:</strong><br>
                Scan QR Code or visit:<br>
                www.velhightech.com/verify.php<br>
                Ref: <?php echo $certificate['ref_number']; ?>
            </div>
        </div>
    </div>
    
    <?php else: ?>
    <div style="text-align: center; padding: 50px;">
        <h3>Certificate Not Found</h3>
        <p>The requested certificate could not be found.</p>
    </div>
    <?php endif; ?>
    
    <script>
        // Auto-close after printing (optional)
        window.onafterprint = function() {
            // window.close();
        };
    </script>
</body>
</html>
<?php
ob_end_flush();
?>