<style>
    /* Scoped Chat UI Styles */
    .chat-wrapper { display: flex; flex-direction: column; height: 100%; width: 100%; background: #fff; overflow: hidden; }
    
    /* 1. Empty State */
    #noChat { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; color: #aaa; padding: 20px; }
    #noChat i { font-size: 3rem; margin-bottom: 15px; opacity: 0.5; }

    /* 2. Active Chat View */
    #activeChat { display: none; flex-direction: column; height: 100%; }
    
    /* Header */
    .chat-head { padding: 10px 15px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; gap: 10px; background: #fff; flex-shrink: 0; }
    .chat-avatar { width: 35px; height: 35px; border-radius: 50%; background: #bc1888; color: white; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.9rem; }
    .chat-info h4 { margin: 0; font-size: 0.95rem; color: #333; }
    .chat-info span { font-size: 0.75rem; color: #2ecc71; } /* Online Status */

    /* Messages Area */
    .chat-msgs { flex: 1; overflow-y: auto; padding: 15px; background: #f9f9f9; display: flex; flex-direction: column; gap: 10px; }
    
    .msg-bubble { max-width: 75%; padding: 10px 14px; border-radius: 12px; font-size: 0.9rem; position: relative; word-wrap: break-word; }
    .msg-in { align-self: flex-start; background: #fff; border: 1px solid #eee; color: #333; border-bottom-left-radius: 2px; }
    .msg-out { align-self: flex-end; background: #333; color: #fff; border-bottom-right-radius: 2px; }
    .msg-time { font-size: 0.65rem; margin-top: 4px; opacity: 0.7; display: block; text-align: right; }

    /* Input Area */
    .chat-input-area { padding: 10px; border-top: 1px solid #eee; background: #fff; display: flex; gap: 8px; align-items: center; flex-shrink: 0; }
    .chat-input { flex: 1; padding: 10px 15px; border-radius: 20px; border: 1px solid #ddd; outline: none; font-family: inherit; font-size: 0.9rem; }
    .chat-btn { border: none; background: none; color: #bc1888; font-size: 1.2rem; cursor: pointer; padding: 5px; }
    .chat-btn:disabled { color: #ccc; }
</style>

<div class="chat-wrapper">
    
    <div id="noChat">
        <i class="far fa-comments"></i>
        <h3>Select a Conversation</h3>
        <p>Choose a user from the list to start chatting.</p>
    </div>

    <div id="activeChat">
        <div class="chat-head">
            <button onclick="backToChatList()" style="border:none; background:none; margin-right:5px; cursor:pointer;" class="mobile-only"><i class="fas fa-arrow-left"></i></button>
            <div class="chat-avatar" id="cAvatar">U</div>
            <div class="chat-info">
                <h4 id="cName">User Name</h4>
                <span>Online</span>
            </div>
        </div>

        <div class="chat-msgs" id="cMessages">
            </div>

        <div class="chat-input-area">
            <button class="chat-btn"><i class="fas fa-paperclip"></i></button>
            <input type="text" class="chat-input" id="cInput" placeholder="Type a message..." onkeypress="handleEnter(event)">
            <button class="chat-btn" onclick="sendChatMessage()"><i class="fas fa-paper-plane"></i></button>
        </div>
    </div>

</div>