<?php
// includes/functions.php - COMPLETE FIXED VERSION WITH ALL MISSING FUNCTIONS
// ERROR-FREE VERSION FOR DASHBOARDS

/* =========================================================
 CORE FUNCTIONS FOR BONAFIDE SYSTEM
 FIXED: All missing functions added, no UI changes ========================================================= */

/**
 * Sanitize input data
 */
function sanitize($input, $type = 'string')
{
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }

    $cleaned = trim($input);
    $cleaned = stripslashes($cleaned);
    $cleaned = htmlspecialchars($cleaned, ENT_QUOTES | ENT_HTML5, 'UTF-8');

    switch ($type) {
        case 'email':
            $cleaned = filter_var($cleaned, FILTER_SANITIZE_EMAIL);
            break;
        case 'int':
            $cleaned = filter_var($cleaned, FILTER_SANITIZE_NUMBER_INT);
            break;
        case 'float':
            $cleaned = filter_var($cleaned, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            break;
        case 'url':
            $cleaned = filter_var($cleaned, FILTER_SANITIZE_URL);
            break;
    }

    return $cleaned;
}

/**
 * Get complete student profile from either table
 */
function getCompleteStudentProfile($sid)
{
    global $mysqli;

    if (!isset($mysqli)) {
        return null; // Don't throw exception
    }

    $tables = [
        ['table' => 'students_login_master', 'id_field' => 'IDNo'],
        ['table' => 'students_batch_25_26', 'id_field' => 'id_no']
    ];

    foreach ($tables as $table_info) {
        $table = $table_info['table'];
        $id_field = $table_info['id_field'];

        $stmt = $mysqli->prepare("SELECT * FROM $table WHERE $id_field = ?");
        if (!$stmt)
            continue;

        $stmt->bind_param("s", $sid);
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $student_data = $result->fetch_assoc();
                $stmt->close();
                return $student_data;
            }
        }
        $stmt->close();
    }

    return null;
}

/**
 * Get student's requests (for STUDENT role) - Returns array
 */
function getStudentRequests($student_id)
{
    global $mysqli;

    if (!isset($mysqli))
        return [];

    $sql = "SELECT * FROM bonafide_requests 
            WHERE student_id = ? 
            ORDER BY submitted_on DESC";
    $stmt = $mysqli->prepare($sql);
    if (!$stmt)
        return [];

    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

/**
 * Get student certificates
 */
function getStudentCertificates($student_id)
{
    global $mysqli;

    if (!isset($mysqli))
        return [];

    $sql = "SELECT c.* FROM bonafide_certificates c
            INNER JOIN bonafide_requests r ON c.request_id = r.id
            WHERE r.student_id = ? AND c.status = 'approved'
            ORDER BY c.bonafide_date DESC";
    $stmt = $mysqli->prepare($sql);
    if (!$stmt)
        return [];

    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

/**
 * Get role requests for staff dashboard - FIXED SIGNATURE
 */
function getRoleRequests($role, $department = '')
{
    global $mysqli;

    if (!isset($mysqli))
        return [];

    switch ($role) {
        case 'class_advisor':
            $status_field = 'advisor_status';
            $query = "SELECT r.*, s.Dept as department, s.Name as student_name, s.RegisterNo as register_number
                     FROM bonafide_requests r
                     LEFT JOIN students_login_master s ON r.student_id = s.IDNo
                     WHERE r.$status_field = 'pending'";
            if (!empty($department)) {
                $query .= " AND s.Dept = ?";
            }
            break;

        case 'hod':
            $status_field = 'hod_status';
            $query = "SELECT r.*, s.Dept as department, s.Name as student_name, s.RegisterNo as register_number
                     FROM bonafide_requests r
                     LEFT JOIN students_login_master s ON r.student_id = s.IDNo
                     WHERE r.$status_field = 'pending' AND r.advisor_status = 'approved'";
            if (!empty($department)) {
                $query .= " AND s.Dept = ?";
            }
            break;

        case 'dean':
            $status_field = 'dean_status';
            $query = "SELECT r.*, s.Dept as department, s.Name as student_name, s.RegisterNo as register_number
                     FROM bonafide_requests r
                     LEFT JOIN students_login_master s ON r.student_id = s.IDNo
                     WHERE r.$status_field = 'pending' AND r.hod_status = 'approved'";
            break;

        case 'admin':
            $status_field = 'admin_status';
            $query = "SELECT r.*, s.Dept as department, s.Name as student_name, s.RegisterNo as register_number
                     FROM bonafide_requests r
                     LEFT JOIN students_login_master s ON r.student_id = s.IDNo
                     WHERE r.$status_field = 'pending' AND r.dean_status = 'approved'";
            break;

        default:
            return [];
    }

    $query .= " ORDER BY r.submitted_on ASC";

    $stmt = $mysqli->prepare($query);
    if (!$stmt)
        return [];

    if (($role === 'class_advisor' || $role === 'hod') && !empty($department)) {
        $stmt->bind_param("s", $department);
    }

    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

/**
 * Create new bonafide request (STUDENT only)
 */
function createBonafideRequest($student_id, $type, $purpose, $additional_info = '')
{
    global $mysqli;

    if (!isset($mysqli))
        return false;

    $student = getCompleteStudentProfile($student_id);
    if (!$student)
        return false;

    $student_name = $student['Name'] ?? $student['student_name'] ?? '';
    $register_no = $student['RegisterNo'] ?? $student['register_no'] ?? '';
    $department = $student['Dept'] ?? $student['department'] ?? '';
    $batch = $student['Batch'] ?? $student['batch'] ?? '';
    $father_name = $student['fathername'] ?? $student['parent_name'] ?? '';
    $gender = $student['Gender'] ?? $student['gender'] ?? 'Male';

    // Generate request number
    $year = date('Y');
    $sql = "SELECT COUNT(*) as count FROM bonafide_requests WHERE YEAR(submitted_on) = $year";
    $result = $mysqli->query($sql);
    $count = $result ? ($result->fetch_assoc()['count'] + 1) : 1;
    $request_number = sprintf("REQ-%s-%04d", $year, $count);

    $sql = "INSERT INTO bonafide_requests 
            (request_number, student_id, student_name, register_number, department, batch,
             father_name, gender, bonafide_type, purpose, student_message,
             advisor_status, hod_status, dean_status, admin_status, 
             status, submitted_on)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 
                    'pending', 'pending', 'pending', 'pending', 
                    'submitted', NOW())";

    $stmt = $mysqli->prepare($sql);
    if (!$stmt)
        return false;

    $stmt->bind_param("sssssssssss",
        $request_number,
        $student_id,
        $student_name,
        $register_no,
        $department,
        $batch,
        $father_name,
        $gender,
        $type,
        $purpose,
        $additional_info
    );

    return $stmt->execute() ? $mysqli->insert_id : false;
}

/**
 * Process approval/rejection (for STAFF roles)
 */
function processApproval($request_id, $action, $role, $user_id, $remarks)
{
    global $mysqli;

    if (!isset($mysqli))
        return false;

    $status_field = '';
    switch ($role) {
        case 'class_advisor':
            $status_field = 'advisor';
            break;
        case 'hod':
            $status_field = 'hod';
            break;
        case 'dean':
            $status_field = 'dean';
            break;
        case 'admin':
            $status_field = 'admin';
            break;
        default:
            return false;
    }

    $new_status = $action === 'approve' ? 'approved' : 'rejected';
    $approved_by_field = $status_field . '_approved_by';
    $status_field .= '_status';

    $sql = "UPDATE bonafide_requests 
            SET $status_field = ?, $approved_by_field = ?, 
                " . ($status_field === 'admin_status' ? 'final_approved = 1, ' : '') . "
                rejection_reason = ?
            WHERE id = ?";

    $stmt = $mysqli->prepare($sql);
    if (!$stmt)
        return false;

    $rejection_reason = $action === 'reject' ? $remarks : null;
    $stmt->bind_param("sssi", $new_status, $user_id, $rejection_reason, $request_id);

    if (!$stmt->execute())
        return false;

    if ($role === 'admin' && $action === 'approve') {
        return generateCertificate($request_id, $user_id);
    }

    return true;
}

/**
 * Generate certificate (for admin approval flow)
 */
function generateCertificate($request_id, $admin_id)
{
    global $mysqli;

    if (!isset($mysqli))
        return false;

    $sql = "SELECT r.*, s.Dept as student_dept 
            FROM bonafide_requests r
            LEFT JOIN students_login_master s ON r.student_id = s.IDNo
            WHERE r.id = ?";

    $stmt = $mysqli->prepare($sql);
    if (!$stmt)
        return false;

    $stmt->bind_param("i", $request_id);
    $stmt->execute();
    $request = $stmt->get_result()->fetch_assoc();

    if (!$request)
        return false;

    $year = date('Y');
    $count_sql = "SELECT COUNT(*) as count FROM bonafide_certificates WHERE YEAR(bonafide_date) = $year";
    $count_result = $mysqli->query($count_sql);
    $count = $count_result ? ($count_result->fetch_assoc()['count'] + 1) : 1;
    $ref_number = sprintf("BON-%s-%04d", $year, $count);

    $cert_sql = "INSERT INTO bonafide_certificates (
        ref_number, request_id, student_id, register_number, 
        student_name, department, certificate_type, purpose, 
        bonafide_date, verified_by, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, 'approved')";

    $stmt = $mysqli->prepare($cert_sql);
    if (!$stmt)
        return false;

    $department = $request['department'] ?? $request['student_dept'] ?? 'Unknown';

    $stmt->bind_param("sisssssss",
        $ref_number,
        $request_id,
        $request['student_id'],
        $request['register_number'],
        $request['student_name'],
        $department,
        $request['bonafide_type'],
        $request['purpose'],
        $admin_id
    );

    if ($stmt->execute()) {
        $certificate_id = $stmt->insert_id;

        $update_sql = "UPDATE bonafide_requests SET certificate_id = ? WHERE id = ?";
        $update = $mysqli->prepare($update_sql);
        if ($update) {
            $update->bind_param("ii", $certificate_id, $request_id);
            $update->execute();
        }

        return true;
    }

    return false;
}

/**
 * Revoke request (STUDENT only, before advisor approval)
 */
function revokeRequest($student_id, $request_id)
{
    global $mysqli;

    if (!isset($mysqli))
        return false;

    $stmt = $mysqli->prepare("
        UPDATE bonafide_requests 
        SET status = 'revoked', advisor_status = 'revoked'
        WHERE id = ? AND student_id = ? AND advisor_status = 'pending'
    ");
    if (!$stmt)
        return false;

    $stmt->bind_param("is", $request_id, $student_id);
    return $stmt->execute();
}

/**
 * Get fee information (for 7.5% scholarship check)
 */
function getFeeInfo($student_id)
{
    global $mysqli;

    if (!isset($mysqli))
        return null;

    $stmt = $mysqli->prepare("
        SELECT * FROM bonafide_fee_details 
        WHERE id_no = ? 
        LIMIT 1
    ");
    if (!$stmt)
        return null;

    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    return $result->fetch_assoc();
}

// ==================== MISSING FUNCTIONS - ADDED BELOW ====================

/**
 * Get student details - MISSING FUNCTION ADDED
 */
function getStudentDetails($student_id)
{
    global $mysqli;

    if (!isset($mysqli)) {
        return ['name' => 'Unknown', 'register_no' => 'N/A', 'department' => 'Unknown'];
    }

    $sql = "SELECT Name as name, RegisterNo as register_no, Dept as department 
            FROM students_login_master WHERE IDNo = ?
            UNION
            SELECT student_name as name, register_no, department 
            FROM students_batch_25_26 WHERE id_no = ?";

    $stmt = $mysqli->prepare($sql);
    if (!$stmt) {
        return ['name' => 'Unknown', 'register_no' => 'N/A', 'department' => 'Unknown'];
    }

    $stmt->bind_param("ss", $student_id, $student_id);
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        return $data ?: ['name' => 'Unknown', 'register_no' => 'N/A', 'department' => 'Unknown'];
    }

    return ['name' => 'Unknown', 'register_no' => 'N/A', 'department' => 'Unknown'];
}

/**
 * Get current status for display - MISSING FUNCTION ADDED
 */
function getCurrentStatus($request)
{
    if (!is_array($request))
        return 'Unknown';

    $status_flow = [
        'advisor_status' => 'Advisor',
        'hod_status' => 'HOD',
        'dean_status' => 'Dean',
        'admin_status' => 'Admin'
    ];

    foreach ($status_flow as $field => $label) {
        if (isset($request[$field]) && $request[$field] === 'pending') {
            return "Pending at $label";
        }
    }

    if (isset($request['admin_status'])) {
        if ($request['admin_status'] === 'approved')
            return 'Approved';
        if ($request['admin_status'] === 'rejected')
            return 'Rejected';
    }

    return 'Processing';
}

/**
 * Display status timeline - MISSING FUNCTION ADDED
 */
function displayStatusTimeline($request, $user_role)
{
    if (!is_array($request))
        return '';

    $timeline = [
        ['label' => 'Student', 'field' => 'status', 'value' => 'submitted'],
        ['label' => 'Advisor', 'field' => 'advisor_status', 'value' => 'approved'],
        ['label' => 'HOD', 'field' => 'hod_status', 'value' => 'approved'],
        ['label' => 'Dean', 'field' => 'dean_status', 'value' => 'approved'],
        ['label' => 'Admin', 'field' => 'admin_status', 'value' => 'approved'],
    ];

    $html = '';
    foreach ($timeline as $step) {
        $status = $request[$step['field']] ?? 'pending';
        $class = ($status === $step['value']) ? 'active' :
            (($status === 'pending' || $status === 'rejected') ? 'pending' : 'inactive');

        $html .= '<div class="status-step">';
        $html .= '<div class="step-dot ' . $class . '"></div>';
        $html .= '<div class="step-label">' . $step['label'] . '</div>';
        $html .= '</div>';
    }

    return $html;
}

/**
 * Get all certificates for staff - MISSING FUNCTION ADDED
 */
function getAllCertificates($role, $dept = '')
{
    global $mysqli;

    if (!isset($mysqli))
        return [];

    $sql = "SELECT c.* FROM bonafide_certificates c
            WHERE c.status = 'approved'";

    if ($role !== 'admin' && !empty($dept)) {
        $sql .= " AND c.department LIKE ?";
    }

    $sql .= " ORDER BY c.bonafide_date DESC";

    $stmt = $mysqli->prepare($sql);
    if (!$stmt)
        return [];

    if ($role !== 'admin' && !empty($dept)) {
        $dept_like = "%$dept%";
        $stmt->bind_param("s", $dept_like);
    }

    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

/**
 * Get role-based pending requests (for legacy compatibility)
 */
function getRoleBasedRequests($role, $user_id, $user_dept = '')
{
    // This is for compatibility with old code
    return getRoleRequests($role, $user_dept);
}

/**
 * Generate certificate from approved request (legacy function)
 */
function generateCertificateFromRequest($request_id)
{
    global $mysqli;

    if (!isset($mysqli))
        return false;

    // Get admin user ID from session if available
    $admin_id = $_SESSION['user_id'] ?? 'admin';

    return generateCertificate($request_id, $admin_id);
}

/**
 * Log activity for auditing (placeholder)
 */
function logActivity($user_id, $action, $details = '')
{
    // Implement logging if needed
    return true;
}

/**
 * Check if profile is complete (placeholder)
 */
function checkProfileCompletion($student_data)
{
    if (!$student_data)
        return false;

    $required = ['Name', 'student_name', 'RegisterNo', 'register_no'];
    foreach ($required as $field) {
        if (isset($student_data[$field]) && !empty(trim($student_data[$field]))) {
            return true;
        }
    }

    return false;
}

/**
 * Get request status with styling (placeholder)
 */
function getRequestStatus($request)
{
    $status = $request['status'] ?? 'pending';

    $config = [
        'pending' => ['text' => 'Pending', 'class' => 'warning'],
        'approved' => ['text' => 'Approved', 'class' => 'success'],
        'rejected' => ['text' => 'Rejected', 'class' => 'error'],
        'submitted' => ['text' => 'Submitted', 'class' => 'info'],
    ];

    return $config[$status] ?? $config['pending'];
}

/**
 * Format date for display
 */
function formatDate($date, $format = 'd M Y')
{
    if (empty($date))
        return '';
    return date($format, strtotime($date));
}

/**
 * Check user permissions
 */
function hasPermission($role, $required_permission)
{
    $permissions = [
        'student' => ['view_profile', 'submit_request', 'view_requests'],
        'class_advisor' => ['view_requests', 'approve_requests'],
        'hod' => ['view_requests', 'approve_requests'],
        'dean' => ['view_requests', 'approve_requests'],
        'admin' => ['view_requests', 'approve_requests', 'manage_certificates'],
    ];

    return isset($permissions[$role]) && in_array($required_permission, $permissions[$role]);
}

/**
 * Notify advisor (placeholder)
 */
function notifyAdvisor($student_id, $request_id)
{
    return true;
}

/**
 * Notify student (placeholder)
 */
function notifyStudent($student_id, $ref_number)
{
    return true;
}

/**
 * Generate certificate content (placeholder for print_certificate.php)
 */
function generateCertificateContent($certificate)
{
    return '<p>Certificate content placeholder</p>';
}

// ==================== PROFILE CHANGE REQUEST FUNCTIONS ====================

/**
 * Create a profile change request (student wants to change existing data)
 */
function createProfileChangeRequest($student_id, $field_name, $field_label, $old_value, $new_value, $reason, $source_table)
{
    global $mysqli;
    if (!isset($mysqli))
        return false;

    // Get student info for denormalization
    $student = getStudentDetails($student_id);
    $student_name = $student['name'] ?? '';
    $department = $student['department'] ?? '';

    // Check if there's already a pending request for this field
    $check = $mysqli->prepare("SELECT id FROM profile_change_requests WHERE student_id = ? AND field_name = ? AND status = 'pending'");
    if ($check) {
        $check->bind_param("ss", $student_id, $field_name);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            return 'duplicate'; // Already has a pending request for this field
        }
    }

    $stmt = $mysqli->prepare("INSERT INTO profile_change_requests 
        (student_id, student_name, department, field_name, field_label, old_value, new_value, reason, source_table) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt)
        return false;

    $stmt->bind_param("sssssssss", $student_id, $student_name, $department, $field_name, $field_label, $old_value, $new_value, $reason, $source_table);
    return $stmt->execute() ? $mysqli->insert_id : false;
}

/**
 * Get pending profile change requests for a student
 */
function getPendingProfileChanges($student_id)
{
    global $mysqli;
    if (!isset($mysqli))
        return [];

    $stmt = $mysqli->prepare("SELECT * FROM profile_change_requests WHERE student_id = ? ORDER BY created_at DESC");
    if (!$stmt)
        return [];

    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

/**
 * Approve a profile change request and apply the change
 */
function approveProfileChange($request_id, $admin_id, $remarks = '')
{
    global $mysqli;
    if (!isset($mysqli))
        return false;

    // Get the request details
    $stmt = $mysqli->prepare("SELECT * FROM profile_change_requests WHERE id = ? AND status = 'pending'");
    if (!$stmt)
        return false;
    $stmt->bind_param("i", $request_id);
    $stmt->execute();
    $request = $stmt->get_result()->fetch_assoc();
    if (!$request)
        return false;

    // Determine the correct ID column for the source table
    $source_table = $request['source_table'];
    $id_col = ($source_table === 'students_batch_25_26') ? 'id_no' : 'IDNo';
    $field_name = $request['field_name'];
    $new_value = $request['new_value'];
    $student_id = $request['student_id'];

    // Apply the change to the student table
    $update = $mysqli->prepare("UPDATE `$source_table` SET `$field_name` = ? WHERE `$id_col` = ?");
    if (!$update)
        return false;
    $update->bind_param("ss", $new_value, $student_id);
    if (!$update->execute())
        return false;

    // Log the change
    $log_stmt = $mysqli->prepare("INSERT INTO profile_edit_log (student_id, changed_by, role, field_changed, old_value, new_value) VALUES (?, ?, 'admin', ?, ?, ?)");
    if ($log_stmt) {
        $old_val = $request['old_value'];
        $log_stmt->bind_param("sssss", $student_id, $admin_id, $field_name, $old_val, $new_value);
        $log_stmt->execute();
    }

    // Mark request as approved
    $approve = $mysqli->prepare("UPDATE profile_change_requests SET status = 'approved', reviewed_by = ?, review_remarks = ?, reviewed_at = NOW() WHERE id = ?");
    if (!$approve)
        return false;
    $approve->bind_param("ssi", $admin_id, $remarks, $request_id);
    return $approve->execute();
}

/**
 * Reject a profile change request
 */
function rejectProfileChange($request_id, $admin_id, $remarks = '')
{
    global $mysqli;
    if (!isset($mysqli))
        return false;

    $stmt = $mysqli->prepare("UPDATE profile_change_requests SET status = 'rejected', reviewed_by = ?, review_remarks = ?, reviewed_at = NOW() WHERE id = ? AND status = 'pending'");
    if (!$stmt)
        return false;
    $stmt->bind_param("ssi", $admin_id, $remarks, $request_id);
    return $stmt->execute();
}

/**
 * Get all profile change requests (for admin page)
 */
function getAllProfileChangeRequests($status = 'pending', $department = '')
{
    global $mysqli;
    if (!isset($mysqli))
        return [];

    $sql = "SELECT * FROM profile_change_requests WHERE 1=1";
    $params = [];
    $types = '';

    if (!empty($status) && $status !== 'all') {
        $sql .= " AND status = ?";
        $params[] = $status;
        $types .= 's';
    }
    if (!empty($department)) {
        $sql .= " AND department = ?";
        $params[] = $department;
        $types .= 's';
    }

    $sql .= " ORDER BY FIELD(status, 'pending', 'approved', 'rejected'), created_at DESC";

    $stmt = $mysqli->prepare($sql);
    if (!$stmt)
        return [];

    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// ==================== END OF MISSING FUNCTIONS ====================

// DO NOT add ob_start(), session_start(), or any output here
// This file should only contain function definitions
?>