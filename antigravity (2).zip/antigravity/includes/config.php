<?php
// includes/config.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// System Settings
define('SITE_NAME', 'Vel Tech High Tech Portal');
define('BASE_URL', 'https://ai.velhightech.com/');
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('LOG_DIR', __DIR__ . '/../logs/');

// Database Credentials (In a real scenario, use .env files)
define('DB_HOST', 'localhost');
define('DB_USER', 'velhight_vthtdb'); // Change this
define('DB_PASS', 'qipMsPKuWeN4'); // Change this
define('DB_NAME', 'velhight_newsite');

// AI Configuration
define('AI_PROVIDER', 'openrouter'); // or 'local'
define('AI_API_KEY', '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'); // Your OpenRouter Key
define('AI_MODEL', 'google/gemma-2-9b-it');

// Security & Roles
define('ROLE_STUDENT', 'student');
define('ROLE_FACULTY', 'faculty'); // Corresponds to 'employee' in some contexts
define('ROLE_HOD', 'hod');
define('ROLE_DEAN', 'dean');
define('ROLE_PRINCIPAL', 'principal');
define('ROLE_ADMIN', 'admin');

// --- GOOGLE OAUTH CREDENTIALS ---
// Get these from: https://console.cloud.google.com/apis/credentials
define('GOOGLE_CLIENT_ID', '813876624596-pirt3q68luna2hj1u9ffqbo39olsq54d.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
// This must match exactly what you put in Google Console "Authorized Redirect URIs"
define('GOOGLE_REDIRECT_URL', BASE_URL . 'auth/google_oauth.php');

// Timezone
date_default_timezone_set('Asia/Kolkata');
