<?php
/**
 * VEL AI - CHAT ENGINE CORE (ENHANCED & FIXED)
 * Fixes: Group Messaging Reliability, Search Unions, Timezones
 */
class Chat {
    private $db;

    public function __construct($mysqli) {
        $this->db = $mysqli;
        $this->db->set_charset("utf8mb4");
        // FIX: Ensure consistent timezone
        date_default_timezone_set('Asia/Kolkata');
        $this->db->query("SET time_zone = '+05:30'");
    }

    // ================================================================
    // 1. FETCH HISTORY (Optimized for Speed)
    // ================================================================
    public function getUserConversations($user_id) {
        // Uses subqueries to get the latest message details efficiently
        $q = "SELECT 
                c.id, c.conversation_type, c.conversation_name, c.updated_at,
                (SELECT message_text FROM chat_messages WHERE conversation_id = c.id ORDER BY sent_at DESC LIMIT 1) as last_msg,
                (SELECT sent_at FROM chat_messages WHERE conversation_id = c.id ORDER BY sent_at DESC LIMIT 1) as last_time,
                (SELECT message_type FROM chat_messages WHERE conversation_id = c.id ORDER BY sent_at DESC LIMIT 1) as msg_type,
                (SELECT file_path FROM chat_messages WHERE conversation_id = c.id ORDER BY sent_at DESC LIMIT 1) as file_path,
                (SELECT sender_id FROM chat_messages WHERE conversation_id = c.id ORDER BY sent_at DESC LIMIT 1) as last_sender,
                (SELECT read_status FROM chat_messages WHERE conversation_id = c.id ORDER BY sent_at DESC LIMIT 1) as read_status
              FROM chat_conversations c
              JOIN chat_participants cp ON c.id = cp.conversation_id
              WHERE cp.participant_id = ?
              HAVING last_time IS NOT NULL 
              ORDER BY last_time DESC";
        
        $stmt = $this->db->prepare($q);
        $stmt->bind_param("s", $user_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    // ================================================================
    // 2. NAME RESOLVER (Smart Detection)
    // ================================================================
    public function getConversationName($conv_id, $my_id) {
        // 1. Check if Group
        $c = $this->db->query("SELECT conversation_type, conversation_name FROM chat_conversations WHERE id = $conv_id")->fetch_assoc();
        if ($c && $c['conversation_type'] === 'group') {
            return $c['conversation_name'];
        }

        // 2. Find Partner ID (Individual Chat)
        $stmt = $this->db->prepare("SELECT participant_id FROM chat_participants WHERE conversation_id = ? AND participant_id != ? LIMIT 1");
        $stmt->bind_param("is", $conv_id, $my_id);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $tid = $res['participant_id'] ?? null;

        if (!$tid) return "Unknown User";

        // 3. Resolve Name (Strict 3-Table Check)
        $q = "SELECT NAME as n FROM employee_details1 WHERE ID_NO = ?
              UNION 
              SELECT Name as n FROM students_login_master WHERE RegisterNo = ?
              UNION 
              SELECT student_name as n FROM students_batch_25_26 WHERE register_no = ?
              LIMIT 1";
        
        $stmt = $this->db->prepare($q);
        $stmt->bind_param("sss", $tid, $tid, $tid);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        return $user['n'] ?? $tid;
    }

    // ================================================================
    // 3. GLOBAL SEARCH (Strict Table Columns)
    // ================================================================
    public function searchDirectory($term) {
        $term = "%$term%";
        // Uses the exact column names from your DB Schema
        $q = "
        (SELECT ID_NO as id, NAME as name, DESIGNATION as role, DEPARTMENT as dept, 'employee' as type 
         FROM employee_details1 WHERE ID_NO LIKE ? OR NAME LIKE ? LIMIT 5)
        UNION ALL
        (SELECT RegisterNo as id, Name as name, 'Student' as role, Dept as dept, 'student' as type 
         FROM students_login_master WHERE RegisterNo LIKE ? OR Name LIKE ? LIMIT 5)
        UNION ALL
        (SELECT register_no as id, student_name as name, '1st Year' as role, department as dept, 'student' as type 
         FROM students_batch_25_26 WHERE register_no LIKE ? OR student_name LIKE ? LIMIT 5)
        ";
        
        $stmt = $this->db->prepare($q);
        // 6 params (2 per table)
        $stmt->bind_param("ssssss", $term, $term, $term, $term, $term, $term);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    // ================================================================
    // 4. START CHAT (Fixed Group Logic with `chat_groups` Table)
    // ================================================================
    public function startChat($my_id, $target_id, $is_group = false) {
        
        // --- A. HANDLE GROUPS ---
        if ($is_group || strpos($target_id, 'GROUP_') === 0) {
            $identifier = str_replace('GROUP_', '', $target_id); // e.g. DEPT_CSE or BATCH_2025_CSE
            
            // Determine Type & Name
            $gType = 'department';
            $gName = $identifier;
            $dept_code = '';
            $batch = '';

            if(strpos($identifier, 'DEPT_') !== false) {
                $raw = str_replace('DEPT_', '', $identifier);
                $gName = $raw . " Faculty";
                $gType = 'department';
                $dept_code = $raw; 
            } elseif(strpos($identifier, 'BATCH_') !== false) {
                $raw = str_replace('BATCH_', '', $identifier);
                $parts = explode('_', $raw); // 2025_CSE
                $batch = $parts[0] ?? '';
                $dept_code = $parts[1] ?? '';
                $gName = "$dept_code $batch Group";
                $gType = 'batch';
            }

            // Check if Conversation Exists (by name/type)
            $q = "SELECT id FROM chat_conversations WHERE conversation_name = ? AND conversation_type = 'group' LIMIT 1";
            $stmt = $this->db->prepare($q);
            $stmt->bind_param("s", $gName);
            $stmt->execute();
            $res = $stmt->get_result()->fetch_assoc();

            if ($res) {
                $cid = $res['id'];
            } else {
                // Create New Conversation
                $this->db->query("INSERT INTO chat_conversations (conversation_type, conversation_name, created_at, updated_at) VALUES ('group', '$gName', NOW(), NOW())");
                $cid = $this->db->insert_id;
                
                // Register in `chat_groups` table (Your Schema)
                $stmtGroup = $this->db->prepare("INSERT INTO chat_groups (conversation_id, group_type, batch, dept_code, created_at) VALUES (?, ?, ?, ?, NOW())");
                $stmtGroup->bind_param("isss", $cid, $gType, $batch, $dept_code);
                $stmtGroup->execute();
            }

            // AUTO-JOIN USER (Check `chat_participants`)
            $chk = $this->db->query("SELECT id FROM chat_participants WHERE conversation_id = $cid AND participant_id = '$my_id'");
            if ($chk->num_rows == 0) {
                $role = (strpos($my_id, 'VH') === 0 || is_numeric($my_id)) ? 'student' : 'employee';
                $this->db->query("INSERT INTO chat_participants (conversation_id, participant_id, participant_type, joined_at) VALUES ($cid, '$my_id', '$role', NOW())");
            }
            return $cid;
        }

        // --- B. HANDLE INDIVIDUAL CHAT ---
        $q = "SELECT c.id FROM chat_conversations c 
              JOIN chat_participants p1 ON c.id = p1.conversation_id 
              JOIN chat_participants p2 ON c.id = p2.conversation_id 
              WHERE c.conversation_type = 'individual' AND p1.participant_id = ? AND p2.participant_id = ? LIMIT 1";
        
        $stmt = $this->db->prepare($q);
        $stmt->bind_param("ss", $my_id, $target_id);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();

        if ($res) return $res['id'];

        $this->db->query("INSERT INTO chat_conversations (conversation_type, created_at, updated_at) VALUES ('individual', NOW(), NOW())");
        $cid = $this->db->insert_id;

        $type1 = (strpos($my_id, 'VH') === 0 || is_numeric($my_id)) ? 'student' : 'employee';
        $type2 = (strpos($target_id, 'VH') === 0 || is_numeric($target_id)) ? 'student' : 'employee';

        $stmt = $this->db->prepare("INSERT INTO chat_participants (conversation_id, participant_id, participant_type, joined_at) VALUES (?, ?, ?, NOW()), (?, ?, ?, NOW())");
        $stmt->bind_param("ississ", $cid, $my_id, $type1, $cid, $target_id, $type2);
        $stmt->execute();

        return $cid;
    }

    // ================================================================
    // 5. SEND MESSAGE (Reliable)
    // ================================================================
    public function sendMessage($cid, $sender_id, $sender_type, $msg_type, $text, $file_path) {
        if (!$cid) return false;

        $stmt = $this->db->prepare("INSERT INTO chat_messages (conversation_id, sender_id, sender_type, message_type, message_text, file_path, sent_at, read_status, deleted) VALUES (?, ?, ?, ?, ?, ?, NOW(), 0, 0)");
        $stmt->bind_param("isssss", $cid, $sender_id, $sender_type, $msg_type, $text, $file_path);
        
        if($stmt->execute()) {
            // Update conversation timestamp for sorting
            $this->db->query("UPDATE chat_conversations SET updated_at = NOW() WHERE id = $cid");
            return true;
        }
        return false;
    }

    // ================================================================
    // 6. GET MESSAGES (Mark Read)
    // ================================================================
    public function getMessages($cid, $viewer_id) {
        $this->db->query("UPDATE chat_messages SET read_status = 1 WHERE conversation_id = $cid AND sender_id != '$viewer_id'");
        $stmt = $this->db->prepare("SELECT * FROM chat_messages WHERE conversation_id = ? AND deleted = 0 ORDER BY sent_at ASC");
        $stmt->bind_param("i", $cid);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}
?>