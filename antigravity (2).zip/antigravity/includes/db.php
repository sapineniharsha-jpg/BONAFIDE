<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', '../logs/dept_errors.log');

// includes/db.php
require_once __DIR__ . '/config.php';

class Database
{
    private $connection = null;
    private $error = '';

    public function __construct()
    {
        try {
            $this->connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            if ($this->connection->connect_error) {
                $this->error = $this->connection->connect_error;
                error_log("[DB Error] Database Connection Failed: " . $this->error, 3, LOG_DIR . 'db_errors.log');
                $this->connection = null;
                return;
            }
            $this->connection->set_charset("utf8mb4");
        }
        catch (Exception $e) {
            $this->error = $e->getMessage();
            error_log("[DB Error] " . $this->error, 3, LOG_DIR . 'db_errors.log');
            $this->connection = null;
        }
    }

    public function getConnection()
    {
        return $this->connection;
    }

    public function getError()
    {
        return $this->error;
    }

    // Pro Helper: Escapes strings to prevent SQL Injection
    public function escape($string)
    {
        if (!$this->connection) {
            return '';
        }
        return $this->connection->real_escape_string(trim($string));
    }
}

// Initialize Global Connection
$db = new Database();
$mysqli = $db->getConnection();
?>