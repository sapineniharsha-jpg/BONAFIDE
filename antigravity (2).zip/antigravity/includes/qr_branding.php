<?php
/**
 * Adds "VEL AI" branding text to the center of a QR code image.
 * Call this AFTER QRcode::png() has generated the QR image file.
 * Uses GD library to overlay white box with "VEL AI" text in the center.
 * Requires QR to use QR_ECLEVEL_H (30% error correction) for reliable scanning.
 */
function add_qr_branding($qrFilePath)
{
    if (!function_exists('imagecreatefrompng') || !file_exists($qrFilePath))
        return;

    $img = @imagecreatefrompng($qrFilePath);
    if (!$img)
        return;

    $w = imagesx($img);
    $h = imagesy($img);

    $text = "VEL AI";
    $font = 3; // GD built-in font (1-5), size 3 is good for small QR codes
    $fw = imagefontwidth($font);
    $fh = imagefontheight($font);
    $textW = $fw * strlen($text);
    $textH = $fh;

    $cx = (int)(($w - $textW) / 2);
    $cy = (int)(($h - $textH) / 2);
    $pad = 4;

    $white = imagecolorallocate($img, 255, 255, 255);
    $black = imagecolorallocate($img, 0, 0, 0);

    // White background behind text
    imagefilledrectangle($img, $cx - $pad, $cy - $pad, $cx + $textW + $pad, $cy + $textH + $pad, $white);

    // Draw "VEL AI" text
    imagestring($img, $font, $cx, $cy, $text, $black);

    imagepng($img, $qrFilePath);
    imagedestroy($img);
}
