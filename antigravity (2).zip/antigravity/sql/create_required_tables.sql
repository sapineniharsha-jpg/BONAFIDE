-- =====================================================
-- VEL AI Portal - Required Tables
-- Run this in phpMyAdmin on the velhight_newsite database
-- =====================================================

-- 1. Public AI Users (for Google login & public AI access)
CREATE TABLE IF NOT EXISTS `ai_public_users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `public_id` VARCHAR(50) UNIQUE,
    `name` VARCHAR(150) NOT NULL,
    `mobile` VARCHAR(20) NOT NULL DEFAULT '',
    `email` VARCHAR(200) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `last_access` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. AI Pending Answers (for AI admin approval queue)
CREATE TABLE IF NOT EXISTS `ai_pending_ai_answers` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `question` MEDIUMTEXT NOT NULL,
    `proposed_answer` MEDIUMTEXT NOT NULL,
    `user_type` VARCHAR(50) DEFAULT 'public',
    `source_model` VARCHAR(120) DEFAULT NULL,
    `source_engine` VARCHAR(80) DEFAULT 'external_ai',
    `confidence` FLOAT DEFAULT NULL,
    `status` ENUM('pending','approved','rejected') DEFAULT 'pending',
    `notes` TEXT DEFAULT NULL,
    `reviewed_by` VARCHAR(80) DEFAULT NULL,
    `reviewed_at` DATETIME DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. AI QA Master (for curated Q&A knowledge base)
CREATE TABLE IF NOT EXISTS `ai_qa_master` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `question` MEDIUMTEXT NOT NULL,
    `answer` MEDIUMTEXT NOT NULL,
    `category` VARCHAR(100) DEFAULT 'general',
    `created_by` VARCHAR(50) DEFAULT 'System',
    `subcategory` VARCHAR(100) DEFAULT NULL,
    `tags` VARCHAR(250) DEFAULT NULL,
    `keywords` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `sector_access` ENUM('public','student','faculty','all') DEFAULT 'all'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Password Reset Tokens
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `user_id` VARCHAR(50) NOT NULL,
    `user_type` VARCHAR(20) NOT NULL,
    `source_table` VARCHAR(80) NOT NULL,
    `id_column` VARCHAR(80) NOT NULL,
    `password_column` VARCHAR(80) NOT NULL,
    `token_hash` CHAR(64) NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `used` TINYINT(1) NOT NULL DEFAULT 0,
    `used_at` DATETIME DEFAULT NULL,
    `user_name` VARCHAR(150) DEFAULT NULL,
    `user_email` VARCHAR(200) DEFAULT NULL,
    `requested_ip` VARCHAR(64) DEFAULT NULL,
    `requested_user_agent` VARCHAR(255) DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_token_hash` (`token_hash`),
    KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Seminar Hall Bookings
CREATE TABLE IF NOT EXISTS `seminar_hall_bookings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `hall_name` VARCHAR(100) NOT NULL,
    `booked_by` VARCHAR(100) NOT NULL,
    `department` VARCHAR(100) DEFAULT NULL,
    `event_name` VARCHAR(200) NOT NULL,
    `booking_date` DATE NOT NULL,
    `start_time` TIME NOT NULL,
    `end_time` TIME NOT NULL,
    `status` ENUM('pending','approved','rejected','cancelled') DEFAULT 'pending',
    `approved_by` VARCHAR(100) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
