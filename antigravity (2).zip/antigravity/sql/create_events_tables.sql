-- =====================================================
-- VEL College Events — Table Creation Script
-- Run this in phpMyAdmin on the velhight_newsite database
-- =====================================================

CREATE TABLE IF NOT EXISTS `college_events` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `event_type` ENUM(
        'guest_lecture',
        'conference',
        'symposium',
        'alumni_interaction',
        'mini_project',
        'value_added_course',
        'seminar_workshop',
        'fdp_sttp',
        'alumni_meet',
        'industry_visit',
        'internship',
        'sim_c',
        'innovative_assignment',
        'nptel',
        'other'
    ) NOT NULL DEFAULT 'other',
    `event_title` VARCHAR(300) NOT NULL,
    `event_description` TEXT DEFAULT NULL,
    `event_date` DATE NOT NULL,
    `start_time` TIME DEFAULT NULL,
    `end_time` TIME DEFAULT NULL,
    `venue` VARCHAR(200) DEFAULT NULL,
    `department` VARCHAR(100) DEFAULT NULL,
    `program` VARCHAR(100) DEFAULT NULL,
    `section` VARCHAR(20) DEFAULT NULL,
    `year_semester` VARCHAR(30) DEFAULT NULL,
    `faculty_incharge_id` VARCHAR(50) DEFAULT NULL,
    `faculty_incharge_name` VARCHAR(150) DEFAULT NULL,
    `resource_person_name` VARCHAR(200) DEFAULT NULL,
    `resource_person_designation` VARCHAR(200) DEFAULT NULL,
    `resource_person_org` VARCHAR(200) DEFAULT NULL,
    `resource_person_contact` VARCHAR(100) DEFAULT NULL,
    `event_date_to` DATE DEFAULT NULL,
    `registration_url` VARCHAR(500) DEFAULT NULL,
    `registration_contact` VARCHAR(200) DEFAULT NULL,
    `registration_deadline` DATE DEFAULT NULL,
    `students_attended` INT DEFAULT 0,
    `beneficiaries` TEXT DEFAULT NULL,
    `outcome` TEXT DEFAULT NULL,
    `status` ENUM('draft','published','completed','cancelled') NOT NULL DEFAULT 'published',
    `created_by_id` VARCHAR(50) DEFAULT NULL,
    `created_by_name` VARCHAR(150) DEFAULT NULL,
    `created_by_role` VARCHAR(50) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_event_type` (`event_type`),
    INDEX `idx_event_date` (`event_date`),
    INDEX `idx_department` (`department`),
    INDEX `idx_status` (`status`),
    INDEX `idx_created_by` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `college_event_photos` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `event_id` INT NOT NULL,
    `file_path` VARCHAR(500) NOT NULL,
    `caption` VARCHAR(200) DEFAULT NULL,
    `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_event_id` (`event_id`),
    CONSTRAINT `fk_event_photos_event` FOREIGN KEY (`event_id`) REFERENCES `college_events`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
