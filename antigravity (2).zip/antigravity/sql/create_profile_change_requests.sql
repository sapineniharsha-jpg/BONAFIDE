-- =====================================================
-- Profile Change Requests Table
-- Students can request changes to existing profile data
-- Admin reviews and approves/rejects
-- =====================================================

CREATE TABLE IF NOT EXISTS `profile_change_requests` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `student_id` VARCHAR(50) NOT NULL,
    `student_name` VARCHAR(150) DEFAULT NULL,
    `department` VARCHAR(100) DEFAULT NULL,
    `field_name` VARCHAR(80) NOT NULL COMMENT 'DB column name in source table',
    `field_label` VARCHAR(100) NOT NULL COMMENT 'Human-readable field label',
    `old_value` TEXT DEFAULT NULL,
    `new_value` TEXT NOT NULL,
    `reason` TEXT DEFAULT NULL COMMENT 'Student reason for the change',
    `status` ENUM('pending','approved','rejected') DEFAULT 'pending',
    `reviewed_by` VARCHAR(50) DEFAULT NULL,
    `review_remarks` TEXT DEFAULT NULL,
    `reviewed_at` DATETIME DEFAULT NULL,
    `source_table` VARCHAR(80) NOT NULL COMMENT 'students_batch_25_26 or students_login_master',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_student_id` (`student_id`),
    KEY `idx_status` (`status`),
    KEY `idx_department` (`department`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
