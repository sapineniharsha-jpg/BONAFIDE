-- =====================================================
-- VEL AI Engine — Synonyms & Patterns Seed Data
-- Run this in phpMyAdmin on the velhight_newsite database
-- =====================================================
-- This script uses INSERT IGNORE to avoid duplicates if run multiple times

-- =====================================================
-- PART 1: SYNONYMS (ai_synonyms)
-- Maps colloquial, Tamil/Hindi, short forms to standard keywords
-- so the AI engine can understand varied inputs
-- =====================================================

-- Academic terms
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('dept', 'department'),
('sem', 'semester'),
('yr', 'year'),
('sub', 'subject'),
('subj', 'subject'),
('subs', 'subjects'),
('engg', 'engineering'),
('eng', 'engineering'),
('tech', 'technology'),
('uni', 'university'),
('univ', 'university'),
('cse', 'computer science and engineering'),
('ece', 'electronics and communication engineering'),
('eee', 'electrical and electronics engineering'),
('mech', 'mechanical engineering'),
('civil', 'civil engineering'),
('it', 'information technology'),
('ai', 'artificial intelligence'),
('ml', 'machine learning'),
('dl', 'deep learning'),
('nlp', 'natural language processing'),
('aids', 'artificial intelligence and data science'),
('aiml', 'artificial intelligence and machine learning'),
('cse(aiml)', 'computer science and engineering(artificial intelligence and machine learning)'),
('btech', 'b.tech'),
('mtech', 'm.tech'),
('be', 'b.e'),
('me', 'm.e'),
('bsc', 'b.sc'),
('msc', 'm.sc'),
('bca', 'bca'),
('mba', 'mba'),
('mca', 'mca'),
('pg', 'postgraduate'),
('ug', 'undergraduate'),
('phd', 'doctorate'),
('cgpa', 'cgpa'),
('gpa', 'cgpa'),
('syllabus', 'syllabus'),
('portion', 'syllabus'),
('curriculum', 'syllabus'),
('lab', 'laboratory'),
('labs', 'laboratory'),
('proj', 'project'),
('internship', 'internship'),
('intern', 'internship'),
('mini project', 'project'),
('final project', 'project'),
('placement', 'placement'),
('placements', 'placement'),
('campus', 'campus'),
('clg', 'college'),
('collg', 'college'),
('veltech', 'vel tech');

-- Examination terms
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('exam', 'examination'),
('exams', 'examination'),
('arrear', 'arrear'),
('arrears', 'arrear'),
('revaluation', 'revaluation'),
('reval', 'revaluation'),
('supplementary', 'arrear'),
('supple', 'arrear'),
('iat', 'internal assessment'),
('internal', 'internal assessment'),
('internals', 'internal assessment'),
('ct', 'class test'),
('assignment', 'assignment'),
('result', 'result'),
('results', 'result'),
('marks', 'marks'),
('grade', 'grade'),
('grades', 'grade'),
('backlog', 'arrear'),
('backlogs', 'arrear'),
('pass', 'pass'),
('fail', 'fail'),
('topper', 'rank'),
('rank', 'rank');

-- Attendance terms
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('attendance', 'attendance'),
('attn', 'attendance'),
('att', 'attendance'),
('absent', 'absent'),
('absnt', 'absent'),
('leave', 'leave'),
('od', 'on duty'),
('on duty', 'on duty'),
('bunk', 'absent'),
('bunking', 'absent'),
('present', 'present'),
('shortage', 'attendance shortage'),
('short', 'attendance shortage'),
('75%', 'minimum attendance'),
('condonation', 'attendance condonation');

-- Fee & Finance terms  
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('fee', 'fees'),
('fees', 'fees'),
('tuition', 'tuition fees'),
('hostel fee', 'hostel fees'),
('bus fee', 'transport fees'),
('transport fee', 'transport fees'),
('scholarship', 'scholarship'),
('freeships', 'scholarship'),
('concession', 'scholarship'),
('loan', 'education loan'),
('edu loan', 'education loan'),
('payment', 'fee payment'),
('challan', 'fee payment'),
('receipt', 'fee receipt'),
('refund', 'fee refund'),
('emi', 'installment'),
('installment', 'installment'),
('installments', 'installment');

-- Hostel terms
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('hostel', 'hostel'),
('hostle', 'hostel'),
('hostl', 'hostel'),
('room', 'hostel room'),
('roommate', 'hostel roommate'),
('mess', 'mess'),
('food', 'mess'),
('canteen', 'canteen'),
('warden', 'hostel warden'),
('curfew', 'hostel timing'),
('gate pass', 'hostel gate pass'),
('outing', 'hostel outing'),
('outpass', 'hostel gate pass');

-- Library terms
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('library', 'library'),
('lib', 'library'),
('book', 'library book'),
('books', 'library book'),
('ebook', 'e-book'),
('ebooks', 'e-book'),
('journal', 'journal'),
('journals', 'journal'),
('nptel', 'nptel'),
('swayam', 'swayam');

-- Staff / Faculty terms
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('sir', 'faculty'),
('madam', 'faculty'),
('mam', 'faculty'),
('teacher', 'faculty'),
('teachers', 'faculty'),
('professor', 'faculty'),
('prof', 'faculty'),
('staff', 'faculty'),
('lecturer', 'faculty'),
('asst prof', 'assistant professor'),
('assoc prof', 'associate professor'),
('hod', 'head of department'),
('dean', 'dean'),
('principal', 'principal'),
('advisor', 'class advisor'),
('class advisor', 'class advisor'),
('mentor', 'mentor'),
('counsellor', 'counsellor'),
('counselor', 'counsellor');

-- Certificate / Document terms
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('bonafide', 'bonafide'),
('bonafied', 'bonafide'),
('bonified', 'bonafide'),
('bonfide', 'bonafide'),
('tc', 'transfer certificate'),
('transfer certificate', 'transfer certificate'),
('conduct certificate', 'conduct certificate'),
('cc', 'conduct certificate'),
('provisional', 'provisional certificate'),
('convocation', 'convocation'),
('degree certificate', 'degree certificate'),
('marksheet', 'marks card'),
('transcript', 'transcript'),
('recommendation', 'recommendation letter'),
('noc', 'no objection certificate');

-- Admission terms
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('admission', 'admission'),
('admit', 'admission'),
('apply', 'apply'),
('application', 'application'),
('eligibility', 'eligibility'),
('cutoff', 'cutoff'),
('cut off', 'cutoff'),
('tnea', 'tnea counseling'),
('counseling', 'counseling'),
('counselling', 'counseling'),
('management quota', 'management quota'),
('mgmt quota', 'management quota'),
('lateral', 'lateral entry'),
('lateral entry', 'lateral entry'),
('document verification', 'document verification'),
('seat', 'seat'),
('seats', 'seat'),
('vacancy', 'seat'),
('intake', 'intake');

-- Tamil/Hindi colloquial
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('padippu', 'course'),
('padikkanum', 'admission'),
('panam', 'fees'),
('leave eduthuko', 'leave'),
('vanakkam', 'hello'),
('nandri', 'thank you'),
('thalaiva', 'hello'),
('anna', 'hello'),
('akka', 'hello'),
('bhai', 'hello'),
('yaar', 'who'),
('eppadi', 'how'),
('enga', 'where'),
('eppo', 'when'),
('enna', 'what'),
('kya', 'what'),
('kaise', 'how'),
('kab', 'when'),
('kaha', 'where'),
('kaun', 'who');

-- Circular / Notice terms
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('circular', 'circular'),
('notice', 'circular'),
('announcement', 'circular'),
('bulletin', 'circular'),
('memo', 'circular'),
('notification', 'circular'),
('order', 'circular');

-- Timetable / Schedule terms
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('timetable', 'timetable'),
('time table', 'timetable'),
('schedule', 'timetable'),
('class schedule', 'timetable'),
('day order', 'day order'),
('dayorder', 'day order'),
('today class', 'today class'),
('tomorrow class', 'tomorrow class'),
('period', 'period'),
('periods', 'period');

-- Placement / Career terms
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('job', 'placement'),
('jobs', 'placement'),
('company', 'company'),
('companies', 'company'),
('recruit', 'recruitment'),
('recruiting', 'recruitment'),
('recruitment', 'recruitment'),
('package', 'salary package'),
('salary', 'salary package'),
('ctc', 'salary package'),
('lpa', 'salary package'),
('aptitude', 'aptitude test'),
('interview', 'interview'),
('resume', 'resume'),
('cv', 'resume'),
('career', 'career'),
('training', 'training');

-- Infrastructure
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('seminar hall', 'seminar hall'),
('auditorium', 'auditorium'),
('audi', 'auditorium'),
('gym', 'gymnasium'),
('sports', 'sports'),
('ground', 'playground'),
('playground', 'playground'),
('parking', 'parking'),
('wifi', 'wifi'),
('internet', 'wifi'),
('bus', 'transport'),
('transport', 'transport'),
('van', 'transport'),
('route', 'bus route');


-- =====================================================
-- PART 2: PATTERNS (ai_patterns)
-- Regex patterns that detect user intent from questions
-- Used by ai_get_pattern_intent() function
-- =====================================================

-- Greeting patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(hi|hello|hey|vanakkam|good morning|good afternoon|good evening|howdy)\\b', 'greeting'),
('\\b(how are you|how r u|whats up|sup)\\b', 'greeting'),
('\\b(thanks|thank you|nandri|dhanyawad)\\b', 'thanks');

-- Course / Program patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(what|which|list|show|tell)\\b.*\\b(course|program|branch|department|stream)\\b', 'courses'),
('\\b(course|program|branch)\\b.*\\b(offered|available|list)\\b', 'courses'),
('\\b(how many|total)\\b.*\\b(course|program|department|branch|seat|intake)\\b', 'courses'),
('\\b(ug|pg|undergraduate|postgraduate|b\\.?e|b\\.?tech|m\\.?e|m\\.?tech|mba|mca|bca)\\b.*\\b(course|program|available|offered)\\b', 'courses'),
('\\b(syllabus|curriculum|subject)\\b.*\\b(for|of|in)\\b', 'syllabus'),
('\\b(what|which)\\b.*\\b(subject|sub)\\b.*\\b(semester|sem|year)\\b', 'syllabus');

-- Admission patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(how to|process|procedure|steps)\\b.*\\b(admission|apply|join|enroll|enrol)\\b', 'admission'),
('\\b(admission|enrollment|enrolment)\\b.*\\b(procedure|process|how|step|requirement|document)\\b', 'admission'),
('\\b(eligibility|eligible|qualify|qualification)\\b.*\\b(admission|course|program|college)\\b', 'admission'),
('\\b(cutoff|cut off)\\b.*\\b(mark|score|rank)\\b', 'admission'),
('\\b(tnea|counseling|counselling)\\b.*\\b(admission|seat|rank)\\b', 'admission'),
('\\b(management quota|mgmt quota|nri quota|direct admission)\\b', 'admission'),
('\\b(lateral entry|diploma entry)\\b', 'admission'),
('\\b(last date|deadline)\\b.*\\b(admission|application|apply)\\b', 'admission');

-- Fee patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(fee|fees|tuition|charge)\\b.*\\b(structure|detail|amount|how much|total|per year|annual)\\b', 'fees'),
('\\b(how much|what is|tell me)\\b.*\\b(fee|fees|cost|charge|tuition)\\b', 'fees'),
('\\b(fee|fees)\\b.*\\b(payment|pay|due|deadline|last date|online)\\b', 'fee_payment'),
('\\b(scholarship|freeship|concession|fee waiver|merit)\\b', 'scholarship'),
('\\b(education loan|edu loan|bank loan)\\b', 'education_loan'),
('\\b(installment|emi|partial payment)\\b', 'fee_payment'),
('\\b(receipt|challan|fee receipt)\\b', 'fee_receipt'),
('\\b(refund|fee refund)\\b', 'fee_refund');

-- Attendance patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(my|show|check|view)\\b.*\\b(attendance|attn)\\b', 'attendance'),
('\\b(attendance)\\b.*\\b(percentage|percent|short|shortage|low)\\b', 'attendance'),
('\\b(minimum attendance|75|condonation)\\b', 'attendance'),
('\\b(absent|leave|on duty|od)\\b.*\\b(today|yesterday|apply|request)\\b', 'attendance'),
('\\b(how many|total)\\b.*\\b(absent|leave|class)\\b.*\\b(missed|taken)\\b', 'attendance');

-- Examination patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(exam|examination)\\b.*\\b(date|schedule|timetable|when|hall ticket)\\b', 'examination'),
('\\b(internal|iat|class test|ct|model)\\b.*\\b(mark|exam|test|schedule)\\b', 'examination'),
('\\b(result|results|marks|grade)\\b.*\\b(when|check|view|out|published)\\b', 'result'),
('\\b(arrear|backlog|supplementary)\\b.*\\b(exam|result|register|fee)\\b', 'arrear'),
('\\b(revaluation|reval|recount|photocopy)\\b', 'revaluation'),
('\\b(cgpa|gpa|sgpa)\\b.*\\b(calculate|check|what|how|my)\\b', 'cgpa'),
('\\b(hall ticket|admit card)\\b', 'examination');

-- Hostel patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(hostel)\\b.*\\b(fee|room|allot|warden|rule|timing|facility|food|mess|apply|available)\\b', 'hostel'),
('\\b(mess|food|menu|canteen)\\b', 'hostel'),
('\\b(hostel|room)\\b.*\\b(change|shift|complaint|maintenance)\\b', 'hostel'),
('\\b(gate pass|outing|out pass)\\b', 'hostel'),
('\\b(warden|hostel warden)\\b.*\\b(name|contact|number|who)\\b', 'hostel');

-- Library patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(library)\\b.*\\b(timing|book|issue|return|renew|fine|card|membership|hours)\\b', 'library'),
('\\b(ebook|e-book|digital library|nptel|swayam)\\b', 'library'),
('\\b(book|journal)\\b.*\\b(available|borrow|issue|reserve)\\b', 'library');

-- Faculty / Staff patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(who is|find|search|look for|contact)\\b.*\\b(faculty|teacher|professor|sir|madam|staff|lecturer)\\b', 'faculty_search'),
('\\b(faculty|teacher|professor|staff)\\b.*\\b(name|department|designation|contact|email|phone|cabin)\\b', 'faculty_search'),
('\\b(hod|head of department|dean|principal)\\b.*\\b(name|who|contact)\\b', 'faculty_search'),
('\\b(class advisor|mentor|counsellor)\\b.*\\b(name|who|contact|my)\\b', 'faculty_search');

-- Bonafide / Certificate patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(apply|request|need|want|get)\\b.*\\b(bonafide|certificate)\\b', 'bonafide_apply'),
('\\b(bonafide|bona fide)\\b.*\\b(apply|request|status|track|pending|check|download)\\b', 'bonafide'),
('\\b(transfer certificate|tc|conduct certificate|cc|noc)\\b.*\\b(apply|request|get|need)\\b', 'certificate'),
('\\b(provisional|degree|convocation)\\b.*\\b(certificate|apply|when|date)\\b', 'certificate'),
('\\b(transcript|marks card|marksheet)\\b.*\\b(apply|request|get|need)\\b', 'certificate');

-- Circular / Notice patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(circular|notice|announcement|notification|memo)\\b', 'circular'),
('\\b(latest|recent|new|today)\\b.*\\b(circular|notice|announcement|update)\\b', 'circular'),
('\\b(any|show|view|check)\\b.*\\b(circular|notice|announcement)\\b', 'circular');

-- Timetable / Schedule patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(timetable|time table|schedule|day order)\\b', 'timetable'),
('\\b(today|tomorrow)\\b.*\\b(class|period|schedule|timetable)\\b', 'timetable'),
('\\b(what|which)\\b.*\\b(class|period|subject)\\b.*\\b(today|tomorrow|now|next)\\b', 'timetable');

-- Placement / Career patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(placement|placements|recruit|recruiting|recruitment)\\b', 'placement'),
('\\b(company|companies)\\b.*\\b(visit|coming|placed|recruit)\\b', 'placement'),
('\\b(package|salary|ctc|lpa|offer)\\b.*\\b(highest|average|company)\\b', 'placement'),
('\\b(training|aptitude|interview|mock)\\b.*\\b(schedule|date|register|when)\\b', 'placement'),
('\\b(resume|cv)\\b.*\\b(format|template|build|help)\\b', 'career');

-- Infrastructure patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(seminar hall|auditorium|conference)\\b.*\\b(book|reserve|available|schedule)\\b', 'seminar_hall'),
('\\b(bus|transport|van)\\b.*\\b(route|timing|fee|schedule|stop)\\b', 'transport'),
('\\b(wifi|internet|network)\\b.*\\b(password|connect|speed|issue)\\b', 'infrastructure'),
('\\b(sports|gym|ground|playground)\\b.*\\b(facility|timing|equipment)\\b', 'infrastructure'),
('\\b(parking|bike|vehicle)\\b.*\\b(sticker|spot|area|rule)\\b', 'infrastructure');

-- College info patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(vision|mission)\\b', 'vision_mission'),
('\\b(about|history|established)\\b.*\\b(college|institution|vel tech)\\b', 'about_college'),
('\\b(accreditation|naac|nba|aicte|approved|recognized)\\b', 'accreditation'),
('\\b(ranking|nirf|rank)\\b.*\\b(college|institution)\\b', 'ranking'),
('\\b(address|location|map|direction|how to reach|where is)\\b.*\\b(college|campus)\\b', 'location'),
('\\b(contact|phone|email|office)\\b.*\\b(college|admission|office|number)\\b', 'contact');

-- Student services
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(id card|identity card|student id)\\b', 'student_services'),
('\\b(uniform|dress code)\\b', 'student_services'),
('\\b(club|cell|forum|committee)\\b.*\\b(join|list|available|register)\\b', 'student_services'),
('\\b(event|fest|symposium|workshop|hackathon|seminar)\\b.*\\b(when|date|register|upcoming)\\b', 'events'),
('\\b(complaint|grievance|feedback|suggestion)\\b', 'grievance');

-- Help / General
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(help|assist|support|guide)\\b', 'help'),
('\\b(what can you|what do you|your feature|your capability)\\b', 'help'),
('\\b(who are you|what are you|your name)\\b', 'about_ai');

-- ePR (blocked topic) patterns
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\be[\\-\\s]?pr\\b', 'epr_blocked'),
('\\bemployee\\s+performance\\s+r', 'epr_blocked'),
('\\bperformance\\s+review\\b', 'epr_blocked'),
('\\bperformance\\s+report\\b', 'epr_blocked'),
('\\bfaculty\\s+appraisal\\b', 'epr_blocked'),
('\\bself\\s+appraisal\\b', 'epr_blocked'),
('\\bstaff\\s+appraisal\\b', 'epr_blocked');

-- College Events patterns (for AI event queries)
INSERT IGNORE INTO ai_patterns (pattern_text, intent) VALUES
('\\b(aavishkaar|avishkar|avishkaar)\\b', 'college_events'),
('\\b(guest\\s+lecture|guest\\s+speaker)\\b', 'college_events'),
('\\b(fdp|sttp|faculty\\s+development)\\b', 'college_events'),
('\\b(alumni\\s+meet|alumni\\s+interaction)\\b', 'college_events'),
('\\b(industry\\s+visit|industrial\\s+visit|field\\s+trip)\\b', 'college_events'),
('\\b(value\\s+added\\s+course|add\\s+on\\s+course|certificate\\s+course)\\b', 'college_events'),
('\\b(tech\\s+fest|cultural\\s+fest|annual\\s+day)\\b', 'college_events'),
('\\b(hackathon|coding\\s+contest|programming\\s+contest)\\b', 'college_events'),
('\\bnptel\\b', 'college_events'),
('\\b(upcoming|next)\\s+(event|program|seminar|workshop|conference)', 'college_events'),
('\\bwhen\\s+is\\b.*\\b(event|program|seminar|workshop|conference|symposium)', 'college_events'),
('\\bregist(er|ration)\\b.*\\b(event|program|seminar|workshop)', 'college_events');

-- College Events synonyms
INSERT IGNORE INTO ai_synonyms (keyword, mapped_keyword) VALUES
('programme', 'program'),
('function', 'event'),
('aavishkaar', 'symposium event'),
('avishkar', 'symposium event'),
('tech fest', 'symposium event'),
('webinar', 'seminar workshop'),
('orientation', 'event program'),
('celebration', 'event');

