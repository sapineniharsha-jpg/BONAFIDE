<?php
// ajax/chat_handler.php
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', '../logs/chat_api.log');
date_default_timezone_set('Asia/Kolkata');

while (ob_get_level()) ob_end_clean();
header('Content-Type: application/json');
session_start();

$root = $_SERVER['DOCUMENT_ROOT'];
require_once $root . '/includes/db.php';
require_once $root . '/includes/chat_class.php';

if (!isset($_SESSION['user_id'])) { echo json_encode(['status'=>'error', 'message'=>'Auth failed']); exit; }

$uid  = $_SESSION['user_id'];
$dept = $_SESSION['dept'] ?? '';
$role = strtolower($_SESSION['role'] ?? 'student');
$chat = new Chat($mysqli);
$act  = $_POST['action'] ?? '';

try {
    // 1. GLOBAL SEARCH
    if ($act === 'search_directory') {
        $data = $chat->searchDirectory($_POST['term']);
        echo json_encode(['status'=>'success', 'data'=>$data]);
        exit;
    }

    // 2. REFRESH HISTORY
    if ($act === 'refresh_history') {
        $convos = $chat->getUserConversations($uid);
        $out = [];
        foreach($convos as $c) {
            $name = $chat->getConversationName($c['id'], $uid);
            $last = $c['last_msg'] ?? 'Tap to chat';
            if($c['file_path']) $last = '📎 Attachment';
            
            $out[] = [
                'id' => $c['id'],
                'name' => $name,
                'last_msg' => $last,
                'time' => date('h:i A', strtotime($c['last_time'] ?? 'now')),
                'sender_id' => $c['last_sender'],
                'initial' => strtoupper(substr($name, 0, 1)),
                'read' => $c['read_status']
            ];
        }
        echo json_encode(['status'=>'success', 'data'=>$out]);
        exit;
    }

    // 3. SEND MESSAGE
    if ($act === 'send_msg') {
        $cid = intval($_POST['cid']);
        $msg = $_POST['msg'] ?? '';
        $file_path = null;

        if (isset($_FILES['file']) && $_FILES['file']['error'] === 0) {
            $dir = '../uploads/chat/';
            if(!is_dir($dir)) mkdir($dir, 0755, true);
            $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
            $fname = uniqid('chat_').'.'.$ext;
            if(move_uploaded_file($_FILES['file']['tmp_name'], $dir.$fname)) {
                $file_path = 'uploads/chat/'.$fname;
                if(empty($msg)) $msg = "📎 File";
            }
        }

        if($cid > 0) {
            $type = ($role == 'student') ? 'student' : 'employee';
            $mt = $file_path ? 'file' : 'text';
            if($chat->sendMessage($cid, $uid, $type, $mt, $msg, $file_path)) {
                echo json_encode(['success'=>true]);
            } else throw new Exception("DB Error");
        } else throw new Exception("Invalid CID");
        exit;
    }

    // 4. OPEN CHAT
    if ($act === 'open_chat') {
        $tid = $_POST['target_id'];
        
        // Logic: Numeric = CID, String = User ID or Group ID
        if (is_numeric($tid)) {
            $cid = $tid;
        } else {
            $cid = $chat->startChat($uid, $tid);
        }
        
        $msgs = $chat->getMessages($cid, $uid);
        echo json_encode(['status'=>'success', 'cid'=>$cid, 'msgs'=>$msgs, 'my_id'=>$uid]);
        exit;
    }

    // 5. LOAD GROUPS
    if ($act === 'load_groups') {
        $groups = [];
        $is_power = in_array($role, ['admin', 'principal', 'dean']);
        
        // Departments
        if ($is_power) {
            $res = $mysqli->query("SELECT DISTINCT DEPARTMENT FROM employee_details1");
            while($r = $res->fetch_assoc()) {
                if(!$r['DEPARTMENT']) continue;
                $slug = preg_replace('/[^a-zA-Z0-9]/', '', $r['DEPARTMENT']);
                $groups[] = ['id'=>'GROUP_DEPT_'.$slug, 'name'=>$r['DEPARTMENT'], 'sub'=>'Faculty'];
            }
        } else {
            if($dept) {
                $slug = preg_replace('/[^a-zA-Z0-9]/', '', $dept);
                $groups[] = ['id'=>'GROUP_DEPT_'.$slug, 'name'=>$dept, 'sub'=>'Faculty'];
            }
        }
        
        // Batches
        $qB = "SELECT DISTINCT Batch, Dept FROM students_login_master ORDER BY Batch DESC LIMIT 10";
        $res = $mysqli->query($qB);
        while($b = $res->fetch_assoc()) {
            $slug = $b['Batch'].'_'.preg_replace('/[^a-zA-Z0-9]/', '', $b['Dept']);
            $groups[] = ['id'=>'GROUP_BATCH_'.$slug, 'name'=>$b['Dept'].' '.$b['Batch'], 'sub'=>'Students'];
        }
        echo json_encode(['status'=>'success', 'data'=>$groups]);
        exit;
    }

} catch (Exception $e) { echo json_encode(['status'=>'error']); }
?>