<?php
// error_log.php - Debug errors
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h2>PHP Error Reporting Enabled</h2>";
echo "<p>Current PHP Version: " . phpversion() . "</p>";

// Test database connection
require_once 'includes/db.php';
if ($mysqli->connect_error) {
    echo "<p style='color: red;'>Database Connection Error: " . $mysqli->connect_error . "</p>";
} else {
    echo "<p style='color: green;'>Database Connection: OK</p>";
}

// Test session
session_start();
echo "<p>Session ID: " . session_id() . "</p>";
echo "<p>Session Data: " . print_r($_SESSION, true) . "</p>";
?>