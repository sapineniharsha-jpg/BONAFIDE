<?php
// dashboard.php - COMPLETE ALL-IN-ONE DASHBOARD FOR ALL ROLES
session_start();

// Check authentication
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

require_once '../includes/db.php';
require_once '../includes/functions.php';

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['name'];
$user_role = $_SESSION['role'];
$user_department = $_SESSION['department'] ?? '';
$user_designation = $_SESSION['designation'] ?? '';

// Role-based permissions
$allowed_roles = ['student', 'class_advisor', 'hod', 'dean', 'principal', 'admin'];
if (!in_array($user_role, $allowed_roles)) {
    header("Location: ../unauthorized.php");
    exit();
}

// Handle actions
$action = $_GET['action'] ?? '';
$request_id = $_GET['id'] ?? 0;
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // STUDENT: Submit new request
    if (isset($_POST['submit_request']) && $user_role == 'student') {
        $bonafide_type = sanitize($_POST['bonafide_type']);
        $purpose = sanitize($_POST['purpose']);
        $additional_info = sanitize($_POST['additional_info'] ?? '');
        
        // Check fee blocking for 7.5% scholarship
        if (in_array($bonafide_type, ['Fee Paid Certificate', 'Fee Structure'])) {
            $fee_details = getFeeInfo($user_id);
            if (isset($fee_details['scholarship_type']) && strpos($fee_details['scholarship_type'], '7.5') !== false) {
                $message = "Fee certificates blocked due to 7.5% scholarship. Contact admin.";
                $message_type = 'error';
            } else {
                $request_id = createBonafideRequest($user_id, $bonafide_type, $purpose, $additional_info);
                if ($request_id) {
                    $message = "Request submitted successfully! Tracking ID: BON-$request_id";
                    $message_type = 'success';
                }
            }
        } else {
            $request_id = createBonafideRequest($user_id, $bonafide_type, $purpose, $additional_info);
            if ($request_id) {
                $message = "Request submitted successfully! Tracking ID: BON-$request_id";
                $message_type = 'success';
            }
        }
    }
    
    // STUDENT: Revoke request
    if (isset($_POST['revoke_request']) && $user_role == 'student') {
        $revoke_id = intval($_POST['revoke_id']);
        if (revokeRequest($user_id, $revoke_id)) {
            $message = "Request revoked successfully!";
            $message_type = 'success';
        }
    }
    
    // FACULTY/ADMIN: Approve/Reject requests
    if (isset($_POST['approve_request']) || isset($_POST['reject_request'])) {
        $request_id = intval($_POST['request_id']);
        $action_type = isset($_POST['approve_request']) ? 'approve' : 'reject';
        $remarks = sanitize($_POST['remarks'] ?? '');
        
        if (processApproval($request_id, $action_type, $user_role, $user_id, $remarks)) {
            $message = "Request " . ($action_type == 'approve' ? 'approved' : 'rejected') . " successfully!";
            $message_type = 'success';
            
            // If admin approves, generate certificate
            if ($action_type == 'approve' && $user_role == 'admin') {
                $certificate_id = generateCertificateFromRequest($request_id);
                if ($certificate_id) {
                    $message .= " Certificate generated!";
                }
            }
        } else {
            $message = "Failed to process request.";
            $message_type = 'error';
        }
    }
    
    // ADMIN: Delete certificate
    if (isset($_POST['delete_certificate']) && $user_role == 'admin') {
        $cert_id = intval($_POST['certificate_id']);
        $query = "UPDATE bonafide_certificates SET status = 'deleted', deleted_at = NOW() WHERE id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("i", $cert_id);
        
        if ($stmt->execute()) {
            $message = "Certificate deleted successfully!";
            $message_type = 'success';
        } else {
            $message = "Failed to delete certificate.";
            $message_type = 'error';
        }
    }
    
    // Update profile (all roles)
    if (isset($_POST['update_profile'])) {
        // Update logic based on role
        if ($user_role == 'student') {
            // Update student profile
            foreach ($_POST as $key => $value) {
                if (strpos($key, 'update_') === 0) {
                    $field = str_replace('update_', '', $key);
                    $value = sanitize($value);
                    
                    // Check which table student belongs to
                    $student = getCompleteStudentProfile($user_id);
                    if (isset($student['IDNo'])) {
                        $query = "UPDATE students_login_master SET $field = ? WHERE IDNo = ?";
                    } else {
                        $query = "UPDATE students_batch_25_26 SET $field = ? WHERE id_no = ?";
                    }
                    
                    $stmt = $mysqli->prepare($query);
                    $stmt->bind_param("ss", $value, $user_id);
                    $stmt->execute();
                }
            }
        } else {
            // Update faculty profile
            foreach ($_POST as $key => $value) {
                if (strpos($key, 'update_') === 0) {
                    $field = str_replace('update_', '', $key);
                    $value = sanitize($value);
                    
                    $query = "UPDATE employee_details1 SET $field = ? WHERE ID_NO = ?";
                    $stmt = $mysqli->prepare($query);
                    $stmt->bind_param("ss", $value, $user_id);
                    $stmt->execute();
                }
            }
        }
        
        $message = "Profile updated successfully!";
        $message_type = 'success';
    }
}

// Get data based on role
$pending_requests = [];
$my_requests = [];
$certificates = [];
$student_data = null;
$faculty_data = null;

switch($user_role) {
    case 'student':
        // Get student data
        $student_data = getCompleteStudentProfile($user_id);
        $profile_complete = checkProfileCompletion($student_data);
        $missing_fields = getMissingFields($student_data);
        
        // Get student requests
        $requests_result = getStudentRequests($user_id);
        while ($row = $requests_result->fetch_assoc()) {
            $my_requests[] = $row;
        }
        
        // Get student certificates
        $certs_result = getStudentCertificates($user_id);
        while ($row = $certs_result->fetch_assoc()) {
            $certificates[] = $row;
        }
        
        // Get additional info
        $hostel_info = getHostelInfo($user_id);
        $transport_info = getTransportInfo($user_id);
        $fee_info = getFeeInfo($user_id);
        break;
        
    case 'class_advisor':
        // Get assigned students' pending requests
        $result = getRoleBasedRequests($user_role, $user_id, $user_department);
        while ($row = $result->fetch_assoc()) {
            $pending_requests[] = $row;
        }
        break;
        
    case 'hod':
        // Get department pending requests
        $result = getRoleBasedRequests($user_role, $user_id, $user_department);
        while ($row = $result->fetch_assoc()) {
            $pending_requests[] = $row;
        }
        break;
        
    case 'dean':
    case 'principal':
        // Get all pending requests
        $result = getRoleBasedRequests($user_role, $user_id);
        while ($row = $result->fetch_assoc()) {
            $pending_requests[] = $row;
        }
        break;
        
    case 'admin':
        // Get all pending requests
        $result = getRoleBasedRequests($user_role, $user_id);
        while ($row = $result->fetch_assoc()) {
            $pending_requests[] = $row;
        }
        
        // Get all certificates for admin
        $search = $_GET['search'] ?? '';
        $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        $cert_query = "SELECT c.*, br.student_name as request_student 
                      FROM bonafide_certificates c
                      LEFT JOIN bonafide_requests br ON c.requestid = br.id
                      WHERE c.status != 'deleted'";
        
        if (!empty($search)) {
            $cert_query .= " AND (c.student_name LIKE '%$search%' OR 
                                 c.ref_number LIKE '%$search%' OR 
                                 c.register_number LIKE '%$search%')";
        }
        
        $cert_query .= " ORDER BY c.created_at DESC LIMIT $limit OFFSET $offset";
        $cert_result = $mysqli->query($cert_query);
        while ($row = $cert_result->fetch_assoc()) {
            $certificates[] = $row;
        }
        
        // Get total count for pagination
        $count_query = "SELECT COUNT(*) as total FROM bonafide_certificates WHERE status != 'deleted'";
        if (!empty($search)) {
            $count_query .= " AND (student_name LIKE '%$search%' OR ref_number LIKE '%$search%' OR register_number LIKE '%$search%')";
        }
        $count_result = $mysqli->query($count_query);
        $total_count = $count_result->fetch_assoc()['total'];
        $total_pages = ceil($total_count / $limit);
        break;
}

// For student preview
$demo_data = null;
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['preview']) && $user_role == 'student') {
    $demo_data = [
        'type' => $_POST['bonafide_type'] ?? 'General',
        'purpose' => $_POST['purpose'] ?? 'General Purpose',
        'student_name' => $user_name,
        'register_no' => $student_data['RegisterNo'] ?? $student_data['id_no'],
        'department' => $student_data['Dept'] ?? $student_data['department'],
        'batch' => $student_data['Batch'] ?? $student_data['batch'],
        'date' => date('d-m-Y'),
        'additional_info' => $_POST['additional_info'] ?? ''
    ];
}

// Get role icon
function getRoleIcon($role) {
    $icons = [
        'student' => 'fas fa-user-graduate',
        'class_advisor' => 'fas fa-chalkboard-teacher',
        'hod' => 'fas fa-user-tie',
        'dean' => 'fas fa-user-graduate',
        'principal' => 'fas fa-crown',
        'admin' => 'fas fa-user-cog'
    ];
    return $icons[$role] ?? 'fas fa-user';
}

// Get role color
function getRoleColor($role) {
    $colors = [
        'student' => 'info',
        'class_advisor' => 'primary',
        'hod' => 'warning',
        'dean' => 'success',
        'principal' => 'danger',
        'admin' => 'dark'
    ];
    return $colors[$role] ?? 'secondary';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ucfirst($user_role); ?> Dashboard - Bonafide System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* INSTAGRAM GRADIENT THEME */
        :root {
            --insta-gradient: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
            --gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --gradient-success: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            --gradient-warning: linear-gradient(135deg, #f6d365 0%, #fda085 100%);
            --gradient-danger: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }
        
        .glass-container {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-radius: 25px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 25px 50px rgba(0,0,0,0.3);
            overflow: hidden;
            margin: 20px;
            min-height: 90vh;
        }
        
        .gradient-header {
            background: var(--insta-gradient);
            color: white;
            padding: 30px;
            position: relative;
            overflow: hidden;
        }
        
        .gradient-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><path d="M0,0 L100,0 L100,100 Z" fill="rgba(255,255,255,0.1)"/></svg>');
            background-size: cover;
        }
        
        .insta-gradient-text {
            background: var(--insta-gradient);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            font-weight: 800;
        }
        
        .role-badge {
            background: rgba(255, 255, 255, 0.2);
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: 50px;
            padding: 8px 20px;
            font-size: 14px;
            font-weight: bold;
            backdrop-filter: blur(10px);
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .card-glass {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
        }
        
        .card-glass:hover {
            transform: translateY(-5px);
            box-shadow: 0 25px 50px rgba(0,0,0,0.15);
        }
        
        .btn-insta {
            background: var(--insta-gradient);
            border: none;
            color: white;
            padding: 12px 30px;
            border-radius: 25px;
            font-weight: 700;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        
        .btn-insta::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: 0.5s;
        }
        
        .btn-insta:hover::before {
            left: 100%;
        }
        
        .btn-insta:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(220, 39, 67, 0.4);
        }
        
        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s;
            border-top: 5px solid;
            height: 100%;
        }
        
        .stats-card:hover {
            transform: translateY(-10px);
        }
        
        .stats-card.pending { border-color: #ffc107; }
        .stats-card.approved { border-color: #28a745; }
        .stats-card.rejected { border-color: #dc3545; }
        .stats-card.certificates { border-color: #6f42c1; }
        
        .stats-icon {
            font-size: 40px;
            margin-bottom: 15px;
            opacity: 0.8;
        }
        
        .request-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
            border-left: 5px solid #ffc107;
            transition: all 0.3s;
        }
        
        .request-card:hover {
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
            transform: translateY(-5px);
        }
        
        .approval-chain {
            display: flex;
            justify-content: space-between;
            margin: 15px 0;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        
        .approval-step {
            text-align: center;
            flex: 1;
            padding: 0 10px;
        }
        
        .step-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 10px;
            font-size: 18px;
        }
        
        .step-pending { background: #ffecb3; color: #ff8f00; }
        .step-approved { background: #c8e6c9; color: #2e7d32; }
        .step-rejected { background: #ffcdd2; color: #c62828; }
        
        .certificate-preview {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
            min-height: 400px;
            position: relative;
            overflow: hidden;
        }
        
        .certificate-preview::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: var(--insta-gradient);
        }
        
        .certificate-template {
            border: 2px dashed #dc2743;
            padding: 25px;
            background: #f8f9fa;
            font-family: 'Times New Roman', serif;
            position: relative;
        }
        
        .floating-action-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: var(--insta-gradient);
            color: white;
            border: none;
            box-shadow: 0 10px 25px rgba(220, 39, 67, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            cursor: pointer;
            z-index: 1000;
            transition: all 0.3s;
        }
        
        .floating-action-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 15px 35px rgba(220, 39, 67, 0.6);
        }
        
        .form-control, .form-select {
            border-radius: 15px;
            border: 2px solid #e2e8f0;
            padding: 12px 15px;
            font-size: 14px;
            transition: all 0.3s;
            background: rgba(255, 255, 255, 0.9);
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #bc1888;
            box-shadow: 0 0 0 3px rgba(188, 24, 136, 0.1);
            background: white;
        }
        
        .nav-tabs-instagram .nav-link {
            border: none;
            color: #666;
            font-weight: 600;
            padding: 15px 25px;
            border-radius: 15px 15px 0 0;
            background: rgba(255, 255, 255, 0.5);
        }
        
        .nav-tabs-instagram .nav-link.active {
            background: white;
            color: #bc1888;
            border-bottom: 3px solid #bc1888;
        }
        
        .qr-preview {
            width: 120px;
            height: 120px;
            background: white;
            border-radius: 10px;
            padding: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin: 0 auto;
        }
        
        @media (max-width: 768px) {
            .glass-container {
                margin: 10px;
                border-radius: 15px;
            }
            
            .gradient-header {
                padding: 20px;
            }
            
            .floating-action-btn {
                bottom: 20px;
                right: 20px;
                width: 50px;
                height: 50px;
            }
            
            .approval-chain {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="glass-container">
        <!-- Header -->
        <div class="gradient-header">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="display-5 fw-bold mb-3">
                        <i class="<?php echo getRoleIcon($user_role); ?>"></i> Bonafide Dashboard
                    </h1>
                    <div class="d-flex align-items-center gap-3">
                        <div>
                            <h4 class="mb-1 text-white"><?php echo htmlspecialchars($user_name); ?></h4>
                            <p class="mb-0 opacity-90">
                                <?php 
                                if ($user_role == 'student') {
                                    echo htmlspecialchars($student_data['RegisterNo'] ?? $student_data['id_no'] ?? '');
                                } else {
                                    echo htmlspecialchars($user_designation);
                                    if ($user_department) echo " | " . htmlspecialchars($user_department);
                                }
                                ?>
                            </p>
                        </div>
                        <span class="role-badge">
                            <i class="<?php echo getRoleIcon($user_role); ?>"></i>
                            <?php echo strtoupper(str_replace('_', ' ', $user_role)); ?>
                        </span>
                    </div>
                </div>
                <div class="col-md-4 text-end">
                    <div class="d-flex align-items-center justify-content-end gap-2">
                        <a href="../index.php" class="btn btn-outline-light btn-sm">
                            <i class="fas fa-home"></i>
                        </a>
                        <a href="logout.php" class="btn btn-light btn-sm">
                            <i class="fas fa-sign-out-alt me-1"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="container-fluid p-4">
            <?php if($message): ?>
                <div class="alert alert-<?php echo $message_type == 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Quick Stats (For all roles except student) -->
            <?php if($user_role != 'student'): ?>
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="stats-card pending">
                        <div class="stats-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <h3 class="fw-bold"><?php echo count($pending_requests); ?></h3>
                        <p class="text-muted mb-0">Pending Requests</p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stats-card approved">
                        <div class="stats-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <h3 class="fw-bold">
                            <?php 
                            $query = "SELECT COUNT(*) as count FROM bonafide_requests WHERE status = 'approved'";
                            if ($user_role == 'hod') {
                                $query .= " AND department = '$user_department'";
                            } elseif ($user_role == 'class_advisor') {
                                $query .= " AND student_id IN (SELECT IDNo FROM students_login_master WHERE class_advisor = '$user_id')";
                            }
                            $result = $mysqli->query($query);
                            echo $result->fetch_assoc()['count'];
                            ?>
                        </h3>
                        <p class="text-muted mb-0">Approved Requests</p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stats-card rejected">
                        <div class="stats-icon">
                            <i class="fas fa-times-circle"></i>
                        </div>
                        <h3 class="fw-bold">
                            <?php 
                            $query = "SELECT COUNT(*) as count FROM bonafide_requests WHERE status = 'rejected'";
                            if ($user_role == 'hod') {
                                $query .= " AND department = '$user_department'";
                            } elseif ($user_role == 'class_advisor') {
                                $query .= " AND student_id IN (SELECT IDNo FROM students_login_master WHERE class_advisor = '$user_id')";
                            }
                            $result = $mysqli->query($query);
                            echo $result->fetch_assoc()['count'];
                            ?>
                        </h3>
                        <p class="text-muted mb-0">Rejected Requests</p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stats-card certificates">
                        <div class="stats-icon">
                            <i class="fas fa-certificate"></i>
                        </div>
                        <h3 class="fw-bold">
                            <?php 
                            if ($user_role == 'admin') {
                                echo $total_count ?? 0;
                            } else {
                                $query = "SELECT COUNT(*) as count FROM bonafide_certificates WHERE status = 'approved'";
                                if ($user_role == 'hod') {
                                    $query .= " AND department = '$user_department'";
                                }
                                $result = $mysqli->query($query);
                                echo $result->fetch_assoc()['count'];
                            }
                            ?>
                        </h3>
                        <p class="text-muted mb-0">Total Certificates</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Tabs Navigation -->
            <ul class="nav nav-tabs-instagram mb-4" id="dashboardTab">
                <?php if($user_role == 'student'): ?>
                    <li class="nav-item">
                        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#request-tab">
                            <i class="fas fa-file-alt me-2"></i> New Request
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#myrequests-tab">
                            <i class="fas fa-history me-2"></i> My Requests
                            <span class="badge bg-primary ms-2"><?php echo count($my_requests); ?></span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#certificates-tab">
                            <i class="fas fa-certificate me-2"></i> My Certificates
                            <span class="badge bg-success ms-2"><?php echo count($certificates); ?></span>
                        </button>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#pending-tab">
                            <i class="fas fa-tasks me-2"></i> Pending Requests
                            <span class="badge bg-warning ms-2"><?php echo count($pending_requests); ?></span>
                        </button>
                    </li>
                    <?php if(in_array($user_role, ['admin', 'principal'])): ?>
                    <li class="nav-item">
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#allcertificates-tab">
                            <i class="fas fa-certificate me-2"></i> All Certificates
                            <span class="badge bg-primary ms-2"><?php echo $total_count ?? 0; ?></span>
                        </button>
                    </li>
                    <?php endif; ?>
                <?php endif; ?>
                <li class="nav-item">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-tab">
                        <i class="fas fa-user me-2"></i> My Profile
                    </button>
                </li>
            </ul>

            <!-- Tab Content -->
            <div class="tab-content">
                <!-- STUDENT: New Request Tab -->
                <?php if($user_role == 'student'): ?>
                <div class="tab-pane fade show active" id="request-tab">
                    <?php if(!$profile_complete): ?>
                        <!-- Profile Completion Required -->
                        <div class="card-glass p-4">
                            <div class="alert alert-warning">
                                <h4><i class="fas fa-user-edit me-2"></i> Complete Your Profile</h4>
                                <p>Please complete your profile to submit bonafide requests.</p>
                            </div>
                            
                            <form method="POST">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Father's Name *</label>
                                        <input type="text" name="update_fathername" class="form-control" 
                                               value="<?php echo htmlspecialchars($student_data['fathername'] ?? $student_data['parent_name'] ?? ''); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Gender *</label>
                                        <select name="update_Gender" class="form-select" required>
                                            <option value="">Select Gender</option>
                                            <option value="Male" <?php echo (($student_data['Gender'] ?? $student_data['gender'] ?? '') == 'Male') ? 'selected' : ''; ?>>Male</option>
                                            <option value="Female" <?php echo (($student_data['Gender'] ?? $student_data['gender'] ?? '') == 'Female') ? 'selected' : ''; ?>>Female</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Batch *</label>
                                        <input type="text" name="update_Batch" class="form-control" 
                                               value="<?php echo htmlspecialchars($student_data['Batch'] ?? $student_data['batch'] ?? ''); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Department *</label>
                                        <input type="text" name="update_Dept" class="form-control" 
                                               value="<?php echo htmlspecialchars($student_data['Dept'] ?? $student_data['department'] ?? ''); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Mobile Number *</label>
                                        <input type="tel" name="update_student_mobile" class="form-control" 
                                               value="<?php echo htmlspecialchars($student_data['student_mobile'] ?? $student_data['Student_contact'] ?? ''); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Email *</label>
                                        <input type="email" name="update_college_email" class="form-control" 
                                               value="<?php echo htmlspecialchars($student_data['college_email'] ?? ''); ?>" required>
                                    </div>
                                    <div class="col-12 mb-3">
                                        <label class="form-label">Address *</label>
                                        <textarea name="update_Address" class="form-control" rows="3" required><?php echo htmlspecialchars($student_data['Address'] ?? $student_data['address'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                                <div class="d-grid gap-2">
                                    <button type="submit" name="update_profile" class="btn-insta">
                                        <i class="fas fa-save me-2"></i> Save Profile
                                    </button>
                                </div>
                            </form>
                        </div>
                    <?php else: ?>
                    <div class="row">
                        <!-- Left Column - Request Form -->
                        <div class="col-lg-6 mb-4">
                            <div class="card-glass p-4 h-100">
                                <h4 class="mb-4 insta-gradient-text">
                                    <i class="fas fa-file-alt me-2"></i> New Bonafide Request
                                </h4>
                                
                                <form method="POST" id="requestForm">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Certificate Type</label>
                                        <select name="bonafide_type" class="form-select" onchange="updatePreview()" required>
                                            <option value="">Select Type</option>
                                            <option value="Study Certificate">Study Certificate</option>
                                            <option value="Fee Paid Certificate">Fee Paid Certificate</option>
                                            <option value="Fee Structure">Fee Structure</option>
                                            <option value="Conduct Certificate">Conduct Certificate</option>
                                            <option value="Course Completion">Course Completion</option>
                                            <option value="Internship">Internship</option>
                                            <option value="Bonafide">General Bonafide</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Purpose</label>
                                        <select name="purpose" class="form-select" onchange="updatePreview()" required>
                                            <option value="">Select Purpose</option>
                                            <option value="Passport Application">Passport Application</option>
                                            <option value="Visa Application">Visa Application</option>
                                            <option value="Bank Loan">Bank Loan</option>
                                            <option value="Scholarship">Scholarship</option>
                                            <option value="Higher Studies">Higher Studies</option>
                                            <option value="Internship">Internship Requirement</option>
                                            <option value="Competition">Competition</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Additional Information</label>
                                        <textarea name="additional_info" class="form-control" rows="3" 
                                                  placeholder="Any specific requirements..." 
                                                  oninput="updatePreview()"></textarea>
                                    </div>
                                    
                                    <div class="d-grid gap-2">
                                        <button type="submit" name="preview" class="btn btn-outline-primary">
                                            <i class="fas fa-eye me-2"></i> Preview Certificate
                                        </button>
                                        <button type="submit" name="submit_request" class="btn-insta">
                                            <i class="fas fa-paper-plane me-2"></i> Submit Request
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <!-- Right Column - Live Preview -->
                        <div class="col-lg-6 mb-4">
                            <div class="certificate-preview">
                                <h4 class="mb-4 insta-gradient-text">
                                    <i class="fas fa-tv me-2"></i> Live Certificate Preview
                                </h4>
                                
                                <div id="previewContent">
                                    <?php if($demo_data): ?>
                                        <div class="certificate-template">
                                            <div class="certificate-watermark">DRAFT</div>
                                            
                                            <div class="text-center mb-4">
                                                <h3 class="fw-bold text-primary">VEL TECH HIGH TECH</h3>
                                                <h5>Dr. Rangarajan Dr. Sakunthala Engineering College</h5>
                                                <h4 class="mt-3 fw-bold">BONAFIDE CERTIFICATE</h4>
                                            </div>
                                            
                                            <div class="certificate-body">
                                                <p>This is to certify that <strong><?php echo htmlspecialchars($demo_data['student_name']); ?></strong>
                                                (Reg. No: <strong><?php echo htmlspecialchars($demo_data['register_no']); ?></strong>) is a bonafide student of 
                                                Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College.</p>
                                                
                                                <p>The student is pursuing <?php echo htmlspecialchars($demo_data['batch']); ?> batch in the Department of 
                                                <?php echo htmlspecialchars($demo_data['department']); ?>.</p>
                                                
                                                <p>This certificate is issued for the purpose of <strong><?php echo htmlspecialchars($demo_data['purpose']); ?></strong> 
                                                and is valid for official use.</p>
                                                
                                                <?php if(!empty($demo_data['additional_info'])): ?>
                                                <p><strong>Additional Information:</strong> <?php echo htmlspecialchars($demo_data['additional_info']); ?></p>
                                                <?php endif; ?>
                                                
                                                <div class="mt-5 pt-4 text-end">
                                                    <p>Date: <?php echo htmlspecialchars($demo_data['date']); ?></p>
                                                    <p><strong>PRINCIPAL</strong></p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-center py-5">
                                            <i class="fas fa-file-alt fa-4x text-muted mb-3"></i>
                                            <h5 class="text-muted">Preview Area</h5>
                                            <p class="text-muted">Fill the form to see certificate preview</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- STUDENT: My Requests Tab -->
                <div class="tab-pane fade" id="myrequests-tab">
                    <?php if(empty($my_requests)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                            <h5>No Requests Found</h5>
                            <p class="text-muted">Submit your first bonafide request.</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Type</th>
                                        <th>Purpose</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Current Stage</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($my_requests as $request): ?>
                                    <tr>
                                        <td><strong>BON-<?php echo $request['id']; ?></strong></td>
                                        <td><?php echo htmlspecialchars($request['bonafide_type']); ?></td>
                                        <td><?php echo htmlspecialchars(substr($request['purpose'], 0, 25)); ?>...</td>
                                        <td><?php echo date('d M Y', strtotime($request['request_date'])); ?></td>
                                        <td>
                                            <?php 
                                            $status = getRequestStatus($request);
                                            ?>
                                            <span class="badge bg-<?php echo $status['color']; ?>">
                                                <?php echo $status['text']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?php 
                                                if($request['advisor_status'] == 'pending') echo 'With Class Advisor';
                                                elseif($request['hod_status'] == 'pending') echo 'With HOD';
                                                elseif($request['dean_status'] == 'pending') echo 'With Dean';
                                                elseif($request['admin_status'] == 'pending') echo 'With Admin';
                                                else echo 'Completed';
                                                ?>
                                            </small>
                                        </td>
                                        <td>
                                            <?php if($request['advisor_status'] == 'pending'): ?>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="revoke_id" value="<?php echo $request['id']; ?>">
                                                <button type="submit" name="revoke_request" 
                                                        class="btn btn-sm btn-outline-danger" 
                                                        onclick="return confirm('Are you sure you want to revoke this request?');">
                                                    <i class="fas fa-times"></i> Revoke
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                            <button class="btn btn-sm btn-outline-primary" 
                                                    onclick="viewRequestDetails(<?php echo $request['id']; ?>)">
                                                <i class="fas fa-eye"></i> View
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- STUDENT: My Certificates Tab -->
                <div class="tab-pane fade" id="certificates-tab">
                    <?php if(empty($certificates)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-certificate fa-3x text-muted mb-3"></i>
                            <h5>No Certificates Found</h5>
                            <p class="text-muted">Your approved certificates will appear here.</p>
                        </div>
                    <?php else: ?>
                        <div class="row">
                            <?php foreach($certificates as $cert): ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="card-glass p-3">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <div>
                                            <h6 class="fw-bold mb-0"><?php echo htmlspecialchars($cert['certificate_type']); ?></h6>
                                            <small class="text-muted">Ref: <?php echo htmlspecialchars($cert['ref_number']); ?></small>
                                        </div>
                                        <span class="badge bg-success">Approved</span>
                                    </div>
                                    
                                    <div class="qr-preview mb-3">
                                        <?php if($cert['qr_code_path']): ?>
                                            <img src="../<?php echo htmlspecialchars($cert['qr_code_path']); ?>" alt="QR Code" class="w-100">
                                        <?php else: ?>
                                            <div class="text-center text-muted small">
                                                <i class="fas fa-qrcode fa-2x mb-2"></i><br>
                                                QR Code
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <p class="small mb-2">
                                        <i class="fas fa-calendar me-2"></i>
                                        <?php echo date('d M Y', strtotime($cert['bonafide_date'])); ?>
                                    </p>
                                    
                                    <div class="d-grid gap-2">
                                        <a href="../print_bonafide.php?id=<?php echo $cert['id']; ?>" 
                                           class="btn-insta btn-sm" target="_blank">
                                            <i class="fas fa-print me-1"></i> Print Certificate
                                        </a>
                                        <a href="../verify.php?ref=<?php echo urlencode($cert['ref_number']); ?>" 
                                           class="btn btn-outline-secondary btn-sm" target="_blank">
                                            <i class="fas fa-shield-alt me-1"></i> Verify Online
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- FACULTY/ADMIN: Pending Requests Tab -->
                <?php else: ?>
                <div class="tab-pane fade show active" id="pending-tab">
                    <?php if(empty($pending_requests)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                            <h4>All Caught Up!</h4>
                            <p class="text-muted">No pending requests require your attention.</p>
                        </div>
                    <?php else: ?>
                        <div class="row">
                            <?php foreach($pending_requests as $request): ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="request-card">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <div>
                                            <h6 class="fw-bold mb-1"><?php echo htmlspecialchars($request['Name'] ?? $request['student_name']); ?></h6>
                                            <p class="small text-muted mb-0">
                                                <?php echo htmlspecialchars($request['RegisterNo'] ?? $request['register_number']); ?> | 
                                                <?php echo htmlspecialchars($request['Dept'] ?? $request['department']); ?>
                                            </p>
                                        </div>
                                        <span class="badge bg-warning">Pending</span>
                                    </div>
                                    
                                    <p class="mb-2">
                                        <strong>Type:</strong> <?php echo htmlspecialchars($request['bonafide_type']); ?>
                                    </p>
                                    
                                    <p class="mb-3">
                                        <strong>Purpose:</strong> <?php echo htmlspecialchars(substr($request['purpose'], 0, 50)); ?>...
                                    </p>
                                    
                                    <div class="approval-chain">
                                        <div class="approval-step">
                                            <div class="step-icon <?php echo 'step-' . $request['advisor_status']; ?>">
                                                <i class="fas fa-user"></i>
                                            </div>
                                            <small>Advisor</small>
                                            <div class="small"><?php echo ucfirst($request['advisor_status']); ?></div>
                                        </div>
                                        
                                        <div class="approval-step">
                                            <div class="step-icon <?php echo 'step-' . $request['hod_status']; ?>">
                                                <i class="fas fa-user-tie"></i>
                                            </div>
                                            <small>HOD</small>
                                            <div class="small"><?php echo ucfirst($request['hod_status']); ?></div>
                                        </div>
                                        
                                        <div class="approval-step">
                                            <div class="step-icon <?php echo 'step-' . $request['dean_status']; ?>">
                                                <i class="fas fa-user-graduate"></i>
                                            </div>
                                            <small>Dean</small>
                                            <div class="small"><?php echo ucfirst($request['dean_status']); ?></div>
                                        </div>
                                        
                                        <div class="approval-step">
                                            <div class="step-icon <?php echo 'step-' . $request['admin_status']; ?>">
                                                <i class="fas fa-user-cog"></i>
                                            </div>
                                            <small>Admin</small>
                                            <div class="small"><?php echo ucfirst($request['admin_status']); ?></div>
                                        </div>
                                    </div>
                                    
                                    <div class="d-grid gap-2 mt-3">
                                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#approveModal<?php echo $request['id']; ?>">
                                            <i class="fas fa-check me-2"></i>Approve
                                        </button>
                                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal<?php echo $request['id']; ?>">
                                            <i class="fas fa-times me-2"></i>Reject
                                        </button>
                                        <a href="request_details.php?id=<?php echo $request['id']; ?>" class="btn btn-outline-primary">
                                            <i class="fas fa-eye me-2"></i>View Details
                                        </a>
                                    </div>
                                </div>
                                
                                <!-- Approve Modal -->
                                <div class="modal fade" id="approveModal<?php echo $request['id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header" style="background: var(--insta-gradient); color: white;">
                                                <h5 class="modal-title">Approve Request</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <form method="POST">
                                                <div class="modal-body">
                                                    <p>Are you sure you want to approve this request?</p>
                                                    <div class="mb-3">
                                                        <label class="form-label">Remarks (Optional)</label>
                                                        <textarea name="remarks" class="form-control" rows="3" placeholder="Add remarks..."></textarea>
                                                    </div>
                                                    <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" name="approve_request" class="btn-insta">Approve Request</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Reject Modal -->
                                <div class="modal fade" id="rejectModal<?php echo $request['id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header" style="background: var(--gradient-danger); color: white;">
                                                <h5 class="modal-title">Reject Request</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                            </div>
                                            <form method="POST">
                                                <div class="modal-body">
                                                    <p>Please provide a reason for rejection:</p>
                                                    <div class="mb-3">
                                                        <label class="form-label">Reason for Rejection *</label>
                                                        <textarea name="remarks" class="form-control" rows="3" required placeholder="Enter reason..."></textarea>
                                                    </div>
                                                    <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" name="reject_request" class="btn-insta" style="background: var(--gradient-danger);">Reject Request</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- ADMIN/PRINCIPAL: All Certificates Tab -->
                <?php if(in_array($user_role, ['admin', 'principal'])): ?>
                <div class="tab-pane fade" id="allcertificates-tab">
                    <div class="card-glass p-4">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4 class="mb-0 insta-gradient-text">
                                <i class="fas fa-certificate me-2"></i> All Certificates
                            </h4>
                            <form method="GET" class="d-flex">
                                <input type="text" name="search" class="form-control me-2" 
                                       placeholder="Search by name, ref no, or reg no..." 
                                       value="<?php echo htmlspecialchars($search ?? ''); ?>">
                                <button type="submit" class="btn-insta">
                                    <i class="fas fa-search"></i>
                                </button>
                            </form>
                        </div>
                        
                        <?php if(empty($certificates)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-certificate fa-3x text-muted mb-3"></i>
                                <h5>No Certificates Found</h5>
                                <p class="text-muted"><?php echo !empty($search) ? 'Try a different search term' : 'No certificates have been issued yet.'; ?></p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Ref No</th>
                                            <th>Student</th>
                                            <th>Type</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th>QR Code</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($certificates as $cert): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo htmlspecialchars($cert['ref_number']); ?></strong>
                                            </td>
                                            <td>
                                                <div class="fw-bold"><?php echo htmlspecialchars($cert['student_name']); ?></div>
                                                <small class="text-muted"><?php echo htmlspecialchars($cert['register_number']); ?></small>
                                            </td>
                                            <td><?php echo htmlspecialchars($cert['certificate_type']); ?></td>
                                            <td><?php echo date('d M Y', strtotime($cert['bonafide_date'])); ?></td>
                                            <td>
                                                <span class="badge bg-success">Approved</span>
                                            </td>
                                            <td>
                                                <div class="qr-preview" style="width: 80px; height: 80px;">
                                                    <?php if($cert['qr_code_path']): ?>
                                                        <img src="../<?php echo htmlspecialchars($cert['qr_code_path']); ?>" 
                                                             alt="QR Code" style="max-width: 100%;">
                                                    <?php else: ?>
                                                        <div class="text-center text-muted small">QR</div>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="../print_bonafide.php?id=<?php echo $cert['id']; ?>" 
                                                       target="_blank" class="btn btn-sm btn-primary">
                                                        <i class="fas fa-print"></i>
                                                    </a>
                                                    <a href="../verify.php?ref=<?php echo urlencode($cert['ref_number']); ?>" 
                                                       target="_blank" class="btn btn-sm btn-info">
                                                        <i class="fas fa-shield-alt"></i>
                                                    </a>
                                                    <?php if($user_role == 'admin'): ?>
                                                    <button type="button" class="btn btn-sm btn-danger" 
                                                            data-bs-toggle="modal" 
                                                            data-bs-target="#deleteModal<?php echo $cert['id']; ?>">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        
                                        <!-- Delete Modal (Admin only) -->
                                        <?php if($user_role == 'admin'): ?>
                                        <div class="modal fade" id="deleteModal<?php echo $cert['id']; ?>" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header" style="background: var(--gradient-danger); color: white;">
                                                        <h5 class="modal-title">Delete Certificate</h5>
                                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <form method="POST">
                                                        <div class="modal-body">
                                                            <div class="alert alert-warning">
                                                                <i class="fas fa-exclamation-triangle me-2"></i>
                                                                <strong>Warning:</strong> This action cannot be undone.
                                                            </div>
                                                            <p>Are you sure you want to delete certificate <strong><?php echo htmlspecialchars($cert['ref_number']); ?></strong>?</p>
                                                            <input type="hidden" name="certificate_id" value="<?php echo $cert['id']; ?>">
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" name="delete_certificate" class="btn-insta" style="background: var(--gradient-danger);">Delete</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Pagination -->
                            <?php if(isset($total_pages) && $total_pages > 1): ?>
                            <nav aria-label="Page navigation" class="mt-4">
                                <ul class="pagination justify-content-center">
                                    <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search ?? ''); ?>">
                                            <i class="fas fa-chevron-left"></i>
                                        </a>
                                    </li>
                                    
                                    <?php 
                                    $start = max(1, $page - 2);
                                    $end = min($total_pages, $page + 2);
                                    
                                    for ($i = $start; $i <= $end; $i++): 
                                    ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search ?? ''); ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                    <?php endfor; ?>
                                    
                                    <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search ?? ''); ?>">
                                            <i class="fas fa-chevron-right"></i>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
                <?php endif; ?>

                <!-- Profile Tab (All Roles) -->
                <div class="tab-pane fade" id="profile-tab">
                    <div class="card-glass p-4">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="text-center mb-4">
                                    <div class="mb-3">
                                        <i class="fas fa-user-circle fa-5x text-primary"></i>
                                    </div>
                                    <h4 class="insta-gradient-text"><?php echo htmlspecialchars($user_name); ?></h4>
                                    <span class="badge bg-<?php echo getRoleColor($user_role); ?>">
                                        <?php echo strtoupper(str_replace('_', ' ', $user_role)); ?>
                                    </span>
                                </div>
                                
                                <div class="list-group">
                                    <a href="#" class="list-group-item list-group-item-action" onclick="switchTab('profile-tab')">
                                        <i class="fas fa-user me-2"></i> Personal Information
                                    </a>
                                    <?php if($user_role == 'student'): ?>
                                    <a href="#" class="list-group-item list-group-item-action" onclick="switchTab('request-tab')">
                                        <i class="fas fa-file-alt me-2"></i> New Request
                                    </a>
                                    <a href="#" class="list-group-item list-group-item-action" onclick="switchTab('myrequests-tab')">
                                        <i class="fas fa-history me-2"></i> My Requests
                                    </a>
                                    <a href="#" class="list-group-item list-group-item-action" onclick="switchTab('certificates-tab')">
                                        <i class="fas fa-certificate me-2"></i> My Certificates
                                    </a>
                                    <?php else: ?>
                                    <a href="#" class="list-group-item list-group-item-action" onclick="switchTab('pending-tab')">
                                        <i class="fas fa-tasks me-2"></i> Pending Requests
                                    </a>
                                    <?php if(in_array($user_role, ['admin', 'principal'])): ?>
                                    <a href="#" class="list-group-item list-group-item-action" onclick="switchTab('allcertificates-tab')">
                                        <i class="fas fa-certificate me-2"></i> All Certificates
                                    </a>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <a href="logout.php" class="list-group-item list-group-item-action text-danger">
                                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                                    </a>
                                </div>
                            </div>
                            
                            <div class="col-md-8">
                                <h4 class="mb-4 insta-gradient-text">Profile Information</h4>
                                
                                <?php if($user_role == 'student'): ?>
                                <!-- Student Profile -->
                                <table class="table table-bordered">
                                    <tr><th>Register Number:</th><td><?php echo htmlspecialchars($student_data['RegisterNo'] ?? $student_data['id_no'] ?? 'N/A'); ?></td></tr>
                                    <tr><th>Department:</th><td><?php echo htmlspecialchars($student_data['Dept'] ?? $student_data['department'] ?? 'N/A'); ?></td></tr>
                                    <tr><th>Batch:</th><td><?php echo htmlspecialchars($student_data['Batch'] ?? $student_data['batch'] ?? 'N/A'); ?></td></tr>
                                    <tr><th>Gender:</th><td><?php echo htmlspecialchars($student_data['Gender'] ?? $student_data['gender'] ?? 'N/A'); ?></td></tr>
                                    <tr><th>Father's Name:</th><td><?php echo htmlspecialchars($student_data['fathername'] ?? $student_data['parent_name'] ?? 'N/A'); ?></td></tr>
                                    <tr><th>Email:</th><td><?php echo htmlspecialchars($student_data['college_email'] ?? 'N/A'); ?></td></tr>
                                    <tr><th>Mobile:</th><td><?php echo htmlspecialchars($student_data['student_mobile'] ?? $student_data['Student_contact'] ?? 'N/A'); ?></td></tr>
                                    <tr><th>Address:</th><td><?php echo htmlspecialchars($student_data['Address'] ?? $student_data['address'] ?? 'N/A'); ?></td></tr>
                                </table>
                                
                                <?php if($hostel_info): ?>
                                <div class="alert alert-info mt-3">
                                    <i class="fas fa-bed me-2"></i>
                                    <strong>Hostel:</strong> <?php echo $hostel_info['hostel_name']; ?> - Room <?php echo $hostel_info['room_no']; ?>
                                </div>
                                <?php endif; ?>
                                
                                <?php if($transport_info): ?>
                                <div class="alert alert-warning mt-2">
                                    <i class="fas fa-bus me-2"></i>
                                    <strong>Transport:</strong> Route <?php echo $transport_info['route_no']; ?> - 
                                    <?php echo $transport_info['pickup_point']; ?>
                                </div>
                                <?php endif; ?>
                                
                                <?php if($fee_info): ?>
                                <div class="alert alert-success mt-2">
                                    <i class="fas fa-rupee-sign me-2"></i>
                                    <strong>Fee Details:</strong> Scholarship - <?php echo $fee_info['scholarship_type'] ?? 'None'; ?>
                                </div>
                                <?php endif; ?>
                                
                                <?php else: ?>
                                <!-- Faculty/Admin Profile -->
                                <table class="table table-bordered">
                                    <tr><th>Employee ID:</th><td><?php echo htmlspecialchars($user_id); ?></td></tr>
                                    <tr><th>Designation:</th><td><?php echo htmlspecialchars($user_designation); ?></td></tr>
                                    <tr><th>Department:</th><td><?php echo htmlspecialchars($user_department); ?></td></tr>
                                    <tr><th>Role:</th><td><?php echo strtoupper(str_replace('_', ' ', $user_role)); ?></td></tr>
                                    <tr><th>Last Login:</th><td>
                                        <?php 
                                        $query = "SELECT last_login FROM employee_details1 WHERE ID_NO = '$user_id'";
                                        $result = $mysqli->query($query);
                                        if ($row = $result->fetch_assoc()) {
                                            echo $row['last_login'] ? date('d M Y, h:i A', strtotime($row['last_login'])) : 'First login';
                                        }
                                        ?>
                                    </td></tr>
                                </table>
                                <?php endif; ?>
                                
                                <div class="mt-4">
                                    <button class="btn-insta" data-bs-toggle="modal" data-bs-target="#editProfileModal">
                                        <i class="fas fa-edit me-2"></i> Edit Profile
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="border-top p-4 text-center text-muted bg-light">
            <p class="mb-0">
                <i class="fas fa-shield-alt me-1"></i> Bonafide Management System v2.0
                <br>
                <small>© <?php echo date('Y'); ?> Vel Tech High Tech - Role: <?php echo ucfirst($user_role); ?> Panel</small>
            </p>
        </div>
    </div>

    <!-- Edit Profile Modal -->
    <div class="modal fade" id="editProfileModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header" style="background: var(--insta-gradient); color: white;">
                    <h5 class="modal-title">Edit Profile</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <?php if($user_role == 'student'): ?>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Father's Name</label>
                                <input type="text" name="update_fathername" class="form-control" 
                                       value="<?php echo htmlspecialchars($student_data['fathername'] ?? $student_data['parent_name'] ?? ''); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Gender</label>
                                <select name="update_Gender" class="form-select">
                                    <option value="">Select Gender</option>
                                    <option value="Male" <?php echo (($student_data['Gender'] ?? $student_data['gender'] ?? '') == 'Male') ? 'selected' : ''; ?>>Male</option>
                                    <option value="Female" <?php echo (($student_data['Gender'] ?? $student_data['gender'] ?? '') == 'Female') ? 'selected' : ''; ?>>Female</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Mobile Number</label>
                                <input type="tel" name="update_student_mobile" class="form-control" 
                                       value="<?php echo htmlspecialchars($student_data['student_mobile'] ?? $student_data['Student_contact'] ?? ''); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="update_college_email" class="form-control" 
                                       value="<?php echo htmlspecialchars($student_data['college_email'] ?? ''); ?>">
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Address</label>
                                <textarea name="update_Address" class="form-control" rows="3"><?php echo htmlspecialchars($student_data['Address'] ?? $student_data['address'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Mobile Number</label>
                                <input type="tel" name="update_PHONE_NO" class="form-control" 
                                       value="<?php 
                                       $query = "SELECT PHONE_NO FROM employee_details1 WHERE ID_NO = '$user_id'";
                                       $result = $mysqli->query($query);
                                       if ($row = $result->fetch_assoc()) {
                                           echo htmlspecialchars($row['PHONE_NO'] ?? '');
                                       }
                                       ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Personal Email</label>
                                <input type="email" name="update_EMAIL" class="form-control" 
                                       value="<?php 
                                       $query = "SELECT EMAIL FROM employee_details1 WHERE ID_NO = '$user_id'";
                                       $result = $mysqli->query($query);
                                       if ($row = $result->fetch_assoc()) {
                                           echo htmlspecialchars($row['EMAIL'] ?? '');
                                       }
                                       ?>">
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Address</label>
                                <textarea name="update_STAFF_ADD1" class="form-control" rows="3"><?php 
                                $query = "SELECT STAFF_ADD1 FROM employee_details1 WHERE ID_NO = '$user_id'";
                                $result = $mysqli->query($query);
                                if ($row = $result->fetch_assoc()) {
                                    echo htmlspecialchars($row['STAFF_ADD1'] ?? '');
                                }
                                ?></textarea>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_profile" class="btn-insta">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Floating Action Button -->
    <button class="floating-action-btn" onclick="scrollToTop()">
        <i class="fas fa-arrow-up"></i>
    </button>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Switch between tabs
        function switchTab(tabId) {
            const tab = document.querySelector(`[data-bs-target="#${tabId}"]`);
            if (tab) {
                new bootstrap.Tab(tab).show();
            }
        }
        
        // Scroll to top
        function scrollToTop() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
        
        // View request details
        function viewRequestDetails(requestId) {
            window.location.href = `request_details.php?id=${requestId}`;
        }
        
        // Update preview (for student)
        function updatePreview() {
            const form = document.getElementById('requestForm');
            const formData = new FormData(form);
            
            fetch('preview_ajax.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(html => {
                document.getElementById('previewContent').innerHTML = html;
            });
        }
        
        // Auto-refresh pending requests every 30 seconds for faculty/admin
        <?php if($user_role != 'student'): ?>
        setInterval(() => {
            const activeTab = document.querySelector('#dashboardTab .nav-link.active');
            if (activeTab && activeTab.getAttribute('data-bs-target') === '#pending-tab') {
                window.location.reload();
            }
        }, 30000);
        <?php endif; ?>
        
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    </script>
</body>
</html>