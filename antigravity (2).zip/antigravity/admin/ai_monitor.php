<?php
require_once '../includes/config.php';
require_once '../includes/db.php';

// Authentication Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Access Denied");
}

// AJAX Handler
if (isset($_GET['ajax'])) {
    $logs = $mysqli->query("SELECT * FROM ai_live_monitor ORDER BY id DESC LIMIT 20");
    $data = [];
    while ($row = $logs->fetch_assoc()) {
        $data[] = $row;
    }
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AI Live Monitor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #1a1a1a; color: #eee; font-family: monospace; }
        .monitor-container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        .log-table { background: #000; border: 1px solid #333; }
        .log-table th { background: #333; color: #fff; }
        .log-table td { border-bottom: 1px solid #222; color: #0f0; }
        .low-conf { color: #f00 !important; }
        .timestamp { color: #888; }
        .intent-badge { padding: 2px 6px; border-radius: 4px; background: #333; color: #fff; font-size: 0.8em; }
    </style>
</head>
<body>
    <div class="monitor-container">
        <h2 class="mb-4">⚡ AI Live Monitor <small class="text-muted" style="font-size:0.6em">Updates every 3s</small></h2>
        
        <table class="table log-table table-dark table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th style="width: 40%">Question</th>
                    <th>Intent</th>
                    <th>Conf.</th>
                    <th>Time</th>
                </tr>
            </thead>
            <tbody id="logBody">
                <!-- Logs will be populated here -->
            </tbody>
        </table>
    </div>

    <script>
        function fetchLogs() {
            fetch('ai_monitor.php?ajax=1')
                .then(response => response.json())
                .then(data => {
                    const tbody = document.getElementById('logBody');
                    tbody.innerHTML = '';
                    
                    data.forEach(log => {
                        const tr = document.createElement('tr');
                        const isLowConf = parseFloat(log.confidence) < 0.5;
                        const confClass = isLowConf ? 'low-conf' : '';
                        
                        tr.innerHTML = `
                            <td>${log.id}</td>
                            <td>${log.user_id}</td>
                            <td class="${confClass}">${log.question}</td>
                            <td><span class="intent-badge">${log.intent}</span></td>
                            <td class="${confClass}">${parseFloat(log.confidence).toFixed(2)}</td>
                            <td class="timestamp">${log.created_at}</td>
                        `;
                        tbody.appendChild(tr);
                    });
                })
                .catch(err => console.error('Error fetching logs:', err));
        }

        // Initial fetch and interval
        fetchLogs();
        setInterval(fetchLogs, 3000);
    </script>
</body>
</html>
