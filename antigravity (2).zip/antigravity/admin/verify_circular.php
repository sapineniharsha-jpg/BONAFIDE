<?php
// admin/verify_circular.php
// 1. EXISTING LOGIC
error_reporting(E_ALL);
ini_set('display_errors', 0);
if (session_status() === PHP_SESSION_NONE) session_start();
$root = $_SERVER['DOCUMENT_ROOT'];
require_once $root . '/includes/db.php';

$raw_no = $_GET['circular_no'] ?? $_GET['no'] ?? '';
$circular_no = urldecode($raw_no);
$row = null;

if ($circular_no) {
    $stmt = $mysqli->prepare("SELECT * FROM circulars WHERE circular_number = ?");
    if ($stmt) {
        $stmt->bind_param("s", $circular_no);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();
    }
}

// 2. PORTAL INTEGRATION
include $root . '/includes/header.php';
?>

<style>
    .verify-container {
        min-height: 80vh; display: flex; justify-content: center; align-items: center; padding: 20px;
        background: linear-gradient(135deg, #f8fafc 0%, #eef2ff 100%);
    }
    
    .verify-card {
        background: #fff; width: 100%; max-width: 700px;
        border-radius: 24px; padding: 40px;
        box-shadow: 0 20px 50px rgba(0,0,0,0.08); text-align: center;
    }

    .status-icon { font-size: 4rem; margin-bottom: 20px; }
    .text-success { color: #10b981; }
    .text-danger { color: #ef4444; }
    
    .detail-row {
        display: flex; justify-content: space-between; padding: 15px 0; border-bottom: 1px solid #f1f5f9;
        text-align: left;
    }
    .detail-label { color: #64748b; font-weight: 600; font-size: 0.9rem; }
    .detail-val { font-weight: 700; color: #1e293b; }

    .btn-verify {
        background: var(--inst-grad); color: white; border: none; padding: 12px 30px;
        border-radius: 50px; font-weight: 700; cursor: pointer; margin-top: 20px;
        text-decoration: none; display: inline-block;
    }
    
    .search-inp {
        padding: 15px; border-radius: 12px; border: 1px solid #e2e8f0; width: 100%; margin-bottom: 15px;
        font-size: 1rem; outline: none;
    }
</style>

<div class="verify-container">
    <div class="verify-card">
        
        <img src="/assets/img/logo.png" style="width:60px; margin-bottom:15px;">
        <h2 style="margin:0 0 5px 0; color:#1e293b; font-weight:800;">Circular Verification</h2>
        <p style="color:#64748b; font-size:0.9rem; margin-bottom:30px;">Official Document Validation System</p>

        <?php if (!$circular_no): ?>
            <form method="get">
                <input type="text" name="circular_no" class="search-inp" placeholder="Enter Reference No (e.g. VTHT/2025/...)" required>
                <button type="submit" class="btn-verify">Verify Now</button>
            </form>

        <?php elseif (!$row): ?>
            <div class="status-icon text-danger"><i class="fas fa-times-circle"></i></div>
            <h3 style="color:#ef4444; font-weight:800;">Verification Failed</h3>
            <p style="color:#64748b;">The document with reference <strong><?= htmlspecialchars($circular_no) ?></strong> was not found in our records.</p>
            <a href="verify_circular.php" class="btn-verify" style="background:#ef4444;">Try Again</a>

        <?php else: ?>
            <div class="status-icon text-success"><i class="fas fa-check-circle"></i></div>
            <h3 style="color:#10b981; font-weight:800; margin-bottom:20px;">Verified Authentic</h3>
            
            <div style="text-align:left; background:#f8fafc; padding:20px; border-radius:16px;">
                <div class="detail-row">
                    <span class="detail-label">Reference No</span>
                    <span class="detail-val"><?= htmlspecialchars($row['circular_number']) ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Date Issued</span>
                    <span class="detail-val"><?= date('d M Y', strtotime($row['circular_date'])) ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Department</span>
                    <span class="detail-val"><?= htmlspecialchars($row['department']) ?></span>
                </div>
                <div class="detail-row" style="border:none;">
                    <span class="detail-label">Subject</span>
                    <span class="detail-val"><?= htmlspecialchars($row['circular_subject']) ?></span>
                </div>
            </div>

            <div style="margin-top:25px; display:flex; gap:10px; justify-content:center;">
                <a href="view_circular.php?id=<?= $row['id'] ?>" class="btn-verify" style="background:#e0f2fe; color:#0284c7; box-shadow:none;">View Original</a>
                <?php if($row['signed_pdf_path']): ?>
                    <a href="<?= htmlspecialchars($row['signed_pdf_path']) ?>" download class="btn-verify">Download PDF</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

    </div>
</div>

<?php include $root . '/includes/footer.php'; ?>