<?php if($is_admin): ?>
<!-- Admin Fee Management Panel -->
<div class="row mb-4">
    <div class="col-12">
        <div class="glass-card p-4">
            <h4 class="fw-bold mb-4">
                <i class="fas fa-edit me-2"></i> Fee Management (Admin Only)
            </h4>
            
            <!-- Student Selector -->
            <div class="student-select-card mb-4">
                <label class="form-label fw-bold">Select Student</label>
                <select id="admin_student_select" class="form-select" onchange="loadStudentFeeDetails(this.value)">
                    <option value="">Select a student</option>
                    <?php
                    $students_query = "SELECT DISTINCT s.id_no, s.Name, s.RegisterNo, s.Dept 
                                      FROM students_login_master s
                                      LEFT JOIN bonafide_fee_details f ON s.id_no = f.id_no
                                      ORDER BY s.Name";
                    $students = $mysqli->query($students_query);
                    while($student = $students->fetch_assoc()):
                    ?>
                    <option value="<?= $student['id_no'] ?>">
                        <?= $student['Name'] ?> - <?= $student['RegisterNo'] ?> (<?= $student['Dept'] ?>)
                    </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <!-- Fee Edit Form (initially hidden) -->
            <div id="fee_edit_form" style="display: none;">
                <form method="POST" action="update_fee.php" class="row g-3">
                    <input type="hidden" id="admin_student_id" name="student_id">
                    
                    <div class="col-md-6">
                        <label class="form-label">Tuition Fee per annum (₹)</label>
                        <input type="number" name="tuition_fee" class="form-control" step="0.01" min="0">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">Other Fee per annum (₹)</label>
                        <input type="number" name="other_fee" class="form-control" step="0.01" min="0">
                    </div>
                    
                    <!-- Academic Year Selector -->
                    <div class="col-12">
                        <label class="form-label">Academic Years</label>
                        <div class="year-range-selector">
                            <div class="row g-2">
                                <div class="col-md-3">
                                    <select name="start_year" class="form-select">
                                        <?php for($y = 2020; $y <= 2030; $y++): ?>
                                        <option value="<?= $y ?>" <?= $y == 2025 ? 'selected' : '' ?>>
                                            <?= $y ?>
                                        </option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <select name="end_year" class="form-select">
                                        <?php for($y = 2025; $y <= 2035; $y++): ?>
                                        <option value="<?= $y ?>" <?= $y == 2029 ? 'selected' : '' ?>>
                                            <?= $y ?>
                                        </option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-outline-primary" onclick="generateYearRange()">
                                        Generate Years
                                    </button>
                                </div>
                            </div>
                            <div id="year_range_display" class="mt-2 p-2 bg-light"></div>
                        </div>
                    </div>
                    
                    <!-- Facility Management -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0">Facility Management</h6>
                            </div>
                            <div class="card-body">
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label>Transport Facility</label>
                                        <select name="transport_type" class="form-select" onchange="updateTransportFee()">
                                            <option value="">No Transport</option>
                                            <option value="ac">AC Bus</option>
                                            <option value="regular">Regular Bus</option>
                                        </select>
                                        <input type="number" name="transport_fee" class="form-control mt-2" 
                                               placeholder="Custom Fee" step="0.01" min="0">
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label>Hostel Facility</label>
                                        <select name="hostel_type" class="form-select" onchange="updateHostelFee()">
                                            <option value="">No Hostel</option>
                                            <option value="ac">AC Room</option>
                                            <option value="non_ac">Non-AC Room</option>
                                        </select>
                                        <input type="number" name="hostel_fee" class="form-control mt-2" 
                                               placeholder="Custom Fee" step="0.01" min="0">
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label>Scholarship</label>
                                        <select name="scholarship_type" class="form-select">
                                            <option value="">No Scholarship</option>
                                            <option value="7.5%">7.5% Scholarship</option>
                                            <option value="50%">50% Scholarship</option>
                                            <option value="100%">100% Scholarship</option>
                                            <option value="other">Other</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label>Community</label>
                                        <select name="community" class="form-select">
                                            <option value="">Select Community</option>
                                            <option value="OC">OC</option>
                                            <option value="BC">BC</option>
                                            <option value="MBC">MBC</option>
                                            <option value="SC">SC</option>
                                            <option value="ST">ST</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <button type="submit" name="update_student_fees" class="btn btn-ig">
                            <i class="fas fa-save me-2"></i> Save Fee Details
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function loadStudentFeeDetails(studentId) {
    if (!studentId) return;
    
    fetch(`get_student_details.php?id=${studentId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Populate form fields
                document.getElementById('admin_student_id').value = studentId;
                document.getElementsByName('tuition_fee')[0].value = data.tuition_fee || '';
                document.getElementsByName('other_fee')[0].value = data.other_fee || '';
                
                // Populate facility details
                if (data.transport) {
                    document.getElementsByName('transport_type')[0].value = data.transport.type;
                    document.getElementsByName('transport_fee')[0].value = data.transport.fee;
                }
                
                if (data.hostel) {
                    document.getElementsByName('hostel_type')[0].value = data.hostel.type;
                    document.getElementsByName('hostel_fee')[0].value = data.hostel.fee;
                }
                
                if (data.scholarship) {
                    document.getElementsByName('scholarship_type')[0].value = data.scholarship.type;
                }
                
                if (data.community) {
                    document.getElementsByName('community')[0].value = data.community;
                }
                
                // Show form
                document.getElementById('fee_edit_form').style.display = 'block';
            }
        });
}

function generateYearRange() {
    const startYear = parseInt(document.querySelector('select[name="start_year"]').value);
    const endYear = parseInt(document.querySelector('select[name="end_year"]').value);
    
    if (startYear >= endYear) {
        alert('End year must be greater than start year');
        return;
    }
    
    const years = [];
    for (let year = startYear; year < endYear; year++) {
        years.push(`${year}-${year + 1}`);
    }
    
    document.getElementById('year_range_display').innerHTML = 
        `<strong>Selected Years:</strong> ${years.join(', ')}`;
}

function updateTransportFee() {
    const type = document.querySelector('select[name="transport_type"]').value;
    const feeField = document.querySelector('input[name="transport_fee"]');
    
    switch(type) {
        case 'ac': feeField.value = 50000; break;
        case 'regular': feeField.value = 20000; break;
        default: feeField.value = ''; break;
    }
}

function updateHostelFee() {
    const type = document.querySelector('select[name="hostel_type"]').value;
    const feeField = document.querySelector('input[name="hostel_fee"]');
    
    switch(type) {
        case 'ac': feeField.value = 110000; break;
        case 'non_ac': feeField.value = 90000; break;
        default: feeField.value = ''; break;
    }
}
</script>
<?php endif; ?>