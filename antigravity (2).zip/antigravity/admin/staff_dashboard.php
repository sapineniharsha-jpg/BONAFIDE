<?php
// staff_dashboard.php - COMPLETE STAFF INTERFACE
ini_set('display_errors', 0); 
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', '../logs/dept_errors.log');
// 1. Session & Path Setup
ob_start();
session_start();

// Authentication
$allowed_roles = ['class_advisor', 'hod', 'dean', 'admin', 'principal'];
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../login.php");
    exit;
}

require_once '../includes/db.php';
require_once '../includes/functions.php';

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];
$user_name = $_SESSION['name'];
$user_dept = $_SESSION['DEPARTMENT'] ?? $_SESSION['department'] ?? '';
$user_designation = $_SESSION['designation'] ?? ucfirst(str_replace('_', ' ', $user_role));

$message = '';
$message_type = '';

// Handle approval/rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['request_id'])) {
    $request_id = intval($_POST['request_id']);
    $action = sanitize($_POST['action'], 'string'); // 'approve' or 'reject'
    $remarks = sanitize($_POST['remarks'] ?? '', 'string');
    
    if (in_array($action, ['approve', 'reject'])) {
        if (processApproval($request_id, $action, $user_role, $user_id, $remarks)) {
            $message = "✅ Request " . ($action === 'approve' ? 'approved' : 'rejected') . " successfully";
            $message_type = "success";
        } else {
            $message = "❌ Error processing request";
            $message_type = "error";
        }
    }
}

// Get pending requests for current role
$pending_requests = getRoleRequests($user_role, $user_dept, $user_id);
$all_certificates = getAllCertificates($user_role, $user_dept);

include '../includes/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ucfirst(str_replace('_', ' ', $user_role)); ?> Dashboard - Bonafide System</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #bc1888;
            --primary-gradient: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
            --success: #10b981;
            --warning: #f59e0b;
            --error: #ef4444;
            --info: #3b82f6;
            --gray-50: #f8fafc;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-400: #94a3b8;
            --gray-500: #64748b;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: var(--gray-50);
            color: var(--gray-800);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Header */
        .header {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-info h1 {
            color: var(--gray-800);
            margin-bottom: 8px;
            font-size: 1.8rem;
        }
        
        .user-info p {
            color: var(--gray-600);
            margin-bottom: 5px;
        }
        
        .role-badge {
            background: var(--primary-gradient);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Admin Actions */
        .admin-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            border: 1px solid var(--gray-200);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--gray-100);
        }
        
        .card-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--gray-800);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        /* Badges */
        .badge {
            display: inline-flex;
            align-items: center;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .badge-primary {
            background: var(--primary-gradient);
            color: white;
        }
        
        .badge-success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }
        
        .badge-warning {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning);
            border: 1px solid rgba(245, 158, 11, 0.2);
        }
        
        .badge-error {
            background: rgba(239, 68, 68, 0.1);
            color: var(--error);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }
        
        .badge-info {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info);
            border: 1px solid rgba(59, 130, 246, 0.2);
        }
        
        /* Buttons */
        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.875rem;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: var(--primary-gradient);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(188, 24, 136, 0.3);
        }
        
        .btn-success {
            background: var(--success);
            color: white;
        }
        
        .btn-error {
            background: var(--error);
            color: white;
        }
        
        .btn-info {
            background: var(--info);
            color: white;
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 0.75rem;
        }
        
        .btn-view {
            background: #dbeafe;
            color: #1d4ed8;
        }
        
        .btn-print {
            background: #dcfce7;
            color: #15803d;
        }
        
        /* Forms */
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--gray-700);
            font-size: 0.875rem;
        }
        
        .form-control, .form-select {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid var(--gray-200);
            border-radius: 8px;
            font-size: 0.95rem;
            transition: border-color 0.2s;
            background: white;
        }
        
        .form-control:focus, .form-select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(188, 24, 136, 0.1);
        }
        
        .form-control-sm {
            padding: 6px 10px;
            font-size: 0.875rem;
        }
        
        /* Request Items */
        .request-item {
            border: 1px solid var(--gray-200);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            background: white;
        }
        
        .request-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }
        
        .student-info h4 {
            color: var(--gray-800);
            margin-bottom: 5px;
            font-size: 1.1rem;
        }
        
        .student-meta {
            color: var(--gray-600);
            font-size: 0.875rem;
        }
        
        /* Status Timeline */
        .status-timeline {
            display: flex;
            justify-content: space-between;
            margin: 15px 0;
            padding: 15px;
            background: var(--gray-50);
            border-radius: 8px;
            border: 1px solid var(--gray-200);
        }
        
        .status-step {
            text-align: center;
            flex: 1;
            position: relative;
        }
        
        .status-step:not(:last-child)::after {
            content: '';
            position: absolute;
            top: 6px;
            right: -50%;
            width: 100%;
            height: 2px;
            background: var(--gray-300);
            z-index: 1;
        }
        
        .step-dot {
            width: 12px;
            height: 12px;
            background: var(--gray-300);
            border-radius: 50%;
            margin: 0 auto 5px;
            position: relative;
            z-index: 2;
        }
        
        .step-dot.active {
            background: var(--success);
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2);
        }
        
        .step-dot.pending {
            background: var(--warning);
            box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.2);
        }
        
        .step-label {
            font-size: 0.7rem;
            color: var(--gray-600);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Action Form */
        .action-form {
            display: flex;
            gap: 10px;
            align-items: flex-end;
            flex-wrap: wrap;
        }
        
        .action-input {
            flex: 1;
            min-width: 200px;
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        
        /* Tables */
        .table-container {
            overflow-x: auto;
            border-radius: 8px;
            border: 1px solid var(--gray-200);
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }
        
        .table th {
            padding: 12px 16px;
            text-align: left;
            font-weight: 600;
            color: var(--gray-600);
            background: var(--gray-50);
            border-bottom: 2px solid var(--gray-200);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .table td {
            padding: 12px 16px;
            border-bottom: 1px solid var(--gray-200);
            vertical-align: middle;
        }
        
        .table tr:hover {
            background: var(--gray-50);
        }
        
        .table tr:last-child td {
            border-bottom: none;
        }
        
        /* Search Bar */
        .search-bar {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .search-input {
            flex: 1;
            max-width: 300px;
        }
        
        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: var(--gray-500);
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 15px;
            color: var(--gray-300);
        }
        
        /* Alert */
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-success {
            background: #dcfce7;
            color: #15803d;
            border: 1px solid #86efac;
        }
        
        .alert-error {
            background: #fee2e2;
            color: #b91c1c;
            border: 1px solid #fca5a5;
        }
        
        /* Print styles */
        @media print {
            .no-print,
            .btn,
            .action-form,
            .search-bar {
                display: none !important;
            }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            
            .header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .admin-actions {
                width: 100%;
                justify-content: flex-start;
            }
            
            .card {
                padding: 20px;
            }
            
            .action-form {
                flex-direction: column;
                align-items: stretch;
            }
            
            .action-input {
                min-width: 100%;
            }
            
            .status-timeline {
                flex-wrap: wrap;
                gap: 10px;
            }
            
            .status-step {
                flex: 0 0 calc(50% - 10px);
            }
            
            .status-step:not(:last-child)::after {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="user-info">
                <h1>Welcome, <?php echo htmlspecialchars($user_name); ?></h1>
                <p><strong>Role:</strong> <?php echo htmlspecialchars($user_designation); ?></p>
                <p><strong>Department:</strong> <?php echo htmlspecialchars($user_dept); ?></p>
                <p><strong>User ID:</strong> <?php echo htmlspecialchars($user_id); ?></p>
            </div>
            
            <div class="role-badge">
                <?php echo strtoupper(str_replace('_', ' ', $user_role)); ?>
            </div>
            
            <?php if($user_role === 'admin'): ?>
            <div class="admin-actions">
                <a href="bonafide_issue.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Direct Issue
                </a>
                <a href="../logout.php" class="btn btn-error">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
            <?php endif; ?>
        </div>
        
        <?php if($message): ?>
            <div class="alert alert-<?php echo $message_type === 'success' ? 'success' : 'error'; ?>">
                <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <!-- Pending Requests -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">
                    <i class="fas fa-clock"></i>
                    Pending Requests
                </div>
                <span class="badge badge-warning"><?php echo count($pending_requests); ?> Pending</span>
            </div>
            
            <?php if(empty($pending_requests)): ?>
                <div class="empty-state">
                    <i class="fas fa-check-circle" style="color: var(--success);"></i>
                    <h3>All Caught Up!</h3>
                    <p>No pending requests require your attention</p>
                </div>
            <?php else: ?>
                <?php foreach($pending_requests as $request): ?>
                <div class="request-item">
                    <div class="request-header">
                        <div class="student-info">
                            <h4><?php echo htmlspecialchars($request['student_name']); ?></h4>
                            <div class="student-meta">
                                <?php echo htmlspecialchars($request['register_number']); ?> • 
                                <?php echo htmlspecialchars($request['department'] ?? $request['Dept'] ?? 'Unknown'); ?> • 
                                <?php echo htmlspecialchars($request['bonafide_type']); ?>
                            </div>
                        </div>
                        <span class="badge badge-warning"><?php echo getCurrentStatus($request); ?></span>
                    </div>
                    
                    <div class="status-timeline">
                        <?php echo displayStatusTimeline($request, $user_role); ?>
                    </div>
                    
                    <div style="margin: 15px 0;">
                        <p><strong>Purpose:</strong> <?php echo htmlspecialchars($request['purpose']); ?></p>
                        <?php if(!empty($request['student_message'])): ?>
                            <p><strong>Additional Info:</strong> <?php echo htmlspecialchars($request['student_message']); ?></p>
                        <?php endif; ?>
                        <p style="color: var(--gray-500); font-size: 0.875rem;">
                            <i class="fas fa-calendar"></i> 
                            Submitted: <?php echo date('d M Y H:i', strtotime($request['submitted_on'] ?? $request['request_date'])); ?>
                        </p>
                    </div>
                    
                    <form method="POST" class="action-form">
                        <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                        
                        <div class="action-input">
                            <input type="text" name="remarks" class="form-control form-control-sm" 
                                   placeholder="Remarks (optional)">
                        </div>
                        
                        <div class="action-buttons">
                            <button type="submit" name="action" value="approve" class="btn btn-success">
                                <i class="fas fa-check"></i> Approve
                            </button>
                            <button type="submit" name="action" value="reject" class="btn btn-error">
                                <i class="fas fa-times"></i> Reject
                            </button>
                            <button type="button" class="btn btn-info" 
                                    onclick="viewDemo(<?php echo $request['id']; ?>)">
                                <i class="fas fa-eye"></i> Demo
                            </button>
                        </div>
                    </form>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <!-- All Certificates -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">
                    <i class="fas fa-certificate"></i>
                    All Certificates
                </div>
                <span class="badge badge-info"><?php echo count($all_certificates); ?> Total</span>
            </div>
            
            <div class="search-bar">
                <div class="search-input">
                    <input type="search" id="certificateSearch" class="form-control" 
                           placeholder="Search by name, ref no, or department...">
                </div>
                <button class="btn btn-primary" onclick="searchCertificates()">
                    <i class="fas fa-search"></i> Search
                </button>
            </div>
            
            <?php if(empty($all_certificates)): ?>
                <div class="empty-state">
                    <i class="fas fa-certificate"></i>
                    <h3>No Certificates Found</h3>
                    <p>Approved certificates will appear here</p>
                </div>
            <?php else: ?>
                <div class="table-container">
                    <table class="table" id="certificatesTable">
                        <thead>
                            <tr>
                                <th>Ref No</th>
                                <th>Student</th>
                                <th>Department</th>
                                <th>Type</th>
                                <th>Approved On</th>
                                <th class="no-print">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($all_certificates as $cert): ?>
                            <tr>
                                <td>
                                    <strong style="color: var(--primary);">
                                        <?php echo htmlspecialchars($cert['ref_number']); ?>
                                    </strong>
                                </td>
                                <td>
                                    <div style="font-weight: 600;"><?php echo htmlspecialchars($cert['student_name']); ?></div>
                                    <div style="font-size: 0.75rem; color: var(--gray-500);">
                                        <?php echo htmlspecialchars($cert['register_number']); ?>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($cert['department']); ?></td>
                                <td>
                                    <span class="badge badge-info">
                                        <?php echo htmlspecialchars($cert['certificate_type']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php echo date('d M Y', strtotime($cert['bonafide_date'])); ?>
                                    <br>
                                    <small style="color: var(--gray-500); font-size: 0.75rem;">
                                        by <?php echo htmlspecialchars($cert['verified_by'] ?? 'Admin'); ?>
                                    </small>
                                </td>
                                <td class="no-print">
                                    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                                        <a href="print_certificate.php?id=<?php echo $cert['id']; ?>" 
                                           target="_blank" 
                                           class="btn btn-sm btn-print">
                                            <i class="fas fa-print"></i> Print
                                        </a>
                                        <a href="../verify.php?ref=<?php echo urlencode($cert['ref_number']); ?>" 
                                           target="_blank" 
                                           class="btn btn-sm btn-view">
                                            <i class="fas fa-shield-alt"></i> Verify
                                        </a>
                                        <?php if($user_role === 'admin'): ?>
                                        <button onclick="editCertificate(<?php echo $cert['id']; ?>)" 
                                                class="btn btn-sm" style="background: var(--primary); color: white;">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        // View Demo
        function viewDemo(requestId) {
            window.open('live_preview.php?request_id=' + requestId, '_blank', 
                       'width=1000,height=700,scrollbars=yes');
        }
        
        // Edit Certificate (Admin only)
        function editCertificate(certId) {
            window.location.href = 'bonafide_issue.php?edit=' + certId;
        }
        
        // Search certificates
        function searchCertificates() {
            const input = document.getElementById('certificateSearch');
            const filter = input.value.toUpperCase();
            const table = document.getElementById('certificatesTable');
            const rows = table.getElementsByTagName('tr');
            
            for (let i = 1; i < rows.length; i++) {
                const cells = rows[i].getElementsByTagName('td');
                let found = false;
                
                for (let j = 0; j < cells.length; j++) {
                    const cell = cells[j];
                    if (cell) {
                        const textValue = cell.textContent || cell.innerText;
                        if (textValue.toUpperCase().indexOf(filter) > -1) {
                            found = true;
                            break;
                        }
                    }
                }
                
                rows[i].style.display = found ? '' : 'none';
            }
        }
        
        // Auto search on typing
        document.getElementById('certificateSearch').addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                searchCertificates();
            }
        });
        
        // Auto-hide alert after 5 seconds
        const alert = document.querySelector('.alert');
        if (alert) {
            setTimeout(() => {
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 300);
            }, 5000);
        }
        
        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // Ctrl+F for search
            if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                e.preventDefault();
                document.getElementById('certificateSearch').focus();
            }
            
            // Escape to clear search
            if (e.key === 'Escape') {
                document.getElementById('certificateSearch').value = '';
                searchCertificates();
            }
        });
    </script>
</body>
</html>

<?php include '../includes/footer.php'; ?>