<?php
require_once '../includes/config.php';
require_once '../includes/db.php';

// Authentication Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Access Denied");
}

// Fetch Stats
$today = date('Y-m-d');
$usage = $mysqli->query("SELECT * FROM ai_usage_summary WHERE date = '$today'")->fetch_assoc();
$intents = $mysqli->query("SELECT intent, count FROM ai_intent_tracking ORDER BY count DESC LIMIT 5");

// Fallback approximation (Total - Success)
$success = $usage['successful_responses'] ?? 0;
$fallback = $total - $success;

// Average Rating
$avgRatingRes = $mysqli->query("SELECT AVG(rating) as avg FROM ai_feedback");
$avgRating = $avgRatingRes ? round($avgRatingRes->fetch_assoc()['avg'], 1) : 0;

// Top 10 Unanswered Questions
$unanswered = $mysqli->query("SELECT question, frequency FROM ai_unanswered_learning ORDER BY frequency DESC LIMIT 10");
$heatmap = $mysqli->query("SELECT hour, total FROM ai_hourly_stats WHERE date = '$today' ORDER BY hour ASC");
$hours = [];
$counts = [];
while ($row = $heatmap->fetch_assoc()) {
    $hours[] = $row['hour'] . ":00";
    $counts[] = $row['total'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AI Analytics Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background: #f4f6f9; }
        .card { border: none; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .stat-card { text-align: center; padding: 20px; }
        .stat-value { font-size: 2rem; font-weight: bold; color: #bc1888; }
    </style>
</head>
<body>
    <div class="container py-5">
        <h2 class="mb-4">🤖 AI Analytics Dashboard</h2>
        
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card stat-card">
                    <h5>Total Queries</h5>
                    <div class="stat-value"><?php echo $total; ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card">
                    <h5>Successful</h5>
                    <div class="stat-value text-success"><?php echo $success; ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card">
                    <h5>Fallbacks</h5>
                    <div class="stat-value text-danger"><?php echo $fallback; ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card">
                    <h5>Avg Rating</h5>
                    <div class="stat-value text-warning">★ <?php echo $avgRating; ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card">
                    <h5>Success Rate</h5>
                    <div class="stat-value"><?php echo $total > 0 ? round(($success / $total) * 100) : 0; ?>%</div>
                </div>
            </div>
        </div>
        
        <div class="row mb-4">
            <div class="col-12">
                <div class="card p-4">
                     <h4 class="text-danger">🔥 Top 10 Unanswered Questions</h4>
                     <table class="table table-sm table-hover">
                        <thead><tr><th>Question</th><th>Frequency</th></tr></thead>
                        <tbody>
                            <?php if ($unanswered && $unanswered->num_rows > 0): ?>
                                <?php while ($row = $unanswered->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['question']); ?></td>
                                    <td><span class="badge bg-danger"><?php echo $row['frequency']; ?></span></td>
                                </tr>
                                <?php
    endwhile; ?>
                            <?php
else: ?>
                                <tr><td colspan="2" class="text-muted">No unanswered questions yet!</td></tr>
                            <?php
endif; ?>
                        </tbody>
                     </table>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="card p-4">
                    <h4>Hourly Activity Heatmap</h4>
                    <canvas id="heatmapChart"></canvas>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card p-4">
                    <h4>Top Intents</h4>
                    <canvas id="intentChart"></canvas>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card p-4">
                    <h4>Recent Activity Log</h4>
                    <table class="table table-striped">
                        <thead><tr><th>User</th><th>Intent</th><th>Time</th></tr></thead>
                        <tbody>
                            <?php
$logs = $mysqli->query("SELECT user_id, intent, created_at FROM ai_live_monitor ORDER BY id DESC LIMIT 10");
while ($row = $logs->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['user_id']); ?></td>
                                <td><?php echo htmlspecialchars($row['intent']); ?></td>
                                <td><?php echo date('H:i', strtotime($row['created_at'])); ?></td>
                            </tr>
                            <?php
endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        const ctx = document.getElementById('intentChart').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: [<?php while ($row = $intents->fetch_assoc())
    echo "'{$row['intent']}',"; ?>],
                datasets: [{
                    data: [<?php
$intents->data_seek(0);
while ($row = $intents->fetch_assoc())
    echo "{$row['count']},";
?>],
                    backgroundColor: ['#bc1888', '#667eea', '#764ba2', '#10b981', '#f09433']
                }]
            }
        });

        const ctx2 = document.getElementById('heatmapChart').getContext('2d');
        new Chart(ctx2, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($hours); ?>,
                datasets: [{
                    label: 'Queries per Hour',
                    data: <?php echo json_encode($counts); ?>,
                    backgroundColor: '#ee0979',
                    borderRadius: 4
                }]
            },
            options: {
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    </script>
</body>
</html>
