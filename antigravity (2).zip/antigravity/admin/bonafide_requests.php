<?php
// bonafide_requests.php - FIXED ENTERPRISE VERSION v1001.0
// 1. ERROR REPORTING (Turn off in production if needed, but keep on for debugging 500s)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

ob_start();
if (session_status() === PHP_SESSION_NONE) session_start();

// 2. INCLUDE CHECKS (Prevents 500 if files miss)
if (!file_exists('../includes/db.php')) die("Error: ../includes/db.php not found");
require_once '../includes/db.php';
require_once '../includes/phpqrcode/qrlib.php';

// 3. AUTHENTICATION
if (!isset($_SESSION['user_id'])) {
    die("<div style='height:100vh; display:flex; align-items:center; justify-content:center; background:#f8fafc; font-family:sans-serif;'>
            <div style='text-align:center; padding:40px; background:white; border-radius:16px; box-shadow:0 10px 30px rgba(0,0,0,0.1);'>
                <h2 style='color:#bc1888; margin-bottom:10px;'>Session Expired</h2>
                <p style='color:#64748b;'>Please login to continue.</p>
                <a href='../index.php' style='display:inline-block; margin-top:15px; text-decoration:none; background:linear-gradient(45deg,#f09433,#bc1888); color:white; padding:10px 30px; border-radius:50px; font-weight:bold;'>Login</a>
            </div>
         </div>");
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'] ?? 'student'; 
$my_dept = $_SESSION['dept'] ?? '';
$is_student = ($role === 'student');

// 4. STUDENT DATA & PROFILE GUARD
$student_data = null;
$missing_fields = [];
$is_fresher = false;
$all_profile_data = []; // Holds every column for "View Profile"

if ($is_student) {
    // Check Freshers Table
    $q1 = $mysqli->query("SELECT * FROM students_batch_25_26 WHERE register_no='$user_id' OR id_no='$user_id'");
    if ($q1 && $q1->num_rows > 0) {
        $student_data = $q1->fetch_assoc();
        $is_fresher = true;
        $col_map = ['id'=>'id_no', 'reg'=>'register_no', 'name'=>'student_name', 'father'=>'parent_name', 'gender'=>'gender', 'dept'=>'department'];
    } else {
        // Check Seniors Table
        $q2 = $mysqli->query("SELECT * FROM students_login_master WHERE RegisterNo='$user_id' OR IDNo='$user_id'");
        if ($q2 && $q2->num_rows > 0) {
            $student_data = $q2->fetch_assoc();
            $is_fresher = false;
            $col_map = ['id'=>'IDNo', 'reg'=>'RegisterNo', 'name'=>'Name', 'father'=>'fathername', 'gender'=>'Gender', 'dept'=>'Dept'];
        }
    }
    
    // Validate Critical Fields
    if ($student_data) {
        $all_profile_data = $student_data; // Store full row
        
        $db_father = $student_data[$col_map['father']];
        $db_gender = $student_data[$col_map['gender']];
        
        if (empty($db_father) || $db_father == '-' || $db_father == '0') $missing_fields['father_name'] = 'Father Name';
        if (empty($db_gender) || $db_gender == '-' || $db_gender == '0') $missing_fields['gender'] = 'Gender';
    }
}

// 5. ACTION HANDLERS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // > Student: Update Profile
    if ($is_student && $action === 'update_profile') {
        $fname = $mysqli->real_escape_string(strtoupper($_POST['father_name']));
        $gender = $mysqli->real_escape_string($_POST['gender']);
        
        if ($is_fresher) { 
            $mysqli->query("UPDATE students_batch_25_26 SET parent_name='$fname', gender='$gender' WHERE {$col_map['id']}='{$student_data[$col_map['id']]}'"); 
        } else { 
            $mysqli->query("UPDATE students_login_master SET fathername='$fname', Gender='$gender' WHERE {$col_map['id']}='{$student_data[$col_map['id']]}'"); 
        }
        header("Location: bonafide_requests.php"); exit();
    }

    // > Student: Submit Request
    if ($is_student && $action === 'submit_request') {
        $type = $_POST['bonafide_type'];
        $purpose = $mysqli->real_escape_string($_POST['purpose']);
        $intern = $mysqli->real_escape_string($_POST['internship_info'] ?? '');
        $prefix = (strtoupper($student_data[$col_map['gender']]) == 'MALE') ? 'Mr.' : 'Ms.';
        $p_prefix = 'Mr.';
        
        // Use column maps safely
        $s_id = $student_data[$col_map['id']];
        $s_reg = $student_data[$col_map['reg']];
        $s_name = $student_data[$col_map['name']];
        $s_father = $student_data[$col_map['father']];
        $s_dept = $student_data[$col_map['dept']];

        $stmt = $mysqli->prepare("INSERT INTO bonafide_requests (student_id, register_number, student_name, student_prefix, father_name, parent_prefix, program, year_pursuing, bonafide_type, purpose, internship_info, status, advisor_status, hod_status, dean_status, admin_status, submitted_on) VALUES (?, ?, ?, ?, ?, ?, ?, 'Current', ?, ?, ?, 'Pending', 'pending', 'pending', 'pending', 'pending', NOW())");
        $stmt->bind_param("sssssssssss", $s_id, $s_reg, $s_name, $prefix, $s_father, $p_prefix, $s_dept, $type, $purpose, $intern);
        
        if($stmt->execute()) { header("Location: bonafide_requests.php?msg=submitted&tab=history"); exit(); }
    }

    // > Staff: Actions
    if (!$is_student) {
        $req_id = intval($_POST['req_id']);
        $remarks = $mysqli->real_escape_string($_POST['remarks'] ?? '');

        if ($action === 'soft_delete' && $role === 'admin') {
            $mysqli->query("UPDATE bonafide_requests SET status='deleted' WHERE id=$req_id");
        }
        elseif ($action === 'reject') {
            $col = $role . "_status";
            $mysqli->query("UPDATE bonafide_requests SET $col='rejected', status='rejected', rejection_reason='$remarks' WHERE id=$req_id");
        } 
        elseif ($action === 'approve') {
            if ($role === 'advisor') $mysqli->query("UPDATE bonafide_requests SET advisor_status='approved', advisor_remarks='$remarks', advisor_action_date=NOW() WHERE id=$req_id");
            elseif ($role === 'hod') $mysqli->query("UPDATE bonafide_requests SET hod_status='approved', hod_approved_by='$user_id' WHERE id=$req_id");
            elseif ($role === 'dean' || $role === 'principal') $mysqli->query("UPDATE bonafide_requests SET dean_status='approved', dean_approved_by='$user_id' WHERE id=$req_id");
        } 
        elseif ($action === 'generate' && $role === 'admin') {
            $r = $mysqli->query("SELECT * FROM bonafide_requests WHERE id=$req_id")->fetch_assoc();
            $res_cnt = $mysqli->query("SELECT id FROM bonafide_certificates ORDER BY id DESC LIMIT 1");
            $last_id = ($res_cnt->fetch_assoc()['id'] ?? 0) + 1;
            $ay = (date('n') > 5) ? date('Y').'-'.(date('Y')+1) : (date('Y')-1).'-'.date('Y');
            $ref_no = "Ref/VH/eBONA/$ay/" . str_pad($last_id, 4, '0', STR_PAD_LEFT);
            
            $t1=floatval($_POST['t_fee']??0); $t2=floatval($_POST['o_fee']??0); $t3=floatval($_POST['h_fee']??0);
            
            $stmt = $mysqli->prepare("INSERT INTO bonafide_certificates (ref_number, bonafide_date, student_id, register_number, student_name, department, certificate_type, purpose, tuition_fee, other_fee, hostel_fee, status, created_at, internship_students, note_details) VALUES (?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?, 'approved', NOW(), ?, ?)");
            $stmt->bind_param("sssssssdddss", $ref_no, $r['student_id'], $r['register_number'], $r['student_name'], $r['program'], $r['bonafide_type'], $r['purpose'], $t1, $t2, $t3, $r['internship_info'], $r['note_details']);
            
            if ($stmt->execute()) {
                $cid = $stmt->insert_id;
                $mysqli->query("UPDATE bonafide_requests SET admin_status='approved', status='Completed', ref_number='$ref_no' WHERE id=$req_id");
                
                // QR Code
                $qrData = "https://www.velhightech.com/verify.php?ref=" . urlencode($ref_no);
                $qrFile = '../temp/qr_'.md5($ref_no).'.png'; if(!is_dir('../temp')) mkdir('../temp');
                QRcode::png($qrData, $qrFile, QR_ECLEVEL_H, 3);
                require_once '../includes/qr_branding.php';
                add_qr_branding($qrFile);
                
                header("Location: view_bonafide.php?id=$cid"); exit();
            }
        }
    }
    header("Location: bonafide_requests.php"); exit();
}

// 6. VIEW DATA PREPARATION
$view_data = [];
if ($is_student) {
    $reg_safe = $student_data[$col_map['reg']];
    $view_data['history'] = $mysqli->query("SELECT * FROM bonafide_requests WHERE register_number='$reg_safe' AND status!='deleted' ORDER BY id DESC");
} else {
    // Staff View Queries
    $sql_all = "SELECT r.* FROM bonafide_requests r";
    if ($role === 'advisor') {
        $sql_all .= " JOIN mentor_mentee m ON r.student_id = m.Student_ID_No WHERE m.Employee_ID_No = '$user_id'";
    } elseif ($role === 'hod') {
        $sql_all .= " WHERE r.program LIKE '%$my_dept%' AND r.advisor_status='approved'";
    } elseif ($role === 'dean' || $role === 'principal') {
        $sql_all .= " WHERE r.hod_status='approved'";
    } elseif ($role === 'admin') {
        $sql_all .= " WHERE r.dean_status='approved'";
    }
    $sql_all .= " AND r.status != 'deleted' ORDER BY r.submitted_on DESC LIMIT 150";
    $view_data['all'] = $mysqli->query($sql_all);
}

include '../includes/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bonafide Portal</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* THEME: Instagram Gradient */
        :root { 
            --insta: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
            --bg: #f8fafc; --card: #ffffff; --text: #1e293b; 
        }
        body { background: var(--bg); font-family: 'Outfit', sans-serif; padding: 20px; color: var(--text); }
        
        /* HEADER */
        .page-header { background: var(--card); padding: 20px; border-radius: 16px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        .page-title { margin: 0; background: var(--insta); -webkit-background-clip: text; color: transparent; font-size: 1.5rem; font-weight: 800; }
        .role-badge { background: #fdf2f8; color: #bc1888; padding: 5px 15px; border-radius: 20px; font-weight: bold; border: 1px solid #fce7f3; font-size: 0.8rem; }
        
        /* TABS */
        .tabs { display: flex; gap: 15px; border-bottom: 2px solid #eee; margin-bottom: 20px; }
        .tab-btn { padding: 10px 20px; border: none; background: none; font-weight: 700; color: #888; cursor: pointer; border-bottom: 3px solid transparent; transition: 0.3s; }
        .tab-btn.active { color: #bc1888; border-bottom-color: #bc1888; }
        .tab-content { display: none; } .tab-content.active { display: block; }

        /* GRID */
        .grid-split { display: grid; grid-template-columns: 450px 1fr; gap: 25px; }
        .card { background: var(--card); padding: 25px; border-radius: 16px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .form-control { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; margin-bottom: 15px; box-sizing: border-box; }
        .btn-insta { background: var(--insta); color: white; padding: 12px; width: 100%; border: none; border-radius: 50px; font-weight: bold; cursor: pointer; }
        
        /* TABLE */
        .table-wrap { overflow-x: auto; background: var(--card); border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        table { width: 100%; border-collapse: collapse; min-width: 800px; }
        th { background: #f8fafc; padding: 15px; text-align: left; } td { padding: 15px; border-bottom: 1px solid #eee; }
        .status-pill { padding: 5px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: 700; }
        .pending { background: #fff7ed; color: #b45309; } .approved { background: #f0fdf4; color: #15803d; } .rejected { background: #fef2f2; color: #b91c1c; }

        /* MODAL */
        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: none; justify-content: center; align-items: center; }
        .modal-box { background: white; width: 95%; max-width: 800px; max-height: 90vh; border-radius: 16px; padding: 25px; overflow-y: auto; }
        
        @media(max-width: 900px) { .grid-split { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

<div class="page-header">
    <div>
        <h2 class="page-title">Bonafide Portal</h2>
        <div style="font-size:0.9rem; color:#888;"><?= $is_student ? 'Apply & Track' : 'Approvals Dashboard' ?></div>
    </div>
    <div>
        <?php if($role === 'admin'): ?><a href="bonafide_issue.php" class="btn-insta" style="width:auto; padding:8px 20px; text-decoration:none; margin-right:10px;">Direct Issue</a><?php endif; ?>
        <span class="role-badge"><?= strtoupper($role) ?></span>
    </div>
</div>

<?php if($is_student): ?>
    <div class="tabs">
        <button class="tab-btn active" onclick="switchTab('new_req')">New Request</button>
        <button class="tab-btn" onclick="switchTab('history')">Your Requests</button>
    </div>

    <div id="new_req" class="tab-content active">
        <div class="grid-split">
            <div class="card">
                <?php if(!empty($missing_fields)): ?>
                    <h3 style="color:#ef4444;">⚠️ Action Required</h3>
                    <p style="color:#666;">Complete your profile to proceed.</p>
                    <form method="POST">
                        <input type="hidden" name="action" value="update_profile">
                        <?php if(isset($missing_fields['father_name'])): ?>
                            <label>Father Name</label><input type="text" name="father_name" class="form-control" required>
                        <?php endif; ?>
                        <?php if(isset($missing_fields['gender'])): ?>
                            <label>Gender</label><select name="gender" class="form-control" required><option value="">Select</option><option value="Male">Male</option><option value="Female">Female</option></select>
                        <?php endif; ?>
                        <button class="btn-insta">Update Profile</button>
                    </form>
                <?php else: ?>
                    <h3>Request Details</h3>
                    <form method="POST">
                        <input type="hidden" name="action" value="submit_request">
                        <label>Type</label>
                        <select name="bonafide_type" id="bType" class="form-control" onchange="updPrev()" required>
                            <option value="Normal">General Bonafide</option>
                            <option value="Fee Structure">Fee Structure</option>
                            <option value="Fee Paid">Fee Paid Certificate</option>
                            <option value="Internship">Internship Permission</option>
                            <option value="Project">Project Work</option>
                            <option value="LOR">Letter of Recommendation</option>
                        </select>
                        <div id="internBox" style="display:none;"><label>Details</label><input type="text" name="internship_info" id="internInfo" class="form-control" placeholder="Company / Project Title" oninput="updPrev()"></div>
                        <label>Purpose</label><input type="text" name="purpose" id="purpInfo" class="form-control" oninput="updPrev()" required>
                        <button class="btn-insta">Submit</button>
                    </form>
                <?php endif; ?>
            </div>

            <div class="card" style="background:#f8f9fa;">
                <h3>Live Preview</h3>
                <?php 
                    $view_name = $student_data[$col_map['name']];
                    $view_reg = $student_data[$col_map['reg']];
                    $view_father = $student_data[$col_map['father']];
                    $view_gender = $student_data[$col_map['gender']];
                    $view_dept = $student_data[$col_map['dept']];
                    include 'bonafide_preview.php'; 
                ?>
            </div>
        </div>
    </div>

    <div id="history" class="tab-content">
        <div class="table-wrap">
            <table>
                <thead><tr><th>Type</th><th>Purpose</th><th>Status</th><th>Date</th><th>Action</th></tr></thead>
                <tbody>
                    <?php if($view_data['history'] && $view_data['history']->num_rows > 0): ?>
                        <?php while($row = $view_data['history']->fetch_assoc()): 
                             $st = ($row['status']=='rejected')?'Rejected':(($row['admin_status']=='approved')?'Approved':'Pending'); ?>
                        <tr>
                            <td><?= $row['bonafide_type'] ?></td>
                            <td><?= $row['purpose'] ?></td>
                            <td><span class="status-pill <?= strtolower($st) ?>"><?= $st ?></span></td>
                            <td><?= date('d M Y', strtotime($row['submitted_on'])) ?></td>
                            <td>
                                <?php if($st=='Approved'): ?>
                                    <a href="view_bonafide.php?ref=<?= $row['ref_number'] ?>" class="status-pill approved" style="text-decoration:none;">Download</a>
                                <?php elseif($st=='Rejected'): ?>
                                    <small style="color:red;"><?= $row['rejection_reason'] ?></small>
                                <?php else: ?>
                                    <small>Processing</small>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" align="center">No requests found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php else: ?>
    <div class="card">
        <h3>Manage Requests</h3>
        <?php renderStaffTable($view_data['all'], $role); ?>
    </div>
<?php endif; ?>

<div class="modal-overlay" id="uniModal">
    <div class="modal-box">
        <div style="display:flex; justify-content:space-between; margin-bottom:15px;">
            <h3>Request Details</h3>
            <button onclick="document.getElementById('uniModal').style.display='none'" style="border:none; font-size:1.5rem; background:none;">&times;</button>
        </div>
        <div id="modalBody"></div>
    </div>
</div>

<script>
function switchTab(id) {
    document.querySelectorAll('.tab-content').forEach(e => e.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(e => e.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    event.currentTarget.classList.add('active');
}

function updPrev() {
    let t = document.getElementById('bType').value;
    let p = document.getElementById('purpInfo').value || '[Purpose]';
    let i = document.getElementById('internInfo').value || '';
    
    document.getElementById('prev_title').innerText = t.toUpperCase() + ' CERTIFICATE';
    let txt = `This certificate is issued for the purpose of <strong>${p}</strong>.`;
    if(t.includes('Fee')) txt = `(Fee Structure table will appear here in final certificate).`;
    if(t.includes('Internship')) txt = `This certificate is for Internship at <strong>${i}</strong>.`;
    
    document.getElementById('prev_text_container').innerHTML = txt; // Updated ID from helper
    document.getElementById('internBox').style.display = (t.includes('Internship') || t.includes('Project')) ? 'block' : 'none';
}

function openModal(type, data, roleArg) {
    const modal = document.getElementById('uniModal');
    const body = document.getElementById('modalBody');
    const isFee = data.bonafide_type.includes('Fee');
    const showAdmin = (roleArg === 'admin' && isFee && data.admin_status === 'pending');

    let html = `
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; background:#f8fafc; padding:15px; border-radius:8px; margin-bottom:15px;">
        <div><small>Name</small><br><b>${data.student_name}</b></div>
        <div><small>Reg No</small><br><b>${data.register_number}</b></div>
        <div><small>Type</small><br><b>${data.bonafide_type}</b></div>
        <div><small>Purpose</small><br><b>${data.purpose}</b></div>
    </div>`;

    if(type === 'profile') {
        // ENHANCED: Showing all available data keys safely
        html += `<div style="padding:15px; border:1px solid #eee; border-radius:8px; max-height:400px; overflow:auto;">`;
        html += `<table style="width:100%;">`;
        for (const [key, value] of Object.entries(data)) {
            if(value && key !== 'password') { // Hide password if accidentally fetched
                html += `<tr><td style="color:#666; text-transform:capitalize; padding:5px;">${key.replace(/_/g, ' ')}</td><td style="font-weight:bold;">${value}</td></tr>`;
            }
        }
        html += `</table></div>`;
        
    } else {
        if(showAdmin) {
            html += `<form method="POST" style="background:#fff5f7; padding:15px; border:1px dashed #bc1888; border-radius:8px; margin-bottom:15px;">
                <input type="hidden" name="req_id" value="${data.id}">
                <input type="hidden" name="action" value="generate">
                <b>Admin Fee Entry:</b>
                <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:5px; margin-top:5px;">
                    <input type="number" name="t_fee" placeholder="Tuition" class="form-control">
                    <input type="number" name="o_fee" placeholder="Other" class="form-control">
                    <input type="number" name="h_fee" placeholder="Hostel" class="form-control">
                </div>
                <button class="btn-insta" style="margin-top:10px;">Generate & Print</button>
            </form>`;
        }
        
        // PURE JS CERTIFICATE PREVIEW (No PHP injection)
        html += `<div class="paper" style="padding:30px; border:1px solid #e2e8f0; font-family:'Times New Roman';">
            <div style="text-align:center; margin-bottom:20px; border-bottom:2px solid #000; padding-bottom:15px;">
                <h3 style="margin:0; color:#1e3a8a;">Vel Tech High Tech</h3>
                <h4 style="margin:5px 0; color:#444;">Dr. Rangarajan Dr. Sakunthala Engineering College</h4>
            </div>
            <div style="text-align:center; font-weight:bold; text-decoration:underline; font-size:1.2rem; margin-bottom:20px;">
                ${data.bonafide_type.toUpperCase()} CERTIFICATE
            </div>
            <div style="text-align:justify; line-height:1.6;">
                <p>This is to certify that <strong>${data.student_name}</strong> (Reg No: <strong>${data.register_number}</strong>), 
                ${data.gender === 'Female' ? 'D/o' : 'S/o'} <strong>${data.father_name}</strong>, is a bonafide student of our institution.</p>
                
                ${isFee ? '<p><i>(The Fee Structure table will be generated in the final certificate)</i></p>' : `<p>This certificate is issued for the purpose of <strong>${data.purpose}</strong>.</p>`}
            </div>
            <div style="margin-top:60px; text-align:right; font-weight:bold;">PRINCIPAL</div>
        </div>`;
    }
    body.innerHTML = html;
    modal.style.display = 'flex';
}
</script>

<?php
function renderStaffTable($res, $roleArg) {
    if ($res && $res->num_rows > 0) {
        echo '<div class="table-wrap"><table><thead><tr><th>ID</th><th>Student</th><th>Type</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
        while ($row = $res->fetch_assoc()) {
            $st = ($row['status']=='rejected')?'Rejected':(($row['admin_status']=='approved')?'Approved':'Pending');
            $cls = strtolower($st);
            $can_act = false;
            // Logic to determine if buttons show
            if ($st === 'Pending') {
                if ($roleArg === 'advisor' && $row['advisor_status'] === 'pending') $can_act = true;
                elseif ($roleArg === 'hod' && $row['hod_status'] === 'pending') $can_act = true;
                elseif (($roleArg === 'dean' || $roleArg === 'principal') && $row['dean_status'] === 'pending') $can_act = true;
                elseif ($roleArg === 'admin' && $row['admin_status'] === 'pending') $can_act = true;
            }
            // Passing all row data to JS for Full Profile View
            $rowData = htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8');
            
            echo "<tr>
                <td>#".str_pad($row['id'],4,'0',STR_PAD_LEFT)."</td>
                <td><b>{$row['student_name']}</b><br><small>{$row['register_number']}</small></td>
                <td>{$row['bonafide_type']}</td>
                <td><span class='status-pill $cls'>$st</span></td>
                <td style='display:flex; gap:5px;'>
                    <button class='btn-insta' style='padding:5px 10px; font-size:0.8rem;' onclick='openModal(\"view\", $rowData, \"$roleArg\")'>View</button>
                    <button class='btn-insta' style='padding:5px 10px; font-size:0.8rem; background:#8b5cf6;' onclick='openModal(\"profile\", $rowData, \"$roleArg\")'>Profile</button>";
            if ($can_act) {
                echo "<form method='POST' style='margin:0;'><input type='hidden' name='req_id' value='{$row['id']}'><input type='hidden' name='action' value='approve'><button class='btn-insta' style='padding:5px 10px; font-size:0.8rem; background:#10b981;'>Approve</button></form>";
                echo "<form method='POST' style='margin:0;'><input type='hidden' name='req_id' value='{$row['id']}'><input type='hidden' name='action' value='reject'><button class='btn-insta' style='padding:5px 10px; font-size:0.8rem; background:#ef4444;'>Reject</button></form>";
            }
            if ($roleArg === 'admin') echo "<form method='POST' style='margin:0;'><input type='hidden' name='req_id' value='{$row['id']}'><input type='hidden' name='action' value='soft_delete'><button class='btn-insta' style='padding:5px 10px; font-size:0.8rem; background:#6366f1;' onclick='return confirm(\"Delete?\")'>Del</button></form>";
            echo "</td></tr>";
        }
        echo '</tbody></table></div>';
    } else {
        echo "<div style='padding:50px; text-align:center;'>No requests found.</div>";
    }
}
include '../includes/footer.php'; 
?>