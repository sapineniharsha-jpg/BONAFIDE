<?php
// student/view.php - Complete Student Bonafide System
session_start();

// Check if student is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student') {
    header("Location: ../login.php");
    exit();
}

require_once '../includes/db.php';
require_once '../includes/functions.php';

$student_id = $_SESSION['user_id'];
$student_name = $_SESSION['name'];
$action = $_GET['action'] ?? '';
$request_id = $_GET['id'] ?? 0;

// Get complete student profile
$student = getCompleteStudentProfile($student_id);

// Check profile completion
$profile_complete = checkProfileCompletion($student);
$missing_fields = getMissingFields($student);

// Handle profile completion redirect
if (!$profile_complete && $action != 'edit_profile') {
    header("Location: view.php?action=edit_profile");
    exit();
}

// Handle form submissions
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['submit_request'])) {
        $bonafide_type = sanitize($_POST['bonafide_type']);
        $purpose = sanitize($_POST['purpose']);
        $additional_info = sanitize($_POST['additional_info'] ?? '');
        
        $request_id = createBonafideRequest($student_id, $bonafide_type, $purpose, $additional_info);
        
        if ($request_id) {
            $message = "Bonafide request submitted successfully! Tracking ID: BON-$request_id";
            $message_type = 'success';
        } else {
            $message = "Failed to submit request. Please try again.";
            $message_type = 'error';
        }
    }
    
    if (isset($_POST['update_profile'])) {
        // Update profile fields
        foreach ($_POST as $key => $value) {
            if (strpos($key, 'update_') === 0) {
                $field = str_replace('update_', '', $key);
                $value = sanitize($value);
                
                // Update in appropriate table
                if (isset($student['IDNo'])) {
                    // Old students table
                    $query = "UPDATE students_login_master SET $field = ? WHERE IDNo = ?";
                } else {
                    // New students table
                    $query = "UPDATE students_batch_25_26 SET $field = ? WHERE id_no = ?";
                }
                
                $stmt = $mysqli->prepare($query);
                $stmt->bind_param("ss", $value, $student_id);
                $stmt->execute();
            }
        }
        
        $message = "Profile updated successfully!";
        $message_type = 'success';
        $student = getCompleteStudentProfile($student_id);
        $profile_complete = checkProfileCompletion($student);
    }
    
    if (isset($_POST['revoke_request'])) {
        $revoke_id = intval($_POST['revoke_id']);
        if (revokeRequest($student_id, $revoke_id)) {
            $message = "Request revoked successfully!";
            $message_type = 'success';
        } else {
            $message = "Unable to revoke request. It may already be processed.";
            $message_type = 'error';
        }
    }
}

// Get student requests
$requests_result = getStudentRequests($student_id);
$requests = [];
while ($row = $requests_result->fetch_assoc()) {
    $requests[] = $row;
}

// Get student certificates
$certificates_result = getStudentCertificates($student_id);
$certificates = [];
while ($row = $certificates_result->fetch_assoc()) {
    $certificates[] = $row;
}

// Demo data for preview
$demo_data = [];
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['preview'])) {
    $demo_data = [
        'type' => $_POST['bonafide_type'] ?? 'General',
        'purpose' => $_POST['purpose'] ?? 'General Purpose',
        'student_name' => $student_name,
        'register_no' => $student['RegisterNo'] ?? $student['id_no'],
        'department' => $student['Dept'] ?? $student['department'],
        'batch' => $student['Batch'] ?? $student['batch'],
        'date' => date('d-m-Y'),
        'additional_info' => $_POST['additional_info'] ?? ''
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bonafide Certificate System - Student Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #3a86ff;
            --secondary: #8338ec;
            --success: #38b000;
            --warning: #ff9e00;
            --danger: #ff006e;
            --light: #f8f9fa;
            --dark: #212529;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .main-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
            margin-top: 20px;
            margin-bottom: 20px;
        }
        
        .header-section {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 30px;
            position: relative;
            overflow: hidden;
        }
        
        .header-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><path d="M0,0 L100,0 L100,100 Z" fill="rgba(255,255,255,0.1)"/></svg>');
            background-size: cover;
        }
        
        .student-info-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            border-left: 5px solid var(--primary);
        }
        
        .request-form-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            height: 100%;
            border-top: 5px solid var(--secondary);
        }
        
        .preview-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            height: 100%;
            border-top: 5px solid var(--success);
        }
        
        .demo-preview {
            border: 2px dashed #ccc;
            padding: 20px;
            min-height: 300px;
            background: #f9f9f9;
            border-radius: 10px;
            font-family: 'Times New Roman', serif;
        }
        
        .status-badge {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .status-pending { background: #fff3cd; color: #856404; }
        .status-approved { background: #d4edda; color: #155724; }
        .status-rejected { background: #f8d7da; color: #721c24; }
        .status-processing { background: #cce5ff; color: #004085; }
        .status-revoked { background: #e2e3e5; color: #383d41; }
        .status-completed { background: #d1ecf1; color: #0c5460; }
        
        .timeline {
            position: relative;
            padding-left: 30px;
            margin: 20px 0;
        }
        
        .timeline::before {
            content: '';
            position: absolute;
            left: 10px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #dee2e6;
        }
        
        .timeline-item {
            position: relative;
            margin-bottom: 20px;
        }
        
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -25px;
            top: 5px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: var(--primary);
            border: 3px solid white;
            box-shadow: 0 0 0 3px var(--primary);
        }
        
        .timeline-item.completed::before {
            background: var(--success);
            box-shadow: 0 0 0 3px var(--success);
        }
        
        .certificate-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            border-left: 5px solid var(--success);
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s;
        }
        
        .certificate-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        
        .qr-code {
            width: 100px;
            height: 100px;
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            color: #6c757d;
            text-align: center;
            padding: 5px;
        }
        
        .btn-gradient {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-gradient:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(58, 134, 255, 0.3);
            color: white;
        }
        
        .alert-profile {
            background: linear-gradient(135deg, #ff9a9e 0%, #fad0c4 100%);
            border: none;
            color: #721c24;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        @media print {
            .no-print { display: none !important; }
            .demo-preview { border: none; box-shadow: none; }
        }
    </style>
</head>
<body>
    <div class="container-fluid py-4">
        <div class="main-container">
            <!-- Header Section -->
            <div class="header-section">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h1 class="display-5 fw-bold mb-3">
                            <i class="fas fa-certificate me-2"></i>Bonafide Certificate System
                        </h1>
                        <p class="lead mb-0">Student Portal - Submit and Track Your Bonafide Requests</p>
                    </div>
                    <div class="col-md-4 text-end">
                        <div class="d-flex align-items-center justify-content-end">
                            <div class="text-end">
                                <h5 class="mb-1"><?php echo htmlspecialchars($student_name); ?></h5>
                                <p class="mb-0">ID: <?php echo htmlspecialchars($student_id); ?></p>
                                <a href="logout.php" class="btn btn-sm btn-light mt-2">
                                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="container-fluid p-4">
                <?php if($message): ?>
                    <div class="alert alert-<?php echo $message_type == 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if(!$profile_complete && $action == 'edit_profile'): ?>
                <!-- Profile Completion Section -->
                <div class="row">
                    <div class="col-12">
                        <div class="alert-profile">
                            <h4><i class="fas fa-exclamation-triangle me-2"></i>Complete Your Profile</h4>
                            <p class="mb-0">Please fill in the following mandatory details to submit bonafide requests:</p>
                        </div>
                        
                        <div class="card">
                            <div class="card-header bg-warning text-dark">
                                <h5 class="mb-0"><i class="fas fa-user-edit me-2"></i>Update Profile Information</h5>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="view.php">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Father's Name *</label>
                                            <input type="text" name="update_fathername" class="form-control" 
                                                   value="<?php echo htmlspecialchars($student['fathername'] ?? $student['parent_name'] ?? ''); ?>" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Gender *</label>
                                            <select name="update_Gender" class="form-select" required>
                                                <option value="">Select Gender</option>
                                                <option value="Male" <?php echo (($student['Gender'] ?? $student['gender'] ?? '') == 'Male') ? 'selected' : ''; ?>>Male</option>
                                                <option value="Female" <?php echo (($student['Gender'] ?? $student['gender'] ?? '') == 'Female') ? 'selected' : ''; ?>>Female</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Batch *</label>
                                            <input type="text" name="update_Batch" class="form-control" 
                                                   value="<?php echo htmlspecialchars($student['Batch'] ?? $student['batch'] ?? ''); ?>" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Community *</label>
                                            <input type="text" name="update_Community" class="form-control" 
                                                   value="<?php echo htmlspecialchars($student['Community'] ?? $student['community'] ?? ''); ?>" required>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <label class="form-label">Address *</label>
                                            <textarea name="update_Address" class="form-control" rows="3" required><?php echo htmlspecialchars($student['Address'] ?? $student['address'] ?? ''); ?></textarea>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Mobile Number *</label>
                                            <input type="tel" name="update_student_mobile" class="form-control" 
                                                   value="<?php echo htmlspecialchars($student['student_mobile'] ?? ''); ?>" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">College Email *</label>
                                            <input type="email" name="update_college_email" class="form-control" 
                                                   value="<?php echo htmlspecialchars($student['college_email'] ?? ''); ?>" required>
                                        </div>
                                    </div>
                                    <div class="d-grid gap-2">
                                        <button type="submit" name="update_profile" class="btn-gradient">
                                            <i class="fas fa-save me-2"></i>Save Profile
                                        </button>
                                        <a href="view.php" class="btn btn-outline-secondary">
                                            <i class="fas fa-times me-2"></i>Cancel
                                        </a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                
                <!-- Student Info Card -->
                <div class="student-info-card">
                    <div class="row">
                        <div class="col-md-8">
                            <h4 class="mb-3">Student Information</h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <p class="mb-2"><strong>Name:</strong> <?php echo htmlspecialchars($student_name); ?></p>
                                    <p class="mb-2"><strong>Register No:</strong> <?php echo htmlspecialchars($student['RegisterNo'] ?? $student['id_no']); ?></p>
                                    <p class="mb-2"><strong>Department:</strong> <?php echo htmlspecialchars($student['Dept'] ?? $student['department']); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p class="mb-2"><strong>Batch:</strong> <?php echo htmlspecialchars($student['Batch'] ?? $student['batch']); ?></p>
                                    <p class="mb-2"><strong>Father's Name:</strong> <?php echo htmlspecialchars($student['fathername'] ?? $student['parent_name'] ?? 'Not provided'); ?></p>
                                    <p class="mb-2"><strong>Profile Status:</strong> 
                                        <span class="badge <?php echo $profile_complete ? 'bg-success' : 'bg-warning'; ?>">
                                            <?php echo $profile_complete ? 'Complete' : 'Incomplete'; ?>
                                        </span>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-end">
                            <a href="view.php?action=edit_profile" class="btn btn-outline-primary">
                                <i class="fas fa-edit me-2"></i>Edit Profile
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Request and Preview Section -->
                <div class="row mb-4">
                    <div class="col-lg-6 mb-4">
                        <div class="request-form-card">
                            <h4 class="mb-4">
                                <i class="fas fa-file-alt me-2"></i>New Bonafide Request
                            </h4>
                            <form method="POST" id="requestForm">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Bonafide Type *</label>
                                    <select name="bonafide_type" class="form-select" required onchange="updatePreview()">
                                        <option value="">Select Type</option>
                                        <option value="Study Certificate">Study Certificate</option>
                                        <option value="Fee Paid Certificate">Fee Paid Certificate</option>
                                        <option value="Conduct Certificate">Conduct Certificate</option>
                                        <option value="Course Completion">Course Completion</option>
                                        <option value="Internship">Internship</option>
                                        <option value="Project">Project</option>
                                        <option value="Scholarship">Scholarship</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Purpose *</label>
                                    <select name="purpose" class="form-select" required onchange="updatePreview()">
                                        <option value="">Select Purpose</option>
                                        <option value="Passport Application">Passport Application</option>
                                        <option value="Visa Application">Visa Application</option>
                                        <option value="Bank Loan">Bank Loan</option>
                                        <option value="Higher Studies">Higher Studies</option>
                                        <option value="Scholarship">Scholarship</option>
                                        <option value="Employment">Employment</option>
                                        <option value="Internship">Internship</option>
                                        <option value="Competition">Competition</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Additional Information</label>
                                    <textarea name="additional_info" class="form-control" rows="3" 
                                              placeholder="Any specific requirements or details..." 
                                              oninput="updatePreview()"></textarea>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <button type="submit" name="preview" class="btn btn-outline-primary">
                                        <i class="fas fa-eye me-2"></i>Preview
                                    </button>
                                    <button type="submit" name="submit_request" class="btn-gradient">
                                        <i class="fas fa-paper-plane me-2"></i>Submit Request
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <div class="col-lg-6 mb-4">
                        <div class="preview-card">
                            <h4 class="mb-4">
                                <i class="fas fa-file-certificate me-2"></i>Live Preview
                            </h4>
                            <div class="demo-preview" id="demoPreview">
                                <?php if(!empty($demo_data)): ?>
                                    <div style="text-align: center; margin-bottom: 20px;">
                                        <h4 style="color: #2c3e50;">BONAFIDE CERTIFICATE</h4>
                                        <hr style="border-top: 2px solid #2c3e50;">
                                    </div>
                                    <p>This is to certify that <strong><?php echo htmlspecialchars($demo_data['student_name']); ?></strong> 
                                    (Reg. No: <strong><?php echo htmlspecialchars($demo_data['register_no']); ?></strong>) is a bonafide student of 
                                    Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College.</p>
                                    
                                    <p>The student is pursuing <?php echo htmlspecialchars($demo_data['batch']); ?> batch in the Department of 
                                    <?php echo htmlspecialchars($demo_data['department']); ?>.</p>
                                    
                                    <p>This certificate is issued for the purpose of <strong><?php echo htmlspecialchars($demo_data['purpose']); ?></strong> 
                                    and is valid for official use.</p>
                                    
                                    <?php if(!empty($demo_data['additional_info'])): ?>
                                    <p><strong>Additional Information:</strong> <?php echo htmlspecialchars($demo_data['additional_info']); ?></p>
                                    <?php endif; ?>
                                    
                                    <div style="margin-top: 40px; text-align: right;">
                                        <p>Date: <?php echo htmlspecialchars($demo_data['date']); ?></p>
                                        <p><strong>PRINCIPAL</strong></p>
                                    </div>
                                <?php else: ?>
                                    <div class="text-center text-muted" style="padding: 100px 0;">
                                        <i class="fas fa-file-alt fa-3x mb-3"></i>
                                        <p>Fill out the form to preview your certificate</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Requests and Certificates Tabs -->
                <div class="row">
                    <div class="col-12">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="requests-tab" data-bs-toggle="tab" data-bs-target="#requests" type="button">
                                    <i class="fas fa-history me-2"></i>My Requests
                                    <span class="badge bg-primary ms-2"><?php echo count($requests); ?></span>
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="certificates-tab" data-bs-toggle="tab" data-bs-target="#certificates" type="button">
                                    <i class="fas fa-award me-2"></i>My Certificates
                                    <span class="badge bg-success ms-2"><?php echo count($certificates); ?></span>
                                </button>
                            </li>
                        </ul>
                        
                        <div class="tab-content p-4 bg-white border border-top-0 rounded-bottom">
                            <!-- Requests Tab -->
                            <div class="tab-pane fade show active" id="requests" role="tabpanel">
                                <?php if(empty($requests)): ?>
                                    <div class="text-center py-5">
                                        <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                        <h5>No Requests Found</h5>
                                        <p class="text-muted">You haven't submitted any bonafide requests yet.</p>
                                    </div>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Type</th>
                                                    <th>Purpose</th>
                                                    <th>Submitted On</th>
                                                    <th>Status</th>
                                                    <th>Approval Chain</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach($requests as $request): 
                                                    $approval_chain = getApprovalChain($request['id']);
                                                ?>
                                                <tr>
                                                    <td>BON-<?php echo $request['id']; ?></td>
                                                    <td><?php echo htmlspecialchars($request['bonafide_type']); ?></td>
                                                    <td><?php echo htmlspecialchars(substr($request['purpose'], 0, 30)) . '...'; ?></td>
                                                    <td><?php echo date('d M Y', strtotime($request['request_date'])); ?></td>
                                                    <td>
                                                        <?php 
                                                        $status = $request['status'];
                                                        $status_class = 'status-' . strtolower($status);
                                                        ?>
                                                        <span class="status-badge <?php echo $status_class; ?>">
                                                            <?php echo ucfirst($status); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <div class="timeline">
                                                            <div class="timeline-item <?php echo ($request['advisor_status'] == 'approved') ? 'completed' : ''; ?>">
                                                                <small>Class Advisor</small>
                                                                <div class="small text-muted">
                                                                    <?php echo ucfirst($request['advisor_status']); ?>
                                                                    <?php if($request['advisor_action_date']): ?>
                                                                        <br><?php echo date('d M', strtotime($request['advisor_action_date'])); ?>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                            <div class="timeline-item <?php echo ($request['hod_status'] == 'approved') ? 'completed' : ''; ?>">
                                                                <small>HOD</small>
                                                                <div class="small text-muted"><?php echo ucfirst($request['hod_status']); ?></div>
                                                            </div>
                                                            <div class="timeline-item <?php echo ($request['dean_status'] == 'approved') ? 'completed' : ''; ?>">
                                                                <small>Dean</small>
                                                                <div class="small text-muted"><?php echo ucfirst($request['dean_status']); ?></div>
                                                            </div>
                                                            <div class="timeline-item <?php echo ($request['admin_status'] == 'approved') ? 'completed' : ''; ?>">
                                                                <small>Admin</small>
                                                                <div class="small text-muted"><?php echo ucfirst($request['admin_status']); ?></div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <?php if($request['advisor_status'] == 'pending'): ?>
                                                        <form method="POST" style="display: inline;">
                                                            <input type="hidden" name="revoke_id" value="<?php echo $request['id']; ?>">
                                                            <button type="submit" name="revoke_request" class="btn btn-sm btn-outline-danger" 
                                                                    onclick="return confirm('Are you sure you want to revoke this request?');">
                                                                <i class="fas fa-times me-1"></i>Revoke
                                                            </button>
                                                        </form>
                                                        <?php endif; ?>
                                                        <a href="request_details.php?id=<?php echo $request['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                            <i class="fas fa-eye me-1"></i>View
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Certificates Tab -->
                            <div class="tab-pane fade" id="certificates" role="tabpanel">
                                <?php if(empty($certificates)): ?>
                                    <div class="text-center py-5">
                                        <i class="fas fa-certificate fa-3x text-muted mb-3"></i>
                                        <h5>No Certificates Found</h5>
                                        <p class="text-muted">Your approved certificates will appear here.</p>
                                    </div>
                                <?php else: ?>
                                    <div class="row">
                                        <?php foreach($certificates as $cert): ?>
                                        <div class="col-md-6 col-lg-4 mb-4">
                                            <div class="certificate-card">
                                                <div class="d-flex justify-content-between align-items-start mb-3">
                                                    <div>
                                                        <h6 class="mb-1 fw-bold"><?php echo htmlspecialchars($cert['certificate_type']); ?></h6>
                                                        <small class="text-muted">Ref: <?php echo htmlspecialchars($cert['ref_number']); ?></small>
                                                    </div>
                                                    <span class="badge bg-success">Approved</span>
                                                </div>
                                                
                                                <p class="small mb-2">
                                                    <i class="fas fa-user-graduate me-2"></i>
                                                    <?php echo htmlspecialchars($cert['student_name']); ?>
                                                </p>
                                                
                                                <p class="small mb-3">
                                                    <i class="fas fa-calendar me-2"></i>
                                                    <?php echo date('d M Y', strtotime($cert['bonafide_date'])); ?>
                                                </p>
                                                
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div class="qr-code">
                                                        <?php if($cert['qr_code_path']): ?>
                                                            <img src="../<?php echo htmlspecialchars($cert['qr_code_path']); ?>" alt="QR Code" style="max-width: 100%;">
                                                        <?php else: ?>
                                                            <div>QR Code</div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div>
                                                        <a href="../print_bonafide.php?id=<?php echo $cert['id']; ?>" target="_blank" class="btn btn-sm btn-primary">
                                                            <i class="fas fa-print me-1"></i>Print
                                                        </a>
                                                        <a href="../verify.php?ref=<?php echo urlencode($cert['ref_number']); ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                                                            <i class="fas fa-shield-alt me-1"></i>Verify
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Footer -->
            <div class="border-top p-4 text-center text-muted">
                <p class="mb-0">
                    <i class="fas fa-university me-1"></i>Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College
                    <br>
                    <small>Bonafide Certificate System © <?php echo date('Y'); ?></small>
                </p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function updatePreview() {
            // This is a simplified preview update
            // In production, you would use AJAX to update the preview dynamically
            const form = document.getElementById('requestForm');
            const previewBtn = form.querySelector('button[name="preview"]');
            previewBtn.click();
        }
        
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    </script>
</body>
</html>