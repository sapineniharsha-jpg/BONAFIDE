<?php
ini_set('display_errors', 0);

error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', '../logs/dept_errors.log');
// print_certificate.php - Final Certificate with QR Code
ob_start();
session_start();

require_once '../includes/db.php';
require_once '../includes/functions.php';

$cert_id = intval($_GET['id'] ?? 0);

$sql = "SELECT * FROM bonafide_certificates WHERE id = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $cert_id);
$stmt->execute();
$certificate = $stmt->get_result()->fetch_assoc();

if (!$certificate) {
    die("Certificate not found");
}

// Generate QR code if not exists
if (empty($certificate['qr_code_path'])) {
    $qrData = "https://www.velhightech.com/verify.php?ref=" . urlencode($certificate['ref_number']);
    $qrFile = '../temp/qr_' . md5($certificate['ref_number']) . '.png';

    if (!file_exists($qrFile)) {
        require_once '../includes/phpqrcode/qrlib.php';
        if (!is_dir('../temp'))
            mkdir('../temp');
        QRcode::png($qrData, $qrFile, QR_ECLEVEL_H, 3);
        require_once '../includes/qr_branding.php';
        add_qr_branding($qrFile);

        // Update database
        $update = $mysqli->prepare("UPDATE bonafide_certificates SET qr_code_path = ? WHERE id = ?");
        $update->bind_param("si", $qrFile, $cert_id);
        $update->execute();
        $certificate['qr_code_path'] = $qrFile;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <style>
        @page { size: A4; margin: 0; }
        body { 
            margin: 0; 
            padding: 0; 
            font-family: 'Times New Roman', serif; 
            background: white;
        }
        .certificate {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm;
            position: relative;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .qr-code {
            position: absolute;
            left: 20mm;
            bottom: 20mm;
            text-align: center;
        }
        .signature {
            position: absolute;
            right: 20mm;
            bottom: 20mm;
            text-align: center;
            width: 150px;
        }
        .valid-note {
            position: absolute;
            bottom: 5mm;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 10px;
            color: #666;
        }
        .ref-number {
            position: absolute;
            top: 10mm;
            right: 20mm;
            font-size: 12px;
            font-weight: bold;
            color: #b71c1c;
        }
    </style>
</head>
<body>
    <div class="certificate">
        <!-- Reference Number -->
        <div class="ref-number">
            Ref: <?php echo htmlspecialchars($certificate['ref_number']); ?>
        </div>
        
        <!-- Header -->
        <div class="header">
            <h1 style="margin: 0; color: #1a237e;">Vel Tech High Tech</h1>
            <h3 style="margin: 5px 0; color: #0d47a1;">Dr. Rangarajan Dr. Sakunthala Engineering College</h3>
            <p style="margin: 5px 0; font-size: 12px;">
                (An Autonomous Institution, Affiliated to Anna University, Chennai)
            </p>
        </div>
        
        <!-- Date -->
        <div style="text-align: right; margin: 10px 0 30px;">
            Date: <?php echo date('d M Y', strtotime($certificate['bonafide_date'])); ?>
        </div>
        
        <!-- Certificate Content -->
        <div style="line-height: 1.6; font-size: 14pt;">
            <h2 style="text-align: center; text-decoration: underline; margin-bottom: 30px;">
                <?php
$title_map = [
    'Normal' => 'BONAFIDE CERTIFICATE',
    'Fee Structure' => 'BONAFIDE CERTIFICATE FOR FEE STRUCTURE',
    'Fee Paid' => 'BONAFIDE CERTIFICATE FOR FEE PAID',
    'Internship' => 'BONAFIDE CERTIFICATE FOR INTERNSHIP',
    'Project' => 'PERMISSION FOR PROJECT WORK',
    'Alumni' => 'TO WHOMSOEVER IT MAY CONCERN',
    'LOR' => 'LETTER OF RECOMMENDATION'
];
echo $title_map[$certificate['certificate_type']] ?? 'BONAFIDE CERTIFICATE';
?>
            </h2>
            
            <!-- Dynamic content based on certificate type -->
            <?php echo generateCertificateContent($certificate); ?>
        </div>
        
        <!-- QR Code -->
        <div class="qr-code">
            <?php if ($certificate['qr_code_path']): ?>
                <img src="<?php echo $certificate['qr_code_path']; ?>" width="80" height="80" alt="QR Code"><br>
                <small>Scan to Verify</small>
            <?php
endif; ?>
        </div>
        
        <!-- Signature -->
        <div class="signature">
            <div style="margin-bottom: 60px; border-top: 1px solid #000; padding-top: 5px;">
                PRINCIPAL
            </div>
            <div style="font-size: 10px; color: #666;">
                Space for College Seal
            </div>
        </div>
        
        <!-- Validation Note -->
        <div class="valid-note">
            This is a digitally signed document. Verify authenticity by scanning QR code.
        </div>
    </div>
    
    <script>
        // Auto print
        window.onload = function() {
            setTimeout(() => {
                window.print();
            }, 1000);
        };
        
        // After print, close window if opened in new tab
        window.onafterprint = function() {
            if (window.opener) {
                window.close();
            }
        };
    </script>
</body>
</html>