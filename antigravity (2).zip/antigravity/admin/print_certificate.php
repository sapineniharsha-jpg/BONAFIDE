<?php
// print_certificate.php - Print Final Certificate
ob_start();
session_start();

require_once '../includes/db.php';
require_once '../includes/functions.php';

$cert_id = intval($_GET['id'] ?? 0);

if (!$cert_id) {
    die("Certificate ID not provided");
}

$sql = "SELECT * FROM bonafide_certificates WHERE id = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $cert_id);
$stmt->execute();
$certificate = $stmt->get_result()->fetch_assoc();

if (!$certificate) {
    die("Certificate not found");
}

// Generate QR code if not exists
if (empty($certificate['qr_code_path'])) {
    $qrData = "https://www.velhightech.com/verify.php?ref=" . urlencode($certificate['ref_number']);
    $qrFile = '../temp/qr_' . md5($certificate['ref_number']) . '.png';

    if (!file_exists($qrFile)) {
        require_once '../includes/phpqrcode/qrlib.php';
        if (!is_dir('../temp'))
            mkdir('../temp', 0755, true);
        QRcode::png($qrData, $qrFile, QR_ECLEVEL_H, 3);
        require_once '../includes/qr_branding.php';
        add_qr_branding($qrFile);

        // Update database
        $update = $mysqli->prepare("UPDATE bonafide_certificates SET qr_code_path = ? WHERE id = ?");
        $update->bind_param("si", $qrFile, $cert_id);
        $update->execute();
        $certificate['qr_code_path'] = $qrFile;
    }
}

// Determine year pursuing based on batch
$batch = $certificate['batch_completed'] ?? '2021-2025';
$startYear = intval(explode('-', $batch)[0] ?? date('Y'));
$curYear = date('Y');
$month = date('n');
$diff = $curYear - $startYear + ($month >= 6 ? 1 : 0);
$year_pursuing = ($diff == 1) ? 'I' : (($diff == 2) ? 'II' : (($diff == 3) ? 'III' : 'IV'));
if ($diff > 4)
    $year_pursuing = 'Completed';

$gender = $certificate['student_prefix'] == 'Mr.' ? 'male' : 'female';
$isMale = $gender === 'male';
$pfx = $isMale ? 'Mr.' : 'Ms.';
$rel = $isMale ? 'son of' : 'daughter of';
$pro = $isMale ? 'his' : 'her';
$objPro = $isMale ? 'him' : 'her';

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate - <?php echo htmlspecialchars($certificate['ref_number']); ?></title>
    <style>
        @page {
            size: A4;
            margin: 0;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Times New Roman', serif;
            margin: 0;
            padding: 0;
            background: white;
            color: #000;
        }
        
        .certificate {
            width: 210mm;
            min-height: 297mm;
            padding: 20mm;
            position: relative;
        }
        
        .header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 15px;
            margin-bottom: 30px;
        }
        
        .college-name {
            color: #1a237e;
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 5px;
            text-transform: uppercase;
        }
        
        .college-subtitle {
            color: #0d47a1;
            font-size: 18px;
            margin-bottom: 10px;
            font-weight: bold;
        }
        
        .college-details {
            font-size: 12px;
            color: #37474f;
            line-height: 1.4;
        }
        
        .ref-number {
            position: absolute;
            top: 20mm;
            right: 20mm;
            font-size: 12px;
            font-weight: bold;
            color: #b71c1c;
        }
        
        .cert-date {
            text-align: right;
            margin: 10px 0 30px;
            font-size: 14px;
        }
        
        .cert-title {
            text-align: center;
            text-decoration: underline;
            font-size: 18px;
            font-weight: bold;
            margin: 30px 0;
            text-transform: uppercase;
        }
        
        .content {
            font-size: 14px;
            line-height: 1.8;
            text-align: justify;
        }
        
        .content p {
            margin-bottom: 15px;
        }
        
        .student-name {
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .footer {
            margin-top: 100px;
            position: relative;
            height: 120px;
        }
        
        .qr-code {
            position: absolute;
            left: 0;
            bottom: 0;
            text-align: center;
        }
        
        .qr-code img {
            width: 80px;
            height: 80px;
            border: 1px solid #ddd;
            padding: 5px;
            background: white;
        }
        
        .signature {
            position: absolute;
            right: 0;
            bottom: 0;
            text-align: center;
        }
        
        .signature-line {
            width: 200px;
            border-top: 1px solid #000;
            margin-top: 60px;
            padding-top: 5px;
            font-weight: bold;
            font-size: 14px;
        }
        
        .valid-note {
            position: absolute;
            bottom: 5mm;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 10px;
            color: #666;
        }
        
        .watermark {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 80px;
            color: rgba(0,0,0,0.05);
            z-index: -1;
            white-space: nowrap;
            font-weight: bold;
        }
        
        /* Print styles */
        @media print {
            body {
                background: white;
                padding: 0;
            }
            
            .certificate {
                width: 100%;
                padding: 15mm;
            }
            
            .no-print {
                display: none !important;
            }
            
            .watermark {
                display: none;
            }
        }
        
        /* Preview styles */
        @media screen {
            body {
                background: #f5f5f5;
                padding: 20px;
            }
            
            .certificate {
                background: white;
                box-shadow: 0 0 20px rgba(0,0,0,0.1);
                margin: 0 auto;
            }
            
            .print-controls {
                text-align: center;
                margin-top: 20px;
                padding: 20px;
            }
            
            .btn {
                padding: 12px 24px;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                font-size: 14px;
                font-weight: bold;
                margin: 0 5px;
            }
            
            .btn-print {
                background: #4CAF50;
                color: white;
            }
            
            .btn-close {
                background: #f44336;
                color: white;
            }
        }
    </style>
</head>
<body>
    <div class="certificate">
        <div class="watermark">OFFICIAL</div>
        
        <!-- Reference Number -->
        <div class="ref-number">
            Ref: <?php echo htmlspecialchars($certificate['ref_number']); ?>
        </div>
        
        <!-- Header -->
        <div class="header">
            <div class="college-name">Vel Tech High Tech</div>
            <div class="college-subtitle">Dr. Rangarajan Dr. Sakunthala Engineering College</div>
            <div class="college-details">
                (An Autonomous Institution, Approved by AICTE, Affiliated to Anna University, Chennai)<br>
                Accredited by NAAC with 'A' Grade | NBA Accredited Programs<br>
                #60, Avadi-Alamathi Road, Morai Village, Avadi, Chennai - 600062
            </div>
        </div>
        
        <!-- Date -->
        <div class="cert-date">
            Date: <?php echo date('d M Y', strtotime($certificate['bonafide_date'])); ?>
        </div>
        
        <!-- Certificate Content -->
        <div class="content">
            <div class="cert-title">
                <?php
$title_map = [
    'Normal' => 'BONAFIDE CERTIFICATE',
    'Fee Structure' => 'BONAFIDE CERTIFICATE FOR FEE STRUCTURE',
    'Fee Paid' => 'BONAFIDE CERTIFICATE FOR FEE PAID',
    'Internship' => 'BONAFIDE CERTIFICATE FOR INTERNSHIP',
    'Project' => 'PERMISSION FOR PROJECT WORK',
    'Alumni' => 'TO WHOMSOEVER IT MAY CONCERN',
    'LOR' => 'LETTER OF RECOMMENDATION'
];
echo $title_map[$certificate['certificate_type']] ?? 'BONAFIDE CERTIFICATE';
?>
            </div>
            
            <?php if ($certificate['certificate_type'] === 'Alumni'): ?>
                <p>This is to certify that <span class="student-name"><?php echo $pfx . ' ' . htmlspecialchars($certificate['student_name']); ?></span> 
                (Register No: <strong><?php echo htmlspecialchars($certificate['register_number']); ?></strong>), 
                <?php echo $rel; ?> <strong><?php echo htmlspecialchars($certificate['father_name']); ?></strong>, 
                was a bonafide student of Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College (Autonomous) 
                and successfully completed the <strong><?php echo htmlspecialchars($certificate['department']); ?></strong> 
                degree program during the academic years <strong><?php echo htmlspecialchars($certificate['batch_completed']); ?></strong>.</p>
                
                <?php if (!empty($certificate['cgpa'])): ?>
                    <p>He/She completed the course with a CGPA of <strong><?php echo number_format($certificate['cgpa'], 2); ?></strong>.</p>
                <?php
    endif; ?>
                
                <?php if ($certificate['include_moi'] === 'Yes'): ?>
                    <p>The Medium of Instruction and Evaluation for the above-mentioned programme followed by the Institute is English.</p>
                <?php
    endif; ?>
                
                <?php if ($certificate['original_certificate_status'] === 'Yes'): ?>
                    <p>Degree Certificate will be issued in due course of time.</p>
                <?php
    endif; ?>
                
                <?php if ($certificate['include_conversion'] === 'Yes' && !empty($certificate['cgpa'])): ?>
                    <p><strong>The CGPA to percentage conversion is as follows:</strong><br>
                    Student CGPA: <?php echo number_format($certificate['cgpa'], 2); ?><br>
                    Conversion Grade: <?php echo number_format($certificate['conversion_factor'] ?? 10.00, 2); ?><br>
                    Converted Percentage: <?php echo number_format($certificate['percentage'] ?? ($certificate['cgpa'] * ($certificate['conversion_factor'] ?? 10.00)), 2); ?>%<br>
                    (Percentage = CGPA × Conversion Grade)</p>
                <?php
    endif; ?>
                
                <p>This certificate is issued upon <?php echo $pro; ?> request for the purpose of applying for 
                <strong><?php echo htmlspecialchars($certificate['purpose']); ?></strong> only.</p>
                
            <?php
elseif ($certificate['certificate_type'] === 'LOR'): ?>
                <?php
    $lor_details = explode('|', $certificate['internship_students'] ?? '');
    $lor_faculty = $lor_details[0] ?? '';
    $lor_designation = $lor_details[1] ?? 'Assistant Professor';
    $lor_subject = $lor_details[2] ?? '';
?>
                
                <p>To Whom It May Concern,</p>
                
                <p>This is to certify that <?php echo $pfx . ' ' . htmlspecialchars($certificate['student_name']); ?> 
                (Register No: <?php echo htmlspecialchars($certificate['register_number']); ?>) is an alumnus of 
                Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College, where <?php echo $pro; ?> studied 
                B.E/B.Tech in the Department of <?php echo htmlspecialchars($certificate['department']); ?> 
                during the academic period <?php echo htmlspecialchars($certificate['batch_completed']); ?>.</p>
                
                <p>As the <?php echo strtolower($lor_designation); ?> for the subject "<?php echo htmlspecialchars($lor_subject); ?>", 
                I had the opportunity to teach and observe <?php echo $pfx . ' ' . htmlspecialchars($certificate['student_name']); ?> 
                closely during <?php echo $pro; ?> academic tenure.</p>
                
                <p><?php echo $pfx . ' ' . htmlspecialchars($certificate['student_name']); ?> exhibited strong analytical skills, 
                innovative thinking, and the ability to apply theoretical concepts to practical problems.</p>
                
                <p>Based on my professional assessment, I strongly and wholeheartedly recommend 
                <?php echo $pfx . ' ' . htmlspecialchars($certificate['student_name']); ?> for higher education.</p>
                
                <br>
                <p>Yours sincerely,</p>
                <div style="font-weight:bold; margin-top: 20px;">
                    <?php echo htmlspecialchars($lor_faculty); ?><br>
                    <?php echo htmlspecialchars($lor_designation); ?>, <?php echo htmlspecialchars($certificate['department']); ?><br>
                    Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College
                </div>
                
            <?php
else: ?>
                <p>This is to certify that <span class="student-name"><?php echo $pfx . ' ' . htmlspecialchars($certificate['student_name']); ?></span> 
                (Register No: <strong><?php echo htmlspecialchars($certificate['register_number']); ?></strong>), 
                <?php echo $rel; ?> <strong><?php echo htmlspecialchars($certificate['father_name']); ?></strong>, 
                is a bonafide student of our institution, pursuing 
                <strong><?php echo $year_pursuing; ?></strong> Year B.E/B.Tech in 
                <strong><?php echo htmlspecialchars($certificate['department']); ?></strong> 
                during the academic year 2025-2026.</p>
                
                <p>This certificate is issued on <?php echo $pro; ?> request for the purpose of 
                <strong><?php echo htmlspecialchars($certificate['purpose']); ?></strong>.</p>
            <?php
endif; ?>
        </div>
        
        <!-- Footer -->
        <div class="footer">
            <div class="qr-code">
                <?php if (!empty($certificate['qr_code_path'])): ?>
                    <img src="<?php echo $certificate['qr_code_path']; ?>" alt="QR Code"><br>
                    <small>Scan to Verify</small>
                <?php
endif; ?>
            </div>
            
            <div class="signature">
                <div class="signature-line">
                    PRINCIPAL<br>
                    Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College
                </div>
            </div>
        </div>
        
        <!-- Validation Note -->
        <div class="valid-note">
            This is a digitally signed document. Verify authenticity by scanning QR code.
        </div>
    </div>
    
    <!-- Print Controls (only shown on screen) -->
    <div class="print-controls no-print">
        <button class="btn btn-print" onclick="window.print()">
            <i class="fas fa-print"></i> Print Certificate
        </button>
        <button class="btn btn-close" onclick="window.close()">
            <i class="fas fa-times"></i> Close Window
        </button>
    </div>
    
    <script>
        // Auto print after 1 second
        setTimeout(() => {
            if (!window.location.search.includes('noprint')) {
                window.print();
            }
        }, 1000);
        
        // Close window after print (if opened in popup)
        window.onafterprint = function() {
            if (window.opener) {
                setTimeout(() => {
                    window.close();
                }, 1000);
            }
        };
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Ctrl+P for print
            if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
                e.preventDefault();
                window.print();
            }
            
            // Escape to close
            if (e.key === 'Escape' && window.opener) {
                window.close();
            }
        });
    </script>
</body>
</html>