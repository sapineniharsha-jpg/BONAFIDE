<?php
require_once '../includes/config.php';
require_once '../includes/db.php';

// Auth Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Access Denied");
}

// Handle Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['answer'])) {
    $qId = (int)$_POST['id'];
    $answer = trim($_POST['answer']);
    $originalQ = trim($_POST['question']);

    if ($answer !== '') {
        // 1. Add to Master QA
        $stmt = $mysqli->prepare("INSERT INTO ai_qa_master (question, answer, category, created_by) VALUES (?, ?, 'general', ?)");
        $adminId = $_SESSION['user_id'];
        $stmt->bind_param("sss", $originalQ, $answer, $adminId);
        $stmt->execute();

        // 2. Mark as Answered
        $mysqli->query("UPDATE ai_unanswered_learning SET status = 'answered', admin_answer = '$answer' WHERE id = $qId");

        $success = "✅ Answer added to AI knowledge base!";
    }
}

// Fetch Pending
$pending = $mysqli->query("SELECT * FROM ai_unanswered_learning WHERE status = 'pending' ORDER BY frequency DESC, id DESC LIMIT 50");

// Fetch Training Suggestions (Frequency > 5)
$topPatterns = $mysqli->query("SELECT question, frequency FROM ai_unanswered_learning WHERE frequency > 5 AND status = 'pending' LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AI Training Center</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .train-card { background: white; border-radius: 12px; padding: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 20px; }
        .freq-badge { background: #fee2e2; color: #dc2626; padding: 4px 8px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; }
        .suggestion-box { background: #e0f2fe; border-left: 4px solid #0284c7; padding: 15px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container py-5">
        <h2 class="mb-4">🧠 AI Training Center</h2>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php
endif; ?>

        <?php if ($topPatterns->num_rows > 0): ?>
        <div class="suggestion-box">
            <h5>⚡ High Impact Training Suggestions</h5>
            <p>These questions are asked frequently. Answering them will significantly improve AI performance.</p>
            <ul>
                <?php while ($row = $topPatterns->fetch_assoc()): ?>
                    <li><strong>"<?php echo htmlspecialchars($row['question']); ?>"</strong> (Asked <?php echo $row['frequency']; ?> times)</li>
                <?php
    endwhile; ?>
            </ul>
        </div>
        <?php
endif; ?>

        <div class="row">
        <?php while ($row = $pending->fetch_assoc()): ?>
            <div class="col-md-6">
                <div class="train-card">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h6 class="text-primary mb-0"><?php echo htmlspecialchars($row['user_type']); ?> Query</h6>
                        <span class="freq-badge">Freq: <?php echo $row['frequency']; ?></span>
                    </div>
                    <p class="lead">"<?php echo htmlspecialchars($row['question']); ?>"</p>
                    <p class="text-muted small">First asked: <?php echo $row['created_at']; ?></p>
                    
                    <form method="post">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <input type="hidden" name="question" value="<?php echo htmlspecialchars($row['question']); ?>">
                        <div class="mb-2">
                            <textarea name="answer" class="form-control" placeholder="Type the correct answer here..." rows="3" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-sm btn-success w-100">Train AI & Save Answer</button>
                    </form>
                </div>
            </div>
        <?php
endwhile; ?>
        </div>
        
        <?php if ($pending->num_rows === 0): ?>
            <div class="text-center text-muted py-5">
                <h4>🎉 All caught up!</h4>
                <p>No unanswered questions pending review.</p>
            </div>
        <?php
endif; ?>
    </div>
</body>
</html>
