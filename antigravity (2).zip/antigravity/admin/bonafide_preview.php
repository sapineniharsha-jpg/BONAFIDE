<?php
// bonafide_preview.php
$v_name = $view_name ?? '[Student]';
$v_reg = $view_reg ?? '[Reg No]';
$v_father = $view_father ?? '[Parent]';
$v_dept = $view_dept ?? '[Dept]';
$v_purpose = $view_purpose ?? '[Purpose]';
$v_type = $view_type ?? 'BONAFIDE';
$v_gender = $view_gender ?? 'Male';
$pronoun = (strtoupper($v_gender) === 'FEMALE') ? 'D/o' : 'S/o';
?>
<div class="paper" style="padding:40px; border:1px solid #e2e8f0; font-family:'Times New Roman', serif; min-height:500px; box-shadow:0 10px 40px rgba(0,0,0,0.03); background:white;">
    <div style="text-align:center; margin-bottom:30px; border-bottom:2px solid #000; padding-bottom:20px;">
        <img src="https://www.velhightech.com/LP/logo.png" style="height:80px; display:block; margin:0 auto;">
        <h3 style="margin:10px 0 0; color:#1e3a8a;">Vel Tech High Tech</h3>
        <h4 style="margin:5px 0; color:#444;">Dr. Rangarajan Dr. Sakunthala Engineering College</h4>
    </div>
    <div style="text-align:center; font-weight:bold; text-decoration:underline; font-size:1.4rem; margin-bottom:30px;" id="prev_title">
        <?= $v_type ?> CERTIFICATE
    </div>
    <div style="text-align:justify; line-height:1.8; font-size:1.1rem;">
        <p>This is to certify that <strong><?= $v_name ?></strong> (Reg No: <strong><?= $v_reg ?></strong>), 
        <?= $pronoun ?> <strong><?= $v_father ?></strong>, is a bonafide student of our institution, pursuing <strong><?= $v_dept ?></strong>.</p>
        <p id="prev_text_container" style="margin-top:20px;">This certificate is issued for the purpose of <strong><?= $v_purpose ?></strong>.</p>
        <div id="fee_table_placeholder" style="display:none; margin-top:20px; text-align:center; color:#888;">
            <em>[Fee Structure Table will be inserted here by Admin]</em>
        </div>
    </div>
    <div style="margin-top:80px; text-align:right; font-weight:bold;">PRINCIPAL</div>
</div>