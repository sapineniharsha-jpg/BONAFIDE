<?php
ini_set('display_errors', 0); 
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', '../logs/dept_errors.log');
ob_start();
session_start();
require_once '../includes/db.php';
require_once '../includes/header.php';

if ($_SESSION['role'] !== 'student') {
    header('Location: unauthorized.php');
    exit();
}

$student_id = $_SESSION['user_id'];
$message = '';
$success = false;

// Get student data
$student_data = null;
$is_fresher = false;

$q1 = $mysqli->query("SELECT * FROM students_batch_25_26 WHERE register_no='$student_id' OR id_no='$student_id'");
if ($q1 && $q1->num_rows > 0) {
    $student_data = $q1->fetch_assoc();
    $is_fresher = true;
    $table = 'students_batch_25_26';
    $id_field = 'id_no';
} else {
    $q2 = $mysqli->query("SELECT * FROM students_login_master WHERE RegisterNo='$student_id' OR IDNo='$student_id'");
    if ($q2 && $q2->num_rows > 0) {
        $student_data = $q2->fetch_assoc();
        $is_fresher = false;
        $table = 'students_login_master';
        $id_field = 'IDNo';
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $updates = [];
    $field_map = [];
    
    if ($is_fresher) {
        $field_map = [
            'father_name' => 'parent_name',
            'gender' => 'gender',
            'dob' => 'dob',
            'mobile' => 'student_mobile',
            'father_mobile' => 'father_mobile',
            'mother_mobile' => 'mother_mobile',
            'address' => 'address',
            'pincode' => 'pincode',
            'aadhaar' => 'aadhaar_no',
            'community' => 'community',
            'batch' => 'batch',
            'section' => 'section'
        ];
    } else {
        $field_map = [
            'father_name' => 'fathername',
            'gender' => 'Gender',
            'dob' => 'DateofBirth',
            'mobile' => 'Student_contact',
            'father_mobile' => 'parent_contact',
            'address' => 'address',
            'pincode' => 'pincode',
            'aadhaar' => 'aadhaar_no',
            'community' => 'community',
            'batch' => 'Batch',
            'section' => 'Section'
        ];
    }
    
    foreach ($field_map as $form_field => $db_field) {
        if (isset($_POST[$form_field])) {
            $value = $mysqli->real_escape_string(trim($_POST[$form_field]));
            $updates[] = "$db_field = '$value'";
        }
    }
    
    if (!empty($updates)) {
        $update_sql = "UPDATE $table SET " . implode(', ', $updates) . " WHERE $id_field = '{$student_data[$id_field]}'";
        
        if ($mysqli->query($update_sql)) {
            $message = 'Profile updated successfully!';
            $success = true;
            
            // Refresh data
            $refresh = $mysqli->query("SELECT * FROM $table WHERE $id_field = '{$student_data[$id_field]}'");
            if ($refresh) $student_data = $refresh->fetch_assoc();
        } else {
            $message = 'Error: ' . $mysqli->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Complete Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Complete Your Profile</h4>
                </div>
                <div class="card-body">
                    <?php if($message): ?>
                        <div class="alert alert-<?php echo $success ? 'success' : 'danger'; ?>">
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Full Name</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($student_data['student_name'] ?? $student_data['Name'] ?? ''); ?>" disabled>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Register Number</label>
                                <input type="text" class="form-control" value="<?php echo $student_data['register_no'] ?? $student_data['RegisterNo'] ?? ''; ?>" disabled>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Father Name *</label>
                                <input type="text" name="father_name" class="form-control" required
                                       value="<?php echo htmlspecialchars($student_data['parent_name'] ?? $student_data['fathername'] ?? ''); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Gender *</label>
                                <select name="gender" class="form-select" required>
                                    <option value="">Select</option>
                                    <option value="Male" <?php echo ($student_data['gender'] ?? $student_data['Gender'] ?? '') == 'Male' ? 'selected' : ''; ?>>Male</option>
                                    <option value="Female" <?php echo ($student_data['gender'] ?? $student_data['Gender'] ?? '') == 'Female' ? 'selected' : ''; ?>>Female</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Date of Birth *</label>
                                <input type="date" name="dob" class="form-control" required
                                       value="<?php echo $student_data['dob'] ?? $student_data['DateofBirth'] ?? ''; ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Mobile Number *</label>
                                <input type="tel" name="mobile" class="form-control" required
                                       value="<?php echo $student_data['student_mobile'] ?? $student_data['Student_contact'] ?? ''; ?>">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Father Mobile *</label>
                                <input type="tel" name="father_mobile" class="form-control" required
                                       value="<?php echo $student_data['father_mobile'] ?? $student_data['parent_contact'] ?? ''; ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Aadhaar Number *</label>
                                <input type="text" name="aadhaar" class="form-control" required
                                       value="<?php echo $student_data['aadhaar_no'] ?? ''; ?>">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Batch *</label>
                                <input type="text" name="batch" class="form-control" required pattern="\d{4}-\d{4}"
                                       value="<?php echo $student_data['batch'] ?? $student_data['Batch'] ?? ''; ?>" placeholder="YYYY-YYYY">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Section</label>
                                <input type="text" name="section" class="form-control"
                                       value="<?php echo $student_data['section'] ?? $student_data['Section'] ?? ''; ?>">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Address *</label>
                                <textarea name="address" class="form-control" rows="3" required><?php echo htmlspecialchars($student_data['address'] ?? ''); ?></textarea>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Pincode *</label>
                                <input type="text" name="pincode" class="form-control" required
                                       value="<?php echo $student_data['pincode'] ?? ''; ?>">
                                <label class="mt-2">Community</label>
                                <select name="community" class="form-select">
                                    <option value="">Select</option>
                                    <option value="OC" <?php echo ($student_data['community'] ?? '') == 'OC' ? 'selected' : ''; ?>>OC</option>
                                    <option value="BC" <?php echo ($student_data['community'] ?? '') == 'BC' ? 'selected' : ''; ?>>BC</option>
                                    <option value="MBC" <?php echo ($student_data['community'] ?? '') == 'MBC' ? 'selected' : ''; ?>>MBC</option>
                                    <option value="SC" <?php echo ($student_data['community'] ?? '') == 'SC' ? 'selected' : ''; ?>>SC</option>
                                    <option value="ST" <?php echo ($student_data['community'] ?? '') == 'ST' ? 'selected' : ''; ?>>ST</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary btn-lg">Save Profile</button>
                            <a href="bonafide_system.php?tab=new" class="btn btn-success">Go to Bonafide Request</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php include '../includes/footer.php'; ?>