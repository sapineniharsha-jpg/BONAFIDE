<?php
// verify.php - Certificate Verification System
session_start();
require_once 'includes/db.php';

$ref_number = isset($_GET['ref']) ? $_GET['ref'] : '';
$search_query = isset($_GET['search']) ? $_GET['search'] : '';
$message = '';
$certificate = null;

// Handle verification
if (!empty($ref_number)) {
    $query = "SELECT c.*, br.purpose as request_purpose, br.bonafide_type as request_type 
              FROM bonafide_certificates c
              LEFT JOIN bonafide_requests br ON c.requestid = br.id
              WHERE c.ref_number = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $ref_number);
    $stmt->execute();
    $result = $stmt->get_result();
    $certificate = $result->fetch_assoc();
    
    if ($certificate) {
        // Record verification
        $mysqli->query("UPDATE bonafide_certificates SET verified_at = NOW() WHERE id = {$certificate['id']}");
    } else {
        $message = "Invalid certificate reference number.";
    }
}

// Handle search
if (!empty($search_query)) {
    $query = "SELECT c.*, br.purpose as request_purpose, br.bonafide_type as request_type 
              FROM bonafide_certificates c
              LEFT JOIN bonafide_requests br ON c.requestid = br.id
              WHERE c.ref_number LIKE ? OR c.student_name LIKE ? OR c.register_number LIKE ?
              ORDER BY c.created_at DESC LIMIT 10";
    $stmt = $mysqli->prepare($query);
    $search_param = "%$search_query%";
    $stmt->bind_param("sss", $search_param, $search_param, $search_param);
    $stmt->execute();
    $search_results = $stmt->get_result();
}

// Get recent verifications
$recent_query = "SELECT ref_number, student_name, verified_at 
                 FROM bonafide_certificates 
                 WHERE verified_at IS NOT NULL 
                 ORDER BY verified_at DESC 
                 LIMIT 5";
$recent_results = $mysqli->query($recent_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Bonafide Certificate</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --verify-primary: #2196f3;
            --verify-success: #4caf50;
            --verify-warning: #ff9800;
            --verify-danger: #f44336;
            --verify-light: #f5f5f5;
            --verify-dark: #212121;
        }
        
        body {
            background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .verify-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .verify-header {
            background: white;
            border-radius: 20px;
            padding: 40px;
            text-align: center;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            background: linear-gradient(135deg, var(--verify-primary), #0d47a1);
            color: white;
            position: relative;
            overflow: hidden;
        }
        
        .verify-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><path d="M0,0 L100,0 L100,100 Z" fill="rgba(255,255,255,0.1)"/></svg>');
            background-size: cover;
        }
        
        .college-logo {
            height: 80px;
            margin-bottom: 20px;
            filter: brightness(0) invert(1);
        }
        
        .verify-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .search-box {
            position: relative;
            margin-bottom: 20px;
        }
        
        .search-box input {
            padding-left: 50px;
            border-radius: 50px;
            border: 2px solid #e0e0e0;
            height: 50px;
            font-size: 16px;
        }
        
        .search-box i {
            position: absolute;
            left: 20px;
            top: 15px;
            color: #666;
            font-size: 20px;
        }
        
        .verify-result {
            border-left: 5px solid var(--verify-success);
            padding: 20px;
            margin: 20px 0;
            background: #f8fff8;
            border-radius: 10px;
        }
        
        .verify-result.invalid {
            border-left-color: var(--verify-danger);
            background: #fff8f8;
        }
        
        .certificate-details {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
        }
        
        .detail-item {
            display: flex;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .detail-label {
            font-weight: bold;
            width: 200px;
            color: #333;
        }
        
        .detail-value {
            flex: 1;
            color: #555;
        }
        
        .qr-display {
            text-align: center;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .qr-code {
            width: 200px;
            height: 200px;
            margin: 0 auto 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
            background: white;
        }
        
        .verification-badge {
            display: inline-block;
            padding: 10px 25px;
            border-radius: 50px;
            font-weight: bold;
            margin: 10px 0;
        }
        
        .badge-valid {
            background: #d4edda;
            color: #155724;
            border: 2px solid #c3e6cb;
        }
        
        .badge-invalid {
            background: #f8d7da;
            color: #721c24;
            border: 2px solid #f5c6cb;
        }
        
        .recent-verifications {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-top: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .recent-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        
        .recent-item:last-child {
            border-bottom: none;
        }
        
        .recent-ref {
            font-weight: bold;
            color: var(--verify-primary);
        }
        
        .recent-time {
            font-size: 12px;
            color: #666;
        }
        
        .print-btn {
            background: linear-gradient(135deg, var(--verify-primary), #0d47a1);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: bold;
            margin: 10px;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }
        
        .print-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(13, 71, 161, 0.3);
            color: white;
        }
        
        .share-buttons {
            margin-top: 20px;
        }
        
        .share-btn {
            display: inline-block;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            color: white;
            text-align: center;
            line-height: 40px;
            margin: 0 5px;
            text-decoration: none;
        }
        
        .share-whatsapp { background: #25d366; }
        .share-telegram { background: #0088cc; }
        .share-email { background: #ea4335; }
        .share-copy { background: #666; }
        
        .security-features {
            background: #e8f5e9;
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
            font-size: 14px;
        }
        
        .feature-item {
            display: flex;
            align-items: center;
            margin-bottom: 8px;
        }
        
        .feature-item i {
            color: var(--verify-success);
            margin-right: 10px;
        }
        
        .verify-footer {
            text-align: center;
            margin-top: 40px;
            padding: 20px;
            color: #666;
            font-size: 14px;
        }
        
        @media (max-width: 768px) {
            .verify-container {
                padding: 10px;
            }
            
            .verify-header {
                padding: 20px;
            }
            
            .detail-item {
                flex-direction: column;
            }
            
            .detail-label {
                width: 100%;
                margin-bottom: 5px;
            }
        }
    </style>
</head>
<body>
    <div class="verify-container">
        <!-- Header -->
        <div class="verify-header">
            <img src="https://www.velhightech.com/LP/logo.png" alt="College Logo" class="college-logo">
            <h1 class="display-5 fw-bold mb-3">Certificate Verification System</h1>
            <p class="lead mb-0">Verify the authenticity of bonafide certificates issued by Vel Tech High Tech</p>
        </div>
        
        <!-- Search Section -->
        <div class="verify-card">
            <h3 class="mb-4"><i class="fas fa-search me-2"></i>Verify Certificate</h3>
            
            <form method="GET" class="mb-4">
                <div class="search-box">
                    <i class="fas fa-certificate"></i>
                    <input type="text" name="ref" class="form-control" 
                           placeholder="Enter Certificate Reference Number (e.g., Ref/VH/eBONA/2024-25/001)" 
                           value="<?php echo htmlspecialchars($ref_number); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary btn-lg w-100">
                    <i class="fas fa-shield-alt me-2"></i>Verify Now
                </button>
            </form>
            
            <div class="text-center">
                <p class="text-muted">OR</p>
                <form method="GET">
                    <div class="search-box">
                        <i class="fas fa-user-graduate"></i>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search by Student Name or Register Number" 
                               value="<?php echo htmlspecialchars($search_query); ?>">
                    </div>
                    <button type="submit" class="btn btn-outline-primary btn-lg w-100">
                        <i class="fas fa-search me-2"></i>Search Records
                    </button>
                </form>
            </div>
        </div>
        
        <!-- Verification Results -->
        <?php if (!empty($ref_number) || !empty($search_query)): ?>
            <div class="verify-card">
                <?php if (!empty($ref_number)): ?>
                    <?php if ($certificate): ?>
                        <div class="verify-result">
                            <div class="text-center mb-4">
                                <span class="verification-badge badge-valid">
                                    <i class="fas fa-check-circle me-2"></i>VALID CERTIFICATE
                                </span>
                                <h3 class="mt-3">Certificate Verification Successful</h3>
                            </div>
                            
                            <div class="certificate-details">
                                <h5 class="mb-4"><i class="fas fa-info-circle me-2"></i>Certificate Details</h5>
                                
                                <div class="detail-item">
                                    <div class="detail-label">Reference Number:</div>
                                    <div class="detail-value fw-bold text-primary"><?php echo htmlspecialchars($certificate['ref_number']); ?></div>
                                </div>
                                
                                <div class="detail-item">
                                    <div class="detail-label">Student Name:</div>
                                    <div class="detail-value"><?php echo htmlspecialchars($certificate['student_name']); ?></div>
                                </div>
                                
                                <div class="detail-item">
                                    <div class="detail-label">Register Number:</div>
                                    <div class="detail-value"><?php echo htmlspecialchars($certificate['register_number']); ?></div>
                                </div>
                                
                                <div class="detail-item">
                                    <div class="detail-label">Department:</div>
                                    <div class="detail-value"><?php echo htmlspecialchars($certificate['department']); ?></div>
                                </div>
                                
                                <div class="detail-item">
                                    <div class="detail-label">Certificate Type:</div>
                                    <div class="detail-value"><?php echo htmlspecialchars($certificate['certificate_type']); ?></div>
                                </div>
                                
                                <div class="detail-item">
                                    <div class="detail-label">Issue Date:</div>
                                    <div class="detail-value"><?php echo date('d F Y', strtotime($certificate['bonafide_date'])); ?></div>
                                </div>
                                
                                <div class="detail-item">
                                    <div class="detail-label">Purpose:</div>
                                    <div class="detail-value"><?php echo htmlspecialchars($certificate['purpose']); ?></div>
                                </div>
                                
                                <div class="detail-item">
                                    <div class="detail-label">Verification Status:</div>
                                    <div class="detail-value">
                                        <span class="badge bg-success">Verified</span>
                                        <small class="text-muted ms-2">(Verified on <?php echo date('d M Y H:i', strtotime($certificate['verified_at'] ?? 'now')); ?>)</small>
                                    </div>
                                </div>
                                
                                <?php if (!empty($certificate['qr_code_path'])): ?>
                                <div class="detail-item">
                                    <div class="detail-label">QR Code:</div>
                                    <div class="detail-value">
                                        <img src="<?php echo htmlspecialchars($certificate['qr_code_path']); ?>" 
                                             alt="QR Code" style="width: 100px; height: 100px;">
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Action Buttons -->
                            <div class="text-center mt-4">
                                <a href="print_bonafide.php?ref=<?php echo urlencode($certificate['ref_number']); ?>" 
                                   target="_blank" class="print-btn">
                                    <i class="fas fa-print me-2"></i>Print Certificate
                                </a>
                                
                                <div class="share-buttons">
                                    <small class="text-muted d-block mb-2">Share Verification Link:</small>
                                    <?php
                                    $verification_url = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . "?ref=" . urlencode($certificate['ref_number']);
                                    $message = "Verify this bonafide certificate: " . $verification_url;
                                    ?>
                                    <a href="https://wa.me/?text=<?php echo urlencode($message); ?>" 
                                       target="_blank" class="share-btn share-whatsapp">
                                        <i class="fab fa-whatsapp"></i>
                                    </a>
                                    <a href="https://t.me/share/url?url=<?php echo urlencode($verification_url); ?>&text=<?php echo urlencode('Verify this bonafide certificate'); ?>" 
                                       target="_blank" class="share-btn share-telegram">
                                        <i class="fab fa-telegram"></i>
                                    </a>
                                    <a href="mailto:?subject=Certificate Verification&body=<?php echo urlencode($message); ?>" 
                                       class="share-btn share-email">
                                        <i class="fas fa-envelope"></i>
                                    </a>
                                    <button onclick="copyToClipboard('<?php echo $verification_url; ?>')" 
                                            class="share-btn share-copy">
                                        <i class="fas fa-copy"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <!-- Security Features -->
                            <div class="security-features">
                                <h6><i class="fas fa-shield-alt me-2"></i>Security Features</h6>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="feature-item">
                                            <i class="fas fa-check-circle"></i>
                                            <span>Unique Reference Number</span>
                                        </div>
                                        <div class="feature-item">
                                            <i class="fas fa-check-circle"></i>
                                            <span>QR Code Verification</span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="feature-item">
                                            <i class="fas fa-check-circle"></i>
                                            <span>Digital Verification Timestamp</span>
                                        </div>
                                        <div class="feature-item">
                                            <i class="fas fa-check-circle"></i>
                                            <span>Official College Seal</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="verify-result invalid">
                            <div class="text-center mb-4">
                                <span class="verification-badge badge-invalid">
                                    <i class="fas fa-times-circle me-2"></i>INVALID CERTIFICATE
                                </span>
                                <h3 class="mt-3">Certificate Not Found</h3>
                            </div>
                            
                            <div class="alert alert-danger">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                The certificate reference number <strong><?php echo htmlspecialchars($ref_number); ?></strong> 
                                was not found in our database. This could be due to:
                                <ul class="mt-2">
                                    <li>Incorrect reference number</li>
                                    <li>Certificate has been revoked or deleted</li>
                                    <li>Reference number is misspelled</li>
                                    <li>Certificate is not yet issued</li>
                                </ul>
                            </div>
                            
                            <div class="text-center">
                                <p>Please contact the college administration for assistance:</p>
                                <p class="mb-0">
                                    <i class="fas fa-phone me-2"></i>+91 44 2684 0181 | 
                                    <i class="fas fa-envelope ms-2 me-2"></i>principal@velhightech.com
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                
                <!-- Search Results -->
                <?php if (!empty($search_query) && isset($search_results)): ?>
                    <h5 class="mb-4">Search Results for "<?php echo htmlspecialchars($search_query); ?>"</h5>
                    
                    <?php if ($search_results->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Ref No</th>
                                        <th>Student Name</th>
                                        <th>Register No</th>
                                        <th>Type</th>
                                        <th>Issue Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($row = $search_results->fetch_assoc()): ?>
                                    <tr>
                                        <td class="fw-bold"><?php echo htmlspecialchars($row['ref_number']); ?></td>
                                        <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['register_number']); ?></td>
                                        <td><?php echo htmlspecialchars($row['certificate_type']); ?></td>
                                        <td><?php echo date('d M Y', strtotime($row['bonafide_date'])); ?></td>
                                        <td>
                                            <a href="verify.php?ref=<?php echo urlencode($row['ref_number']); ?>" 
                                               class="btn btn-sm btn-primary">
                                                <i class="fas fa-shield-alt me-1"></i>Verify
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning">
                            <i class="fas fa-search me-2"></i>
                            No certificates found matching "<?php echo htmlspecialchars($search_query); ?>"
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <!-- Recent Verifications -->
        <div class="recent-verifications">
            <h5 class="mb-4"><i class="fas fa-history me-2"></i>Recently Verified Certificates</h5>
            
            <?php if ($recent_results->num_rows > 0): ?>
                <?php while ($recent = $recent_results->fetch_assoc()): ?>
                <div class="recent-item">
                    <div>
                        <span class="recent-ref"><?php echo htmlspecialchars($recent['ref_number']); ?></span>
                        <div class="small"><?php echo htmlspecialchars($recent['student_name']); ?></div>
                    </div>
                    <div class="text-end">
                        <div class="recent-time"><?php echo date('d M H:i', strtotime($recent['verified_at'])); ?></div>
                        <a href="verify.php?ref=<?php echo urlencode($recent['ref_number']); ?>" 
                           class="btn btn-sm btn-outline-primary mt-1">
                            View
                        </a>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="text-center py-3 text-muted">
                    <i class="fas fa-certificate fa-2x mb-3"></i>
                    <p>No recent verifications found</p>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Footer -->
        <div class="verify-footer">
            <p class="mb-2">
                <i class="fas fa-university me-1"></i>
                Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College
            </p>
            <p class="small text-muted mb-0">
                <i class="fas fa-shield-alt me-1"></i>
                This verification system ensures the authenticity of certificates issued by the institution.
                For any discrepancies, please contact the administration.
            </p>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(function() {
                alert('Verification link copied to clipboard!');
            }, function(err) {
                console.error('Could not copy text: ', err);
            });
        }
        
        // Auto-focus search input
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.querySelector('input[name="ref"]');
            if (searchInput) {
                searchInput.focus();
            }
        });
        
        // Handle QR code scanning
        function startQRScanner() {
            alert('QR scanner feature requires camera access. Please use a mobile device with camera.');
        }
    </script>
</body>
</html>