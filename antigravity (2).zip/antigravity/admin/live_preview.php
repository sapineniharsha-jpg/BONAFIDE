<?php
// live_preview.php - Live Demo for Pending Requests
ob_start();
session_start();

require_once '../includes/db.php';
require_once '../includes/functions.php';

$request_id = intval($_GET['request_id'] ?? 0);

if (!$request_id) {
    die("Request ID not provided");
}

// Get request details
$sql = "SELECT r.*, 
               s.Name as student_name, 
               s.RegisterNo as register_number,
               s.Dept as department,
               s.Batch as batch,
               s.fathername as father_name,
               s.Gender as gender
        FROM bonafide_requests r
        LEFT JOIN students_login_master s ON r.student_id = s.IDNo
        WHERE r.id = ?";
        
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $request_id);
$stmt->execute();
$request = $stmt->get_result()->fetch_assoc();

if (!$request) {
    die("Request not found");
}

// Check if user can view demo
if (!isset($_SESSION['user_id'])) {
    die("Unauthorized access");
}

// Check if demo should be available (only for pending requests)
if ($request['admin_status'] === 'approved' || $request['final_approved'] == 1) {
    die("Demo not available. Certificate has been approved.");
}

// Set student data
$student = [
    'name' => $request['student_name'],
    'reg' => $request['register_number'],
    'dept' => $request['department'],
    'batch' => $request['batch'],
    'father' => $request['father_name'],
    'gender' => $request['gender']
];

// Determine year pursuing
$startYear = intval(explode('-', $student['batch'])[0] ?? date('Y'));
$curYear = date('Y');
$month = date('n');
$diff = $curYear - $startYear + ($month >= 6 ? 1 : 0);
$year_pursuing = ($diff == 1) ? 'I' : (($diff == 2) ? 'II' : (($diff == 3) ? 'III' : 'IV'));
if($diff > 4) $year_pursuing = 'Completed';

$isMale = strtolower($student['gender']) === 'male';
$pfx = $isMale ? 'Mr.' : 'Ms.';
$rel = $isMale ? 'son of' : 'daughter of';
$pro = $isMale ? 'his' : 'her';
$objPro = $isMale ? 'him' : 'her';
$pSub = $isMale ? 'he' : 'she';

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Preview - Request #<?php echo $request_id; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Times New Roman', serif;
            background: #f5f5f5;
            padding: 20px;
        }
        
        .certificate {
            width: 210mm;
            min-height: 297mm;
            padding: 20mm;
            background: white;
            margin: 0 auto;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            position: relative;
        }
        
        .demo-watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 100px;
            color: rgba(0,0,0,0.1);
            z-index: 1;
            white-space: nowrap;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 5px;
        }
        
        .demo-notice {
            background: #fff3cd;
            border: 2px solid #ffecb5;
            padding: 15px;
            text-align: center;
            margin-bottom: 20px;
            font-weight: bold;
            color: #856404;
            border-radius: 5px;
            position: relative;
            z-index: 2;
        }
        
        .header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 15px;
            margin-bottom: 30px;
            position: relative;
            z-index: 2;
        }
        
        .college-name {
            color: #1a237e;
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .college-subtitle {
            color: #0d47a1;
            font-size: 18px;
            margin-bottom: 10px;
        }
        
        .college-details {
            font-size: 12px;
            color: #37474f;
            line-height: 1.4;
        }
        
        .ref-info {
            text-align: right;
            margin: 15px 0 30px;
            font-size: 12px;
            position: relative;
            z-index: 2;
        }
        
        .cert-title {
            text-align: center;
            text-decoration: underline;
            font-size: 18px;
            font-weight: bold;
            margin: 30px 0;
            text-transform: uppercase;
            position: relative;
            z-index: 2;
        }
        
        .content {
            font-size: 14px;
            line-height: 1.8;
            text-align: justify;
            position: relative;
            z-index: 2;
        }
        
        .content p {
            margin-bottom: 15px;
        }
        
        .student-name {
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .footer {
            margin-top: 60px;
            position: relative;
            height: 120px;
            z-index: 2;
        }
        
        .qr-placeholder {
            position: absolute;
            left: 0;
            bottom: 0;
            width: 100px;
            height: 100px;
            border: 2px dashed #ccc;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #666;
            font-size: 10px;
            text-align: center;
            padding: 5px;
        }
        
        .signature {
            position: absolute;
            right: 0;
            bottom: 0;
            text-align: center;
        }
        
        .signature-line {
            width: 200px;
            border-top: 1px solid #000;
            margin-top: 60px;
            padding-top: 5px;
            font-weight: bold;
        }
        
        @media print {
            body {
                background: white;
                padding: 0;
            }
            
            .certificate {
                box-shadow: none;
                width: 100%;
                padding: 15mm;
            }
            
            .demo-watermark {
                display: none;
            }
            
            .demo-notice {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="certificate">
        <div class="demo-watermark">DEMO PREVIEW</div>
        
        <div class="demo-notice">
            ⚠️ DEMO PREVIEW - NOT VALID FOR OFFICIAL USE ⚠️<br>
            Request No: <?php echo htmlspecialchars($request['request_number'] ?? 'N/A'); ?>
        </div>
        
        <!-- Header -->
        <div class="header">
            <div class="college-name">Vel Tech High Tech</div>
            <div class="college-subtitle">Dr. Rangarajan Dr. Sakunthala Engineering College</div>
            <div class="college-details">
                (An Autonomous Institution, Approved by AICTE, Affiliated to Anna University, Chennai)<br>
                #60, Avadi-Alamathi Road, Morai Village, Avadi, Chennai - 600062
            </div>
        </div>
        
        <!-- Reference Info -->
        <div class="ref-info">
            <strong>Request No:</strong> <?php echo htmlspecialchars($request['request_number'] ?? 'N/A'); ?><br>
            <strong>Date:</strong> <?php echo date('d M Y'); ?>
        </div>
        
        <!-- Certificate Content -->
        <div class="content">
            <div class="cert-title">BONAFIDE CERTIFICATE</div>
            
            <p>This is to certify that <span class="student-name"><?php echo $pfx . ' ' . htmlspecialchars($student['name']); ?></span> 
            (Register No: <strong><?php echo htmlspecialchars($student['reg']); ?></strong>), 
            <?php echo $rel; ?> <strong><?php echo htmlspecialchars($student['father']); ?></strong>, 
            is a bonafide student of our institution, pursuing 
            <strong><?php echo $year_pursuing; ?></strong> Year B.E/B.Tech in 
            <strong><?php echo htmlspecialchars($student['dept']); ?></strong> 
            during the academic year 2025-2026.</p>
            
            <p>This certificate is issued on <?php echo $pro; ?> request for the purpose of 
            <strong><?php echo htmlspecialchars($request['purpose']); ?></strong>.</p>
            
            <?php if(!empty($request['student_message'])): ?>
            <p><strong>Additional Information:</strong> <?php echo htmlspecialchars($request['student_message']); ?></p>
            <?php endif; ?>
            
            <p>We wish <?php echo $objPro; ?> all success in <?php echo $pro; ?> future endeavors.</p>
        </div>
        
        <!-- Footer -->
        <div class="footer">
            <div class="qr-placeholder">
                QR CODE<br>WILL APPEAR<br>AFTER APPROVAL
            </div>
            
            <div class="signature">
                <div class="signature-line">
                    PRINCIPAL<br>
                    Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College
                </div>
                <div style="margin-top: 10px; font-size: 11px; color: #666;">
                    Space for College Seal
                </div>
            </div>
        </div>
    </div>
    
    <div style="text-align: center; margin-top: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;">
            <i class="fas fa-print"></i> Print Preview
        </button>
        <button onclick="window.close()" style="padding: 10px 20px; background: #f44336; color: white; border: none; border-radius: 4px; cursor: pointer; margin-left: 10px;">
            <i class="fas fa-times"></i> Close
        </button>
    </div>
    
    <script>
        // Auto-close after 60 seconds if opened in popup
        if (window.opener) {
            setTimeout(() => {
                window.close();
            }, 60000);
        }
        
        // Print on Ctrl+P
        document.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
                e.preventDefault();
                window.print();
            }
        });
    </script>
</body>
</html>