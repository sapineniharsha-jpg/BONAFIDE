<?php
// 1. SETUP & CONFIG - Mandatory Error Handling
ini_set('display_errors', 0); 
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', '../logs/dept_errors.log');
// bonafide_issue.php - ENTERPRISE v122.0 (Ultimate Alumni Logic & Preservation)
ob_start();
if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../includes/db.php';
require_once '../includes/phpqrcode/qrlib.php';

// 1. AUTH CHECK
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin', 'principal'])) {
    die("Access Denied");
}

$student = null;
$msg = "";
$missing_data = [];
$table_source = "";
$primary_col = "";
$fee_info = null;
$block_fee = false;
$manual_mode = false;
$edit_mode = false;
$existing_certificate = null;
$certificate_id = null;

// Check if we're editing an existing certificate
if (isset($_GET['edit'])) {
    $certificate_id = intval($_GET['edit']);
    $edit_result = $mysqli->query("SELECT * FROM bonafide_certificates WHERE id = '$certificate_id'");
    if ($edit_result && $edit_result->num_rows > 0) {
        $existing_certificate = $edit_result->fetch_assoc();
        $edit_mode = true;
        
        // Get student data from the certificate
        $student = [
            'id' => $existing_certificate['student_id'],
            'reg' => $existing_certificate['register_number'],
            'name' => $existing_certificate['student_name'],
            'dept' => $existing_certificate['department'],
            'batch' => $existing_certificate['academic_year'] ?? '2021-2025',
            'father' => $existing_certificate['father_name'],
            'gender' => $existing_certificate['student_prefix'] == 'Mr.' ? 'Male' : 'Female',
            'facility' => $existing_certificate['facility_option'] == 'None' ? 'None' : 'Hostel/Transport'
        ];
        
        // Set saved reference number
        $saved_ref_no = $existing_certificate['ref_number'];
        
        // Generate QR code for existing certificate
        $qrData = "https://www.velhightech.com/verify.php?ref=" . urlencode($saved_ref_no);
        $qrFile = '../temp/qr_'.md5($saved_ref_no).'.png';
        if(!is_dir('../temp')) mkdir('../temp');
        if(!file_exists($qrFile)) {
            QRcode::png($qrData, $qrFile, QR_ECLEVEL_H, 3);
            require_once '../includes/qr_branding.php';
            add_qr_branding($qrFile);
        }
        $saved_qr_path = $qrFile;
    }
}

// Field Mapping
$field_map = [
    ['label' => 'Father Name', 'senior' => 'fathername', 'fresher' => 'parent_name'],
    ['label' => 'Gender', 'senior' => 'Gender', 'fresher' => 'gender'],
    ['label' => 'Batch', 'senior' => 'Batch', 'fresher' => 'batch'],
    ['label' => 'Department', 'senior' => 'Dept', 'fresher' => 'department'],
    ['label' => 'Register No', 'senior' => 'RegisterNo', 'fresher' => 'register_no'],
    ['label' => 'Section', 'senior' => 'Section', 'fresher' => 'section']
];

// --- 2. HANDLE SEARCH ---
if (isset($_POST['search_student']) && !$edit_mode) {
    $sid = strtoupper(trim($_POST['sid']));
    
    // Check Seniors
    $q = $mysqli->query("SELECT * FROM students_login_master WHERE IDNo='$sid'");
    if ($q && $q->num_rows > 0) {
        $row = $q->fetch_assoc();
        $table_source = "students_login_master";
        $primary_col = "IDNo";
        $type = "senior";
    } else {
        // Check Freshers
        $q2 = $mysqli->query("SELECT * FROM students_batch_25_26 WHERE id_no='$sid'");
        if ($q2 && $q2->num_rows > 0) {
            $row = $q2->fetch_assoc();
            $table_source = "students_batch_25_26";
            $primary_col = "id_no";
            $type = "fresher";
        }
    }

    if (isset($row)) {
        $student = [
            'id' => $row[$type == 'senior' ? 'IDNo' : 'id_no'],
            'reg' => $row[$type == 'senior' ? 'RegisterNo' : 'register_no'],
            'name' => $row[$type == 'senior' ? 'Name' : 'student_name'],
            'dept' => $row[$type == 'senior' ? 'Dept' : 'department'],
            'batch' => $row[$type == 'senior' ? 'Batch' : 'batch'],
            'father' => $row[$type == 'senior' ? 'fathername' : 'parent_name'],
            'gender' => $row[$type == 'senior' ? 'Gender' : 'gender'],
            'facility' => 'None', // Default
            'trans_fee' => 0
        ];

        // Facility Check
        $fac_h = $mysqli->query("SELECT * FROM hostel_boys_titans WHERE id_no='$sid' UNION SELECT * FROM hostel_girls_padmavathy WHERE id_no='$sid'");
        if ($fac_h->num_rows > 0) {
            $student['facility'] = 'Hostel';
        } else {
            $fac_t = $mysqli->query("SELECT * FROM transport_allocation WHERE id_no='$sid'");
            if ($fac_t->num_rows > 0) {
                $student['facility'] = 'Transport';
                $t_row = $fac_t->fetch_assoc();
                $student['trans_fee'] = $t_row['fee_amount'] ?? 0;
            }
        }

        // Fee Check (7.5% Logic)
        $fee_q = $mysqli->query("SELECT * FROM bonafide_fee_details WHERE id_no='$sid' LIMIT 1");
        if ($fee_q && $fee_q->num_rows > 0) {
            $fee_row = $fee_q->fetch_assoc();
            $scholarship = trim($fee_row['scholarship_type']);
            if ($scholarship === '7.5' || $scholarship === '7.5%') { $block_fee = true; }
            $fee_info = ['scholarship' => $scholarship, 'tuition' => $fee_row['tuition_fees'], 'other' => $fee_row['other_fees']];
        }

        // Missing Data Check
        foreach ($field_map as $map) {
            $col = $map[$type];
            if (array_key_exists($col, $row)) {
                $val = trim($row[$col]);
                if (empty($val) || $val === '0') {
                    $missing_data[] = ['col' => $col, 'label' => $map['label']];
                }
            }
        }
    } else {
        $msg = "<div class='alert alert-danger'>Student ID not found. <a href='?manual=1' class='alert-link'>Switch to Manual Mode</a></div>";
    }
}

// --- 3. MANUAL MODE TRIGGER ---
if (isset($_GET['manual']) && !$edit_mode) {
    $manual_mode = true;
    $student = ['id' => '', 'reg' => '', 'name' => '', 'dept' => '', 'batch' => '', 'father' => '', 'gender' => '', 'facility' => 'None'];
}

// --- 4. HANDLE SAVE ---
if (isset($_POST['save_and_print'])) {
    $is_edit = !empty($_POST['certificate_id']);
    
    // Get or generate reference number
    if ($is_edit && !empty($_POST['ref_number'])) {
        $ref_no = $_POST['ref_number'];
        $saved_ref_no = $ref_no;
    } else {
        // Generate new reference number
        $month = date('n');
        $curYear = date('Y');
        $acad_year_ref = ($month > 5) ? "$curYear-".($curYear+1) : ($curYear-1)."-$curYear";
        $res_cnt = $mysqli->query("SELECT id FROM bonafide_certificates ORDER BY id DESC LIMIT 1");
        $last_id = ($res_cnt->fetch_assoc()['id'] ?? 0) + 1;
        $ref_no = "Ref/VH/eBONA/$acad_year_ref/" . str_pad($last_id, 4, '0', STR_PAD_LEFT);
        $saved_ref_no = $ref_no;
    }
    
    // Get date (allow editing in edit mode)
    $certificate_date = $is_edit && !empty($_POST['certificate_date']) ? $_POST['certificate_date'] : date('Y-m-d');
    
    // Logic
    $batch = $_POST['hid_batch'] ?? '';
    $startYear = intval(explode('-', $batch)[0] ?? date('Y'));
    $curYear = date('Y');
    $month = date('n');
    
    // Year logic
    $diff = $curYear - $startYear + ($month >= 6 ? 1 : 0);
    $year_pursuing = ($diff == 1) ? '1st' : (($diff == 2) ? '2nd' : (($diff == 3) ? '3rd' : '4th'));
    if($_POST['certType'] == 'Alumni' || $diff > 4) $year_pursuing = 'Completed';

    // For Alumni, prioritize manual fields if provided
    $name = (!empty($_POST['alm_name'])) ? $_POST['alm_name'] : ($_POST['hid_name'] ?? '');
    $father = (!empty($_POST['alm_father'])) ? $_POST['alm_father'] : ($_POST['hid_father'] ?? '');
    $reg = (!empty($_POST['alm_reg'])) ? $_POST['alm_reg'] : ($_POST['hid_reg'] ?? '');
    $dept = (!empty($_POST['alm_dept'])) ? $_POST['alm_dept'] : ($_POST['hid_dept'] ?? '');
    $gender = (!empty($_POST['alm_gender'])) ? $_POST['alm_gender'] : ($_POST['hid_gender'] ?? 'Male');

    $degree = (strpos($dept, 'MBA') !== false) ? 'MBA' : 'B.E/B.Tech'; 
    $s_prefix = (stripos($gender, 'M') === 0) ? 'Mr.' : 'Ms.';
    $p_prefix = 'Mr.'; 

    $acad_years_str = isset($_POST['academic_year']) ? implode(',', $_POST['academic_year']) : '';
    $fac_opt = ($_POST['f_fac'] > 0 || $_POST['p_fac'] > 0) ? 'Hostel/Transport' : 'None';
    $bank_opt = isset($_POST['bank_details']) ? 'Yes' : 'No';
    
    $t1 = $_POST['f_tui'] ?? 0; $t2 = $_POST['f_oth'] ?? 0; $t3 = $_POST['f_fac'] ?? 0;
    $p1 = $_POST['p_tui'] ?? 0; $p2 = $_POST['p_oth'] ?? 0; $p3 = $_POST['p_fac'] ?? 0;
    
    $details = '';
    if($_POST['certType'] == 'Internship') $details = $_POST['comp_name'] ?? '';
    if($_POST['certType'] == 'Project') $details = $_POST['project_title'] ?? '';
    if($_POST['certType'] == 'LOR') $details = ($_POST['lor_faculty'] ?? '') . "|" . ($_POST['lor_designation'] ?? '') . "|" . ($_POST['lor_subject'] ?? '');

    // Alumni Specifics
    $cgpa = $_POST['alm_cgpa'] ?? 0;
    $inc_moi = isset($_POST['alm_moi']) ? 'Yes' : 'No';
    $inc_conv = isset($_POST['alm_conv']) ? 'Yes' : 'No';
    $orig_stat = isset($_POST['alm_orig']) ? 'Yes' : 'No';

    // Fix: CORRECTED UPDATE query with proper column names
    if ($is_edit) {
        // UPDATE existing certificate with CORRECT columns
        $stmt = $mysqli->prepare("UPDATE bonafide_certificates SET 
            bonafide_date = ?,
            student_id = ?,
            register_number = ?,
            student_name = ?,
            student_prefix = ?,
            father_name = ?,
            parent_prefix = ?,
            department = ?,
            degree_name = ?,
            year_pursuing = ?,
            duration_course = ?,
            content_academic_year = ?,
            academic_year = ?,
            certificate_type = ?,
            purpose = ?,
            tuition_fee = ?,
            other_fee = ?,
            hostel_fee = ?,
            paid_tuition_fee = ?,
            paid_other_fee = ?,
            paid_hostel_fee = ?,
            facility_option = ?,
            internship_students = ?,
            note_details = ?,
            cgpa = ?,
            include_moi = ?,
            include_conversion = ?,
            original_certificate_status = ?,
            status = ?,
            batch_completed = ?
            WHERE id = ?");
        
        // Create variables for fixed values
        $duration_course = '4 Years';
        $content_academic_year = '2025-2026';
        $status_val = 'approved';
        
        $stmt->bind_param("sssssssssssssssddddddsssdsssssi", 
            $certificate_date,      // s (1)
            $_POST['hid_id'] ?? '', // s (2)
            $reg,                   // s (3)
            $name,                  // s (4)
            $s_prefix,              // s (5)
            $father,                // s (6)
            $p_prefix,              // s (7)
            $dept,                  // s (8)
            $degree,                // s (9)
            $year_pursuing,         // s (10)
            $duration_course,       // s (11)
            $content_academic_year, // s (12)
            $acad_years_str,        // s (13)
            $_POST['certType'],     // s (14)
            $_POST['purpose'],      // s (15)
            $t1,                    // d (16)
            $t2,                    // d (17)
            $t3,                    // d (18)
            $p1,                    // d (19)
            $p2,                    // d (20)
            $p3,                    // d (21)
            $fac_opt,               // s (22)
            $details,               // s (23)
            $bank_opt,              // s (24)
            $cgpa,                  // d (25)
            $inc_moi,               // s (26)
            $inc_conv,              // s (27)
            $orig_stat,             // s (28)
            $status_val,            // s (29)
            $batch,                 // s (30)
            $_POST['certificate_id'] // i (31)
        );
    } else {
        // INSERT new certificate - CORRECTED VERSION
        $sid = $_POST['hid_id'] ?? '';
        
        // Prepare the CORRECT INSERT statement
        $stmt = $mysqli->prepare("INSERT INTO bonafide_certificates (
            ref_number, bonafide_date, student_id, register_number, student_name, student_prefix, 
            father_name, parent_prefix, department, degree_name, year_pursuing, duration_course,
            content_academic_year, academic_year, certificate_type, purpose, 
            tuition_fee, other_fee, hostel_fee, paid_tuition_fee, paid_other_fee, paid_hostel_fee, 
            facility_option, internship_students, note_details, 
            cgpa, include_moi, include_conversion, original_certificate_status, status, batch_completed
        ) VALUES (
            ?, ?, ?, ?, ?, ?, 
            ?, ?, ?, ?, ?, ?, 
            ?, ?, ?, ?, 
            ?, ?, ?, ?, ?, ?, 
            ?, ?, ?, 
            ?, ?, ?, ?, ?, ?
        )");

        if(!$stmt) {
            die("Prepare Failed: " . $mysqli->error);
        }

        // 31 parameters now (matching columns)
        $bind_string = "ssssssssssssssssddddddsssdsssss";
        
        // Validation
        $t1 = floatval($t1); $t2 = floatval($t2); $t3 = floatval($t3);
        $p1 = floatval($p1); $p2 = floatval($p2); $p3 = floatval($p3);
        $cgpa = floatval($cgpa);
        
        $status = 'approved';
        $batch_val = $batch;
        
        // Create variables for the literals
        $duration_course = '4 Years';
        $content_academic_year = '2025-2026';

        $stmt->bind_param($bind_string, 
            $ref_no,                // s (1)
            $certificate_date,      // s (2)
            $sid,                   // s (3)
            $reg,                   // s (4)
            $name,                  // s (5)
            $s_prefix,              // s (6)
            $father,                // s (7)
            $p_prefix,              // s (8)
            $dept,                  // s (9)
            $degree,                // s (10)
            $year_pursuing,         // s (11)
            $duration_course,       // s (12) - VARIABLE, not literal
            $content_academic_year, // s (13) - VARIABLE, not literal
            $acad_years_str,        // s (14)
            $_POST['certType'],     // s (15)
            $_POST['purpose'],      // s (16)
            $t1,                    // d (17)
            $t2,                    // d (18)
            $t3,                    // d (19)
            $p1,                    // d (20)
            $p2,                    // d (21)
            $p3,                    // d (22)
            $fac_opt,               // s (23)
            $details,               // s (24)
            $bank_opt,              // s (25)
            $cgpa,                  // d (26)
            $inc_moi,               // s (27)
            $inc_conv,              // s (28)
            $orig_stat,             // s (29)
            $status,                // s (30)
            $batch_val              // s (31)
        );
    }

    if ($stmt->execute()) {
        if (!$is_edit) {
            $certificate_id = $stmt->insert_id;
        }
        
        $msg = "<div class='alert alert-success no-print'>" . ($is_edit ? "Updated" : "Saved") . "! Ref: $ref_no 
                <a href='?edit=$certificate_id' class='btn btn-sm btn-warning ms-2'>Edit</a>
                <button onclick='window.print()' class='btn btn-sm btn-primary ms-1'>Print</button></div>";
        
        // Generate/Update QR code
        $qrData = "https://www.velhightech.com/verify.php?ref=" . urlencode($ref_no);
        $qrFile = '../temp/qr_'.md5($ref_no).'.png';
        if(!is_dir('../temp')) mkdir('../temp');
        QRcode::png($qrData, $qrFile, QR_ECLEVEL_H, 3);
            require_once '../includes/qr_branding.php';
            add_qr_branding($qrFile);
        $saved_qr_path = $qrFile;
        
        // Set edit mode after save
        $edit_mode = true;
        $existing_certificate = [
            'ref_number' => $ref_no,
            'bonafide_date' => $certificate_date,
            'student_id' => $_POST['hid_id'] ?? '',
            'register_number' => $reg,
            'student_name' => $name,
            'student_prefix' => $s_prefix,
            'father_name' => $father,
            'parent_prefix' => $p_prefix,
            'department' => $dept,
            'degree_name' => $degree,
            'year_pursuing' => $year_pursuing,
            'academic_year' => $acad_years_str,
            'certificate_type' => $_POST['certType'],
            'purpose' => $_POST['purpose'],
            'tuition_fee' => $t1,
            'other_fee' => $t2,
            'hostel_fee' => $t3,
            'paid_tuition_fee' => $p1,
            'paid_other_fee' => $p2,
            'paid_hostel_fee' => $p3,
            'facility_option' => $fac_opt,
            'internship_students' => $details,
            'note_details' => $bank_opt,
            'cgpa' => $cgpa,
            'include_moi' => $inc_moi,
            'include_conversion' => $inc_conv,
            'original_certificate_status' => $orig_stat
        ];
        
        // Update student data for preview
        $student = [
            'id' => $_POST['hid_id'] ?? '',
            'reg' => $reg,
            'name' => $name,
            'dept' => $dept,
            'batch' => $_POST['hid_batch'] ?? '2021-2025',
            'father' => $father,
            'gender' => $gender,
            'facility' => $fac_opt
        ];
    } else {
        $msg = "<div class='alert alert-danger no-print'>Error: " . $stmt->error . "</div>";
        // Debug: Show the actual SQL error
        error_log("Database Error: " . $stmt->error);
    }
}

include '../includes/header.php';
?>

<style>
    /* INSTAGRAM GRADIENT THEME */
    :root { 
        --insta-grad: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
        --primary: #bc1888; 
        --bg: #f8fafc; 
    }
    body { background: var(--bg); font-family: 'Outfit', sans-serif; }
    .app-grid { display: grid; grid-template-columns: 380px 1fr; gap: 25px; padding: 25px; min-height: 92vh; }
    
    /* PANELS */
    .left-panel { background: white; border-radius: 20px; padding: 25px; overflow-y: auto; box-shadow: 0 10px 30px rgba(0,0,0,0.05); border: 1px solid #f1f5f9; }
    .cp-header { font-size: 1.4rem; font-weight: 800; background: var(--insta-grad); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
    
    /* BUTTONS */
    .btn-insta { background: var(--insta-grad); color: white; border: none; padding: 12px; border-radius: 50px; width: 100%; font-weight: 700; cursor: pointer; transition: 0.3s; box-shadow: 0 4px 15px rgba(220, 39, 67, 0.3); position: relative; overflow: hidden; }
    .btn-insta:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(220, 39, 67, 0.4); }
    .btn-search { background: #1e293b; color: white; border-radius: 0 10px 10px 0; border: none; padding: 0 20px; }
    .edit-badge { position: absolute; top: 10px; right: 10px; background: #ffc107; color: #000; padding: 5px 10px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; }

    /* CARDS */
    .fee-card { background: linear-gradient(135deg, #10b981 0%, #059669 100%); border-radius: 15px; padding: 15px; margin-bottom: 20px; color: white; box-shadow: 0 8px 20px rgba(16, 185, 129, 0.25); }
    .fee-card.blocked { background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%); box-shadow: 0 8px 20px rgba(239, 68, 68, 0.25); }
    .fee-row { display: flex; justify-content: space-between; font-size: 0.85rem; margin-bottom: 4px; opacity: 0.95; }
    .btn-apply { background: white; color: #059669; border: none; padding: 4px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 800; cursor: pointer; }

    /* STUDENT CARD */
    .student-card { background: #fff; border: 1px solid #e2e8f0; border-left: 5px solid #bc1888; border-radius: 12px; padding: 20px; margin-bottom: 20px; box-shadow: 0 4px 10px -2px rgba(0,0,0,0.05); position: relative; }
    .stu-name { font-weight: 800; font-size: 1.1rem; color: #1e293b; }
    .manual-field { border: 1px dashed #bc1888; background: #fff5f8; margin-bottom: 5px; width: 100%; padding: 8px; border-radius: 6px; }

    /* MISSING ALERT */
    .missing-alert { background: #fff1f2; border: 1px solid #fda4af; border-radius: 12px; padding: 15px; margin-bottom: 20px; }
    .missing-head { color: #be123c; font-weight: 800; font-size: 0.9rem; margin-bottom: 10px; display: flex; align-items: center; gap: 8px; }

    /* FORMS */
    .form-label { font-size: 0.7rem; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 5px; display: block; }
    .form-control, .form-select { border-radius: 10px; border: 2px solid #e2e8f0; padding: 10px 12px; font-size: 0.9rem; transition: 0.2s; background: #f8fafc; width: 100%; }
    .form-control:focus, .form-select:focus { border-color: #bc1888; background: #fff; outline: none; }

    /* PREVIEW PANEL */
    .preview-panel { background: #525659; border-radius: 20px; padding: 40px; display: flex; justify-content: center; overflow-y: auto; }
    .paper { background: white; width: 210mm; min-height: 297mm; padding: 10mm 15mm; box-shadow: 0 10px 40px rgba(0,0,0,0.3); font-family: 'Times New Roman', serif; position: relative; transform: scale(0.85); transform-origin: top center; color: #000; }
    
    /* ENHANCED HEADER STYLING - WITH REDUCED LEFT CONTAINER */
    .header-container {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        padding: 5px 0;
        border-bottom: 1px solid #000;
        margin-bottom: 4px;
        page-break-inside: avoid;
    }

    .logo-container {
        flex: 0 0 75px;
        padding: 5px;
    }

    .college-logo {
        height: 70px;
        width: auto;
        object-fit: contain;
    }

    .college-info {
        flex: 1;
        text-align: center;
        padding: 0 10px;
    }

    .college-name {
        font-size: 32px;
        font-weight: 900;
        color: #1a237e;
        margin-bottom: 3px;
        text-transform: uppercase;
        letter-spacing: 0.6px;
        line-height: 1.1;
    }

    .college-subtitle {
        font-size: 16px;
        font-weight: 700;
        color: #0d47a1;
        margin-bottom: 3px;
        line-height: 1.1;
    }

    .college-details {
        font-size: 12px;
        color: #37474f;
        line-height: 1.3;
    }

    .college-details span {
        display: block;
        margin-bottom: 1px;
    }

    .college-accreditation {
        font-size: 10px;
        font-weight: 600;
        color: #00695c;
        margin-top: 2px;
        line-height: 1.2;
    }

    .contact-info {
        flex: 0 0 180px;
        text-align: right;
        font-size: 12px;
        line-height: 1.3;
        padding: 5px;
        border-left: 1px solid #e0e0e0;
    }

    .contact-info strong {
        color: #1a237e;
        font-weight: 700;
    }

    .contact-phone {
        font-weight: 700;
        color: #0d47a1;
        margin-bottom: 3px;
    }

    .contact-email {
        color: #1565c0;
        word-break: break-all;
        margin: 2px 0;
    }

    .contact-website {
        color: #1565c0;
        font-weight: 600;
        margin: 2px 0;
    }

    .contact-address {
        color: #455a64;
        font-size: 12px;
        line-height: 1.2;
        margin-top: 4px;
    }

    .ref-number {
        font-size: 12px;
        font-weight: 700;
        color: #b71c1c;
        background: #fff3cd;
        padding: 5px 10px;
        border-radius: 3px;
        border-left: 3px solid #b71c1c;
        display: inline-block;
    }

    .certificate-date {
        font-size: 12px;
        font-weight: 600;
        color: #1b5e20;
        background: #e8f5e9;
        padding: 5px 10px;
        border-radius: 3px;
        border-left: 3px solid #1b5e20;
        margin-left: 10px;
        display: inline-block;
    }

    .ref-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 8px 30px 12px;
        padding-bottom: 5px;
        border-bottom: 0.5px solid #ddd;
    }
    
    /* FEE TABLE STYLING */
    .fee-table { border-collapse: collapse; width: 100%; margin: 10px 0; font-size: 10pt; }
    .fee-table th { background: #f1f5f9; padding: 6px; text-align: center; border: 1px solid #000; font-weight: bold; }
    .fee-table td { padding: 6px; border: 1px solid #000; }
    .fee-table .amount { text-align: right; font-family: 'Courier New', monospace; font-weight: bold; }
    .fee-table .total-row { background: #e7f5ff; font-weight: bold; }
    
    .amount-words-box { 
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); 
        border: 1px solid #dee2e6; 
        border-radius: 5px; 
        padding: 10px; 
        margin: 12px 0; 
        font-family: 'Georgia', serif;
        min-height: auto;
    }
    .amount-words-box .numeric { 
        font-size: 0.95rem; 
        color: #dc3545; 
        font-weight: bold; 
        margin-bottom: 3px;
        font-family: 'Courier New', monospace;
    }
    .amount-words-box .words { 
        font-size: 0.85rem; 
        color: #495057; 
        line-height: 1.3;
        text-transform: capitalize;
    }

    /* INPUT VALIDATION */
    .input-invalid { border-color: #dc3545 !important; background: #fff5f5 !important; }
    .input-valid { border-color: #198754 !important; }

    @media print {
        .control-panel, .no-print, .glass-header { display: none !important; }
        .app-grid { display: block; padding: 0; }
        .preview-panel { background: white; padding: 0; display: block; overflow: visible; }
        .paper { box-shadow: none; transform: none; width: 100%; margin: 0; padding: 8mm 12mm; }
        
        .header-container {
            border-bottom: 1px solid #000;
            padding: 4px 0;
            margin-bottom: 3px;
        }
        
        .logo-container {
            flex: 0 0 70px;
        }
        
        .college-logo {
            height: 65px;
        }
        
        .college-name {
            font-size: 20px;
        }
        
        .college-subtitle {
            font-size: 12px;
        }
        
        .college-details {
            font-size: 9px;
        }
        
        .contact-info {
            flex: 0 0 170px;
            font-size: 9px;
        }
        
        .ref-container {
            margin: 6px 25px 8px;
            padding-bottom: 3px;
        }
        
        .amount-words-box { 
            border: 1px solid #000; 
            background: none; 
            margin: 10px 0; 
            padding: 8px;
            break-inside: avoid;
        }
        .fee-table { break-inside: avoid; margin: 8px 0; }
        .fee-table th, .fee-table td { padding: 4px 6px; }
        .fee-table .amount { font-weight: bold; }
    }
    
    /* CERTIFICATE CSS */
    .cert-title { text-align: center; font-size: 14pt; font-weight: bold; text-decoration: underline; margin: 15px 0 10px; text-transform: uppercase; }
    .content { font-size: 12.5pt; line-height: 1.5; text-align: justify; }
    .footer { margin-top: 40px; position: relative; height: 80px; }
    .sign { position: absolute; right: 10px; bottom: 25px; font-weight: bold; font-size: 13pt; }
    .qr img { width: 75px; } 
    .watermark { position: fixed; top: 50%; width: 300px; opacity: 0.08; z-index: -1; }
    
    /* ACTION BUTTONS */
    .action-buttons {
        display: flex;
        gap: 10px;
        margin-top: 20px;
    }
    .btn-print { background: #0d6efd; color: white; border: none; padding: 10px 20px; border-radius: 10px; font-weight: 600; cursor: pointer; }
    .btn-edit { background: #ffc107; color: #000; border: none; padding: 10px 20px; border-radius: 10px; font-weight: 600; cursor: pointer; }
    .btn-new { background: #198754; color: white; border: none; padding: 10px 20px; border-radius: 10px; font-weight: 600; cursor: pointer; }
    
    /* SPACE OPTIMIZATION */
    .content p { margin-bottom: 8px; }
    .content .mt-4 { margin-top: 12px !important; }
</style>

<div class="app-grid">
    <div class="control-panel no-print">
        <div class="cp-header">
            <i class="fas fa-magic"></i> Bonafide Wizard
            <?php if($edit_mode): ?>
                <span class="edit-badge">EDIT MODE</span>
            <?php endif; ?>
        </div>
        
        <?php if(!$edit_mode): ?>
        <form method="POST">
            <div class="input-group mb-3">
                <input type="text" name="sid" class="form-control" placeholder="ID (e.g. VH1001)" value="<?= $_POST['sid'] ?? '' ?>" required>
                <button type="submit" name="search_student" class="btn btn-search"><i class="fas fa-search"></i></button>
            </div>
        </form>
        <div class="text-end mb-2">
            <a href="?manual=1" class="text-decoration-none small fw-bold text-muted">Switch to Manual Mode</a>
        </div>
        <?php endif; ?>
        
        <?= $msg ?>

        <?php if($student || $manual_mode || $edit_mode): ?>
        <form method="POST" id="issueForm">
            <?php if($edit_mode && $existing_certificate): ?>
                <input type="hidden" name="certificate_id" value="<?= $certificate_id ?>">
                <input type="hidden" name="ref_number" value="<?= $existing_certificate['ref_number'] ?>">
                
                <div class="alert alert-info mb-3">
                    <strong>Editing Certificate:</strong> <?= $existing_certificate['ref_number'] ?><br>
                    <small>Reference number cannot be changed once generated.</small>
                </div>
                
                <!-- Date Editing for Edit Mode -->
                <div class="mb-3">
                    <label class="form-label">Certificate Date</label>
                    <input type="date" name="certificate_date" class="form-control" value="<?= date('Y-m-d', strtotime($existing_certificate['bonafide_date'])) ?>" onchange="updatePreview()">
                </div>
            <?php endif; ?>
            
            <input type="hidden" name="hid_id" value="<?= $student['id'] ?? '' ?>">
            <input type="hidden" name="hid_table" value="<?= $table_source ?>">
            <input type="hidden" name="hid_primary" value="<?= $primary_col ?>">
            <input type="hidden" name="hid_name" value="<?= $student['name'] ?>">
            <input type="hidden" name="hid_reg" value="<?= $student['reg'] ?>">
            <input type="hidden" name="hid_dept" value="<?= $student['dept'] ?>">
            <input type="hidden" name="hid_batch" value="<?= $student['batch'] ?>">
            <input type="hidden" name="hid_father" value="<?= $student['father'] ?>">
            <input type="hidden" name="hid_gender" value="<?= $student['gender'] ?>">
            <input type="hidden" name="save_and_print" value="1">
            
            <input type="hidden" id="has_facility_access" value="<?= ($student['facility'] ?? 'None') === 'None' ? '0' : '1' ?>">
            <input type="hidden" id="facility_type" value="<?= $student['facility'] ?? '' ?>">

            <?php if(!empty($missing_data) && !$edit_mode): ?>
            <div class="missing-alert">
                <div class="missing-head"><i class="fas fa-exclamation-triangle"></i> Mandatory Updates</div>
                <?php foreach($missing_data as $field): ?>
                    <?php if($field['label'] == 'Section'): ?>
                        <select name="upd_<?= $field['col'] ?>" class="form-select form-select-sm mb-2" required>
                            <option value="">Select Section</option><option value="A">A</option><option value="B">B</option><option value="C">C</option>
                        </select>
                    <?php elseif($field['label'] == 'Gender'): ?>
                        <select name="upd_<?= $field['col'] ?>" class="form-select form-select-sm mb-2" required onchange="updatePreviewLocal(this)">
                            <option value="">Gender</option><option value="Male">Male</option><option value="Female">Female</option>
                        </select>
                    <?php else: ?>
                        <input type="text" name="upd_<?= $field['col'] ?>" class="form-control form-control-sm mb-2" placeholder="<?= $field['label'] ?>" required oninput="updatePreviewLocal(this)">
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if($fee_info && !$edit_mode): ?>
                <div class="fee-card <?= $block_fee ? 'blocked' : '' ?>">
                    <div class="fee-head">
                        <span class="fee-title"><?= $block_fee ? 'Fee Cert Blocked' : 'Fee Data Found' ?></span>
                        <?php if(!$block_fee): ?><button type="button" class="btn-apply" onclick="applyFeeData()">Auto-Fill</button><?php endif; ?>
                    </div>
                    <div class="fee-row"><span>Scholarship</span> <span class="fee-val"><?= $fee_info['scholarship'] ?></span></div>
                    <div class="fee-row"><span>Tuition</span> <span class="fee-val"><?= number_format($fee_info['tuition']) ?></span></div>
                    <div class="fee-row"><span>Other</span> <span class="fee-val"><?= number_format($fee_info['other']) ?></span></div>
                    <?php if($block_fee): ?><div style="font-size:0.7rem; margin-top:5px;">Reason: 7.5% Govt Quota</div><?php endif; ?>
                </div>
                <input type="hidden" id="db_tui" value="<?= $fee_info['tuition'] ?>">
                <input type="hidden" id="db_oth" value="<?= $fee_info['other'] ?>">
                <input type="hidden" id="db_block" value="<?= $block_fee ? '1' : '0' ?>">
            <?php endif; ?>

            <div id="studentSection" class="student-card">
                <?php if($manual_mode || $edit_mode): ?>
                    <?php if($edit_mode): ?>
                        <div class="alert alert-warning p-2 small mb-2">
                            <i class="fas fa-info-circle"></i> Editing existing certificate data
                        </div>
                    <?php endif; ?>
                    <input type="text" name="hid_name" id="in_name" class="manual-field" placeholder="Student Name" value="<?= $student['name'] ?? '' ?>" required oninput="validateName(this); updatePreview()">
                    <input type="text" name="hid_id" id="in_id" class="manual-field" placeholder="Register No" value="<?= $student['reg'] ?? '' ?>" required oninput="updatePreview()">
                    <input type="text" name="hid_father" id="in_father" class="manual-field" placeholder="Father Name" value="<?= $student['father'] ?? '' ?>" required oninput="validateName(this); updatePreview()">
                    <input type="text" name="hid_dept" id="in_dept" class="manual-field" placeholder="Department" value="<?= $student['dept'] ?? '' ?>" required oninput="updatePreview()">
                    <input type="text" name="hid_batch" id="in_batch" class="manual-field" placeholder="Batch (e.g. 2021-2025)" value="<?= $student['batch'] ?? '' ?>" required pattern="\d{4}-\d{4}" oninput="validateBatch(this); updatePreview()">
                    <select name="hid_gender" id="in_gender" class="manual-field" onchange="updatePreview()">
                        <option value="Male" <?= ($student['gender'] ?? '') == 'Male' ? 'selected' : '' ?>>Male</option>
                        <option value="Female" <?= ($student['gender'] ?? '') == 'Female' ? 'selected' : '' ?>>Female</option>
                    </select>
                <?php else: ?>
                    <div class="stu-name"><?= $student['name'] ?></div>
                    <div class="small text-muted"><?= $student['dept'] ?></div>
                    <div class="small text-muted mt-1"><?= $student['id'] ?> | <?= $student['facility'] ?></div>
                    
                    <input type="hidden" name="hid_name" id="in_name" value="<?= $student['name'] ?>">
                    <input type="hidden" name="hid_reg" id="in_reg" value="<?= $student['reg'] ?>">
                    <input type="hidden" name="hid_dept" id="in_dept" value="<?= $student['dept'] ?>">
                    <input type="hidden" name="hid_batch" id="in_batch" value="<?= $student['batch'] ?>">
                    <input type="hidden" name="hid_father" id="in_father" value="<?= $student['father'] ?>">
                    <input type="hidden" name="hid_gender" id="in_gender" value="<?= $student['gender'] ?>">
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="form-label">Type</label>
                <select name="certType" id="certType" class="form-select" onchange="toggleFields(); updatePreview();">
                    <option value="Normal" <?= (($existing_certificate['certificate_type'] ?? 'Normal') == 'Normal') ? 'selected' : '' ?>>General</option>
                    <option value="Fee Structure" <?= (($existing_certificate['certificate_type'] ?? '') == 'Fee Structure') ? 'selected' : '' ?>>Fee Structure</option>
                    <option value="Fee Paid" <?= (($existing_certificate['certificate_type'] ?? '') == 'Fee Paid') ? 'selected' : '' ?>>Fee Paid</option>
                    <option value="Internship" <?= (($existing_certificate['certificate_type'] ?? '') == 'Internship') ? 'selected' : '' ?>>Internship</option>
                    <option value="Project" <?= (($existing_certificate['certificate_type'] ?? '') == 'Project') ? 'selected' : '' ?>>Project</option>
                    <option value="Alumni" <?= (($existing_certificate['certificate_type'] ?? '') == 'Alumni') ? 'selected' : '' ?>>Alumni</option>
                    <option value="LOR" <?= (($existing_certificate['certificate_type'] ?? '') == 'LOR') ? 'selected' : '' ?>>Letter of Recommendation</option>
                </select>
            </div>

            <div id="alumniCheck" style="display:none;" class="alert alert-warning p-2 small mb-3">
                <strong>Is Student Studying?</strong><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="is_studying" value="yes" checked onclick="toggleManualMode(false)"> Yes
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="is_studying" value="no" onclick="toggleManualMode(true)"> No (Manual)
                </div>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Purpose</label>
                <select name="purpose" id="purpose" class="form-select" onchange="updatePreview()">
                    <option value="Scholarship" <?= (($existing_certificate['purpose'] ?? 'Scholarship') == 'Scholarship') ? 'selected' : '' ?>>Scholarship</option>
                    <option value="Education Loan" <?= (($existing_certificate['purpose'] ?? '') == 'Education Loan') ? 'selected' : '' ?>>Education Loan</option>
                    <option value="Visa Process" <?= (($existing_certificate['purpose'] ?? '') == 'Visa Process') ? 'selected' : '' ?>>Visa Process</option>
                    <option value="Internship Application" <?= (($existing_certificate['purpose'] ?? '') == 'Internship Application') ? 'selected' : '' ?>>Internship Application</option>
                    <option value="Higher Studies" <?= (($existing_certificate['purpose'] ?? '') == 'Higher Studies') ? 'selected' : '' ?>>Higher Studies</option>
                </select>
            </div>

            <div id="feeArea" style="display:none;" class="p-3 border rounded mb-3 bg-white">
                <label class="form-label text-primary">Academic Years</label>
                <div class="d-flex flex-wrap gap-2 mb-3 small">
                    <?php 
                    $acad_years = $existing_certificate['academic_year'] ?? '';
                    $selected_years = !empty($acad_years) ? explode(',', $acad_years) : ['2025-26'];
                    ?>
                    <label><input type="checkbox" name="academic_year[]" value="2024-25" class="year-chk" <?= in_array('2024-25', $selected_years) ? 'checked' : '' ?> onchange="updatePreview()"> 24-25</label>
                    <label><input type="checkbox" name="academic_year[]" value="2025-26" class="year-chk" <?= in_array('2025-26', $selected_years) ? 'checked' : '' ?> onchange="updatePreview()"> 25-26</label>
                    <label><input type="checkbox" name="academic_year[]" value="2026-27" class="year-chk" <?= in_array('2026-27', $selected_years) ? 'checked' : '' ?> onchange="updatePreview()"> 26-27</label>
                    <label><input type="checkbox" name="academic_year[]" value="2027-28" class="year-chk" <?= in_array('2027-28', $selected_years) ? 'checked' : '' ?> onchange="updatePreview()"> 27-28</label>
                    <label><input type="checkbox" name="academic_year[]" value="2028-29" class="year-chk" <?= in_array('2028-29', $selected_years) ? 'checked' : '' ?> onchange="updatePreview()"> 28-29</label>
                </div>
                <div class="row g-2 mb-2">
                    <div class="col-4"><input type="number" name="f_tui" id="f_tui" class="form-control form-control-sm fee-input" placeholder="Tuition" min="0" step="0.01" value="<?= $existing_certificate['tuition_fee'] ?? 0 ?>" oninput="validateFeeInput(this); updatePreview()"></div>
                    <div class="col-4"><input type="number" name="f_oth" id="f_oth" class="form-control form-control-sm fee-input" placeholder="Other" min="0" step="0.01" value="<?= $existing_certificate['other_fee'] ?? 0 ?>" oninput="validateFeeInput(this); updatePreview()"></div>
                    <div class="col-4" id="fac_div" style="display:<?= ($student['facility'] ?? 'None') =='None'?'none':'block' ?>">
                        <input type="number" name="f_fac" id="f_fac" class="form-control form-control-sm fee-input" placeholder="Fac Fee" min="0" step="0.01" value="<?= $existing_certificate['hostel_fee'] ?? 0 ?>" oninput="validateFeeInput(this); updatePreview()">
                    </div>
                </div>
                
                <?php if(($student['facility'] ?? '') === 'Hostel'): ?>
                    <select class="form-select form-select-sm mb-2" onchange="setFacFee(this.value)">
                        <option value="">Select Room</option><option value="90000" <?= ($existing_certificate['hostel_fee'] ?? 0) == 90000 ? 'selected' : '' ?>>Non-AC (90k)</option><option value="110000" <?= ($existing_certificate['hostel_fee'] ?? 0) == 110000 ? 'selected' : '' ?>>AC (1.1L)</option>
                    </select>
                <?php elseif(($student['facility'] ?? '') === 'Transport'): ?>
                    <select class="form-select form-select-sm mb-2" onchange="setFacFee(this.value)">
                        <option value="">Select Zone</option><option value="20000" <?= ($existing_certificate['hostel_fee'] ?? 0) == 20000 ? 'selected' : '' ?>>R1 (20k)</option><option value="37000" <?= ($existing_certificate['hostel_fee'] ?? 0) == 37000 ? 'selected' : '' ?>>R2 (37k)</option><option value="40000" <?= ($existing_certificate['hostel_fee'] ?? 0) == 40000 ? 'selected' : '' ?>>R3 (40k)</option>
                    </select>
                <?php endif; ?>
                
                <div id="paidArea" style="display:none;" class="mt-3 pt-3 border-top">
                    <label class="form-label text-success">Paid Amount</label>
                    <div class="row g-2 mb-2">
                        <div class="col-4"><input type="number" id="p_tui" name="p_tui" class="form-control form-control-sm border-success fee-input" placeholder="Pd Tui" min="0" step="0.01" value="<?= $existing_certificate['paid_tuition_fee'] ?? 0 ?>" oninput="validateFeeInput(this); updatePreview()"></div>
                        <div class="col-4"><input type="number" id="p_oth" name="p_oth" class="form-control form-control-sm border-success fee-input" placeholder="Pd Oth" min="0" step="0.01" value="<?= $existing_certificate['paid_other_fee'] ?? 0 ?>" oninput="validateFeeInput(this); updatePreview()"></div>
                        <div class="col-4" style="display:<?= ($student['facility'] ?? 'None') =='None'?'none':'block' ?>">
                            <input type="number" id="p_fac" name="p_fac" class="form-control form-control-sm border-success fee-input" placeholder="Pd Fac" min="0" step="0.01" value="<?= $existing_certificate['paid_hostel_fee'] ?? 0 ?>" oninput="validateFeeInput(this); updatePreview()">
                        </div>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="autoCalculate" onchange="autoCalculatePaid()">
                        <label class="form-check-label small">Auto-calculate 50%</label>
                    </div>
                </div>

                <div class="form-check form-switch mt-2">
                    <input class="form-check-input" type="checkbox" name="bank_details" id="bankToggle" value="1" <?= (($existing_certificate['note_details'] ?? 'Yes') == 'Yes') ? 'checked' : '' ?> onchange="updatePreview()">
                    <label class="form-check-label small">Include Bank Details</label>
                </div>
            </div>

            <div id="alumniArea" style="display:none;" class="p-3 border rounded mb-3 bg-white">
                <label class="form-label">Alumni Details (Manual Entry Supported)</label>
                <div class="manual-group mb-2">
                    <input type="text" name="alm_name" id="alm_name" class="manual-field" placeholder="Name (e.g. John Doe)" value="<?= $student['name'] ?? '' ?>" oninput="validateName(this); updatePreview()">
                    <input type="text" name="alm_reg" id="alm_reg" class="manual-field" placeholder="Reg No (e.g. 113...)" value="<?= $student['reg'] ?? '' ?>" oninput="updatePreview()">
                    <input type="text" name="alm_father" id="alm_father" class="manual-field" placeholder="Father Name" value="<?= $student['father'] ?? '' ?>" oninput="validateName(this); updatePreview()">
                    <select name="alm_dept" id="alm_dept" class="manual-field" onchange="updatePreview()">
                        <option value="">Select Department</option>
                        <option value="Department of Biotechnology" <?= (($student['dept'] ?? '') == 'Department of Biotechnology') ? 'selected' : '' ?>>B.Tech – Biotechnology</option>
                        <option value="Department of Chemical Engineering" <?= (($student['dept'] ?? '') == 'Department of Chemical Engineering') ? 'selected' : '' ?>>B.Tech – Chemical Engineering</option>
                        <option value="Department of Civil Engineering" <?= (($student['dept'] ?? '') == 'Department of Civil Engineering') ? 'selected' : '' ?>>B.E – Civil Engineering</option>
                        <option value="Department of Computer Science and Engineering" <?= (($student['dept'] ?? '') == 'Department of Computer Science and Engineering') ? 'selected' : '' ?>>B.E – CSE</option>
                        <option value="Department of Computer Science and Engineering (Artificial Intelligence)" <?= (($student['dept'] ?? '') == 'Department of Computer Science and Engineering (Artificial Intelligence)') ? 'selected' : '' ?>>B.E – CSE (AI)</option>
                        <option value="Department of Artificial Intelligence and Data Science" <?= (($student['dept'] ?? '') == 'Department of Artificial Intelligence and Data Science') ? 'selected' : '' ?>>B.Tech – AI & DS</option>
                        <option value="Department of Mechanical Engineering" <?= (($student['dept'] ?? '') == 'Department of Mechanical Engineering') ? 'selected' : '' ?>>B.E – Mechanical</option>
                        <option value="Department of Information Technology" <?= (($student['dept'] ?? '') == 'Department of Information Technology') ? 'selected' : '' ?>>B.Tech – IT</option>
                        <option value="Department of Electronics and Communication Engineering" <?= (($student['dept'] ?? '') == 'Department of Electronics and Communication Engineering') ? 'selected' : '' ?>>B.E – ECE</option>
                        <option value="Department of Electrical and Electronics Engineering" <?= (($student['dept'] ?? '') == 'Department of Electrical and Electronics Engineering') ? 'selected' : '' ?>>B.E – EEE</option>
                        <option value="Department of Management Studies" <?= (($student['dept'] ?? '') == 'Department of Management Studies') ? 'selected' : '' ?>>MBA</option>
                        <option value="Department of Computer Applications" <?= (($student['dept'] ?? '') == 'Department of Computer Applications') ? 'selected' : '' ?>>MCA</option>
                    </select>
                    <select name="alm_gender" id="alm_gender" class="manual-field" onchange="updatePreview()">
                        <option value="Male" <?= ($student['gender'] ?? '') == 'Male' ? 'selected' : '' ?>>Male</option>
                        <option value="Female" <?= ($student['gender'] ?? '') == 'Female' ? 'selected' : '' ?>>Female</option>
                    </select>
                </div>
                <input type="number" step="0.01" min="0" max="10" name="alm_cgpa" id="alm_cgpa" class="form-control mb-2" placeholder="CGPA (e.g. 8.5)" value="<?= $existing_certificate['cgpa'] ?? '' ?>" oninput="validateCGPA(this); updatePreview()">
                <div class="form-check"><input type="checkbox" name="alm_moi" id="alm_moi" value="Yes" <?= (($existing_certificate['include_moi'] ?? 'No') == 'Yes') ? 'checked' : '' ?> onchange="updatePreview()"><label>Medium of Instruction</label></div>
                <div class="form-check"><input type="checkbox" name="alm_conv" id="alm_conv" value="Yes" <?= (($existing_certificate['include_conversion'] ?? 'No') == 'Yes') ? 'checked' : '' ?> onchange="updatePreview()"><label>CGPA Conversion</label></div>
                <div class="form-check"><input type="checkbox" name="alm_orig" id="alm_orig" value="Yes" <?= (($existing_certificate['original_certificate_status'] ?? 'No') == 'Yes') ? 'checked' : '' ?> onchange="updatePreview()"><label>Original Pending</label></div>
            </div>

            <div id="lorArea" style="display:none;" class="p-3 border rounded mb-3 bg-white">
                <?php 
                $lor_details = $existing_certificate['internship_students'] ?? '';
                $lor_parts = explode('|', $lor_details);
                $lor_faculty = $lor_parts[0] ?? '';
                $lor_designation = $lor_parts[1] ?? 'Assistant Professor';
                $lor_subject = $lor_parts[2] ?? '';
                ?>
                <input type="text" name="lor_faculty" id="lor_faculty" class="form-control mb-2" placeholder="Faculty Name" value="<?= $lor_faculty ?>" oninput="updatePreview()">
                <select name="lor_designation" id="lor_designation" class="form-select mb-2" onchange="updatePreview()">
                    <option value="Assistant Professor" <?= $lor_designation == 'Assistant Professor' ? 'selected' : '' ?>>Assistant Professor</option>
                    <option value="Associate Professor" <?= $lor_designation == 'Associate Professor' ? 'selected' : '' ?>>Associate Professor</option>
                    <option value="Professor" <?= $lor_designation == 'Professor' ? 'selected' : '' ?>>Professor</option>
                    <option value="Head of Department" <?= $lor_designation == 'Head of Department' ? 'selected' : '' ?>>Head of Department</option>
                </select>
                <input type="text" name="lor_subject" id="lor_subject" class="form-control" placeholder="Subject Taught (e.g. Database Management Systems)" value="<?= $lor_subject ?>" oninput="updatePreview()">
            </div>

            <div id="internArea" style="display:none;" class="mb-3">
                <input type="text" id="comp_name" name="comp_name" class="form-control mb-2" placeholder="Company / Project Title" value="<?= $existing_certificate['internship_students'] ?? '' ?>" oninput="updatePreview()">
            </div>

            <div class="action-buttons">
                <button type="submit" class="btn-insta"><?= $edit_mode ? 'Update & Print' : 'Save & Print' ?> <i class="fas fa-print ms-1"></i></button>
                <?php if($edit_mode): ?>
                    <a href="bonafide_issue.php" class="btn-new"><i class="fas fa-plus"></i> New Certificate</a>
                <?php endif; ?>
            </div>
        </form>
        <?php else: ?>
            <div class="text-center text-muted mt-5 opacity-50"><p>Enter Student ID to Start</p></div>
        <?php endif; ?>
    </div>

    <div class="right-panel">
        <div class="paper">
            <img src="https://www.velhightech.com/LP/logo.png" class="watermark">
            
            <!-- ENHANCED HEADER SECTION WITH REDUCED LEFT CONTAINER -->
            <div class="header-container">
                <div class="logo-container">
                    <img src="https://www.velhightech.com/LP/logo.png" alt="Vel Tech Logo" class="college-logo">
                </div>
                
                <div class="college-info">
                    <div class="college-name">Vel Tech High Tech</div>
                    <div class="college-subtitle">Dr. Rangarajan Dr. Sakunthala Engineering College</div>
                    
                    <div class="college-details">
                        <span>An Autonomous Institution</span>
                        <span>(Approved by AICTE, New Delhi, Affiliated to Anna University, Chennai)</span>
                    </div>
                    
                    <div class="college-accreditation">
                        <span>Accredited by NAAC with 'A' Grade & CGPA 3.27 | </span>
                        <span>NBA Accredited Programs (ECE, IT, Biotech & Chemical Engineering)</span>
                    </div>
                </div>
                
                <div class="contact-info">
                    <div class="contact-phone">📞 Mobile: 9789037651<br>☎️ Tel: 044-26840181</div>
                    <div class="contact-email">✉️ principal@velhightech.com</div>
                    <div class="contact-website">🌐 www.velhightech.com</div>
                    <div class="contact-address">
                        <strong>Address:</strong><br>
                        #60, Avadi-Alamathi Road,<br>
                        Morai Village, Vellanur Post,<br>
                        Avadi Taluk, Thiruvallur District,<br>
                        600062, Tamil Nadu, India.
                    </div>
                </div>
            </div>

            <!-- REFERENCE AND DATE -->
            <div class="ref-container">
                <div class="ref-number" id="v_ref"><?= !empty($saved_ref_no) ? $saved_ref_no : 'Ref/VH/eBONA/2025-26/DEMO' ?></div>
                <div class="certificate-date" id="v_date">Date: <?= !empty($existing_certificate['bonafide_date']) ? date('d M Y', strtotime($existing_certificate['bonafide_date'])) : date('d M Y') ?></div>
            </div>

            <div class="content">
                <div id="cert_heading" class="cert-title">BONAFIDE CERTIFICATE</div>
                
                <div id="dynamic_body"></div>

                <div class="footer">
                    <div class="qr">
                        <?php if(isset($saved_qr_path)): ?>
                            <img src="<?= $saved_qr_path ?>"><br>SCAN TO VERIFY
                        <?php else: ?>
                            <div style="width: 75px; height: 75px; background: #f0f0f0; display: flex; align-items: center; justify-content: center; color: #666; font-size: 9px; text-align: center;">
                                QR CODE<br>WILL APPEAR<br>AFTER SAVE
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="sign">PRINCIPAL</div>
                    <div style="position: absolute; right: 10px; bottom: 5px; font-size: 10px; color: #666;">
                        <i>Space for College Seal</i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let student = <?= $student ? json_encode($student) : 'null' ?>;
let manualMode = <?= $manual_mode ? 'true' : 'false' ?>;
let editMode = <?= $edit_mode ? 'true' : 'false' ?>;
let existingCertificate = <?= $existing_certificate ? json_encode($existing_certificate) : 'null' ?>;
const savedRef = "<?= $saved_ref_no ?? '' ?>";

// Enhanced number-to-words converter
function numToWords(n) {
    n = parseFloat(n);
    if (n === 0) return "Zero";
    
    // Handle decimals (paise)
    let rupees = Math.floor(n);
    let paise = Math.round((n - rupees) * 100);
    
    const units = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", 
                   "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", 
                   "Eighteen", "Nineteen"];
    const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
    
    function convertLessThanThousand(num) {
        if (num === 0) return "";
        if (num < 20) return units[num] + " ";
        if (num < 100) return tens[Math.floor(num / 10)] + " " + units[num % 10] + " ";
        return units[Math.floor(num / 100)] + " Hundred " + convertLessThanThousand(num % 100);
    }
    
    function convert(num) {
        if (num === 0) return "Zero";
        let result = "";
        const crore = Math.floor(num / 10000000);
        if (crore > 0) result += convertLessThanThousand(crore) + "Crore ";
        num %= 10000000;
        
        const lakh = Math.floor(num / 100000);
        if (lakh > 0) result += convertLessThanThousand(lakh) + "Lakh ";
        num %= 100000;
        
        const thousand = Math.floor(num / 1000);
        if (thousand > 0) result += convertLessThanThousand(thousand) + "Thousand ";
        num %= 1000;
        
        const hundred = Math.floor(num / 100);
        if (hundred > 0) result += units[hundred] + " Hundred ";
        num %= 100;
        
        if (num > 0) {
            if (num < 20) {
                result += units[num] + " ";
            } else {
                result += tens[Math.floor(num / 10)] + " " + units[num % 10] + " ";
            }
        }
        
        return result.trim();
    }
    
    let result = "";
    if (rupees > 0) result = convert(rupees) + " Rupees";
    if (paise > 0) {
        if (result) result += " and ";
        result += convert(paise) + " Paise";
    }
    return result + " Only";
}

// Format currency with Indian numbering system
function formatCurrency(n) {
    return parseFloat(n).toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// Input validation functions
function validateFeeInput(input) {
    let value = parseFloat(input.value);
    if (isNaN(value)) value = 0;
    if (value < 0) {
        input.value = 0;
        input.classList.add('input-invalid');
        setTimeout(() => input.classList.remove('input-invalid'), 2000);
    } else {
        input.value = value.toFixed(2);
        input.classList.add('input-valid');
    }
    updatePreview();
}

function validateName(input) {
    const nameRegex = /^[A-Za-z\s\.\-']+$/;
    if (!nameRegex.test(input.value) && input.value.length > 0) {
        input.classList.add('input-invalid');
    } else {
        input.classList.remove('input-invalid');
        input.classList.add('input-valid');
    }
}

function validateBatch(input) {
    const batchRegex = /^\d{4}-\d{4}$/;
    if (!batchRegex.test(input.value)) {
        input.classList.add('input-invalid');
    } else {
        input.classList.remove('input-invalid');
        input.classList.add('input-valid');
    }
}

function validateCGPA(input) {
    let value = parseFloat(input.value);
    if (isNaN(value)) value = 0;
    if (value < 0 || value > 10) {
        input.classList.add('input-invalid');
    } else {
        input.classList.remove('input-invalid');
        input.classList.add('input-valid');
    }
}

function init() {
    toggleFields();
    updatePreview();
    if(savedRef) {
        setTimeout(() => {
            window.print();
        }, 500);
    }
}

function toggleManualMode(force) {
    if(force) window.location.href = "?manual=1";
    else window.location.href = "bonafide_issue.php";
}

function setFacFee(val) {
    if(val) { 
        document.getElementById('f_fac').value = val; 
        validateFeeInput(document.getElementById('f_fac'));
    }
}

function applyFeeData() {
    document.getElementById('f_tui').value = document.getElementById('db_tui').value;
    document.getElementById('f_oth').value = document.getElementById('db_oth').value;
    validateFeeInput(document.getElementById('f_tui'));
    validateFeeInput(document.getElementById('f_oth'));
}

function autoCalculatePaid() {
    const autoCalc = document.getElementById('autoCalculate');
    if (autoCalc.checked) {
        const tui = parseFloat(document.getElementById('f_tui').value) || 0;
        const oth = parseFloat(document.getElementById('f_oth').value) || 0;
        const fac = parseFloat(document.getElementById('f_fac').value) || 0;
        
        document.getElementById('p_tui').value = (tui * 0.5).toFixed(2);
        document.getElementById('p_oth').value = (oth * 0.5).toFixed(2);
        document.getElementById('p_fac').value = (fac * 0.5).toFixed(2);
        
        validateFeeInput(document.getElementById('p_tui'));
        validateFeeInput(document.getElementById('p_oth'));
        validateFeeInput(document.getElementById('p_fac'));
    }
}

function updatePreviewLocal(el) {
    if(el.name.includes('father')) document.getElementById('v_father').innerText = el.value.toUpperCase();
}

function toggleFields() {
    const t = document.getElementById('certType').value;
    document.getElementById('feeArea').style.display = t.includes('Fee') ? 'block' : 'none';
    document.getElementById('paidArea').style.display = t === 'Fee Paid' ? 'block' : 'none';
    document.getElementById('alumniArea').style.display = t === 'Alumni' ? 'block' : 'none';
    document.getElementById('alumniCheck').style.display = t === 'Alumni' ? 'block' : 'none';
    document.getElementById('lorArea').style.display = t === 'LOR' ? 'block' : 'none';
    document.getElementById('internArea').style.display = (t === 'Internship' || t === 'Project') ? 'block' : 'none';
}

function updatePreview() {
    const type = document.getElementById('certType').value;
    let name, id, father, dept, batch, gender;

    // Logic to prefer Manual Alumni fields if present and visible
    if(type === 'Alumni' && document.getElementById('alm_name')?.value) {
        name = document.getElementById('alm_name').value.toUpperCase();
        id = document.getElementById('alm_reg').value;
        father = document.getElementById('alm_father').value.toUpperCase();
        dept = document.getElementById('alm_dept').value;
        batch = (student && student.batch) ? student.batch : '2021-2025'; // Fallback
        gender = document.getElementById('alm_gender').value;
    } else {
        name = (document.getElementById('in_name').value || 'STUDENT NAME').toUpperCase();
        id = document.getElementById('in_id')?.value || (student ? student.id : '12345');
        father = (document.getElementById('in_father').value || 'FATHER NAME').toUpperCase();
        dept = document.getElementById('in_dept').value || 'DEPARTMENT';
        batch = document.getElementById('in_batch').value || '2021-2025';
        gender = document.getElementById('in_gender').value;
    }
    
    const isMale = gender.toLowerCase().startsWith('m');
    const pfx = isMale ? 'Mr.' : 'Ms.';
    const rel = isMale ? 'son of' : 'daughter of';
    const ppfx = isMale ? 'Mr.' : 'Mr.';
    const pro = isMale ? 'his' : 'her';
    const objPro = isMale ? 'him' : 'her';
    const pSub = isMale ? 'he' : 'she';

    // Year Logic
    const startYear = parseInt(batch.split('-')[0]);
    const curYear = new Date().getFullYear();
    const m = new Date().getMonth() + 1;
    let year = (curYear - startYear) + (m >= 6 ? 1 : 0);
    if(year > 4) year = 4;
    const yearStr = (year==1?'I':(year==2?'II':(year==3?'III':'IV')));

    const purpose = document.getElementById('purpose').value;
    let html = "";
    
    // --- LOR ---
    if(type === 'LOR') {
        document.getElementById('cert_heading').innerText = "LETTER OF RECOMMENDATION"; 
        let fac = document.getElementById('lor_faculty').value || "[Faculty Name]";
        let desig = document.getElementById('lor_designation').value || "Assistant Professor";
        let sub = document.getElementById('lor_subject').value || "[Subject]";
        
        html = `<p>To Whom It May Concern,</p>
        <p>This is to certify that ${pfx} ${name} (Register No: ${id}) is an alumnus of Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College, where ${pSub} studied B.E/B.Tech in the Department of ${dept} during the academic period ${batch}.</p>
        <p>As the ${desig.toLowerCase()} for the subject "${sub}", I had the opportunity to teach and observe ${pfx} ${name} closely during ${pro} academic tenure. ${pSub} demonstrated exceptional aptitude in ${sub}, consistently scoring high grades and showing deep understanding of the subject matter.</p>
        <p>${pfx} ${name} exhibited strong analytical skills, innovative thinking, and the ability to apply theoretical concepts to practical problems. ${pSub} actively participated in classroom discussions, group projects, and demonstrated excellent teamwork abilities.</p>
        <p>${pro} dedication to academic excellence, combined with ${pro} strong work ethic and positive attitude, makes ${objPro} an ideal candidate for higher education. ${pfx} ${name} possesses the intellectual curiosity and perseverance necessary to succeed in advanced academic pursuits.</p>
        <p>Based on my professional assessment of ${pro} capabilities and performance in "${sub}", I strongly and wholeheartedly recommend ${pfx} ${name} for higher education. I am confident that ${pSub} will excel in ${pro} chosen field and make significant contributions to the academic community.</p>
        <p>We wish ${objPro} all success in ${pro} future academic endeavors and career.</p>
        <br><p>Yours sincerely,</p>
        <div style="font-weight:bold;">${fac}<br>${desig}, ${dept}<br>Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College</div>`;
    } 
    // --- ALUMNI ---
    else if(type === 'Alumni') {
        document.getElementById('cert_heading').innerText = "TO WHOMSOEVER IT MAY CONCERN";
        html = `<p>This is to certify that <strong>${pfx} ${name}</strong> (Register No: <strong>${id}</strong>), 
        ${rel} <strong>${ppfx} ${father}</strong>, was a bonafide student of 
        <strong>Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College (Autonomous)</strong> 
        and successfully completed the <strong>${dept}</strong> degree program during the academic years <strong>${batch}</strong>`;

        if(document.getElementById('alm_cgpa').value) {
            let cgpa = document.getElementById('alm_cgpa').value;
            html += ` with a CGPA of <strong>${parseFloat(cgpa).toFixed(2)}</strong>.`;
        }
        html += `</p>`;

        if(document.getElementById('alm_moi').checked) html += `<p>The Medium of Instruction and Evaluation for the above-mentioned programme followed by the Institute is English.</p>`;
        if(document.getElementById('alm_orig').checked) html += `<p>Degree Certificate will be issued in due course of time.</p>`;
        
        if(document.getElementById('alm_conv').checked) {
            let cgpa = document.getElementById('alm_cgpa').value || 0;
            html += `<p><strong>The CGPA to percentage conversion is as follows:</strong><br>
            Student CGPA: ${parseFloat(cgpa).toFixed(2)}<br>Conversion Grade: 10<br>
            Converted Percentage: ${(cgpa*10).toFixed(2)}%<br>(Percentage = CGPA × Conversion Grade)</p>`;
        }
        
        html += `<p>This certificate is issued upon ${pro} request for the purpose of applying for <strong>${purpose}</strong> only.</p>`;
    }
    // --- PROJECT ---
    else if(type === 'Project') {
        document.getElementById('cert_heading').innerText = "PERMISSION FOR PROJECT WORK";
        let title = document.getElementById('comp_name').value || "__________";
        html = `<p>This is to certify that <strong>${pfx} ${name}</strong> (${id}), ${rel} <strong>${father}</strong>, 
        pursuing <strong>${yearStr}</strong> Year ${dept} is a bonafide student of this college in the academic year 2025-2026.</p>
        <p>We kindly request you to permit ${objPro} to undertake <strong>Project Work</strong> in your esteemed organization.</p>
        <p>During the period of Project Work, ${pSub} will abide by the rules and regulations of your organization.
        You may please send us the duly signed attendance and periodic review / evaluation results of Project Work, at the end of every week.</p>
        <p>The outcome of the Project Work carried out by the student will be kept confidential by the department and will be used only for academic purposes.</p>
        <p style="text-align:center;">Thanking You,</p>`;
    }
    // --- INTERNSHIP ---
    else if(type === 'Internship') {
        document.getElementById('cert_heading').innerText = "BONAFIDE CERTIFICATE FOR INTERNSHIP";
        let comp = document.getElementById('comp_name').value || "__________";
        html = `<p>This is to certify that <strong>${pfx} ${name}</strong> (${id}), ${rel} <strong>${father}</strong>, 
        pursuing <strong>${yearStr}</strong> Year ${dept} is a bonafide student of this college in the academic year 2025-2026.</p>
        <p>This certificate is issued on ${pro} request for the purpose of applying <strong>${purpose}</strong> at your esteemed organization. 
        The above student will abide by all the rules, regulations and terms and conditions of your organization during the internship period.</p>`;
    }
    // --- FEE STRUCTURE ---
    else if(type === 'Fee Structure') {
        document.getElementById('cert_heading').innerText = "BONAFIDE CERTIFICATE FOR FEE STRUCTURE";
        
        let years = [];
        document.querySelectorAll('input[name="academic_year[]"]:checked').forEach(c => years.push(c.value));
        if(years.length === 0) years.push("2025-26"); 

        const fmt = (n) => parseFloat(n||0).toFixed(2);
        let tui = document.getElementById('f_tui').value || 0;
        let oth = document.getElementById('f_oth').value || 0;
        let fac = document.getElementById('f_fac').value || 0;
        let total = parseFloat(tui) + parseFloat(oth) + parseFloat(fac);
        
        let header = `<tr><th class="text-left" style="width:30%">Particulars</th>`;
        years.forEach(y => header += `<th>Academic Year<br>${y}<br>Amount (Rs.)</th>`);
        header += `</tr>`;
        
        let rows = `<tr><td class="text-left">Tuition Fee</td>`;
        years.forEach(() => rows += `<td class="amount">${fmt(tui)}</td>`);
        rows += `</tr><tr><td class="text-left">Other Fee</td>`;
        years.forEach(() => rows += `<td class="amount">${fmt(oth)}</td>`);
        rows += `</tr>`;
        if(fac > 0) {
            let facName = document.getElementById('facility_type').value + ' Fee';
            rows += `<tr><td class="text-left">${facName}</td>`;
            years.forEach(() => rows += `<td class="amount">${fmt(fac)}</td>`);
            rows += `</tr>`;
        }
        rows += `<tr class="total-row"><td class="text-left"><strong>Total</strong></td>`;
        years.forEach(() => rows += `<td class="amount"><strong>${fmt(total)}</strong></td>`);
        rows += `</tr>`;
        
        html = `<p>This is to certify that <strong>${pfx} ${name}</strong> (${id}), ${rel} <strong>${father}</strong>, 
        pursuing ${yearStr} Year ${dept} is a bonafide student of this college.</p>
        <p>The fee structure for the academic year(s) is detailed below:</p>
        <table class="fee-table"><thead>${header}</thead><tbody>${rows}</tbody></table>
        <div class="amount-words-box">
            <div class="numeric">₹ ${fmt(total)} per annum</div>
            <div class="words">${numToWords(total)}</div>
        </div>`;

        if(document.getElementById('bankToggle').checked) {
            html += `<div style="font-size:10pt; border:1px solid #000; padding:8px; margin-top:12px; background:#f8f9fa;">
                        <strong>Note:</strong> Demand Draft in favour of <strong>"The Principal, Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College"</strong><br>
                        <strong>Account Number:</strong> 75330100003390 | <strong>IFSC:</strong> BARB0VJVELT | <strong>Bank:</strong> Bank of Baroda, Vel Tech Branch
                     </div>`;
        }
    }
    // --- FEE PAID ---
    else if(type === 'Fee Paid') {
        document.getElementById('cert_heading').innerText = "BONAFIDE CERTIFICATE FOR FEE PAID";
        
        let years = [];
        document.querySelectorAll('input[name="academic_year[]"]:checked').forEach(c => years.push(c.value));
        if(years.length === 0) years.push("2025-26"); 

        const fmt = (n) => parseFloat(n||0).toFixed(2);
        let tui = document.getElementById('f_tui').value || 0;
        let oth = document.getElementById('f_oth').value || 0;
        let fac = document.getElementById('f_fac').value || 0;
        let total = parseFloat(tui) + parseFloat(oth) + parseFloat(fac);
        
        let ptui = document.getElementById('p_tui').value || 0;
        let poth = document.getElementById('p_oth').value || 0;
        let pfac = document.getElementById('p_fac').value || 0;
        let ptotal = parseFloat(ptui) + parseFloat(poth) + parseFloat(pfac);
        
        // Fee Structure Table
        let header = `<tr><th class="text-left" style="width:30%">Particulars</th>`;
        years.forEach(y => header += `<th>Academic Year<br>${y}<br>Amount (Rs.)</th>`);
        header += `</tr>`;
        
        let rows = `<tr><td class="text-left">Tuition Fee</td>`;
        years.forEach(() => rows += `<td class="amount">${fmt(tui)}</td>`);
        rows += `</tr><tr><td class="text-left">Other Fee</td>`;
        years.forEach(() => rows += `<td class="amount">${fmt(oth)}</td>`);
        rows += `</tr>`;
        if(fac > 0) {
            let facName = document.getElementById('facility_type').value + ' Fee';
            rows += `<tr><td class="text-left">${facName}</td>`;
            years.forEach(() => rows += `<td class="amount">${fmt(fac)}</td>`);
            rows += `</tr>`;
        }
        rows += `<tr class="total-row"><td class="text-left"><strong>Total</strong></td>`;
        years.forEach(() => rows += `<td class="amount"><strong>${fmt(total)}</strong></td>`);
        rows += `</tr>`;
        
        // Paid Amount Table
        let pheader = `<tr><th class="text-left" style="width:30%">Particulars</th>`;
        years.forEach(y => pheader += `<th>Academic Year<br>${y}<br>Paid (Rs.)</th>`);
        pheader += `</tr>`;
        
        let prows = `<tr><td class="text-left">Tuition Fee Paid</td>`;
        years.forEach(() => prows += `<td class="amount">${fmt(ptui)}</td>`);
        prows += `</tr><tr><td class="text-left">Other Fee Paid</td>`;
        years.forEach(() => prows += `<td class="amount">${fmt(poth)}</td>`);
        prows += `</tr>`;
        if(pfac > 0) {
            let facName = document.getElementById('facility_type').value + ' Paid';
            prows += `<tr><td class="text-left">${facName}</td>`;
            years.forEach(() => prows += `<td class="amount">${fmt(pfac)}</td>`);
            prows += `</tr>`;
        }
        prows += `<tr class="total-row"><td class="text-left"><strong>Total Paid</strong></td>`;
        years.forEach(() => prows += `<td class="amount"><strong>${fmt(ptotal)}</strong></td>`);
        prows += `</tr>`;
        
        html = `<p>This is to certify that <strong>${pfx} ${name}</strong> (${id}), ${rel} <strong>${father}</strong>, 
        pursuing ${yearStr} Year ${dept} is a bonafide student of this college.</p>
        <p>The fee structure and payment details for the academic year(s) are detailed below:</p>
        
        <p><strong>A. Fee Structure:</strong></p>
        <table class="fee-table"><thead>${header}</thead><tbody>${rows}</tbody></table>
        <div class="amount-words-box">
            <div class="numeric">Total Fee: ₹ ${fmt(total)} per annum</div>
            <div class="words">${numToWords(total)}</div>
        </div>
        
        <p><strong>B. Fee Paid Details:</strong></p>
        <table class="fee-table"><thead>${pheader}</thead><tbody>${prows}</tbody></table>
        <div class="amount-words-box">
            <div class="numeric">Total Paid: ₹ ${fmt(ptotal)}</div>
            <div class="words">${numToWords(ptotal)}</div>
        </div>`;

        if(document.getElementById('bankToggle').checked) {
            html += `<div style="font-size:10pt; border:1px solid #000; padding:8px; margin-top:12px; background:#f8f9fa;">
                        <strong>Note:</strong> All payments have been received through Demand Draft/Bank Transfer<br>
                        <strong>Account:</strong> 75330100003390 | <strong>IFSC:</strong> BARB0VJVELT | <strong>Bank:</strong> Bank of Baroda
                     </div>`;
        }
    }
    // --- NORMAL CERTIFICATE ---
    else {
        document.getElementById('cert_heading').innerText = "BONAFIDE CERTIFICATE";
        html = `<p>This is to certify that <strong>${pfx} ${name}</strong> (Reg No: <strong>${id}</strong>), 
        ${rel} <strong>${ppfx} ${father}</strong>, is a bonafide student of our institution, pursuing 
        <strong>${yearStr}</strong> Year B.E/B.Tech in <strong>${dept}</strong> during the academic year 2025-2026.</p>
        <p class="mt-4">This certificate is issued on ${pro} request for <strong>${purpose}</strong>.</p>`;
    }
    
    document.getElementById('dynamic_body').innerHTML = html;
}

window.onload = init;
</script>

<?php if($student && !$manual_mode): ?>
<input type="hidden" id="raw_father" value="<?= $student['father'] ?>">
<input type="hidden" id="raw_gender" value="<?= $student['gender'] ?>">
<?php endif; ?>

</body>
</html>
<?php 
include '../assets/ui/floating_chat_widget.php';
include '../includes/footer.php'; 
?>