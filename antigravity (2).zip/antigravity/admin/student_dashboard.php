<?php
// student_dashboard.php - COMPLETE STUDENT INTERFACE
ini_set('display_errors', 0); 
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', '../logs/dept_errors.log');
// 1. Session & Path Setup
ob_start();
session_start();

// Authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit;
}

require_once '../includes/db.php';
require_once '../includes/functions.php';

$student_id = $_SESSION['user_id'];
$student_name = $_SESSION['name'];
$student_dept = $_SESSION['DEPARTMENT'] ?? 'Not Specified';
$message = '';
$message_type = '';

// Handle new request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_request'])) {
    $bonafide_type = sanitize($_POST['bonafide_type'], 'string');
    $purpose = sanitize($_POST['purpose'], 'string');
    $additional_info = sanitize($_POST['additional_info'] ?? '', 'string');
    
    if (empty($bonafide_type) || empty($purpose)) {
        $message = "Please fill in all required fields";
        $message_type = "error";
    } else {
        $request_id = createBonafideRequest($student_id, $bonafide_type, $purpose, $additional_info);
        if ($request_id) {
            $message = "✅ Request submitted successfully!";
            $message_type = "success";
        } else {
            $message = "❌ Error submitting request";
            $message_type = "error";
        }
    }
}

// Handle revoke request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['revoke_request'])) {
    $request_id = intval($_POST['request_id']);
    if (revokeRequest($student_id, $request_id)) {
        $message = "✅ Request revoked successfully";
        $message_type = "success";
    } else {
        $message = "❌ Unable to revoke request";
        $message_type = "error";
    }
}

// Get student's requests
$requests = getStudentRequests($student_id);
$approved_certificates = getStudentCertificates($student_id);

// Get student details for profile display
$student_details = getStudentDetails($student_id);

include '../includes/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - Bonafide System</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #bc1888;
            --primary-gradient: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
            --success: #10b981;
            --warning: #f59e0b;
            --error: #ef4444;
            --info: #3b82f6;
            --gray-50: #f8fafc;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-400: #94a3b8;
            --gray-500: #64748b;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: var(--gray-50);
            color: var(--gray-800);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Header */
        .header {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            border-left: 5px solid var(--primary);
        }
        
        .header h1 {
            color: var(--gray-800);
            margin-bottom: 8px;
            font-size: 1.8rem;
        }
        
        .header p {
            color: var(--gray-600);
            margin-bottom: 5px;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            border: 1px solid var(--gray-200);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--gray-100);
        }
        
        .card-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--gray-800);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        /* Badges */
        .badge {
            display: inline-flex;
            align-items: center;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .badge-primary {
            background: var(--primary-gradient);
            color: white;
        }
        
        .badge-success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }
        
        .badge-warning {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning);
            border: 1px solid rgba(245, 158, 11, 0.2);
        }
        
        .badge-error {
            background: rgba(239, 68, 68, 0.1);
            color: var(--error);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }
        
        .badge-info {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info);
            border: 1px solid rgba(59, 130, 246, 0.2);
        }
        
        /* Buttons */
        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.875rem;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: var(--primary-gradient);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(188, 24, 136, 0.3);
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 0.75rem;
        }
        
        .btn-view {
            background: #dbeafe;
            color: #1d4ed8;
        }
        
        .btn-download {
            background: #dcfce7;
            color: #15803d;
        }
        
        .btn-revoke {
            background: #fee2e2;
            color: #b91c1c;
        }
        
        /* Forms */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--gray-700);
            font-size: 0.875rem;
        }
        
        .form-control, .form-select {
            width: 100%;
            padding: 12px;
            border: 2px solid var(--gray-200);
            border-radius: 8px;
            font-size: 0.95rem;
            transition: border-color 0.2s;
            background: white;
        }
        
        .form-control:focus, .form-select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(188, 24, 136, 0.1);
        }
        
        /* Tables */
        .table-container {
            overflow-x: auto;
            border-radius: 8px;
            border: 1px solid var(--gray-200);
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            min-width: 800px;
        }
        
        .table th {
            padding: 12px 16px;
            text-align: left;
            font-weight: 600;
            color: var(--gray-600);
            background: var(--gray-50);
            border-bottom: 2px solid var(--gray-200);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .table td {
            padding: 12px 16px;
            border-bottom: 1px solid var(--gray-200);
            vertical-align: middle;
        }
        
        .table tr:hover {
            background: var(--gray-50);
        }
        
        .table tr:last-child td {
            border-bottom: none;
        }
        
        /* Status indicators */
        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        
        .status-dot.pending { background: var(--warning); }
        .status-dot.approved { background: var(--success); }
        .status-dot.rejected { background: var(--error); }
        .status-dot.submitted { background: var(--info); }
        
        /* Action buttons */
        .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        /* QR Code */
        .qr-code {
            width: 60px;
            height: 60px;
            background: var(--gray-100);
            border: 1px dashed var(--gray-300);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--gray-500);
            font-size: 0.7rem;
            text-align: center;
            border-radius: 4px;
        }
        
        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: var(--gray-500);
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 15px;
            color: var(--gray-300);
        }
        
        /* Alert */
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-success {
            background: #dcfce7;
            color: #15803d;
            border: 1px solid #86efac;
        }
        
        .alert-error {
            background: #fee2e2;
            color: #b91c1c;
            border: 1px solid #fca5a5;
        }
        
        .alert-warning {
            background: #fef3c7;
            color: #d97706;
            border: 1px solid #fcd34d;
        }
        
        /* Grid */
        .dashboard-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
            margin-top: 25px;
        }
        
        @media (max-width: 1024px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            padding: 30px;
            width: 100%;
            max-width: 800px;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .close-modal {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--gray-500);
        }
        
        /* Print styles */
        @media print {
            .no-print,
            .btn,
            .action-buttons,
            .modal {
                display: none !important;
            }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            
            .card {
                padding: 20px;
            }
            
            .table {
                font-size: 0.875rem;
            }
            
            .table th,
            .table td {
                padding: 8px 12px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>Welcome, <?php echo htmlspecialchars($student_name); ?></h1>
            <p><strong>Student ID:</strong> <?php echo htmlspecialchars($student_id); ?></p>
            <p><strong>Department:</strong> <?php echo htmlspecialchars($student_dept); ?></p>
            <p><strong>Register No:</strong> <?php echo htmlspecialchars($student_details['register_no'] ?? 'N/A'); ?></p>
            
            <?php if($message): ?>
                <div class="alert alert-<?php echo $message_type === 'success' ? 'success' : 'error'; ?> mt-3">
                    <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- New Request Form -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">
                    <i class="fas fa-file-circle-plus"></i>
                    New Bonafide Request
                </div>
                <span class="badge badge-primary">Student</span>
            </div>
            
            <form method="POST" id="requestForm">
                <div class="form-group">
                    <label class="form-label">Certificate Type <span style="color: var(--error);">*</span></label>
                    <select name="bonafide_type" class="form-select" required>
                        <option value="">Select Type</option>
                        <option value="Bonafide">Bonafide Certificate</option>
                        <option value="Fee Structure">Fee Structure</option>
                        <option value="Fee Paid">Fee Paid Certificate</option>
                        <option value="Internship">Internship Certificate</option>
                        <option value="Project">Project Permission</option>
                        <option value="Alumni">Alumni Certificate</option>
                        <option value="LOR">Letter of Recommendation</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Purpose <span style="color: var(--error);">*</span></label>
                    <select name="purpose" class="form-select" required>
                        <option value="">Select Purpose</option>
                        <option value="Scholarship">Scholarship</option>
                        <option value="Education Loan">Education Loan</option>
                        <option value="Visa">Visa Process</option>
                        <option value="Passport">Passport</option>
                        <option value="Higher Studies">Higher Studies</option>
                        <option value="Internship Application">Internship Application</option>
                        <option value="Bank Account">Bank Account Opening</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Additional Information (Optional)</label>
                    <textarea name="additional_info" class="form-control" rows="3" 
                              placeholder="Any specific requirements or details..."></textarea>
                </div>
                
                <button type="submit" name="submit_request" class="btn btn-primary">
                    <i class="fas fa-paper-plane"></i> Submit Request
                </button>
            </form>
        </div>
        
        <div class="dashboard-grid">
            <!-- My Requests -->
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <i class="fas fa-list-check"></i>
                        My Requests
                    </div>
                    <span class="badge badge-warning"><?php echo count($requests); ?> Total</span>
                </div>
                
                <?php if(empty($requests)): ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>No Requests Yet</h3>
                        <p>Submit your first bonafide request above</p>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Request No</th>
                                    <th>Type</th>
                                    <th>Purpose</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th class="no-print">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($requests as $r): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($r['request_number'] ?? 'REQ-' . $r['id']); ?></strong>
                                    </td>
                                    <td><?php echo htmlspecialchars($r['bonafide_type']); ?></td>
                                    <td><?php echo htmlspecialchars(substr($r['purpose'], 0, 20)); ?>...</td>
                                    <td><?php echo date('d M Y', strtotime($r['submitted_on'] ?? $r['request_date'])); ?></td>
                                    <td>
                                        <?php
                                        $status_class = '';
                                        $status_text = '';
                                        $status_icon = '';
                                        
                                        if($r['admin_status'] === 'approved') {
                                            $status_class = 'badge-success';
                                            $status_text = 'Approved';
                                            $status_icon = 'approved';
                                        } elseif($r['admin_status'] === 'rejected') {
                                            $status_class = 'badge-error';
                                            $status_text = 'Rejected';
                                            $status_icon = 'rejected';
                                        } else {
                                            $status_class = 'badge-warning';
                                            $status_text = getCurrentStatus($r);
                                            $status_icon = 'pending';
                                        }
                                        ?>
                                        <span class="badge <?php echo $status_class; ?>">
                                            <span class="status-dot <?php echo $status_icon; ?>"></span>
                                            <?php echo $status_text; ?>
                                        </span>
                                    </td>
                                    <td class="no-print">
                                        <div class="action-buttons">
                                            <?php if($r['admin_status'] !== 'approved'): ?>
                                                <button type="button" class="btn btn-sm btn-view" 
                                                        onclick="viewLiveDemo(<?php echo $r['id']; ?>)">
                                                    <i class="fas fa-eye"></i> Demo
                                                </button>
                                                
                                                <?php if($r['advisor_status'] === 'pending'): ?>
                                                    <form method="POST" style="display: inline;">
                                                        <input type="hidden" name="request_id" value="<?php echo $r['id']; ?>">
                                                        <button type="submit" name="revoke_request" 
                                                                class="btn btn-sm btn-revoke"
                                                                onclick="return confirm('Are you sure you want to revoke this request?')">
                                                            <i class="fas fa-times"></i> Revoke
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span style="color: var(--success);">
                                                    <i class="fas fa-check-circle"></i> Completed
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Approved Certificates -->
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <i class="fas fa-certificate"></i>
                        Approved Certificates
                    </div>
                    <span class="badge badge-success"><?php echo count($approved_certificates); ?> Total</span>
                </div>
                
                <?php if(empty($approved_certificates)): ?>
                    <div class="empty-state">
                        <i class="fas fa-certificate"></i>
                        <h3>No Certificates Yet</h3>
                        <p>Your approved certificates will appear here</p>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Ref No</th>
                                    <th>Type</th>
                                    <th>Approved On</th>
                                    <th>QR Code</th>
                                    <th class="no-print">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($approved_certificates as $cert): ?>
                                <tr>
                                    <td>
                                        <strong style="color: var(--primary);">
                                            <?php echo htmlspecialchars($cert['ref_number']); ?>
                                        </strong>
                                    </td>
                                    <td>
                                        <span class="badge badge-info">
                                            <?php echo htmlspecialchars($cert['certificate_type']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php echo date('d M Y', strtotime($cert['bonafide_date'])); ?>
                                        <br>
                                        <small style="color: var(--gray-500); font-size: 0.75rem;">
                                            by <?php echo htmlspecialchars($cert['verified_by'] ?? 'Admin'); ?>
                                        </small>
                                    </td>
                                    <td>
                                        <?php if(!empty($cert['qr_code_path'])): ?>
                                            <img src="<?php echo $cert['qr_code_path']; ?>" 
                                                 width="60" height="60" 
                                                 alt="QR Code" 
                                                 style="border-radius: 4px;">
                                        <?php else: ?>
                                            <div class="qr-code">
                                                QR Code
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="no-print">
                                        <div class="action-buttons">
                                            <a href="print_certificate.php?id=<?php echo $cert['id']; ?>" 
                                               target="_blank" 
                                               class="btn btn-sm btn-download">
                                                <i class="fas fa-print"></i> Print
                                            </a>
                                            <a href="../verify.php?ref=<?php echo urlencode($cert['ref_number']); ?>" 
                                               target="_blank" 
                                               class="btn btn-sm btn-view">
                                                <i class="fas fa-shield-alt"></i> Verify
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Live View Modal -->
    <div class="modal" id="liveViewModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 style="margin: 0;">Live Preview</h2>
                <button class="close-modal" onclick="closeModal()">&times;</button>
            </div>
            <div id="livePreviewContent" style="min-height: 400px;">
                <!-- Content will be loaded here -->
            </div>
            <div style="margin-top: 20px; text-align: center; color: var(--gray-500); font-size: 0.875rem;">
                <i class="fas fa-info-circle"></i> This is a preview. Certificate will be generated after final approval.
            </div>
        </div>
    </div>
    
    <script>
        // View Live Demo
        function viewLiveDemo(requestId) {
            fetch('live_preview.php?request_id=' + requestId)
                .then(response => response.text())
                .then(html => {
                    document.getElementById('livePreviewContent').innerHTML = html;
                    document.getElementById('liveViewModal').style.display = 'flex';
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Unable to load preview');
                });
        }
        
        // Close modal
        function closeModal() {
            document.getElementById('liveViewModal').style.display = 'none';
        }
        
        // Close modal on outside click
        window.onclick = function(event) {
            const modal = document.getElementById('liveViewModal');
            if (event.target == modal) {
                closeModal();
            }
        }
        
        // Close modal on Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeModal();
            }
        });
        
        // Form validation
        document.getElementById('requestForm').addEventListener('submit', function(e) {
            const required = this.querySelectorAll('[required]');
            let valid = true;
            
            required.forEach(input => {
                if (!input.value.trim()) {
                    valid = false;
                    input.style.borderColor = 'var(--error)';
                } else {
                    input.style.borderColor = '';
                }
            });
            
            if (!valid) {
                e.preventDefault();
                alert('Please fill in all required fields');
            }
        });
        
        // Auto-hide alert after 5 seconds
        const alert = document.querySelector('.alert');
        if (alert) {
            setTimeout(() => {
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 300);
            }, 5000);
        }
    </script>
</body>
</html>

<?php include '../includes/footer.php'; ?>