<?php
ob_start();
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user_id'])) die("Unauthorized");

$request_id = intval($_GET['id']);
$query = "SELECT r.*, 
          (SELECT NAME FROM employee_details1 WHERE ID_NO = r.advisor_approved_by) as advisor_name,
          (SELECT NAME FROM employee_details1 WHERE ID_NO = r.hod_approved_by) as hod_name,
          (SELECT NAME FROM employee_details1 WHERE ID_NO = r.dean_approved_by) as dean_name,
          (SELECT NAME FROM employee_details1 WHERE ID_NO = r.admin_approved_by) as admin_name
          FROM bonafide_requests r WHERE id = $request_id";
$result = $mysqli->query($query);

if ($result && $result->num_rows > 0) {
    $request = $result->fetch_assoc();
?>
<div class="request-details">
    <div class="row mb-3">
        <div class="col-md-6">
            <strong>Request ID:</strong> #<?php echo str_pad($request['id'], 4, '0', STR_PAD_LEFT); ?>
        </div>
        <div class="col-md-6">
            <strong>Submitted:</strong> <?php echo date('d M Y H:i', strtotime($request['submitted_on'])); ?>
        </div>
    </div>
    
    <div class="row mb-3">
        <div class="col-md-6">
            <strong>Student Name:</strong> <?php echo htmlspecialchars($request['student_name']); ?>
        </div>
        <div class="col-md-6">
            <strong>Register No:</strong> <?php echo $request['register_number']; ?>
        </div>
    </div>
    
    <div class="row mb-3">
        <div class="col-md-6">
            <strong>Certificate Type:</strong> <?php echo $request['bonafide_type']; ?>
        </div>
        <div class="col-md-6">
            <strong>Purpose:</strong> <?php echo htmlspecialchars($request['purpose']); ?>
        </div>
    </div>
    
    <div class="row mb-3">
        <div class="col-md-12">
            <strong>Department:</strong> <?php echo $request['program']; ?>
        </div>
    </div>
    
    <?php if(!empty($request['academic_year'])): ?>
    <div class="row mb-3">
        <div class="col-md-12">
            <strong>Academic Years:</strong> <?php echo $request['academic_year']; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <?php if(!empty($request['internship_info'])): ?>
    <div class="row mb-3">
        <div class="col-md-12">
            <strong>Additional Info:</strong> <?php echo htmlspecialchars($request['internship_info']); ?>
        </div>
    </div>
    <?php endif; ?>
    
    <hr>
    
    <h6>Approval Status</h6>
    <div class="row mb-3">
        <div class="col-md-3">
            <strong>Class Advisor:</strong><br>
            <span class="badge bg-<?php echo $request['advisor_status'] == 'approved' ? 'success' : ($request['advisor_status'] == 'rejected' ? 'danger' : 'warning'); ?>">
                <?php echo ucfirst($request['advisor_status']); ?>
            </span><br>
            <small><?php echo $request['advisor_name'] ?? 'Pending'; ?></small>
        </div>
        <div class="col-md-3">
            <strong>HOD:</strong><br>
            <span class="badge bg-<?php echo $request['hod_status'] == 'approved' ? 'success' : ($request['hod_status'] == 'rejected' ? 'danger' : 'warning'); ?>">
                <?php echo ucfirst($request['hod_status']); ?>
            </span><br>
            <small><?php echo $request['hod_name'] ?? 'Pending'; ?></small>
        </div>
        <div class="col-md-3">
            <strong>Dean:</strong><br>
            <span class="badge bg-<?php echo $request['dean_status'] == 'approved' ? 'success' : ($request['dean_status'] == 'rejected' ? 'danger' : 'warning'); ?>">
                <?php echo ucfirst($request['dean_status']); ?>
            </span><br>
            <small><?php echo $request['dean_name'] ?? 'Pending'; ?></small>
        </div>
        <div class="col-md-3">
            <strong>Admin:</strong><br>
            <span class="badge bg-<?php echo $request['admin_status'] == 'approved' ? 'success' : ($request['admin_status'] == 'rejected' ? 'danger' : 'warning'); ?>">
                <?php echo ucfirst($request['admin_status']); ?>
            </span><br>
            <small><?php echo $request['admin_name'] ?? 'Pending'; ?></small>
        </div>
    </div>
    
    <?php if(!empty($request['ref_number'])): ?>
    <div class="alert alert-info">
        <i class="fas fa-certificate"></i> 
        <strong>Certificate Generated:</strong> <?php echo $request['ref_number']; ?>
    </div>
    <?php endif; ?>
</div>
<?php } else { echo "Request not found."; } ?>