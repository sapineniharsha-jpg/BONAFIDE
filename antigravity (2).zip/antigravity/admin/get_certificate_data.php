<?php
// get_certificate_data.php
session_start();
require_once '../includes/db.php';

// Check admin access
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['admin', 'principal'])) {
    echo json_encode(['success' => false, 'error' => 'Access denied']);
    exit;
}

if (isset($_GET['id'])) {
    $cert_id = intval($_GET['id']);
    
    $query = "SELECT * FROM bonafide_certificates WHERE id = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("i", $cert_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $cert = $result->fetch_assoc();
        
        echo json_encode([
            'success' => true,
            'certificate_type' => $cert['certificate_type'],
            'tuition_fee' => $cert['tuition_fee'],
            'other_fee' => $cert['other_fee'],
            'hostel_fee' => $cert['hostel_fee'],
            'bus_fee' => $cert['bus_fee'],
            'bus_type' => $cert['bus_type'],
            'bus_zone' => $cert['bus_zone'],
            'hostel_type' => $cert['hostel_type'],
            'total_fee' => $cert['total_fee'],
            'fee_paid' => $cert['fee_paid'],
            'academic_years' => $cert['academic_years']
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Certificate not found']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No ID provided']);
}
?>