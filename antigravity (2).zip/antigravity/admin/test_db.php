<?php
// test_db.php - Test database connection and tables
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'includes/db.php';

echo "<h2>Database Connection Test</h2>";

// Test connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
echo "<p style='color: green;'>✓ Database connected successfully</p>";

// Check bonafide_requests table structure
echo "<h3>Checking bonafide_requests table:</h3>";
$result = $mysqli->query("DESCRIBE bonafide_requests");
if ($result) {
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['Field']) . "</td>";
        echo "<td>" . htmlspecialchars($row['Type']) . "</td>";
        echo "<td>" . htmlspecialchars($row['Null']) . "</td>";
        echo "<td>" . htmlspecialchars($row['Key']) . "</td>";
        echo "<td>" . htmlspecialchars($row['Default']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>Error describing table: " . $mysqli->error . "</p>";
}

// Check bonafide_certificates table structure
echo "<h3>Checking bonafide_certificates table:</h3>";
$result = $mysqli->query("DESCRIBE bonafide_certificates");
if ($result) {
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['Field']) . "</td>";
        echo "<td>" . htmlspecialchars($row['Type']) . "</td>";
        echo "<td>" . htmlspecialchars($row['Null']) . "</td>";
        echo "<td>" . htmlspecialchars($row['Key']) . "</td>";
        echo "<td>" . htmlspecialchars($row['Default']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>Error describing table: " . $mysqli->error . "</p>";
}

// Test a sample query
echo "<h3>Testing sample query:</h3>";
$sql = "SELECT COUNT(*) as count FROM bonafide_requests";
$result = $mysqli->query($sql);
if ($result) {
    $row = $result->fetch_assoc();
    echo "<p>Total requests in system: " . $row['count'] . "</p>";
} else {
    echo "<p style='color: red;'>Query failed: " . $mysqli->error . "</p>";
}

$mysqli->close();
?>