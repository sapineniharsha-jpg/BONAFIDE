-- Phase 4: Intelligence Expansion Schema

-- Module 1: AI Self-Learning (Unanswered Queries)
CREATE TABLE IF NOT EXISTS ai_unanswered_learning (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question TEXT,
    user_type VARCHAR(50),
    frequency INT DEFAULT 1,
    status ENUM('pending','answered') DEFAULT 'pending',
    admin_answer TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_question (question(255)),
    INDEX idx_status (status)
);

-- Module 2: AI Retraining Logic
CREATE TABLE IF NOT EXISTS ai_training_suggestions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pattern TEXT,
    suggestion TEXT,
    frequency INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Module 3: Heatmap Analytics (Lightweight)
CREATE TABLE IF NOT EXISTS ai_hourly_stats (
    date DATE,
    hour INT,
    total INT DEFAULT 0,
    PRIMARY KEY (date, hour)
);

-- Module 4: User Satisfaction Scoring
CREATE TABLE IF NOT EXISTS ai_feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(50),
    question TEXT,
    rating INT,
    feedback TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
