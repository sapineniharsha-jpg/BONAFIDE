<?php
// migrate_phase4.php
require_once '../includes/config.php';
require_once '../includes/db.php';

echo "Starting Phase 4 Migration...\n";

$sqlFile = 'phase4_schema.sql';
if (!file_exists($sqlFile)) {
    die("Error: SQL file not found: $sqlFile\n");
}

$sqlContent = file_get_contents($sqlFile);
$queries = explode(';', $sqlContent);

foreach ($queries as $query) {
    $query = trim($query);
    if (empty($query))
        continue;

    if ($mysqli->query($query)) {
        echo "Executed: " . substr($query, 0, 50) . "...\n";
    }
    else {
        echo "Error executing query: " . $mysqli->error . "\n";
        echo "Query: $query\n";
    }
}

echo "Migration Complete.\n";
?>
