<?php
// ai/ai_engine.php
// Local-first institutional AI pipeline with admin approval queue.

// Shared Hosting Performance Settings
ini_set('memory_limit', '128M');
set_time_limit(10);


// Output buffering to catch any premature output/warnings
ob_start();

header('Content-Type: application/json');
// header("X-Frame-Options: DENY"); // Removed to allow iframe integration
header("X-Content-Type-Options: nosniff");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure utility functions exist (may be redundant if in helpers, but safe)
if (!function_exists('ai_json')) {
    function ai_json(array $payload): void
    {
        ob_end_clean(); // Discard any previous output (warnings, spaces, etc.)
        echo json_encode($payload);
        exit;
    }
}
if (!function_exists('ai_response')) {
    function ai_response(string $reply, string $source, string $intent = 'general', float $confidence = 0.0): void
    {
        ai_json(['status' => 'success', 'reply' => $reply, 'source' => $source, 'intent' => $intent, 'confidence' => $confidence, 'data' => ['answer' => $reply]]);
    }
}
if (!function_exists('ai_error')) {
    function ai_error(string $message): void
    {
        ai_json(['status' => 'error', 'message' => $message, 'reply' => $message]);
    }
}
if (!function_exists('ai_table_exists')) {
    function ai_table_exists(mysqli $db, string $table): bool
    {
        $safe = $db->real_escape_string($table);
        $res = $db->query("SHOW TABLES LIKE '{$safe}'");
        return (bool)($res && $res->num_rows > 0);
    }
}

// DB Connection
$dbPath = rtrim((string)($_SERVER['DOCUMENT_ROOT'] ?? ''), '/') . '/includes/db.php';
if (!file_exists($dbPath)) {
    $dbPath = dirname(__DIR__) . '/includes/db.php';
}
if (!file_exists($dbPath)) {
    ai_error('Database bootstrap not found.');
}
require_once $dbPath;

$dbConn = null;
if (isset($mysqli) && $mysqli instanceof mysqli) {
    $dbConn = $mysqli;
}
elseif (isset($conn) && $conn instanceof mysqli) {
    $dbConn = $conn;
}
elseif (isset($GLOBALS['db']) && is_object($GLOBALS['db']) && method_exists($GLOBALS['db'], 'getConnection')) {
    $candidate = $GLOBALS['db']->getConnection();
    if ($candidate instanceof mysqli) {
        $dbConn = $candidate;
    }
}
if (!$dbConn || $dbConn->connect_error) {
    ai_error('Database connection unavailable.');
}
$db = $dbConn;

require_once __DIR__ . '/ai_helpers.php';

$raw = file_get_contents('php://input');
$payload = json_decode((string)$raw, true);
$question = trim((string)($payload['question'] ?? ''));
$userType = ai_safe_user_type((string)($payload['user_context'] ?? ($_SESSION['role'] ?? 'public')));
$userId = (string)($_SESSION['user_id'] ?? 'PUBLIC');
$action = $payload['action'] ?? 'ask';

// === MODULE 4: USER SATISFACTION SCORING ===
if ($action === 'rate_answer') {
    $rating = (int)($payload['rating'] ?? 0);
    $qText = (string)($payload['question'] ?? '');

    if ($rating >= 1 && $rating <= 5) {
        $stmt = $db->prepare("INSERT INTO ai_feedback (user_id, question, rating) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $userId, $qText, $rating);
        $stmt->execute();
        ai_json(['status' => 'success', 'message' => 'Rating saved']);
    }
    ai_json(['status' => 'error', 'message' => 'Invalid rating']);
}

if ($question === '') {
    ai_error('Please ask a valid question.');
}

$start = microtime(true);

// Rate Limiting (15 req/min)
$limitCheck = $db->query("SELECT COUNT(*) as c FROM ai_chat_history WHERE user_id = '$userId' AND created_at > NOW() - INTERVAL 1 MINUTE");
if ($limitCheck && $limitCheck->fetch_assoc()['c'] > 15) {
    ai_error("Rate limit exceeded. Please wait a moment.");
}

$qLower = strtolower($question);

// Abuse Filter
$abusiveWords = ['fuck', 'shit', 'asshole', 'madarchod', 'bhenchod', 'chutiya', 'punda', 'otha', 'myre', 'sule'];
foreach ($abusiveWords as $w) {
    if (strpos($qLower, $w) !== false) {
        $_SESSION['ai_abuse_count'] = (int)($_SESSION['ai_abuse_count'] ?? 0) + 1;
        if ($_SESSION['ai_abuse_count'] >= 3) {
            $_SESSION['ai_ban_time'] = time() + (24 * 60 * 60);
            $msg = "Policy violation limit reached. Access blocked for 24 hours.";
            // ai_insert_log call removed
            // ai_insert_interaction call removed
            // ai_upsert_metrics call removed
            ai_reply_with_audit($db, $userId, $userType, $question, $msg, 'safety_block', 'safety_block', 1.0, false, $start);
        }
        $msg = "Please use professional language. Warning " . $_SESSION['ai_abuse_count'] . "/3.";
        // ai_insert_log call removed
        // ai_insert_interaction call removed
        // ai_upsert_metrics call removed
        ai_reply_with_audit($db, $userId, $userType, $question, $msg, 'safety_warning', 'safety_warning', 1.0, true, $start);
    }
}
if ((int)($_SESSION['ai_ban_time'] ?? 0) > time()) {
    ai_response("Access temporarily blocked for 24 hours due to repeated abuse.", 'safety_block', 'safety_block', 1.0);
}

// Normalize & Intent
$normalizedQuestion = ai_apply_synonyms($db, $question);

// === BONAFIDE WORKFLOW HANDLER ===
$flow = $_SESSION['ai_bonafide_flow'] ?? null;
if (is_array($flow) && (($flow['type'] ?? '') === 'bonafide')) {
    if (stripos($normalizedQuestion, 'cancel') !== false || stripos($normalizedQuestion, 'stop') !== false) {
        unset($_SESSION['ai_bonafide_flow']);
        ai_reply_with_audit($db, $userId, $userType, $question, "❌ Application cancelled.", 'flow', 'cancel', 1.0, true, $start);
    }

    $step = $flow['step'] ?? 'confirm_start';

    // Step 2: Purpose validation
    if ($step === 'purpose') {
        if (strlen($normalizedQuestion) < 5) {
            ai_reply_with_audit($db, $userId, $userType, $question, "⚠️ Please provide a valid reason (e.g., 'Internship at Amazon', 'Passport application').", 'flow', 'purpose_check', 1.0, true, $start);
        }
        $_SESSION['ai_bonafide_flow']['purpose'] = $normalizedQuestion;
        $_SESSION['ai_bonafide_flow']['step'] = 'period';
        ai_reply_with_audit($db, $userId, $userType, $question, "📅 Great. Which academic year/period is this for? (e.g., '2025-2026' or 'Current Semester')", 'flow', 'period_ask', 1.0, true, $start);
    }

    // Step 3: Period validation
    if ($step === 'period') {
        $_SESSION['ai_bonafide_flow']['period'] = $normalizedQuestion;
        $_SESSION['ai_bonafide_flow']['step'] = 'confirm_submit';

        $summary = "📝 **Review Application:**\n" .
            "• **Name:** " . $_SESSION['ai_bonafide_flow']['data']['name'] . "\n" .
            "• **Reg No:** " . $_SESSION['ai_bonafide_flow']['data']['reg_no'] . "\n" .
            "• **Purpose:** " . $_SESSION['ai_bonafide_flow']['purpose'] . "\n" .
            "• **Period:** " . $normalizedQuestion . "\n\n" .
            "Type 'Yes' to submit or 'Cancel' to stop.";
        ai_reply_with_audit($db, $userId, $userType, $question, $summary, 'flow', 'confirm_ask', 1.0, true, $start);
    }

    // Step 4: Final Submission
    if ($step === 'confirm_submit') {
        if (stripos($normalizedQuestion, 'yes') !== false || stripos($normalizedQuestion, 'ok') !== false || stripos($normalizedQuestion, 'submit') !== false) {
            // Insert into bonafide_requests
            $stmt = $db->prepare("INSERT INTO bonafide_requests (student_id, purpose, academic_year, status, request_date) VALUES (?, ?, ?, 'pending', NOW())");
            if ($stmt) {
                $stmt->bind_param("sss", $userId, $_SESSION['ai_bonafide_flow']['purpose'], $_SESSION['ai_bonafide_flow']['period']);
                $stmt->execute();
                unset($_SESSION['ai_bonafide_flow']);
                ai_reply_with_audit($db, $userId, $userType, $question, "✅ **Application Submitted Successfully!**\nReference ID: #" . $stmt->insert_id . "\nYou will be notified once approved.", 'flow', 'complete', 1.0, true, $start);
            }
            else {
                ai_reply_with_audit($db, $userId, $userType, $question, "❌ Database error. Please try again later.", 'flow', 'error', 1.0, true, $start);
            }
        }
        else {
            unset($_SESSION['ai_bonafide_flow']);
            ai_reply_with_audit($db, $userId, $userType, $question, "❌ Application cancelled.", 'flow', 'cancel', 1.0, true, $start);
        }
    }
}

// Start Bonafide Application
if (ai_is_bonafide_intent($normalizedQuestion) && $userType === 'student') {
    // Check pending requests first
    $stmt = $db->prepare("SELECT id, status FROM bonafide_requests WHERE student_id = ? AND status IN ('pending', 'approved') LIMIT 1");
    $stmt->bind_param("s", $userId);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        ai_reply_with_audit($db, $userId, $userType, $question, "ℹ️ You already have a " . $row['status'] . " request (ID: #" . $row['id'] . "). Only one active request allowed.", 'flow', 'status_check', 1.0, true, $start);
    }

    // Start flow
    // Gets student details
    $stmt = $db->prepare("SELECT Name, Register_Number, Department FROM students_login_master WHERE Register_Number = ?");
    $stmt->bind_param("s", $userId);
    $stmt->execute();
    $sRes = $stmt->get_result();
    if ($sRow = $sRes->fetch_assoc()) {
        $_SESSION['ai_bonafide_flow'] = [
            'type' => 'bonafide',
            'step' => 'purpose',
            'data' => ['name' => $sRow['Name'], 'reg_no' => $sRow['Register_Number']]
        ];
        ai_reply_with_audit($db, $userId, $userType, $question, "📝 **New Bonafide Application**\nRole: Student (" . $sRow['Name'] . ")\n\nPlease state the **purpose** of this certificate?", 'flow', 'start', 1.0, true, $start);
    }
}

// Greetings
if (preg_match('/^(hi|hello|hey|vanakkam|good morning|good afternoon|good evening)\b/i', $normalizedQuestion)) {
    $hour = date("H");
    $timeGreeting = ($hour < 12) ? "Good Morning" :
        (($hour < 17) ? "Good Afternoon" : "Good Evening");

    $name = $_SESSION['name'] ?? 'User';
    $greetingMessage = "$timeGreeting, {$name} 👋\n\nI am Antigravity AI.\nHow can I assist you today?";

    ai_reply_with_audit($db, $userId, $userType, $question, $greetingMessage, 'structured', 'greeting', 0.99, true, $start);
}

// Public Restricted Check
if ($userType === 'public' && ai_is_internal_restricted_intent($normalizedQuestion)) {
    ai_reply_with_audit($db, $userId, $userType, $question, "🔒 This information is available only for students and staff. Please login.", 'policy', 'restricted', 1.0, true, $start);
}

// === LOCAL AI PIPELINE ===
$local = null;

if ($userType === 'public') {
    // Limited Public Knowledge
    $local = ai_db_exact_or_keyword($db, $normalizedQuestion, 'public');
}
else {
    // 1. Structured DB Responses
    $local = ai_structured_response($db, $normalizedQuestion);

    // 2. Helper Logic
    if (!$local) {

        // === CONTEXT MEMORY EXTENSION ===
        if (isset($_SESSION['ai_last_faculty'])) {
            $last = $_SESSION['ai_last_faculty'];
            if (stripos($normalizedQuestion, 'email') !== false) {
                ai_reply_with_audit($db, $userId, $userType, $question, "📧 Email of {$last['NAME']}: {$last['EMAIL']}", 'memory', 'context_followup', 0.95, true, $start);
            }
        }

        // === DEPARTMENT SMART FILTER EXTENSION ===
        if (preg_match('/(cse|ece|mech|civil|it|aids|biotech)/i', $normalizedQuestion, $match) && (stripos($normalizedQuestion, 'faculty') !== false || stripos($normalizedQuestion, 'staff') !== false)) {
            $dept = strtoupper($match[1]);
            $stmt = $db->prepare("SELECT * FROM employee_details1 WHERE department LIKE ? LIMIT 15");
            $likeDept = "%$dept%";
            $stmt->bind_param("s", $likeDept);
            $stmt->execute();
            $res = $stmt->get_result();

            $reply = "👨🏫 {$dept} Department Faculty:\n\n";
            while ($row = $res->fetch_assoc()) {
                $reply .= "• " . $row['NAME'] . "\n";
            }
            ai_reply_with_audit($db, $userId, $userType, $question, $reply, 'department_search', 'faculty_department', 0.9, true, $start);
        }

        // === ROLE RECOGNITION (Principal/HOD) ===
        if (stripos($normalizedQuestion, 'principal') !== false) {
            $stmt = $db->prepare("SELECT * FROM employee_details1 WHERE role LIKE '%Principal%' LIMIT 1");
            $stmt->execute();
            $res = $stmt->get_result();
            if ($row = $res->fetch_assoc()) {
                ai_reply_with_audit($db, $userId, $userType, $question, "🎓 Principal: {$row['NAME']}", 'role_search', 'principal_info', 0.95, true, $start);
            }
        }
        if (stripos($normalizedQuestion, 'hod') !== false) {
            if (preg_match('/(cse|ece|mech|civil|it|aids|biotech)/i', $normalizedQuestion, $match)) {
                $dept = strtoupper($match[1]);
                $stmt = $db->prepare("SELECT * FROM employee_details1 WHERE role LIKE '%HOD%' AND department LIKE ?");
                $likeDept = "%$dept%";
                $stmt->bind_param("s", $likeDept);
                $stmt->execute();
                $res = $stmt->get_result();
                if ($row = $res->fetch_assoc()) {
                    ai_reply_with_audit($db, $userId, $userType, $question, "👨🏫 HOD of {$dept}: {$row['NAME']}", 'role_search', 'hod_info', 0.95, true, $start);
                }
            }
        }

        // === FACULTY SEARCH INTEGRATION ===
        // Implicit Name Check or Explicit Intent
        $isFacultySearch = false;
        $facKeywords = ['faculty', 'staff', 'professor', 'teacher', 'sir', 'mam', 'dean', 'hod', 'principal', 'details of'];

        foreach ($facKeywords as $kw) {
            if (stripos($normalizedQuestion, $kw) !== false) {
                $isFacultySearch = true;
                break;
            }
        }

        // Implicit Check for Names (2-3 words, capitalized maybe? or just short queries)
        // If query is short and not a known command
        if (!$isFacultySearch && str_word_count($normalizedQuestion) <= 4 && strlen($normalizedQuestion) > 3) {
            $commonCmds = ['fees', 'exam', 'mark', 'result', 'hostel', 'bus', 'food', 'mess', 'library', 'wifi', 'login', 'logout', 'attendance', 'admin', 'profile'];
            $isCmd = false;
            foreach ($commonCmds as $cmd) {
                if (stripos($normalizedQuestion, $cmd) !== false) {
                    $isCmd = true;
                    break;
                }
            }
            if (!$isCmd) {
                $isFacultySearch = true;
            }
        }

        if ($isFacultySearch && function_exists('ai_search_faculty')) {
            $facRes = ai_search_faculty($db, $normalizedQuestion);

            // Check for student existence if it's an implicit search (not explicit "faculty ...")
            $studentCount = 0;
            $isExplicitFaculty = (stripos($normalizedQuestion, 'faculty') !== false || stripos($normalizedQuestion, 'staff') !== false || stripos($normalizedQuestion, 'professor') !== false);

            if (!$isExplicitFaculty && function_exists('ai_quick_check_student')) {
                $studentCount = ai_quick_check_student($db, $normalizedQuestion);
            }

            // HIT: Faculty Found
            if ($facRes) {
                // Disambiguation needed?
                if ($studentCount > 0) {
                    $ans = "🤔 I found matching names in both **Faculty** and **Student** records.\n\n";
                    $ans .= "Are you looking for:\n";
                    $ans .= "1. **Faculty/Staff** details?\n";
                    $ans .= "2. **Student** details?\n\n";
                    $ans .= "Please type 'Faculty' or 'Student' to clarify.";
                    $local = ['answer' => $ans, 'source' => 'disambiguation', 'intent' => 'clarify_role', 'confidence' => 1.0];
                }
                else {
                    // Only Faculty found - Show it
                    if (count($facRes) === 1) {
                        $f = $facRes[0];

                        // Store in session for memory
                        $_SESSION['ai_last_faculty'] = $f;

                        $ans = "👨🏫 **Faculty Found:**\n\n**" . $f['NAME'] . "**\n" . ($f['DESIGNATION'] ?: '') . "\n" . ($f['DEPARTMENT'] ?: '') . "\n" . ($f['EMAIL'] ? "📧 " . $f['EMAIL'] : '');
                        $local = ['answer' => $ans, 'source' => 'faculty_search', 'intent' => 'faculty_info', 'confidence' => 0.95];
                    }
                    else {
                        $ans = "🧑🏫 Found " . count($facRes) . " faculty members:\n";
                        foreach ($facRes as $f) {
                            $ans .= "• **" . $f['NAME'] . "** (" . ($f['DEPARTMENT'] ?? 'Dept') . ")\n";
                        }
                        $ans .= "\nPlease be specific.";
                        $local = ['answer' => $ans, 'source' => 'faculty_search', 'intent' => 'faculty_list', 'confidence' => 0.85];
                    }
                }
            }
            // HIT: Only Student Found (Privacy Protected)
            elseif ($studentCount > 0) {
                $ans = "👤 I found a **Student** with that name.\n\n";
                $ans .= "🔒 **Privacy Notice:**\n";
                $ans .= "Student personal details are protected and cannot be shared publicly.\n";
                $ans .= "If you are looking for a faculty member, please check the spelling or try searching by department.";
                $local = ['answer' => $ans, 'source' => 'student_search', 'intent' => 'student_privacy', 'confidence' => 0.9];
            }
        }

        // Other Helpers
        if (!$local && function_exists('ai_handle_accreditation')) {
            $acc = ai_handle_accreditation($normalizedQuestion);
            if ($acc)
                $local = ['answer' => $acc, 'source' => 'structured', 'intent' => 'accreditation', 'confidence' => 0.95];
        }
        if (!$local && function_exists('ai_get_calendar_info')) {
            $cal = ai_get_calendar_info($db, $normalizedQuestion);
            if ($cal)
                $local = ['answer' => $cal, 'source' => 'calendar', 'intent' => 'calendar', 'confidence' => 0.9];
        }
        if (!$local && function_exists('ai_get_bus_route')) {
            if (preg_match('/bus\s*(?:no|number)?\s*(\d+)/i', $normalizedQuestion, $m)) {
                $bus = ai_get_bus_route($db, $m[1]);
                if ($bus)
                    $local = ['answer' => $bus, 'source' => 'transport', 'intent' => 'bus_route', 'confidence' => 0.9];
            }
        }
        if (!$local && function_exists('ai_handle_idea_lab')) {
            $ilab = ai_handle_idea_lab($db, $normalizedQuestion);
            if ($ilab)
                $local = ['answer' => $ilab, 'source' => 'structured', 'intent' => 'idea_lab', 'confidence' => 0.9];
        }
    }

    // 3. KB Match
    if (!$local && function_exists('ai_knowledge_base_match')) {
        $local = ai_knowledge_base_match($db, $normalizedQuestion, $userType);
    }

    // 4. QA Master Match
    if (!$local && function_exists('ai_qa_master_match')) {
        $local = ai_qa_master_match($db, $normalizedQuestion);
    }
}

// === RESPONSE ===
if ($local) {
    ai_reply_with_audit($db, $userId, $userType, $question, $local['answer'], $local['source'], $local['intent'] ?? 'general', $local['confidence'] ?? 0.8, true, $start);
}

// === EXTERNAL FALLBACK ===
// Placeholder for external AI API call (OpenAI/Gemini)
/*
if (defined('AI_API_KEY')) {
    $ext = ai_external_answer($question);
    if ($ext) ai_reply_with_audit($db, $userId, $userType, $question, $ext, 'external_ai', 'fallback', 0.7, true, $start);
}
*/

// === FINAL FALLBACK ===
$fallback = "I'm not sure about that. Could you please rephrase or reach out to the Front Office for assistance?";

// === MODULE 1: AI SELF-LEARNING (Unanswered Query Engine) ===
// Capture unanswered queries for admin review
try {
    $stmt = $db->prepare("
    INSERT INTO ai_unanswered_learning (question, user_type)
    VALUES (?, ?)
    ON DUPLICATE KEY UPDATE frequency = frequency + 1
    ");
    if ($stmt) {
        $stmt->bind_param("ss", $question, $userType);
        $stmt->execute();
    }
}
catch (Exception $e) { /* Silent fail */
}

ai_reply_with_audit($db, $userId, $userType, $question, $fallback, 'fallback', 'unanswered', 0.0, false, $start);


// --- LOCAL FUNCTIONS (If not in helpers, added here for robustness) ---

function ai_apply_synonyms($db, $text)
{
    // Basic replacement for now
    $text = str_replace('?', '', $text);
    return trim($text);
}

function ai_structured_response($db, $q)
{
    // Basic structured intents
    if (stripos($q, 'fee') !== false)
        return ['answer' => "You can check fee details in the Fees section of your dashboard.", 'source' => 'structured', 'confidence' => 0.8];
    return null;
}

function ai_reply_with_audit($db, $uid, $type, $q, $a, $src, $intent, $conf, $success, $start)
{
    // Full Chat History Extension (Existing)
    try {
        $duration = (int)((microtime(true) - $start) * 1000);
        $status = ($intent === 'fallback' || $intent === 'unanswered') ? 'fallback' : 'success';

        // Try new schema first (with analytics)
        // Corrected Schema: Using 'message' and 'reply' instead of 'question' and 'answer'
        $stmt = $db->prepare("INSERT INTO ai_chat_history (user_id, user_type, message, reply, response_time_ms, status) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("ssssis", $uid, $type, $q, $a, $duration, $status);
            $stmt->execute();
        }
        else {
            // If prepare fails, it might be due to missing columns, throw to catch block
            throw new Exception("New schema failed");
        }
    }
    catch (Exception $e) {
        // Fallback to legacy schema
        try {
            // Corrected Schema: Using 'message' and 'reply'
            $stmt = $db->prepare("INSERT INTO ai_chat_history (user_id, user_type, message, reply) VALUES (?, ?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("ssss", $uid, $type, $q, $a);
                $stmt->execute();
            }
        }
        catch (Exception $e2) { /* Silent fail */
        }
    }

    // === MODULE 1: AI ANALYTICS DASHBOARD ===
    try {
        $db->query("
        INSERT INTO ai_usage_summary (date, total_queries, successful_responses)
        VALUES (CURDATE(), 1, 1)
        ON DUPLICATE KEY UPDATE
        total_queries = total_queries + 1,
        successful_responses = successful_responses + 1
        ");

        $db->query("
        INSERT INTO ai_intent_tracking (intent, user_type, count)
        VALUES ('$intent', '$type', 1)
        ON DUPLICATE KEY UPDATE
        count = count + 1,
        last_used = NOW()
        ");
    }
    catch (Exception $e) { /* Silent fail */
    }

    // === MODULE 2: ADMIN AI MONITORING PANEL ===
    try {
        $stmt = $db->prepare("INSERT INTO ai_live_monitor (user_id, question, intent, confidence) VALUES (?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("sssd", $uid, $q, $intent, $conf);
            $stmt->execute();
        }
    }
    catch (Exception $e) { /* Silent fail */
    }

    // === MODULE 3: HEATMAP ANALYTICS (Lightweight) ===
    try {
        $hour = (int)date('H');
        // Insert or update hourly counter
        $db->query("
        INSERT INTO ai_hourly_stats (date, hour, total)
        VALUES (CURDATE(), $hour, 1)
        ON DUPLICATE KEY UPDATE total = total + 1
        ");
    }
    catch (Exception $e) { /* Silent fail */
    }

    ai_response($a, $src, $intent, $conf);
}

function ai_safe_user_type($t)
{
    return in_array($t, ['student', 'staff', 'admin']) ? $t : 'public';
}

function ai_is_bonafide_intent($q)
{
    return stripos($q, 'bonafide') !== false || stripos($q, 'certificate') !== false;
}

function ai_db_exact_or_keyword($db, $q, $type)
{
    // Implementation needed or rely on helpers
    return null;
}

function ai_is_internal_restricted_intent($q)
{
    // Check if query is about sensitive internal topics
    return false;
}

function ai_knowledge_base_match($db, $q, $type = 'public')
{
    // Search ai_knowledge_base table
    return null;
}

function ai_qa_master_match($db, $q)
{
    // Search qa_master
    return null;
}
?>
