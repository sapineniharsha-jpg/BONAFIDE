<?php
// ai/ai_helpers.php - Bonafide Certificate Intelligence & Helper Functions

/**
 * ==========================================
 * BONAFIDE INTELLIGENCE HANDLER
 * ==========================================
 * Detects and responds to bonafide-related queries
 */
function ai_bonafide_handler($db, $question, $userId, $userType)
{
    // Bonafide detection patterns with priority
    $patterns = [
        'apply' => [
            'regex' => '/\b(how|can|want|need|apply|request|submit|get)\s+(bonafide|certificate|bona fide)\b/i',
            'priority' => 10
        ],
        'status' => [
            'regex' => '/\b(bonafide|certificate|bona fide)\s+(status|track|where|check|pending|approved)\b/i',
            'priority' => 10
        ],
        'types' => [
            'regex' => '/\b(types?|kinds?|categories)\s+(of\s+)?(bonafide|certificate|bona fide)\b/i',
            'priority' => 8
        ],
        'time' => [
            'regex' => '/\b(how\s+long|duration|time|days|weeks)\s+.*(bonafide|certificate|bona fide)\b/i',
            'priority' => 7
        ],
        'fee' => [
            'regex' => '/\b(bonafide|certificate|bona fide)\s+(fee|cost|price|charge|payment)\b/i',
            'priority' => 6
        ],
        'reject' => [
            'regex' => '/\b(bonafide|certificate|bona fide)\s+(reject|denied|fail|refuse)\b/i',
            'priority' => 9
        ],
        'process' => [
            'regex' => '/\b(process|procedure|workflow|steps)\s+(for|of)?\s+(bonafide|certificate|bona fide)\b/i',
            'priority' => 7
        ],
        'download' => [
            'regex' => '/\b(download|print|save|view)\s+(bonafide|certificate|bona fide)\b/i',
            'priority' => 8
        ]
    ];

    // Check each pattern
    $matchedIntent = null;
    $highestPriority = 0;

    foreach ($patterns as $intent => $config) {
        if (preg_match($config['regex'], $question) && $config['priority'] > $highestPriority) {
            $matchedIntent = $intent;
            $highestPriority = $config['priority'];
        }
    }

    // If bonafide query detected, get contextual response
    if ($matchedIntent) {
        return ai_bonafide_response($db, $matchedIntent, $userId, $userType);
    }

    return null;
}

/**
 * Generate intelligent bonafide responses based on user context
 */
function ai_bonafide_response($db, $intent, $userId, $userType)
{
    // Get user-specific data for personalized responses
    $userData = ai_get_user_bonafide_data($db, $userId, $userType);

    // Response templates with dynamic content
    $responses = [
        'apply' => [
            'student' => function ($data) {
            $answer = "📝 **How to Apply for Bonafide Certificate:**\n\n";
            $answer .= "**Step 1:** Go to Department → Bonafide Certificate\n";
            $answer .= "**Step 2:** Select certificate type:\n";
            $answer .= "  • General Bonafide\n";
            $answer .= "  • Fee Structure\n";
            $answer .= "  • Fee Paid\n";
            $answer .= "  • Internship\n";
            $answer .= "  • Project\n\n";
            $answer .= "**Step 3:** Choose purpose (Scholarship, Loan, Visa, etc.)\n";
            $answer .= "**Step 4:** Submit request\n\n";

            if ($data['has_pending_request']) {
                $answer .= "⚠️ **Note:** You currently have {$data['pending_count']} pending request(s).\n";
            }

            if ($data['is_scholarship_75']) {
                $answer .= "⚠️ **Important:** 7.5% scholarship holders cannot request Fee Structure/Paid certificates.\n";
            }

            $answer .= "\n✅ **Approval Chain:** Class Advisor → HOD → Dean → Admin\n";
            $answer .= "⏱️ **Processing Time:** 4-7 working days";

            return $answer;
        },
            'staff' => function ($data) {
            return "👨🏫 **For Staff/Advisors:**\n\n" .
            "Students can submit bonafide requests through the system. You'll receive pending requests in your dashboard for approval.\n\n" .
            "**Your Current Queue:** {$data['pending_approvals']} request(s) awaiting your approval\n\n" .
            "Please review and approve within 1-2 working days to maintain efficient processing.";
        },
            'admin' => function ($data) {
            return "🔐 **For Administrators:**\n\n" .
            "Students submit requests through the system. You'll see requests after Dean approval for final processing.\n\n" .
            "**Current Statistics:**\n" .
            "• Pending Admin Approval: {$data['admin_queue']}\n" .
            "• Total Processed Today: {$data['processed_today']}\n\n" .
            "For Fee Structure/Paid certificates, you'll need to enter fee details before final approval.";
        }
        ],

        'status' => [
            'student' => function ($data) {
            $answer = "🔍 **Check Your Bonafide Certificate Status:**\n\n";

            if ($data['has_pending_request']) {
                $answer .= "📋 **Your Pending Requests:** {$data['pending_count']}\n\n";
                foreach ($data['pending_requests'] as $req) {
                    $answer .= "**Request #{$req['request_number']}** ({$req['bonafide_type']})\n";
                    $answer .= "• Submitted: {$req['request_date']}\n";
                    $answer .= "• Class Advisor: " . ucfirst($req['advisor_status']) . "\n";
                    $answer .= "• HOD: " . ucfirst($req['hod_status']) . "\n";
                    $answer .= "• Dean: " . ucfirst($req['dean_status']) . "\n";
                    $answer .= "• Admin: " . ucfirst($req['admin_status']) . "\n\n";
                }
            }

            if ($data['has_approved_cert']) {
                $answer .= "✅ **Approved Certificates:** {$data['approved_count']}\n";
                $answer .= "You can view and download them from the Certificates section.\n\n";
            }

            if (!$data['has_pending_request'] && !$data['has_approved_cert']) {
                $answer .= "You don't have any bonafide certificate requests yet.\n\n";
                $answer .= "Would you like to know how to apply?";
            }

            return $answer;
        },
            'staff' => function ($data) {
            return "📊 **Bonafide Request Status Overview:**\n\n" .
            "• Awaiting Your Approval: {$data['pending_approvals']}\n" .
            "• You've Approved: {$data['approved_by_you']}\n" .
            "• You've Rejected: {$data['rejected_by_you']}\n\n" .
            "Access the Bonafide System dashboard to see detailed request information.";
        },
            'admin' => function ($data) {
            return "📈 **System-Wide Status:**\n\n" .
            "• Pending Admin Approval: {$data['admin_queue']}\n" .
            "• Completed Today: {$data['completed_today']}\n" .
            "• Total Certificates Issued: {$data['total_issued']}\n\n" .
            "View the admin dashboard for detailed analytics.";
        }
        ],

        'types' => [
            'student' => function ($data) {
            $answer = "📜 **Bonafide Certificate Types:**\n\n";
            $answer .= "**1. General Bonafide**\n";
            $answer .= "   For general purposes like passport, bank account, etc.\n\n";
            $answer .= "**2. Fee Structure**\n";
            $answer .= "   Shows complete fee breakup for scholarships/loans\n\n";
            $answer .= "**3. Fee Paid**\n";
            $answer .= "   Shows fees already paid (50% of total fees)\n\n";
            $answer .= "**4. Internship**\n";
            $answer .= "   Permission letter for internship programs\n\n";
            $answer .= "**5. Project**\n";
            $answer .= "   Permission for project work at organizations\n\n";

            if ($data['is_scholarship_75']) {
                $answer .= "⚠️ **Note:** As a 7.5% scholarship holder, you cannot request Fee Structure/Paid certificates.";
            }

            return $answer;
        },
            'staff' => function ($data) {
            return "📋 **Certificate Types Available:**\n\n" .
            "• General, Fee Structure, Fee Paid, Internship, Project\n\n" .
            "Each certificate goes through the standard approval chain. Fee certificates require admin fee entry before final approval.";
        },
            'admin' => function ($data) {
            return "📂 **All Certificate Types:**\n\n" .
            "• General Bonafide\n" .
            "• Fee Structure (requires fee entry)\n" .
            "• Fee Paid (requires fee entry)\n" .
            "• Internship\n" .
            "• Project\n\n" .
            "Plus direct issue options:\n" .
            "• Letter of Recommendation (LOR)\n" .
            "• Alumni Certificates";
        }
        ],

        'time' => [
            'student' => function ($data) {
            return "⏱️ **Processing Time Breakdown:**\n\n" .
            "**Standard Approval Chain:**\n" .
            "• Class Advisor: 1-2 days\n" .
            "• HOD: 1-2 days\n" .
            "• Dean: 1-2 days\n" .
            "• Admin (Final): 1 day\n\n" .
            "**Total Time:** 4-7 working days\n\n" .
            "💡 **Tip:** Submit your request well in advance if you have a deadline!";
        },
            'staff' => function ($data) {
            return "⏱️ **Processing Guidelines:**\n\n" .
            "Please approve/reject requests within **1-2 working days** to maintain efficient processing.\n\n" .
            "Total system processing time: 4-7 working days from submission to certificate generation.";
        },
            'admin' => function ($data) {
            return "📊 **Average Processing Times:**\n\n" .
            "• Class Advisor: 1.5 days (avg)\n" .
            "• HOD: 1.2 days (avg)\n" .
            "• Dean: 1.3 days (avg)\n" .
            "• Admin: Same day\n\n" .
            "Total system average: 5 working days";
        }
        ],

        'fee' => [
            'student' => function ($data) {
            return "💰 **Bonafide Certificate Fees:**\n\n" .
            "Bonafide certificates are issued **FREE OF CHARGE** as part of student services.\n\n" .
            "There are no fees for:\n" .
            "• Submitting requests\n" .
            "• Certificate generation\n" .
            "• Downloading/printing\n\n" .
            "If you face any issues, contact the administration office.";
        },
            'staff' => function ($data) {
            return "💰 **Certificate Issuance:**\n\n" .
            "Bonafide certificates are issued free of charge to students. No fees are collected for certificate processing or issuance.";
        },
            'admin' => function ($data) {
            return "💰 **Fee Policy:**\n\n" .
            "Bonafide certificates are provided as complimentary student services. No charges apply.";
        }
        ],

        'reject' => [
            'student' => function ($data) {
            $answer = "❌ **If Your Request is Rejected:**\n\n";
            $answer .= "**Why rejections happen:**\n";
            $answer .= "• Incomplete information\n";
            $answer .= "• Invalid certificate type for your eligibility\n";
            $answer .= "• Document verification issues\n\n";
            $answer .= "**What to do:**\n";
            $answer .= "1. Check the rejection remarks in your requests table\n";
            $answer .= "2. Contact the person who rejected it for clarification\n";
            $answer .= "3. Correct the issues and submit a new request\n\n";

            if ($data['has_rejected']) {
                $answer .= "⚠️ You have {$data['rejected_count']} rejected request(s). Check the remarks for details.";
            }

            return $answer;
        },
            'staff' => function ($data) {
            return "❌ **Rejection Guidelines:**\n\n" .
            "When rejecting a request, please:\n" .
            "• Provide clear, specific rejection reasons\n" .
            "• Explain what needs correction\n" .
            "• Guide student on next steps\n\n" .
            "This helps students correct issues and resubmit successfully.";
        },
            'admin' => function ($data) {
            return "❌ **Rejection Analytics:**\n\n" .
            "• Total Rejections This Month: {$data['rejections_month']}\n" .
            "• Common Rejection Reasons: Check admin dashboard\n\n" .
            "Review rejection patterns to improve the system or provide better guidance to students.";
        }
        ],

        'process' => [
            'student' => function ($data) {
            return "🔄 **Bonafide Certificate Workflow:**\n\n" .
            "**1. Student Submits Request**\n" .
            "   Select type and purpose\n\n" .
            "**2. Class Advisor Reviews**\n" .
            "   Verifies student details\n\n" .
            "**3. HOD Approves**\n" .
            "   Department-level verification\n\n" .
            "**4. Dean Approves**\n" .
            "   Academic approval\n\n" .
            "**5. Admin Final Processing**\n" .
            "   Certificate generation with QR code\n\n" .
            "✅ You receive your certificate in the Certificates section!";
        },
            'staff' => function ($data) {
            return "🔄 **Approval Workflow:**\n\n" .
            "Student → Class Advisor (You) → HOD → Dean → Admin\n\n" .
            "**Your Role:**\n" .
            "• Verify student enrollment status\n" .
            "• Check request validity\n" .
            "• Approve or reject with remarks\n\n" .
            "You'll only see requests for students under your mentorship.";
        },
            'admin' => function ($data) {
            return "🔄 **Complete Workflow:**\n\n" .
            "1. Student submits via web interface\n" .
            "2. Class Advisor (auto-assigned from mentor_mentee)\n" .
            "3. HOD (department-specific)\n" .
            "4. Dean (institution-level)\n" .
            "5. Admin (you) - Enter fees if needed, generate certificate\n\n" .
            "**Certificate Generation:**\n" .
            "• Unique reference number\n" .
            "• QR code for verification\n" .
            "• Stored in bonafide_certificates table";
        }
        ],

        'download' => [
            'student' => function ($data) {
            $answer = "📥 **Download Your Certificate:**\n\n";

            if ($data['has_approved_cert']) {
                $answer .= "✅ You have {$data['approved_count']} approved certificate(s).\n\n";
                $answer .= "**To download:**\n";
                $answer .= "1. Go to Bonafide Certificate page\n";
                $answer .= "2. Navigate to 'My Certificates' section\n";
                $answer .= "3. Click the 'View' button on any certificate\n";
                $answer .= "4. Click 'Print' to download as PDF\n\n";
                $answer .= "💡 Your certificate includes a QR code for verification.";
            }
            else {
                $answer .= "You don't have any approved certificates yet.\n\n";
                if ($data['has_pending_request']) {
                    $answer .= "Your request is currently being processed. You'll be able to download once it's approved by all authorities.";
                }
                else {
                    $answer .= "Would you like to know how to apply for a bonafide certificate?";
                }
            }

            return $answer;
        },
            'staff' => function ($data) {
            return "📥 **Certificate Access:**\n\n" .
            "You can view certificates for students under your mentorship in the Certificates section.\n\n" .
            "Use the 'View' button to see the full certificate with QR code, and 'Print' to download.";
        },
            'admin' => function ($data) {
            return "📥 **Certificate Management:**\n\n" .
            "• View all issued certificates in the system\n" .
            "• Edit fees for Fee Structure/Paid certificates\n" .
            "• Reprint certificates if needed\n" .
            "• Track certificate issuance through analytics\n\n" .
            "All certificates are stored with QR codes in /temp/ directory.";
        }
        ]
    ];

    // Get appropriate response
    $responseFunc = $responses[$intent][$userType] ?? $responses[$intent]['student'];
    $answer = $responseFunc($userData);

    // Log bonafide query for analytics
    ai_log_bonafide_query($db, $intent, $userType);

    return [
        'answer' => $answer,
        'source' => 'Bonafide AI',
        'type' => 'bonafide_' . $intent,
        'confidence' => 0.95
    ];
}

/**
 * Get user-specific bonafide data for personalized responses
 */
function ai_get_user_bonafide_data($db, $userId, $userType)
{
    $data = [
        'has_pending_request' => false,
        'pending_count' => 0,
        'pending_requests' => [],
        'has_approved_cert' => false,
        'approved_count' => 0,
        'has_rejected' => false,
        'rejected_count' => 0,
        'is_scholarship_75' => false,
        'pending_approvals' => 0,
        'approved_by_you' => 0,
        'rejected_by_you' => 0,
        'admin_queue' => 0,
        'completed_today' => 0,
        'processed_today' => 0,
        'total_issued' => 0,
        'rejections_month' => 0
    ];

    try {
        if ($userType === 'student') {
            // Pending requests
            $stmt = $db->prepare("SELECT * FROM bonafide_requests WHERE student_id = ? AND status != 'completed' ORDER BY request_date DESC");
            $stmt->bind_param("s", $userId);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $data['has_pending_request'] = true;
                $data['pending_count'] = $result->num_rows;
                while ($row = $result->fetch_assoc()) {
                    $data['pending_requests'][] = [
                        'request_number' => $row['request_number'],
                        'bonafide_type' => $row['bonafide_type'],
                        'request_date' => date('d M Y', strtotime($row['request_date'])),
                        'advisor_status' => $row['advisor_status'],
                        'hod_status' => $row['hod_status'],
                        'dean_status' => $row['dean_status'],
                        'admin_status' => $row['admin_status']
                    ];
                }
            }

            // Approved certificates
            $stmt = $db->prepare("SELECT COUNT(*) as cnt FROM bonafide_certificates WHERE student_id = ? AND status = 'approved'");
            $stmt->bind_param("s", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            if ($row['cnt'] > 0) {
                $data['has_approved_cert'] = true;
                $data['approved_count'] = $row['cnt'];
            }

            // Rejected requests
            $stmt = $db->prepare("SELECT COUNT(*) as cnt FROM bonafide_requests WHERE student_id = ? AND status = 'rejected'");
            $stmt->bind_param("s", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            if ($row['cnt'] > 0) {
                $data['has_rejected'] = true;
                $data['rejected_count'] = $row['cnt'];
            }

            // Check scholarship
            $stmt = $db->prepare("SELECT scholarship_type FROM bonafide_fee_details WHERE id_no = ?");
            $stmt->bind_param("s", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $scholarship = trim($row['scholarship_type']);
                if (in_array($scholarship, ['7.5', '7.5%'])) {
                    $data['is_scholarship_75'] = true;
                }
            }

        }
        elseif ($userType === 'staff') {
            // Pending approvals for this advisor
            $stmt = $db->prepare("SELECT COUNT(*) as cnt FROM bonafide_requests WHERE advisor_id = ? AND advisor_status = 'pending'");
            $stmt->bind_param("s", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $data['pending_approvals'] = $row['cnt'];

            // Approved by this advisor
            $stmt = $db->prepare("SELECT COUNT(*) as cnt FROM bonafide_requests WHERE advisor_id = ? AND advisor_status = 'approved'");
            $stmt->bind_param("s", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $data['approved_by_you'] = $row['cnt'];

            // Rejected by this advisor
            $stmt = $db->prepare("SELECT COUNT(*) as cnt FROM bonafide_requests WHERE advisor_id = ? AND advisor_status = 'rejected'");
            $stmt->bind_param("s", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $data['rejected_by_you'] = $row['cnt'];

        }
        elseif ($userType === 'admin' || $userType === 'principal') {
            // Admin queue
            $result = $db->query("SELECT COUNT(*) as cnt FROM bonafide_requests WHERE admin_status = 'pending' AND dean_status = 'approved'");
            $row = $result->fetch_assoc();
            $data['admin_queue'] = $row['cnt'];

            // Completed today
            $today = date('Y-m-d');
            $result = $db->query("SELECT COUNT(*) as cnt FROM bonafide_certificates WHERE DATE(created_at) = '$today'");
            $row = $result->fetch_assoc();
            $data['completed_today'] = $row['cnt'];

            // Total issued
            $result = $db->query("SELECT COUNT(*) as cnt FROM bonafide_certificates WHERE status = 'approved'");
            $row = $result->fetch_assoc();
            $data['total_issued'] = $row['cnt'];

            // Rejections this month
            $firstDay = date('Y-m-01');
            $result = $db->query("SELECT COUNT(*) as cnt FROM bonafide_requests WHERE status = 'rejected' AND request_date >= '$firstDay'");
            $row = $result->fetch_assoc();
            $data['rejections_month'] = $row['cnt'];
        }

    }
    catch (Exception $e) {
    // Silent fail - return default data
    }

    return $data;
}

/**
 * Log bonafide queries for analytics
 */
function ai_log_bonafide_query($db, $queryType, $userType)
{
    try {
        $today = date('Y-m-d');
        $db->query("INSERT INTO ai_bonafide_insights (query_type, query_count, user_type, last_query_date) 
                    VALUES ('$queryType', 1, '$userType', '$today')
                    ON DUPLICATE KEY UPDATE 
                    query_count = query_count + 1, 
                    last_query_date = '$today'");
    }
    catch (Exception $e) {
    // Silent fail
    }
}

/**
 * ==========================================
 * FACULTY INTELLIGENCE HANDLER
 * ==========================================
 */

/**
 * Search for faculty by name or ID
 */
/**
 * Search for faculty by name or ID
 */
// Duplicate function removed

/**
 * Quick check if a student exists by name (for disambiguation)
 */
function ai_quick_check_student($db, $name)
{
    if (strlen($name) < 3)
        return 0;
    $safeName = $db->real_escape_string($name);
    // Assuming students_login_master is the main student table
    $res = $db->query("SELECT COUNT(*) as cnt FROM students_login_master WHERE Name LIKE '%$safeName%'");
    if ($res && $row = $res->fetch_assoc()) {
        return (int)$row['cnt'];
    }
    return 0;
}


/**
 * Format faculty search results into a response
 */
/**
 * Format faculty search results into a response
 */
function ai_format_faculty_response($facultyList, $originalQuery)
{
    $count = count($facultyList);

    // Single Match - Detailed Card
    if ($count === 1) {
        $f = $facultyList[0];
        $photo = $f['photovarchar'];
        if ($photo && strpos($photo, '/') === false) {
            // Check if it's already a full path or just a filename
            $photo = "uploads/faculty_photos/" . $photo;
        }

        $answer = "👨🏫 **Faculty Details Found:**\n\n";
        $answer .= "**" . $f['NAME'] . "**\n";
        $answer .= "_{$f['DESIGNATION']} - {$f['DEPARTMENT']}_\n\n";

        if (!empty($f['QUALIFICATION']))
            $answer .= "🎓 **Qualification:** " . $f['QUALIFICATION'] . "\n";
        if (!empty($f['EMAIL']))
            $answer .= "📧 **Email:** " . $f['EMAIL'] . "\n";
        // Phone number suppressed for privacy unless requested specifically, or maybe show it if it's public data
        // $answer .= "📞 **Phone:** " . $f['PHONE_NO'] . "\n"; 

        return [
            'answer' => $answer,
            'source' => 'Faculty Database',
            'type' => 'faculty_profile',
            'confidence' => 0.95,
            'data' => $f
        ];
    }

    // Multiple Matches - List
    $answer = "🧑🏫 I found **$count faculty members** matching '$originalQuery':\n\n";

    foreach ($facultyList as $f) {
        $answer .= "• **" . $f['NAME'] . "** (" . $f['DEPARTMENT'] . ")\n";
    }

    $answer .= "\nPlease be more specific (e.g., 'details of " . $facultyList[0]['NAME'] . "') to see full profile.";

    return [
        'answer' => $answer,
        'source' => 'Faculty Database',
        'type' => 'faculty_list',
        'confidence' => 0.85
    ];
}

// ==========================================================
// NEW HELPERS (ACCREDITATION, BUS, CALENDAR, ETC.)
// ==========================================================

if (!function_exists('ai_handle_accreditation')) {
    function ai_handle_accreditation(string $text): ?string
    {
        $text = strtolower($text);

        // 1. NAAC INQUIRY
        if (strpos($text, 'naac') !== false || strpos($text, 'grade') !== false || strpos($text, 'cgpa') !== false) {
            return "🏆 **Institutional Accreditation:**\n\n" .
                "Vel Tech High Tech is **NAAC Accredited** with an **'A' Grade**.\n" .
                "📈 **CGPA:** 3.27";
        }

        // 2. NBA INQUIRY
        if (strpos($text, 'nba') !== false || strpos($text, 'accredit') !== false) {
            $nba_courses = [
                'ece' => 'B.E - Electronics and Communication Engineering',
                'biotech' => 'B.Tech - Biotechnology',
                'chem' => 'B.Tech - Chemical Engineering',
                'it' => 'B.Tech - Information Technology'
            ];

            $specific_reply = "";
            if (strpos($text, 'ece') !== false || strpos($text, 'electronics') !== false) {
                $specific_reply = "✅ **Yes, B.E - ECE is NBA Accredited.**";
            }
            elseif (strpos($text, 'biotech') !== false) {
                $specific_reply = "✅ **Yes, B.Tech - Biotechnology is NBA Accredited.**";
            }
            elseif (strpos($text, 'chem') !== false) {
                $specific_reply = "✅ **Yes, B.Tech - Chemical Engineering is NBA Accredited.**";
            }
            elseif (strpos($text, 'it') !== false || strpos($text, 'information tech') !== false) {
                $specific_reply = "✅ **Yes, B.Tech - IT is NBA Accredited.**";
            }
            elseif (strpos($text, 'cse') !== false || strpos($text, 'mech') !== false || strpos($text, 'civil') !== false || strpos($text, 'aids') !== false) {
                $specific_reply = "ℹ️ This specific program is currently **not** in the NBA list, but the institution itself is **NAAC 'A' Grade** accredited.";
            }

            $list = "\n\n📋 **List of NBA Accredited Programs:**\n";
            foreach ($nba_courses as $course) {
                $list .= "• $course\n";
            }
            return $specific_reply ? $specific_reply . $list : $list;
        }
        return null;
    }
}

if (!function_exists('ai_get_calendar_info')) {
    function ai_get_calendar_info(mysqli $db, string $question): ?string
    {
        if (!ai_table_exists($db, 'academic_calendar')) {
            return null;
        }

        // 1. Check for "List All"
        if (strpos($question, 'all') !== false || strpos($question, 'list') !== false || strpos($question, 'full') !== false) {
            $res = $db->query("SELECT event_name, DATE_FORMAT(event_date, '%d-%b-%Y') as fmt_date FROM academic_calendar WHERE event_date >= CURDATE() ORDER BY event_date ASC LIMIT 10");
            if ($res && $res->num_rows > 0) {
                $reply = "📅 **Upcoming Academic Calendar:**\n\n";
                while ($row = $res->fetch_assoc()) {
                    $reply .= "• **" . $row['fmt_date'] . ":** " . $row['event_name'] . "\n";
                }
                return $reply . "\n*(Showing next 10 events)*";
            }
        }

        // 2. Specific Event Search
        $remove = ['when', 'is', 'the', 'date', 'of', 'holiday', 'event', 'calendar', 'tell', 'me', 'about'];
        $clean = str_replace($remove, '', strtolower($question));
        $keywords = array_filter(explode(' ', $clean));

        foreach ($keywords as $word) {
            if (strlen($word) > 3) {
                $safe = $db->real_escape_string($word);
                $res = $db->query("SELECT event_name, DATE_FORMAT(event_date, '%W, %d-%M-%Y') as fmt_date, is_holiday FROM academic_calendar WHERE event_name LIKE '%$safe%' AND event_date >= CURDATE() LIMIT 1");
                if ($res && $row = $res->fetch_assoc()) {
                    $icon = ($row['is_holiday'] == 1) ? "🏖️ **Holiday Alert:**" : "📅 **Event Detail:**";
                    return $icon . "\n\n**" . $row['event_name'] . "** is on **" . $row['fmt_date'] . "**.";
                }
            }
        }

        // 3. Next Holiday/Event
        if (strpos($question, 'holiday') !== false || strpos($question, 'calendar') !== false) {
            $res = $db->query("SELECT event_name, DATE_FORMAT(event_date, '%W, %d-%M-%Y') as fmt_date, is_holiday FROM academic_calendar WHERE event_date >= CURDATE() ORDER BY event_date ASC LIMIT 1");
            if ($res && $row = $res->fetch_assoc()) {
                $type = ($row['is_holiday'] == 1) ? "🏖️ **Next Holiday:**" : "📅 **Next Event:**";
                return $type . "\n\n**" . $row['event_name'] . "** on " . $row['fmt_date'];
            }
        }
        return null;
    }
}

if (!function_exists('ai_get_bus_route')) {
    function ai_get_bus_route(mysqli $db, string $busNo): ?string
    {
        if (!ai_table_exists($db, 'transport_master')) {
            return null;
        }
        $stmt = $db->prepare("SELECT route_name, starting_point, time FROM transport_master WHERE bus_no = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param("s", $busNo);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($row = $res->fetch_assoc()) {
                return "🚌 **Bus No: $busNo**\n\n" .
                    "📍 **Route:** " . $row['route_name'] . "\n" .
                    "🏁 **Starts at:** " . $row['starting_point'] . "\n" .
                    "⏰ **Time:** " . $row['time'];
            }
        }
        return "I couldn't find details for Bus Number $busNo.";
    }
}

if (!function_exists('ai_handle_idea_lab')) {
    function ai_handle_idea_lab(mysqli $db, string $question): ?string
    {
        if (stripos($question, 'idea lab') === false && stripos($question, 'aicte lab') === false && stripos($question, 'innovation lab') === false) {
            return null;
        }

        $answer = '';
        $hasData = false;

        // 1. Idea Lab general info from ai_idea_lab_info
        if (ai_table_exists($db, 'ai_idea_lab_info')) {
            $res = $db->query('SELECT section, content FROM ai_idea_lab_info ORDER BY id ASC');
            if ($res && $res->num_rows > 0) {
                $hasData = true;
                $answer .= "AICTE IDEA Lab @ VTHT\n\n";
                while ($row = $res->fetch_assoc()) {
                    $section = trim((string)($row['section'] ?? ''));
                    $content = trim((string)($row['content'] ?? ''));
                    if ($section !== '')
                        $answer .= "** $section: ** $content\n";
                }
                $answer .= "\n";
            }
        }

        // 2. Equipment from ai_idea_lab_equipment
        if (stripos($question, 'equipment') !== false || stripos($question, 'facility') !== false || stripos($question, 'facilities') !== false) {
            if (ai_table_exists($db, 'ai_idea_lab_equipment')) {
                $res = $db->query('SELECT equipment_name, category, description FROM ai_idea_lab_equipment ORDER BY category, id ASC');
                if ($res && $res->num_rows > 0) {
                    $hasData = true;
                    $answer .= "Idea Lab Equipment:\n";
                    $currentCat = '';
                    while ($row = $res->fetch_assoc()) {
                        $cat = trim((string)($row['category'] ?? ''));
                        $name = trim((string)($row['equipment_name'] ?? ''));
                        $desc = trim((string)($row['description'] ?? ''));
                        if ($cat !== '' && $cat !== $currentCat) {
                            $answer .= "\n[$cat]\n";
                            $currentCat = $cat;
                        }
                        $answer .= "- $name";
                        if ($desc !== '')
                            $answer .= " - $desc";
                        $answer .= "\n";
                    }
                    $answer .= "\n";
                }
            }
        }

        // 3. Team from ai_idea_lab_team
        if (stripos($question, 'team') !== false || stripos($question, 'mentor') !== false || stripos($question, 'coordinator') !== false) {
            if (ai_table_exists($db, 'ai_idea_lab_team')) {
                $res = $db->query("SELECT name, role, designation, department, member_type FROM ai_idea_lab_team ORDER BY id ASC LIMIT 15");
                if ($res && $res->num_rows > 0) {
                    $hasData = true;
                    $answer .= "Idea Lab Team:\n";
                    while ($row = $res->fetch_assoc()) {
                        $name = trim((string)($row['name'] ?? ''));
                        $role = trim((string)($row['role'] ?? ''));
                        $dept = trim((string)($row['department'] ?? ''));
                        $type = trim((string)($row['member_type'] ?? ''));
                        $answer .= "- $name";
                        if ($type !== '')
                            $answer .= " ($type)";
                        if ($role !== '')
                            $answer .= " - $role";
                        if ($dept !== '')
                            $answer .= ", $dept";
                        $answer .= "\n";
                    }
                    $answer .= "\n";
                }
            }
        }

        if (!$hasData) {
            return "AICTE IDEA Lab @ VTHT\n(Idea Development, Evaluation & Application)\n\nA state-of-the-art facility funded by AICTE.\nOpen 24/7 for students.\nAsk about: idea lab equipment, idea lab team";
        }

        return $answer;
    }
}

class GeneralLanguageAI
{
    private $collegeName;
    private $userType;

    public function __construct(array $context = [])
    {
        $this->collegeName = 'Vel Tech High Tech Dr.Rangarajan Dr.Sakunthala Engineering College';
        $this->userType = $context['user_type'] ?? 'public';
    }

    public function handle(string $userInput): array
    {
        $clean = strtolower(trim($userInput));
        if (strlen($clean) < 2) {
            return $this->reply("Could you please type a little more so I can understand you better?", 'System', 100);
        }
        if ($this->isGreeting($clean)) {
            return $this->reply($this->greetingMessage(), 'General Conversation', 100);
        }
        if ($this->isEmotionalTalk($clean)) {
            return $this->reply($this->emotionalResponse($clean), 'Conversational AI', 90);
        }
        if ($this->isCasualQuestion($clean)) {
            return $this->reply($this->casualResponse($clean), 'General Knowledge', 80);
        }
        // Fallback confidence 0 to let external AI or DB handle it if specific content
        return $this->reply("", "General AI", 0);
    }

    private function reply(string $text, string $source, int $conf): array
    {
        return ['reply' => $text, 'source' => $source, 'confidence' => $conf];
    }

    private function isGreeting(string $text): bool
    {
        return (bool)preg_match('/^(hi|hello|hey|good morning|good afternoon|good evening|namaste)/i', $text);
    }

    private function greetingMessage(): string
    {
        $hour = (int)date('H');
        $timeGreeting = ($hour < 12) ? 'Good morning' : (($hour < 17) ? 'Good afternoon' : 'Good evening');
        return "$timeGreeting! 👋 I'm your AI assistant for <b>{$this->collegeName}</b>.";
    }

    private function isEmotionalTalk(string $text): bool
    {
        return (bool)preg_match('/(sad|happy|stress|tired|bored|angry|excited|worried|feeling)/i', $text);
    }

    private function emotionalResponse(string $text): string
    {
        $responses = [
            "I understand how you feel 🙂. If you'd like, you can tell me more.",
            "That sounds important. I'm here to listen.",
            "It's okay to feel that way. You're not alone.",
        ];
        return $responses[array_rand($responses)];
    }

    private function isCasualQuestion(string $text): bool
    {
        return (bool)preg_match('/(what do you think|your opinion|tell me something|can you talk|who are you)/i', $text);
    }

    private function casualResponse(string $text): string
    {
        if (strpos($text, 'who are you') !== false)
            return "I'm an institutional AI assistant designed to help students, faculty, and visitors.";
        if (strpos($text, 'your opinion') !== false)
            return "I don't have personal opinions, but I can share facts and helpful insights.";
        return "Sure! You can ask me anything related to college life, academics, or general conversation.";
    }
}

// ==========================================================
// FACULTY SEARCH HELPER (Smart Column Detection)
// ==========================================================
if (!function_exists('ai_search_faculty')) {
    function ai_search_faculty(mysqli $db, string $query): ?array
    {
        if (!ai_table_exists($db, 'employee_details1')) {
            return null;
        }

        // Dynamically find relevant columns
        $cols = [];
        $res = $db->query("SHOW COLUMNS FROM employee_details1");
        if ($res) {
            while ($row = $res->fetch_assoc()) {
                $cols[] = $row['Field'];
            }
        }

        // Map standard keys to actual columns
        $map = [
            'name' => null,
            'designation' => null,
            'department' => null,
            'email' => null,
            'mobile' => null,
            'image' => null
        ];

        foreach ($cols as $c) {
            $lo = strtolower($c);
            if (strpos($lo, 'name') !== false && !$map['name'])
                $map['name'] = $c;
            if ((strpos($lo, 'desig') !== false || strpos($lo, 'role') !== false) && !$map['designation'])
                $map['designation'] = $c;
            if ((strpos($lo, 'dept') !== false || strpos($lo, 'department') !== false) && !$map['department'])
                $map['department'] = $c;
            if (strpos($lo, 'email') !== false && !$map['email'])
                $map['email'] = $c;
            if (strpos($lo, 'mobile') !== false && !$map['mobile'])
                $map['mobile'] = $c;
            if ((strpos($lo, 'image') !== false || strpos($lo, 'photo') !== false) && !$map['image'])
                $map['image'] = $c;
        }

        if (!$map['name'])
            return null; // Cannot search without name col

        // Extract search term (remove "search", "faculty", "details", "of")
        $term = preg_replace('/\b(search|info|details|about|faculty|teacher|professor|sir|mam|madam|dr|mr|mrs|prof)\b/i', '', $query);
        $term = trim($term);
        if (strlen($term) < 2)
            return null;

        $like = "%$term%";
        $sql = "SELECT * FROM employee_details1 WHERE {$map['name']} LIKE ? LIMIT 3";
        $stmt = $db->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("s", $like);
            $stmt->execute();
            $result = $stmt->get_result();

            $matches = [];
            $nameKey = $map['name'] ?? '';
            $desigKey = $map['designation'];
            $deptKey = $map['department'];
            $emailKey = $map['email'];
            $mobileKey = $map['mobile'];

            while ($row = $result->fetch_assoc()) {
                $name = $nameKey ? ($row[$nameKey] ?? 'Unknown') : 'Unknown';
                $info = [
                    'NAME' => $name,
                    'DESIGNATION' => $desigKey ? ($row[$desigKey] ?? '') : '',
                    'DEPARTMENT' => $deptKey ? ($row[$deptKey] ?? '') : '',
                    'EMAIL' => $emailKey ? ($row[$emailKey] ?? '') : '',
                    'MOBILE' => $mobileKey ? ($row[$mobileKey] ?? '') : ''
                ];
                $matches[] = $info;
            }

            return empty($matches) ? null : $matches;
        }

        // === ADVANCED FUZZY MATCHING EXTENSION ===
        $termLower = strtolower($term);

        $resAll = $db->query("SELECT * FROM employee_details1 LIMIT 100");

        $fuzzyMatches = [];

        if ($resAll) {
            $nameKey = $map['name'];
            $desigKey = $map['designation'];
            $deptKey = $map['department'];
            $emailKey = $map['email'];
            $mobileKey = $map['mobile'];

            while ($row = $resAll->fetch_assoc()) {

                $dbName = strtolower($row[$nameKey] ?? '');
                $role = strtolower($row['role'] ?? '');

                similar_text($termLower, $dbName, $percent);

                // Role Weighting
                $roleWeight = 1.0;
                if (strpos($role, 'principal') !== false)
                    $roleWeight = 5.0;
                elseif (strpos($role, 'hod') !== false)
                    $roleWeight = 4.0;
                elseif (strpos($role, 'dean') !== false)
                    $roleWeight = 3.0;
                elseif (strpos($role, 'professor') !== false)
                    $roleWeight = 2.0;

                // Combined Score
                $score = $percent * $roleWeight;

                // Threshold: If high role, lower % needed (e.g. "Princpal" -> Principal)
                // If standard role, need 60% match
                if ($percent >= 60 || ($roleWeight >= 4.0 && $percent >= 40)) {

                    $name = $nameKey ? ($row[$nameKey] ?? 'Unknown') : 'Unknown';
                    $fuzzyMatches[] = [
                        'score' => $score,
                        'NAME' => $name,
                        'DESIGNATION' => $desigKey ? ($row[$desigKey] ?? '') : '',
                        'DEPARTMENT' => $deptKey ? ($row[$deptKey] ?? '') : '',
                        'EMAIL' => $emailKey ? ($row[$emailKey] ?? '') : '',
                        'MOBILE' => $mobileKey ? ($row[$mobileKey] ?? '') : ''
                    ];
                }
            }
        }

        if (!empty($fuzzyMatches)) {
            // Sort by score descending
            usort($fuzzyMatches, function ($a, $b) {
                return $b['score'] <=> $a['score'];
            });
            return $fuzzyMatches;
        }

        return null;
    }
    function ai_get_principal_info(mysqli $db): ?array
    {
        if (!ai_table_exists($db, 'employee_details1')) {
            return null;
        }
        $cols = [];
        $res = $db->query("SHOW COLUMNS FROM employee_details1");
        if ($res) {
            while ($row = $res->fetch_assoc()) {
                $cols[] = $row['Field'];
            }
        }
        $nameCol = '';
        $desigCol = '';
        foreach ($cols as $c) {
            $lo = strtolower($c);
            if (strpos($lo, 'name') !== false && !$nameCol)
                $nameCol = $c;
            if ((strpos($lo, 'desig') !== false || strpos($lo, 'role') !== false) && !$desigCol)
                $desigCol = $c;
        }
        if (!$nameCol || !$desigCol)
            return null;

        $sql = "SELECT * FROM employee_details1 WHERE $desigCol LIKE '%Principal%' LIMIT 1";
        $stmt = $db->query($sql);
        if ($stmt && $row = $stmt->fetch_assoc()) {
            return [
                'name' => $row[$nameCol] ?? 'Principal',
                'designation' => $row[$desigCol] ?? 'Principal'
            ];
        }
        return null;
    }

    function ai_search_employee_by_role(mysqli $db, string $role, string $dept = ''): ?array
    {
        if (!ai_table_exists($db, 'employee_details1')) {
            return null;
        }

        $cols = [];
        $res = $db->query("SHOW COLUMNS FROM employee_details1");
        if ($res) {
            while ($row = $res->fetch_assoc()) {
                $cols[] = $row['Field'];
            }
        }

        $map = ['name' => null, 'designation' => null, 'department' => null, 'email' => null];
        foreach ($cols as $c) {
            $lo = strtolower($c);
            if (strpos($lo, 'name') !== false && !$map['name'])
                $map['name'] = $c;
            if ((strpos($lo, 'desig') !== false || strpos($lo, 'role') !== false) && !$map['designation'])
                $map['designation'] = $c;
            if ((strpos($lo, 'dept') !== false || strpos($lo, 'department') !== false) && !$map['department'])
                $map['department'] = $c;
            if (strpos($lo, 'email') !== false && !$map['email'])
                $map['email'] = $c;
        }

        if (!$map['name'] || !$map['designation'])
            return null;

        $roleLike = "%$role%";
        $deptLike = "%$dept%";

        $sql = "SELECT * FROM employee_details1 WHERE {$map['designation']} LIKE ?";
        if ($dept && $map['department']) {
            $sql .= " AND ( {$map['department']} LIKE ? )";
        }
        $sql .= " LIMIT 10";

        $stmt = $db->prepare($sql);
        if ($stmt) {
            if ($dept && $map['department']) {
                $stmt->bind_param("ss", $roleLike, $deptLike);
            }
            else {
                $stmt->bind_param("s", $roleLike);
            }
            $stmt->execute();
            $result = $stmt->get_result();
            $matches = [];
            $nameKey = $map['name'];
            $desigKey = $map['designation'];
            $emailKey = $map['email'];
            $deptKey = $map['department'];

            while ($row = $result->fetch_assoc()) {
                $matches[] = [
                    'name' => ($nameKey && isset($row[$nameKey])) ? $row[$nameKey] : 'Unknown',
                    'designation' => ($desigKey && isset($row[$desigKey])) ? $row[$desigKey] : $role,
                    'department' => $deptKey ? ($row[$deptKey] ?? '') : '',
                    'email' => $emailKey ? ($row[$emailKey] ?? '') : ''
                ];
            }
            return !empty($matches) ? $matches : null;
        }
        return null;
    }

    function ai_search_student_policy(): string
    {
        return "I am sorry, but for security and privacy reasons, I cannot disclose any student information. I can only assist with faculty or general institutional details.";
    }
}

// ==========================================================
// PRIVACY & SAFETY HELPERS
// ==========================================================
if (!function_exists('ai_check_privacy_violation')) {
    function ai_check_privacy_violation(string $query, string $userType, string $userId): ?string
    {
        // Policy: No student PII for anyone except authorized staff (and self)
        // Public/Student users cannot ask for "student phone", "student address", etc.

        $q = strtolower($query);

        // Block patterns
        $piiPatterns = [
            '/\b(student|friend|boy|girl|classmate)\b.*\b(phone|mobile|number|email|address|contact)\b/i',
            '/\b(give|send|want|need)\b.*\b(number|phone|email)\b.*\bof\b/i',
            '/\bwhere\b.*\b(live|stay)\b/i'
        ];

        // Let's enforce strict privacy for now as requested.
        foreach ($piiPatterns as $p) {
            if (preg_match($p, $q)) {
                return "🔒 **Privacy Alert**: Sharing student personal information is restricted under VEL AI Privacy Policy.";
            }
        }

        return null;
    }
}

if (!function_exists('ai_fetch_latest_circulars')) {
    function ai_fetch_latest_circulars(mysqli $db): array
    {
        if (!ai_table_exists($db, 'circulars'))
            return [];
        $res = $db->query("SELECT * FROM circulars ORDER BY circular_date DESC, id DESC LIMIT 5");
        $data = [];
        if ($res) {
            while ($row = $res->fetch_assoc())
                $data[] = $row;
        }
        return $data;
    }
}
