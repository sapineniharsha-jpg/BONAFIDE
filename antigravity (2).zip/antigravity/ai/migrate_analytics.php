<?php
// ai/migrate_analytics.php
require_once '../includes/config.php';
require_once '../includes/db.php';

echo "<h2>Migrating Analytics Schema (Phase 4.1)</h2>";

// 1. Add response_time_ms to ai_chat_history
try {
    $res = $mysqli->query("SHOW COLUMNS FROM ai_chat_history LIKE 'response_time_ms'");
    if ($res && $res->num_rows === 0) {
        $mysqli->query("ALTER TABLE ai_chat_history ADD COLUMN response_time_ms INT DEFAULT 0 AFTER reply");
        echo "✅ Added column: response_time_ms<br>";
    }
    else {
        echo "ℹ️ Column response_time_ms already exists<br>";
    }
}
catch (Exception $e) {
    echo "❌ Error adding response_time_ms: " . $e->getMessage() . "<br>";
}

// 2. Add status to ai_chat_history
try {
    $res = $mysqli->query("SHOW COLUMNS FROM ai_chat_history LIKE 'status'");
    if ($res && $res->num_rows === 0) {
        $mysqli->query("ALTER TABLE ai_chat_history ADD COLUMN status ENUM('success', 'fallback') DEFAULT 'success' AFTER response_time_ms");
        echo "✅ Added column: status<br>";
    }
    else {
        echo "ℹ️ Column status already exists<br>";
    }
}
catch (Exception $e) {
    echo "❌ Error adding status: " . $e->getMessage() . "<br>";
}

echo "<h3>Migration Complete.</h3>";
?>
