<?php
// ai/whatsapp_webhook.php
// Webhook for Twilio WhatsApp Integration

require_once '../includes/config.php';
require_once '../includes/db.php';
require_once 'ai_helpers.php';
require_once 'ai_engine.php'; // Reuse core logic if possible, or extract

// Log incoming request for debugging
file_put_contents('whatsapp_log.txt', print_r($_POST, true), FILE_APPEND);

$userMsg = $_POST['Body'] ?? '';
$sender = $_POST['From'] ?? ''; // e.g., whatsapp:+919876543210

if (trim($userMsg) === '') {
    exit;
}

// Simple Logic (Reuse existing functions where possible)
// In a real scenario, this would call the same pipeline as ai_engine.php
// For now, we use a simplified version for shared hosting safety

$response = "I'm sorry, I couldn't understand that.";

// 1. Check exact match
$local = ai_db_exact_or_keyword($db, $userMsg, 'public');
if ($local) {
    $response = $local['answer'];
}
else {
    // 2. Fallback / AI
    // Here we can call the Faculty Search or other helpers
    if (stripos($userMsg, 'faculty') !== false && function_exists('ai_search_faculty')) {
        $facRes = ai_search_faculty($db, $userMsg);
        if ($facRes) {
            if (count($facRes) === 1) {
                $f = $facRes[0];
                $response = "👨🏫 *Faculty Found:*\n\n*{$f['NAME']}*\n{$f['DESIGNATION']}\n{$f['DEPARTMENT']}";
            }
            else {
                $response = "Found " . count($facRes) . " matches. Please be more specific.";
            }
        }
    }
    else {
        $response = "🤖 Hi! I am VEL AI. I can help with Faculty info, Bus routes, and more. Try asking 'Show CSE Faculty' or 'Bus route 12'.";
    }
}

// Return TwiML
header('Content-Type: text/xml');
?>
<Response>
    <Message>
        <Body><?php echo htmlspecialchars($response); ?></Body>
    </Message>
</Response>
