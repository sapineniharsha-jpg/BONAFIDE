-- Add missing columns to ai_chat_history (Corrected schema)
-- The table uses 'reply' instead of 'answer'
ALTER TABLE ai_chat_history ADD COLUMN response_time_ms INT DEFAULT 0 AFTER reply;
ALTER TABLE ai_chat_history ADD COLUMN status ENUM('success', 'fallback') DEFAULT 'success' AFTER response_time_ms;
