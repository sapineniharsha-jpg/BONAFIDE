<?php
ini_set('display_errors', 0); 
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', '../logs/dept_errors.log');
// verify_bonafide.php - Public verification (Instagram Gradient Theme)
ob_start();
session_start();
require_once 'includes/db.php';

$ref = isset($_GET['ref']) ? $_GET['ref'] : '';
$certificate = null;
$verification_status = 'not_found';

if (!empty($ref)) {
    $cert_result = $mysqli->query("SELECT * FROM bonafide_certificates WHERE ref_number = '$ref'");
    if ($cert_result && $cert_result->num_rows > 0) {
        $certificate = $cert_result->fetch_assoc();
        $verification_status = $certificate['status'] == 'approved' ? 'verified' : 'pending';
    }
}

include 'includes/header.php';
?>

<style>
    :root { 
        --insta-grad: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
        --verified: #10b981;
        --pending: #f59e0b;
        --invalid: #ef4444;
    }
    
    .verification-container {
        max-width: 800px;
        margin: 40px auto;
        padding: 30px;
        background: white;
        border-radius: 20px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    }
    
    .verification-header {
        text-align: center;
        margin-bottom: 30px;
    }
    
    .verification-icon {
        font-size: 4rem;
        margin-bottom: 20px;
    }
    
    .verified { color: var(--verified); }
    .pending { color: var(--pending); }
    .invalid { color: var(--invalid); }
    
    .verification-badge {
        display: inline-block;
        padding: 10px 25px;
        border-radius: 50px;
        font-weight: bold;
        font-size: 1.2rem;
        margin-bottom: 20px;
    }
    
    .badge-verified { 
        background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%); 
        color: #065f46;
        border: 2px solid #10b981;
    }
    
    .badge-pending { 
        background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); 
        color: #92400e;
        border: 2px solid #f59e0b;
    }
    
    .badge-invalid { 
        background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%); 
        color: #991b1b;
        border: 2px solid #ef4444;
    }
    
    .certificate-details {
        background: #f8fafc;
        border-radius: 15px;
        padding: 25px;
        margin: 30px 0;
    }
    
    .detail-row {
        display: grid;
        grid-template-columns: 200px 1fr;
        margin-bottom: 12px;
        padding-bottom: 12px;
        border-bottom: 1px solid #e2e8f0;
    }
    
    .detail-label {
        font-weight: 600;
        color: #64748b;
    }
    
    .detail-value {
        font-weight: 700;
        color: #1e293b;
    }
    
    .action-buttons {
        display: flex;
        gap: 15px;
        justify-content: center;
        margin-top: 30px;
    }
    
    .btn-action {
        padding: 12px 25px;
        border-radius: 50px;
        font-weight: 600;
        border: none;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        transition: 0.3s;
    }
    
    .btn-print { background: var(--insta-grad); color: white; }
    .btn-verify-another { background: #3b82f6; color: white; }
    .btn-download { background: #10b981; color: white; }
    
    .btn-action:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(0,0,0,0.2); color: white; }
    
    .verification-form {
        max-width: 500px;
        margin: 0 auto;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-control {
        width: 100%;
        padding: 12px 15px;
        border: 2px solid #e2e8f0;
        border-radius: 12px;
        font-size: 16px;
    }
    
    .form-control:focus {
        border-color: var(--primary);
        outline: none;
    }
    
    .btn-submit {
        background: var(--insta-grad);
        color: white;
        border: none;
        padding: 15px 30px;
        border-radius: 50px;
        font-weight: 700;
        font-size: 16px;
        width: 100%;
        cursor: pointer;
    }
    
    .security-stamp {
        position: absolute;
        top: 20px;
        right: 20px;
        transform: rotate(15deg);
        opacity: 0.8;
    }
    
    @media (max-width: 768px) {
        .detail-row { grid-template-columns: 1fr; }
        .action-buttons { flex-direction: column; }
        .btn-action { justify-content: center; }
    }
</style>

<div class="verification-container">
    <?php if($verification_status == 'verified' && $certificate): ?>
    
    <div class="verification-header">
        <div class="verification-icon verified">
            <i class="fas fa-shield-check"></i>
        </div>
        <h1>Certificate Verified</h1>
        <div class="verification-badge badge-verified">
            <i class="fas fa-check-circle"></i> VALID & VERIFIED
        </div>
        <p class="text-muted">This certificate has been verified and issued by Vel Tech High Tech</p>
    </div>
    
    <div class="security-stamp">
        <div style="border: 3px solid #10b981; padding: 10px 20px; border-radius: 5px; transform: rotate(15deg); background: white;">
            <div style="font-weight: bold; color: #10b981;">VERIFIED</div>
            <div style="font-size: 10px;"><?php echo date('Y-m-d H:i:s'); ?></div>
        </div>
    </div>
    
    <div class="certificate-details">
        <h4><i class="fas fa-certificate"></i> Certificate Details</h4>
        
        <div class="detail-row">
            <div class="detail-label">Reference Number:</div>
            <div class="detail-value"><?php echo $certificate['ref_number']; ?></div>
        </div>
        
        <div class="detail-row">
            <div class="detail-label">Student Name:</div>
            <div class="detail-value"><?php echo $certificate['student_prefix'] . ' ' . $certificate['student_name']; ?></div>
        </div>
        
        <div class="detail-row">
            <div class="detail-label">Register Number:</div>
            <div class="detail-value"><?php echo $certificate['register_number']; ?></div>
        </div>
        
        <div class="detail-row">
            <div class="detail-label">Department:</div>
            <div class="detail-value"><?php echo $certificate['department']; ?></div>
        </div>
        
        <div class="detail-row">
            <div class="detail-label">Certificate Type:</div>
            <div class="detail-value"><?php echo $certificate['certificate_type']; ?></div>
        </div>
        
        <div class="detail-row">
            <div class="detail-label">Issue Date:</div>
            <div class="detail-value"><?php echo date('d M Y', strtotime($certificate['bonafide_date'])); ?></div>
        </div>
        
        <div class="detail-row">
            <div class="detail-label">Status:</div>
            <div class="detail-value">
                <span style="color: #10b981; font-weight: bold;">
                    <i class="fas fa-check-circle"></i> APPROVED & VERIFIED
                </span>
            </div>
        </div>
        
        <div class="detail-row">
            <div class="detail-label">Verification Timestamp:</div>
            <div class="detail-value"><?php echo date('d M Y H:i:s'); ?></div>
        </div>
    </div>
    
    <div class="certificate-details">
        <h4><i class="fas fa-info-circle"></i> Issuing Authority</h4>
        
        <div class="detail-row">
            <div class="detail-label">Issued By:</div>
            <div class="detail-value">Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College</div>
        </div>
        
        <div class="detail-row">
            <div class="detail-label">Authorized Signatory:</div>
            <div class="detail-value">PRINCIPAL</div>
        </div>
        
        <div class="detail-row">
            <div class="detail-label">Contact:</div>
            <div class="detail-value">044-26840181 | principal@velhightech.com</div>
        </div>
    </div>
    
    <div class="action-buttons">
        <a href="print_bonafide.php?ref=<?php echo urlencode($certificate['ref_number']); ?>" class="btn-action btn-print" target="_blank">
            <i class="fas fa-print"></i> Print Certificate
        </a>
        
        <a href="certificate_view.php?ref=<?php echo urlencode($certificate['ref_number']); ?>" class="btn-action btn-download" target="_blank">
            <i class="fas fa-eye"></i> View Full Certificate
        </a>
        
        <a href="verify.php" class="btn-action btn-verify-another">
            <i class="fas fa-search"></i> Verify Another
        </a>
    </div>
    
    <?php elseif($verification_status == 'pending' && $certificate): ?>
    
    <div class="verification-header">
        <div class="verification-icon pending">
            <i class="fas fa-clock"></i>
        </div>
        <h1>Certificate Pending</h1>
        <div class="verification-badge badge-pending">
            <i class="fas fa-clock"></i> PENDING APPROVAL
        </div>
        <p class="text-muted">This certificate is pending approval from the issuing authority</p>
    </div>
    
    <div class="certificate-details">
        <div class="detail-row">
            <div class="detail-label">Reference Number:</div>
            <div class="detail-value"><?php echo $certificate['ref_number']; ?></div>
        </div>
        
        <div class="detail-row">
            <div class="detail-label">Status:</div>
            <div class="detail-value">
                <span style="color: #f59e0b; font-weight: bold;">
                    <i class="fas fa-clock"></i> PENDING APPROVAL
                </span>
            </div>
        </div>
        
        <div class="detail-row">
            <div class="detail-label">Last Updated:</div>
            <div class="detail-value"><?php echo date('d M Y', strtotime($certificate['bonafide_date'])); ?></div>
        </div>
    </div>
    
    <div class="action-buttons">
        <a href="verify.php" class="btn-action btn-verify-another">
            <i class="fas fa-search"></i> Verify Another Certificate
        </a>
    </div>
    
    <?php elseif($verification_status == 'not_found'): ?>
    
    <div class="verification-header">
        <div class="verification-icon invalid">
            <i class="fas fa-exclamation-triangle"></i>
        </div>
        <h1>Certificate Not Found</h1>
        <div class="verification-badge badge-invalid">
            <i class="fas fa-times-circle"></i> INVALID REFERENCE
        </div>
        <p class="text-muted">The certificate reference could not be found in our system</p>
    </div>
    
    <div class="alert alert-warning">
        <p><strong>Possible reasons:</strong></p>
        <ul>
            <li>The reference number is incorrect</li>
            <li>The certificate has been revoked or deleted</li>
            <li>You may have entered an invalid reference</li>
        </ul>
    </div>
    
    <?php else: ?>
    
    <div class="verification-header">
        <div class="verification-icon">
            <i class="fas fa-search"></i>
        </div>
        <h1>Verify Certificate</h1>
        <p>Enter the certificate reference number to verify its authenticity</p>
    </div>
    
    <div class="verification-form">
        <form method="GET" action="verify.php">
            <div class="form-group">
                <label for="ref" class="form-label">Certificate Reference Number</label>
                <input type="text" id="ref" name="ref" class="form-control" 
                       placeholder="Enter reference number (e.g. VTHT/e-Bona/2025-2026/0001)" 
                       required>
            </div>
            
            <button type="submit" class="btn-submit">
                <i class="fas fa-shield-alt"></i> Verify Certificate
            </button>
        </form>
    </div>
    
    <div class="mt-4 text-center text-muted">
        <p><i class="fas fa-info-circle"></i> Certificate verification is powered by Vel Tech High Tech secure system</p>
    </div>
    
    <?php endif; ?>
</div>

<script>
    // Auto-focus on input field
    document.addEventListener('DOMContentLoaded', function() {
        const refInput = document.getElementById('ref');
        if (refInput) {
            refInput.focus();
        }
    });
    
    // Copy reference number to clipboard
    function copyReference() {
        const ref = "<?php echo $certificate['ref_number'] ?? ''; ?>";
        navigator.clipboard.writeText(ref).then(() => {
            alert('Reference number copied to clipboard!');
        });
    }
    
    // Share verification link
    function shareVerification() {
        if (navigator.share) {
            navigator.share({
                title: 'Certificate Verification - Vel Tech High Tech',
                text: 'Verify my certificate from Vel Tech High Tech',
                url: window.location.href
            });
        } else {
            alert('Share this verification link: ' + window.location.href);
        }
    }
</script>

<?php
include 'includes/footer.php';
ob_end_flush();
?>