<?php
// dashboard/search.php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth_guard.php';

// Ensure Admin Access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

// ---------------------------------------------------------
// AJAX HANDLER
// ---------------------------------------------------------
if (isset($_GET['ajax']) && $_GET['ajax'] == '1') {
    header('Content-Type: application/json');
    
    $action = $_GET['action'] ?? 'search';
    
    // -----------------------------------------------------
    // ACTION 1: SEARCH MAIN RECORDS
    // -----------------------------------------------------
    if ($action == 'search') {
        $type = $_GET['type'] ?? 'all';
        $dept = $_GET['dept'] ?? 'all';
        $term = trim($_GET['q'] ?? '');
        $results = [];

        // 1. SEARCH FACULTY (Standard)
        if ($type == 'all' || $type == 'faculty') {
            $sql = "SELECT ID_NO as id, NAME as name, DEPARTMENT as dept, DESIGNATION as role, 'faculty' as type, college_email as email 
                    FROM employee_details WHERE 1=1";
            if ($dept != 'all') $sql .= " AND DEPARTMENT LIKE '%$dept%'";
            if ($term) $sql .= " AND (NAME LIKE '%$term%' OR ID_NO LIKE '%$term%')";
            $sql .= " LIMIT 20";
            
            $res = $mysqli->query($sql);
            if($res) $results = array_merge($results, $res->fetch_all(MYSQLI_ASSOC));
        }

        // 2. SEARCH STUDENTS (With Batch Logic)
        if ($type == 'all' || $type == 'student') {
            // Note: Assuming 'Batch' column exists (e.g., 2025-2029)
            $sql = "SELECT IDNo as id, NAME as name, Dept as dept, Batch as batch, 'Student' as role, 'student' as type 
                    FROM students_login_master WHERE 1=1";
            
            if ($dept != 'all') $sql .= " AND Dept LIKE '%$dept%'";
            if ($term) {
                // Allow search by "2025" for batch or Name/ID
                $sql .= " AND (NAME LIKE '%$term%' OR IDNo LIKE '%$term%' OR Batch LIKE '%$term%')";
            }
            $sql .= " LIMIT 20";

            $res = $mysqli->query($sql);
            if($res) $results = array_merge($results, $res->fetch_all(MYSQLI_ASSOC));
        }

        // 3. SEARCH MENTORS (Advanced Grouping)
        if ($type == 'mentor') {
            // Fetch Faculty who are assigned as Counsellors
            // Also subquery to get HOD Name for their department
            $sql = "SELECT e.ID_NO as id, e.NAME as name, e.DEPARTMENT as dept, 'Mentor' as role, 'mentor' as type,
                    (SELECT COUNT(*) FROM students_login_master s WHERE s.counsellor_id = e.ID_NO) as student_count,
                    (SELECT NAME FROM employee_details h WHERE h.DEPARTMENT = e.DEPARTMENT AND h.DESIGNATION LIKE '%HOD%' LIMIT 1) as hod_name
                    FROM employee_details e WHERE 1=1";
            
            if ($dept != 'all') $sql .= " AND e.DEPARTMENT LIKE '%$dept%'";
            if ($term) $sql .= " AND (e.NAME LIKE '%$term%' OR e.ID_NO LIKE '%$term%')";
            
            // Only show faculty who actually have mentees
            $sql .= " HAVING student_count > 0 LIMIT 20";

            $res = $mysqli->query($sql);
            if($res) $results = array_merge($results, $res->fetch_all(MYSQLI_ASSOC));
        }

        echo json_encode(['success' => true, 'data' => $results]);
        exit;
    }

    // -----------------------------------------------------
    // ACTION 2: GET MENTEE LIST (Detailed View)
    // -----------------------------------------------------
    if ($action == 'get_mentees') {
        $mentor_id = $mysqli->real_escape_string($_GET['mentor_id']);
        
        // Fetch Students linked to this mentor
        // LEFT JOIN to fetch Class Advisor Name using class_advisor_id in student table
        $sql = "SELECT s.IDNo, s.NAME, s.Batch, s.VH_No, s.Dept,
                c.NAME as class_advisor_name
                FROM students_login_master s
                LEFT JOIN employee_details c ON s.class_advisor_id = c.ID_NO
                WHERE s.counsellor_id = '$mentor_id'";
        
        $res = $mysqli->query($sql);
        $students = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
        
        echo json_encode(['success' => true, 'students' => $students]);
        exit;
    }
}

// ---------------------------------------------------------
// INITIAL DATA
// ---------------------------------------------------------
$depts = $mysqli->query("SELECT DISTINCT Dept FROM students_login_master ORDER BY Dept")->fetch_all(MYSQLI_ASSOC);
$initial_term = $_GET['q'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Global Search - Admin</title>
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/search.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#bc1888">
    <script src="/assets/js/pwa-init.js" defer></script>
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="VTHT Portal">
    <link rel="apple-touch-icon" href="assets/images/icon-192.png">
       <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
</head>
<body>

<div class="top-header">
    <div class="brand-logo"><i class="fas fa-search brand-icon"></i> GLOBAL SEARCH</div>
    <div class="header-nav">
        <a href="admin.php" class="nav-link"> <i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>
</div>

<div class="search-page-container">
    
    <div class="search-controls-panel">
        <form id="advancedSearchForm">
            <div class="search-grid">
                
                <div class="search-group item-grow">
                    <label>Search Term</label>
                    <div class="icon-input">
                        <i class="fas fa-search"></i>
                        <input type="text" id="searchInput" value="<?= htmlspecialchars($initial_term) ?>" placeholder="Name, ID, Batch (e.g. 2025-2029)...">
                    </div>
                </div>

                <div class="search-group">
                    <label>Category</label>
                    <select id="typeFilter">
                        <option value="all">All Records</option>
                        <option value="faculty">Faculty Only</option>
                        <option value="student">Students Only</option>
                        <option value="mentor">Mentor Groups</option>
                    </select>
                </div>

                <div class="search-group">
                    <label>Department</label>
                    <select id="deptFilter">
                        <option value="all">All Departments</option>
                        <?php foreach($depts as $d): ?>
                            <option value="<?= $d['Dept'] ?>"><?= $d['Dept'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="search-group" style="display:flex; align-items:flex-end;">
                    <button type="submit" class="btn-search-action">Find Records</button>
                </div>

            </div>
        </form>
    </div>

    <div class="results-meta" id="resultsCount">Waiting for input...</div>
    <div class="results-grid" id="resultsGrid">
        </div>

</div>

<div id="menteeModal" class="modal-overlay">
    <div class="modal-box" style="max-width: 800px;">
        <div class="modal-header">
            <span id="modalMentorName">Mentor Details</span>
            <span class="close-btn" onclick="closeModal()">&times;</span>
        </div>
        <div class="modal-body">
            <div class="modal-meta-info" id="modalMetaInfo">
                </div>
            <div class="table-responsive">
                <table class="vel-table">
                    <thead>
                        <tr>
                            <th>Reg No</th>
                            <th>Student Name</th>
                            <th>Batch</th>
                            <th>VH No</th>
                            <th>Class Advisor</th>
                        </tr>
                    </thead>
                    <tbody id="menteeTableBody">
                        </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="../assets/js/search.js"></script>
</body>
</html>