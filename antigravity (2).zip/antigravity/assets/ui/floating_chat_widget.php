<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$root = $_SERVER['DOCUMENT_ROOT'];
require_once $root . '/includes/db.php';
require_once $root . '/includes/chat_class.php';

$uid = $_SESSION['user_id'] ?? '';
?>

<style>
    :root { 
        --inst-grad: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
        --bg-color: #ffffff;
        --sent-bg: linear-gradient(135deg, #833ab4, #fd1d1d);
        --recv-bg: #f3f4f6;
        --border-c: #f3f4f6;
    }

    /* LAUNCHER */
    .sw-launcher {
        position: fixed; bottom: 30px; right: 30px; width: 60px; height: 60px;
        border-radius: 50%; background: var(--inst-grad); color: white;
        display: flex; align-items: center; justify-content: center; font-size: 1.8rem;
        cursor: pointer; z-index: 99999; box-shadow: 0 10px 30px rgba(188,24,136,0.35);
        transition: transform 0.3s;
    }
    .sw-launcher:hover { transform: scale(1.1); }

    /* MAIN WINDOW */
    .sw-window {
        position: fixed; bottom: 100px; right: 30px; width: 380px; height: 700px; max-height: 80vh;
        background: var(--bg-color); border-radius: 20px; 
        box-shadow: 0 25px 60px -12px rgba(0, 0, 0, 0.25);
        display: flex; flex-direction: column; overflow: hidden;
        opacity: 0; transform: translateY(20px) scale(0.95); pointer-events: none;
        transition: 0.3s; z-index: 99998; border: 1px solid rgba(0,0,0,0.05); 
        font-family: -apple-system, sans-serif;
    }
    .sw-window.active { opacity: 1; transform: translateY(0) scale(1); pointer-events: all; }

    /* COMPONENTS */
    .sw-header { padding: 18px 20px; border-bottom: 1px solid var(--border-c); display: flex; justify-content: space-between; align-items: center; }
    .sw-logo { font-weight: 800; font-size: 1.1rem; background: var(--inst-grad); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    
    .sw-tabs { display: flex; padding: 5px; gap: 5px; border-bottom: 1px solid var(--border-c); background: #fff; }
    .sw-tab { flex: 1; text-align: center; padding: 10px; font-size: 0.8rem; font-weight: 600; color: #9ca3af; cursor: pointer; border-radius: 10px; transition: 0.2s; }
    .sw-tab.active { background: #fdf2f8; color: #bc1888; }

    .sw-body { flex: 1; position: relative; overflow: hidden; background: #fff; }
    .sw-view { display: none; height: 100%; flex-direction: column; overflow-y: auto; }
    .sw-view.active { display: flex; }

    /* LIST */
    .sw-item { padding: 12px 15px; display: flex; align-items: center; gap: 15px; cursor: pointer; border-bottom: 1px solid #f9fafb; transition: 0.2s; }
    .sw-item:hover { background: #fff1f2; }
    .sw-av { width: 42px; height: 42px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; color: white; font-size: 1rem; flex-shrink: 0; }

    /* MESSAGES */
    .sw-convo { position: absolute; inset: 0; background: #fff; z-index: 20; display: none; flex-direction: column; }
    .sw-chat-head { padding: 15px; border-bottom: 1px solid var(--border-c); display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.9); }
    .sw-msgs { flex: 1; padding: 15px; overflow-y: auto; display: flex; flex-direction: column; gap: 8px; scroll-behavior: smooth; }
    
    .msg { max-width: 80%; padding: 10px 14px; border-radius: 18px; font-size: 0.9rem; line-height: 1.4; word-wrap: break-word; }
    .msg-out { align-self: flex-end; background: var(--sent-bg); color: white; border-bottom-right-radius: 2px; }
    .msg-in { align-self: flex-start; background: var(--recv-bg); color: #333; border-bottom-left-radius: 2px; }
    
    .sw-input-box { padding: 12px; border-top: 1px solid var(--border-c); display: flex; align-items: center; gap: 10px; background: #fff; }
    #msgInp { flex: 1; padding: 10px 15px; border-radius: 25px; border: 1px solid #e5e7eb; outline: none; transition:0.2s; }
    #msgInp:focus { border-color: #bc1888; }

    /* SEARCH */
    .sw-search-wrap { padding: 15px; border-bottom: 1px solid var(--border-c); }
    .sw-search-input { width: 100%; padding: 10px 15px; border-radius: 20px; border: 1px solid #e5e7eb; outline: none; }

    @media(max-width:480px){ .sw-window{ width:100%; height:100%; bottom:0; right:0; border-radius:0; } .sw-launcher{ bottom:80px; } }
</style>

<div class="sw-launcher" onclick="window.toggleWidget()"><i class="fas fa-comment-dots"></i></div>

<div class="sw-window" id="swWindow">
    <div class="sw-header">
        <div class="sw-logo"><i class="fab fa-instagram"></i> SocialChat</div>
        <i class="fas fa-times" onclick="window.toggleWidget()" style="cursor:pointer; color:#9ca3af; font-size:1.2rem;"></i>
    </div>

    <div class="sw-tabs">
        <div class="sw-tab active" onclick="window.switchTab('chats', this)">Chats</div>
        <div class="sw-tab" onclick="window.switchTab('groups', this)">Groups</div>
        <div class="sw-tab" onclick="window.switchTab('search', this)">Search</div>
    </div>

    <div class="sw-body">
        <div id="view-chats" class="sw-view active">
            <div style="text-align:center; padding:40px; color:#ccc;">Loading chats...</div>
        </div>

        <div id="view-groups" class="sw-view"><div id="groupList" style="padding:10px;">Loading...</div></div>

        <div id="view-search" class="sw-view">
            <div class="sw-search-wrap">
                <input type="text" class="sw-search-input" placeholder="Search HTS... or VH..." onkeyup="window.doSearch(this)">
            </div>
            <div id="dirList"></div>
        </div>

        <div id="view-convo" class="sw-convo">
            <div class="sw-chat-head">
                <i class="fas fa-arrow-left" onclick="window.closeChat()" style="cursor:pointer; font-size:1.2rem; color:#666;"></i>
                <div class="sw-av" id="convoAv" style="width:35px; height:35px; font-size:0.9rem; background:var(--inst-grad);">?</div>
                <div style="font-weight:700; color:#333;" id="convoName">User</div>
            </div>
            <div class="sw-msgs" id="msgArea"></div>
            <div class="sw-input-box">
                <input type="file" id="fileInp" style="display:none;" onchange="window.uploadFile(this)">
                <i class="fas fa-plus" style="color:#bc1888; font-size:1.2rem; cursor:pointer;" onclick="document.getElementById('fileInp').click()"></i>
                <input type="text" id="msgInp" placeholder="Message..." onkeypress="if(event.key==='Enter') window.sendMsg()">
                <i class="fas fa-paper-plane" style="color:#bc1888; font-size:1.2rem; cursor:pointer;" onclick="window.sendMsg()"></i>
            </div>
        </div>
    </div>
</div>

<script>
    // VARS
    window.cid = null;
    window.poll = null;
    
    const getRandomColor = () => ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEEAD', '#D4A5A5', '#9B59B6', '#FF9F1C'][Math.floor(Math.random() * 8)];

    // TOGGLES
    window.toggleWidget = () => {
        document.getElementById('swWindow').classList.toggle('active');
        if(document.getElementById('swWindow').classList.contains('active')) window.refreshHistory();
    };

    window.switchTab = (v, el) => {
        document.querySelectorAll('.sw-view').forEach(e => e.style.display = 'none');
        document.querySelectorAll('.sw-tab').forEach(e => e.classList.remove('active'));
        document.getElementById('view-'+v).style.display = 'flex';
        el.classList.add('active');
        if(v === 'groups') window.loadGroups();
        if(v === 'chats') window.refreshHistory();
    };

    // HISTORY
    window.refreshHistory = () => {
        const fd = new FormData(); fd.append('action', 'refresh_history');
        fetch('/ajax/chat_handler.php', {method:'POST', body:fd}).then(r=>r.json()).then(d => {
            let h = '';
            if(d.data.length === 0) h = '<div style="text-align:center; padding:40px; color:#ccc;">No chats yet</div>';
            d.data.forEach(c => {
                const color = getRandomColor();
                h += `<div class="sw-item" onclick="window.openChat('${c.id}', '${c.name}')">
                        <div class="sw-av" style="background:${color};">${c.initial}</div>
                        <div style="flex:1;">
                            <div style="font-weight:700; color:#333;">${c.name}</div>
                            <div style="font-size:0.8rem; color:#666; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; width:180px;">${c.last_msg}</div>
                        </div>
                        <div style="font-size:0.7rem; color:#999;">${c.time}</div>
                      </div>`;
            });
            document.getElementById('view-chats').innerHTML = h;
        });
    };

    // SEARCH
    let sTimer;
    window.doSearch = (el) => {
        if(el.value.length < 2) return;
        clearTimeout(sTimer);
        sTimer = setTimeout(() => {
            const fd = new FormData(); fd.append('action', 'search_directory'); fd.append('term', el.value);
            fetch('/ajax/chat_handler.php', {method:'POST', body:fd}).then(r=>r.json()).then(d => {
                let h = '';
                d.data.forEach(u => {
                    const color = getRandomColor();
                    h += `<div class="sw-item" onclick="window.initChat('${u.id}', '${u.name}')">
                            <div class="sw-av" style="background:${color};">${u.name[0]}</div>
                            <div style="flex:1;">
                                <div><b>${u.name}</b></div>
                                <div style="font-size:0.8rem; color:#666;">${u.id} • ${u.role}</div>
                            </div>
                          </div>`;
                });
                document.getElementById('dirList').innerHTML = h;
            });
        }, 400);
    };

    // GROUPS
    window.loadGroups = () => {
        const fd = new FormData(); fd.append('action', 'load_groups');
        fetch('/ajax/chat_handler.php', {method:'POST', body:fd}).then(r=>r.json()).then(d => {
            let h = '';
            d.data.forEach(g => {
                h += `<div class="sw-item" onclick="window.initChat('${g.id}', '${g.name}')">
                        <div class="sw-av" style="background:#333; color:white;"><i class="fas fa-users"></i></div>
                        <div style="flex:1;"><b>${g.name}</b><br><small style="color:#999;">${g.sub}</small></div>
                      </div>`;
            });
            document.getElementById('groupList').innerHTML = h;
        });
    };

    // CHAT ACTIONS
    window.initChat = (tid, name) => {
        const fd = new FormData(); fd.append('action', 'open_chat'); fd.append('target_id', tid);
        fetch('/ajax/chat_handler.php', {method:'POST', body:fd}).then(r=>r.json()).then(d => {
            window.openChat(d.cid, name);
        });
    };

    window.openChat = (cid, name) => {
        window.cid = cid;
        document.getElementById('convoName').innerText = name;
        document.getElementById('convoAv').innerText = name[0];
        document.getElementById('view-convo').style.display = 'flex';
        
        if(window.poll) clearInterval(window.poll);
        fetchMsgs();
        window.poll = setInterval(fetchMsgs, 3000);
    };

    function fetchMsgs() {
        if(!window.cid) return;
        const fd = new FormData(); fd.append('action', 'open_chat'); fd.append('target_id', window.cid);
        fetch('/ajax/chat_handler.php', {method:'POST', body:fd}).then(r=>r.json()).then(d => {
            const area = document.getElementById('msgArea');
            const isBottom = area.scrollHeight - area.scrollTop === area.clientHeight;
            area.innerHTML = '';
            
            d.msgs.forEach(m => {
                const isMe = (m.sender_id == d.my_id);
                const cls = isMe ? 'msg-out' : 'msg-in';
                const ticks = isMe ? (m.read_status==1 ? '✓✓' : '✓') : '';
                let txt = m.message_type==='file' ? `<a href="/${m.file_path}" target="_blank" style="color:inherit">📎 File</a>` : m.message_text;
                
                area.innerHTML += `<div class="msg ${cls}">
                                    ${txt}
                                    <div style="font-size:0.6rem; text-align:right; opacity:0.7;">
                                        ${new Date(m.sent_at).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})} ${ticks}
                                    </div>
                                   </div>`;
            });
            if(isBottom || area.scrollTop===0) area.scrollTop = area.scrollHeight;
        });
    }

    window.sendMsg = () => {
        const inp = document.getElementById('msgInp');
        if(!inp.value.trim()) return;
        const fd = new FormData(); fd.append('action','send_msg'); fd.append('cid',window.cid); fd.append('msg',inp.value);
        fetch('/ajax/chat_handler.php', {method:'POST', body:fd}).then(() => fetchMsgs());
        inp.value = '';
    };

    window.uploadFile = (el) => {
        if(!el.files.length) return;
        const fd = new FormData(); fd.append('action','send_msg'); fd.append('cid',window.cid); fd.append('file',el.files[0]);
        fetch('/ajax/chat_handler.php', {method:'POST', body:fd}).then(() => fetchMsgs());
    };

    window.closeChat = () => {
        document.getElementById('view-convo').style.display = 'none';
        if(window.poll) clearInterval(window.poll);
        window.refreshHistory(); 
    };
    
    // Initial Load
    window.refreshHistory();
</script>