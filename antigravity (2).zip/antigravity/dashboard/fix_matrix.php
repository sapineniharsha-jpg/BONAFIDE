<?php
// fix_matrix.php - Run ONCE to sync old timetables to matrix
require_once '../includes/db.php';
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<h3>Starting Matrix Migration...</h3>";

$mysqli->begin_transaction();

try {
    // 1. Get all timetables
    $master_res = $mysqli->query("SELECT * FROM timetable_master");
    
    $count = 0;
    while($m = $master_res->fetch_assoc()) {
        $u_code = $m['unique_code'];
        $mid = $m['id'];
        
        // 2. Clear existing matrix for this code
        $mysqli->query("DELETE FROM timetable_matrix WHERE unique_code = '$u_code'");
        
        // 3. Get Details
        $det_res = $mysqli->query("SELECT * FROM timetable_details WHERE master_id = $mid");
        
        $stmt = $mysqli->prepare("INSERT INTO timetable_matrix (unique_code, day_order, hour_slot, subject_code, subject_name, faculty_id, faculty_name, type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        
        while($d = $det_res->fetch_assoc()) {
            if(empty($d['subject_code'])) continue;
            
            // Normalize data
            $sCode = strtoupper($d['subject_code']);
            $sName = strtoupper($d['subject_name']);
            $fId   = strtoupper($d['faculty_id']);
            $fName = strtoupper($d['faculty_name']);
            $type  = strtoupper($d['type']);
            
            $stmt->bind_param("siisssss", $u_code, $d['day'], $d['hour'], $sCode, $sName, $fId, $fName, $type);
            $stmt->execute();
            $count++;
        }
        $stmt->close();
    }
    
    $mysqli->commit();
    echo "<h3 style='color:green'>Success! migrated $count grid cells to Matrix table.</h3>";
    echo "<p>You can now delete this file.</p>";
    
} catch (Exception $e) {
    $mysqli->rollback();
    echo "<h3 style='color:red'>Error: " . $e->getMessage() . "</h3>";
}
?>