<?php
// print_attendance.php - ENTERPRISE v54.0 (Fuzzy Security & Batch Fix)
session_start();

// 1. SETTINGS
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once '../includes/db.php';

// 2. SECURITY & CONNECTION
if (!isset($mysqli) || $mysqli->connect_error) die("DB Error: " . $mysqli->connect_error);

$user_id = $_SESSION['ID_NO'] ?? $_SESSION['user_id'] ?? '';
$user_role = strtoupper(trim($_SESSION['role'] ?? 'NOT_SET'));
$user_dept = strtoupper(trim($_SESSION['DEPARTMENT'] ?? ''));

// SELF-HEALING: If Session Dept is missing, fetch from DB
if ($user_role === 'HOD' && empty($user_dept) && !empty($user_id)) {
    $stmt = $mysqli->prepare("SELECT DEPARTMENT FROM employee_details1 WHERE ID_NO = ? LIMIT 1");
    if ($stmt) {
        $stmt->bind_param("s", $user_id);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($row = $res->fetch_assoc()) {
            $user_dept = strtoupper(trim($row['DEPARTMENT']));
            $_SESSION['DEPARTMENT'] = $user_dept;
        }
    }
}

$allowed_roles = ['ADMIN', 'PRINCIPAL', 'DEAN', 'DEAN_ACADEMICS', 'HOD'];
if (!in_array($user_role, $allowed_roles)) {
    die("<div style='padding:50px; text-align:center;'><h3>⛔ Access Denied</h3><a href='../dashboard.php'>Go Back</a></div>");
}

// 3. MAPPINGS
$dept_full_names = [
    'CSE'   => 'B.E. Computer Science and Engineering',
    'ECE'   => 'B.E. Electronics and Communication Engineering',
    'EEE'   => 'B.E. Electrical and Electronics Engineering',
    'MECH'  => 'B.E. Mechanical Engineering',
    'CIVIL' => 'B.E. Civil Engineering',
    'IT'    => 'B.Tech. Information Technology',
    'AIDS'  => 'B.Tech. Artificial Intelligence and Data Science',
    'AIML'  => 'B.Tech. Artificial Intelligence and Machine Learning',
    'S&H'   => 'Science and Humanities',
    'MBA'   => 'Master of Business Administration'
];

function get_full_dept_name($short) { global $dept_full_names; return $dept_full_names[$short] ?? $short; }

// --- FUZZY SECURITY MATCHER ---
// Compares "CIVIL" with "B.E- CIVIL ENGINEERING" by stripping noise
function is_dept_allowed($selected_short, $session_full) {
    // 1. Normalize Session (Remove B.E, B.Tech, dots, spaces, hyphens)
    $clean_session = strtoupper(preg_replace('/[^A-Z]/', '', $session_full)); // e.g., BECIVILENGINEERING
    $clean_session = str_replace(['BE', 'BTECH', 'ME', 'MTECH', 'ENGINEERING', 'DEPT'], '', $clean_session); // CIVIL
    
    // 2. Normalize Selection
    $clean_selected = strtoupper(preg_replace('/[^A-Z]/', '', $selected_short)); // CIVIL
    
    // 3. Check if one contains the other
    return (strpos($clean_session, $clean_selected) !== false) || (strpos($clean_selected, $clean_session) !== false);
}

// --- BATCH & YEAR CALCULATOR ---
function get_smart_year($batch_str) {
    // Expects "2024-2028"
    if (!preg_match('/^(\d{4})/', $batch_str, $m)) return "Year Unknown";
    
    $start_year = intval($m[1]);
    $curr_month = intval(date('n'));
    $curr_year = intval(date('Y'));
    
    // Academic Year Calculation (Jan 2026 implies we are in 2025-2026 Academic Year)
    $acad_year_end = ($curr_month < 6) ? $curr_year : $curr_year + 1;
    $diff = $acad_year_end - $start_year; // 2026 - 2024 = 2nd Year
    
    $suffixes = [1=>'I', 2=>'II', 3=>'III', 4=>'IV'];
    return ($suffixes[$diff] ?? $diff) . " Year";
}

// --- DETECTIVE PARSER (Prioritizes Full Batch Ranges) ---
function parse_uc_detective($code) {
    $clean = strtoupper(trim($code));
    $clean = str_replace(['-', '_'], '/', $clean);
    $parts = explode('/', $clean);
    
    $meta = ['dept'=>'', 'batch'=>'', 'sem'=>'', 'sec'=>'A']; 
    
    foreach ($parts as $p) {
        // STRICT BATCH MATCH: Must look like 2024-2028 (XXXX-XXXX)
        if (preg_match('/^\d{4}.\d{4}$/', $p)) {
            $meta['batch'] = $p;
        }
        // WEAK BATCH MATCH: 2024 (Only if no full batch found yet)
        else if (preg_match('/^\d{4}$/', $p) && empty($meta['batch'])) {
            $meta['batch'] = $p; // Fallback
        }
        // SEMESTER: S4, S3
        else if (preg_match('/^S\d+$/', $p)) {
            $meta['sem'] = str_replace('S', '', $p);
        }
        // SECTION: Single Letter A, B, C
        else if (preg_match('/^[A-Z]$/', $p) && strlen($p) === 1) {
            $meta['sec'] = $p;
        }
        // DEPT: Text that isn't a batch/sem
        else if (ctype_alpha(str_replace('&','',$p)) && strlen($p) > 1) {
            $meta['dept'] = $p;
        }
    }
    return $meta;
}

// 4. POPULATE DROPDOWNS
$avail_depts = []; $avail_batches = []; $avail_sems = []; $avail_secs = []; $avail_faculty = [];

try {
    // 1. Get Classes
    $res = $mysqli->query("SELECT DISTINCT unique_code FROM timetable_matrix");
    while ($row = $res->fetch_assoc()) {
        $meta = parse_uc_detective($row['unique_code']);
        if($meta['dept']) $avail_depts[$meta['dept']] = get_full_dept_name($meta['dept']);
        if($meta['batch']) $avail_batches[$meta['batch']] = true;
        if($meta['sem']) $avail_sems[$meta['sem']] = true;
        if($meta['sec']) $avail_secs[$meta['sec']] = true;
    }
    
    // 2. Get Faculty List
    $fac_sql = "SELECT DISTINCT al.faculty_id, COALESCE(ed.NAME, al.faculty_id) as fname 
                FROM attendance_logs al 
                LEFT JOIN employee_details1 ed ON al.faculty_id = ed.ID_NO 
                ORDER BY fname ASC";
    $res_fac = $mysqli->query($fac_sql);
    while ($row = $res_fac && $r=$res_fac->fetch_assoc()) $avail_faculty[] = $r;

} catch (Exception $e) {}

ksort($avail_depts); ksort($avail_batches); ksort($avail_sems); ksort($avail_secs);

// 5. REPORT GENERATION LOGIC
$columns_headers = [];
$students_summary = [];
$meta_info = [];
$is_generated = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate'])) {
    
    // Inputs
    $dept_short = strtoupper(trim($_POST['dept'] ?? ''));
    $batch = $_POST['batch'] ?? '';
    $sem = $_POST['sem'] ?? '';
    $sec = $_POST['sec'] ?? '';
    $from_date = $_POST['from_date'];
    $to_date = $_POST['to_date'];
    
    $filter_fac = $_POST['filter_fac'] ?? 'ALL';
    $filter_hour = $_POST['filter_hour'] ?? 'ALL';
    
    // SECURITY FIX: Fuzzy Match
    if ($user_role === 'HOD' && !empty($user_dept)) {
        if (!is_dept_allowed($dept_short, $user_dept)) {
            die("<div style='padding:50px; text-align:center; color:red; border:2px solid red; margin:20px;'>
                    <h3>⚠️ Security Warning: Dept Mismatch</h3>
                    <p>Selected: <b>$dept_short</b> <br> Allowed Session: <b>$user_dept</b></p>
                    <a href='print_attendance.php' style='padding:10px; background:#333; color:white; text-decoration:none;'>Go Back</a>
                 </div>");
        }
    }

    // Identify Unique Codes matching this combination
    $target_codes = [];
    $chk_res = $mysqli->query("SELECT unique_code FROM timetable_matrix");
    while($row = $chk_res->fetch_assoc()) {
        $m = parse_uc_detective($row['unique_code']);
        if ($m['dept'] == $dept_short && $m['batch'] == $batch && $m['sem'] == $sem && $m['sec'] == $sec) {
            $target_codes[] = $row['unique_code'];
        }
    }

    // Fallback if no matrix match found (Manual Construction)
    if (empty($target_codes)) {
        $target_codes[] = "$dept_short/$batch/S$sem/$sec"; // Standard Slash
        $target_codes[] = "$dept_short-$batch-S$sem-$sec"; // Standard Dash
    }

    // BUILD QUERY
    $in_clause = implode("','", $target_codes); 
    
    $base_query = " FROM attendance_logs al
                    INNER JOIN timetable_matrix tm 
                        ON al.faculty_id = tm.faculty_id 
                        AND al.day_order = tm.day_order 
                        AND al.hour = tm.hour_slot
                        AND al.subject_code = tm.subject_code
                    LEFT JOIN employee_details1 ed ON al.faculty_id = ed.ID_NO
                    WHERE tm.unique_code IN ('$in_clause') 
                      AND al.date BETWEEN '$from_date' AND '$to_date' ";

    if ($filter_fac !== 'ALL') $base_query .= " AND al.faculty_id = '$filter_fac' ";
    if ($filter_hour !== 'ALL') $base_query .= " AND al.hour = '$filter_hour' ";

    // A. GET COLUMNS
    $col_sql = "SELECT DISTINCT al.date, al.hour, al.subject_code, al.day_order, 
                COALESCE(ed.NAME, al.faculty_id) as faculty_name 
                $base_query 
                ORDER BY al.date ASC, al.hour ASC";
    
    $res_cols = $mysqli->query($col_sql);
    
    if ($res_cols && $res_cols->num_rows > 0) {
        while ($row = $res_cols->fetch_assoc()) {
            $key = $row['date'] . '_' . $row['hour'];
            $columns_headers[$key] = [
                'date' => date('d/m', strtotime($row['date'])),
                'hour' => $row['hour'],
                'day'  => $row['day_order'],
                'sub'  => $row['subject_code'],
                'fac'  => $row['faculty_name']
            ];
        }
        
        // B. GET STUDENTS
        $log_sql = "SELECT al.student_id, al.status, al.date, al.hour, 
                    COALESCE(sl.Name, sb.student_name, 'Unknown') as name,
                    COALESCE(sl.RegisterNo, sb.register_no, al.student_id) as reg_no " . 
                    str_replace("LEFT JOIN employee_details1 ed ON al.faculty_id = ed.ID_NO", "", $base_query); 
        
        $log_sql = str_replace("FROM attendance_logs al", 
                               "FROM attendance_logs al 
                                LEFT JOIN students_login_master sl ON al.student_id = sl.IDNo
                                LEFT JOIN students_batch_25_26 sb ON al.student_id = sb.id_no", $log_sql);
        
        $log_sql .= " ORDER BY reg_no ASC";
        $res_logs = $mysqli->query($log_sql);

        while ($row = $res_logs->fetch_assoc()) {
            $sid = $row['student_id'];
            if (!isset($students_summary[$sid])) {
                $students_summary[$sid] = ['name'=>$row['name'], 'reg'=>$row['reg_no'], 'attended'=>0, 'logs'=>[]];
            }
            $key = $row['date'] . '_' . $row['hour'];
            $students_summary[$sid]['logs'][$key] = $row['status'];
            if ($row['status'] == 'P' || $row['status'] == 'OD') $students_summary[$sid]['attended']++;
        }
        
        $is_generated = true;
        
        // C. META INFO
        $smart_year = get_smart_year($batch);
        $full_dept = get_full_dept_name($dept_short);
        
        $sub_text = "Consolidated Report";
        if ($filter_fac !== 'ALL') {
            $fname = $mysqli->query("SELECT NAME FROM employee_details1 WHERE ID_NO='$filter_fac'")->fetch_assoc()['NAME'] ?? $filter_fac;
            $sub_text = "Faculty Report: " . $fname;
        }

        $meta_info = [
            'title_1' => "$smart_year $full_dept",
            'title_2' => "Semester $sem - Section $sec (Batch $batch)",
            'period' => date('d M Y', strtotime($from_date)) . " - " . date('d M Y', strtotime($to_date)),
            'sub_text' => $sub_text,
            'total_hrs' => count($columns_headers),
            'hod_name' => ($filter_fac === 'ALL') ? "Head of Department" : "Faculty In-Charge"
        ];
    }
}

include '../includes/header.php';
?>

<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    :root { --accent: #2563eb; --bg: #f8fafc; }
    body { font-family: 'Outfit', sans-serif; background: var(--bg); color: #1e293b; }
    
    .report-card { background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); max-width: 1200px; margin: 20px auto; }
    .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; align-items: end; }
    .form-input { width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-weight: 600; }
    .btn { width: 100%; padding: 12px; background: var(--accent); color: white; border: none; border-radius: 6px; font-weight: 700; cursor: pointer; }
    
    .report-wrapper { background: white; padding: 30px; margin: 20px auto; overflow-x: auto; border-radius: 12px; }
    .att-table { width: 100%; border-collapse: collapse; font-size: 0.8rem; }
    .att-table th { background: #f1f5f9; padding: 8px 4px; border: 1px solid #e2e8f0; text-align: center; color: #475569; }
    .att-table td { padding: 6px 4px; border: 1px solid #e2e8f0; text-align: center; font-weight: 600; }
    
    .fac-tooltip:hover::after { content: attr(data-fac); position: absolute; background: #333; color: #fff; padding: 5px; font-size: 0.7rem; border-radius: 4px; bottom: 100%; left: 50%; transform: translateX(-50%); white-space: nowrap; z-index:100; }
    .fac-tooltip { position: relative; }

    @media print {
        .no-print { display: none !important; }
        .report-wrapper { box-shadow: none; margin: 0; padding: 0; }
        .att-table th, .att-table td { border: 1px solid #000; }
        @page { size: landscape; margin: 5mm; }
    }
</style>

<div class="glass-header no-print" style="padding:15px 30px; background:white; border-bottom:1px solid #eee; display:flex; justify-content:space-between; align-items:center;">
    <h3 style="margin:0; color:var(--accent);">Attendance Reports</h3>
    <a href="../dashboard.php" style="text-decoration:none; color:#64748b; font-weight:bold;">Back</a>
</div>

<div class="report-card no-print">
    <form method="POST">
        <div class="form-grid">
            <div style="grid-column:span 2;"><label>Department</label>
                <select name="dept" class="form-input">
                    <?php foreach($avail_depts as $k=>$v) echo "<option value='$k'>$v</option>"; ?>
                </select>
            </div>
            <div><label>Batch (Year)</label><select name="batch" class="form-input"><?php foreach($avail_batches as $k=>$v) echo "<option>$k</option>"; ?></select></div>
            <div><label>Sem</label><select name="sem" class="form-input"><?php foreach($avail_sems as $k=>$v) echo "<option>$k</option>"; ?></select></div>
            <div><label>Sec</label><select name="sec" class="form-input"><?php foreach($avail_secs as $k=>$v) echo "<option>$k</option>"; ?></select></div>
            <div><label>From</label><input type="date" name="from_date" class="form-input" value="<?= date('Y-m-01') ?>" required></div>
            <div><label>To</label><input type="date" name="to_date" class="form-input" value="<?= date('Y-m-d') ?>" required></div>
            
            <div style="border-left:2px solid #eee; padding-left:15px;">
                <label>Optional: Faculty</label>
                <select name="filter_fac" class="form-input"><option value="ALL">All Faculty</option><?php foreach($avail_faculty as $f) echo "<option value='{$f['faculty_id']}'>{$f['fname']}</option>"; ?></select>
            </div>
            <div><label>Optional: Hour</label><select name="filter_hour" class="form-input"><option value="ALL">All</option><?php for($i=1;$i<=8;$i++) echo "<option value='$i'>H$i</option>"; ?></select></div>
            
            <div style="align-self:end;"><button type="submit" name="generate" class="btn">Generate Report</button></div>
        </div>
    </form>
</div>

<?php if ($is_generated): ?>
<div class="report-wrapper">
    <div style="text-align:center; margin-bottom:20px; border-bottom:2px solid #000; padding-bottom:10px;">
        <h2 style="margin:0; text-transform:uppercase; font-size:1.4rem;">Attendance Report</h2>
        <div style="font-weight:bold; font-size:1.1rem; margin-top:5px;"><?= $meta_info['title_1'] ?></div>
        <div style="color:#444; margin-top:3px;"><?= $meta_info['title_2'] ?></div>
        <div style="display:flex; justify-content:space-between; margin-top:15px; border-top:1px dashed #999; padding-top:10px; font-weight:bold; font-size:0.9rem;">
            <span>Period: <?= $meta_info['period'] ?></span>
            <span><?= $meta_info['sub_text'] ?></span>
            <span>Total Sessions: <?= $meta_info['total_hrs'] ?></span>
        </div>
    </div>

    <?php if (empty($students_summary)): ?>
        <div style="text-align:center; padding:40px; color:#999;">No Data Found</div>
    <?php else: ?>
        <table class="att-table">
            <thead>
                <tr>
                    <th width="30">#</th>
                    <th width="100" style="text-align:left;">Register No</th>
                    <th style="text-align:left;">Name</th>
                    <?php foreach ($columns_headers as $col): ?>
                        <th class="fac-tooltip" data-fac="<?= $col['fac'] ?> [<?= $col['sub'] ?>]">
                            <div style="font-size:0.7rem;"><?= $col['date'] ?></div>
                            <div style="font-size:0.6rem; color:#555;">H<?= $col['hour'] ?></div>
                        </th>
                    <?php endforeach; ?>
                    <th style="background:#f0f9ff;">Tot</th>
                    <th style="background:#f0fdf4;">Pre</th>
                    <th style="background:#fff7ed;">%</th>
                </tr>
            </thead>
            <tbody>
                <?php $i=1; foreach ($students_summary as $sid => $data): 
                    $pct = ($meta_info['total_hrs'] > 0) ? round(($data['attended'] / $meta_info['total_hrs']) * 100) : 0;
                ?>
                <tr>
                    <td><?= $i++ ?></td>
                    <td style="text-align:left;"><?= $data['reg'] ?></td>
                    <td style="text-align:left; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:180px;"><?= $data['name'] ?></td>
                    <?php foreach ($columns_headers as $key => $col): 
                        $st = $data['logs'][$key] ?? '-';
                        $clr = $st=='A'?'color:red;':($st=='OD'?'color:orange;':'color:green;');
                    ?>
                        <td style="<?= $clr ?>"><?= $st=='P'?'P':$st ?></td>
                    <?php endforeach; ?>
                    <td style="background:#f0f9ff; font-weight:bold;"><?= $meta_info['total_hrs'] ?></td>
                    <td style="background:#f0fdf4; font-weight:bold;"><?= $data['attended'] ?></td>
                    <td style="background:#fff7ed; font-weight:bold; color:<?= $pct<75?'red':'green' ?>"><?= $pct ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div style="margin-top:60px; display:flex; justify-content:space-between; padding:0 50px;">
            <div style="text-align:center;"><div style="border-top:1px solid #000; width:150px; font-weight:bold; padding-top:5px;">Class Advisor</div></div>
            <div style="text-align:center;"><div style="border-top:1px solid #000; width:180px; font-weight:bold; padding-top:5px;"><?= $meta_info['hod_name'] ?></div></div>
            <div style="text-align:center;"><div style="border-top:1px solid #000; width:150px; font-weight:bold; padding-top:5px;">Principal</div></div>
        </div>
        
        <div class="no-print" style="text-align:center; margin-top:30px;">
            <button onclick="window.print()" class="btn" style="width:auto; padding:10px 30px;"><i class="fas fa-print"></i> Print</button>
        </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>