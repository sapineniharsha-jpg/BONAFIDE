<?php
// faculty_profile.php - ENTERPRISE v21.0 (Smart Edit Logic)
session_start();
require_once '../includes/db.php';

// 1. CONFIGURATION
ini_set('display_errors', 0);
error_reporting(E_ALL);
date_default_timezone_set('Asia/Kolkata');

// 2. SECURITY & AUTH
$my_role = strtolower($_SESSION['role'] ?? 'faculty'); 
$my_id = $_SESSION['ID_NO'] ?? $_SESSION['user_id'] ?? '';

// Determine Target ID
// If Faculty/Admin is viewing someone else via ?id=... allow it if authorized
// Otherwise default to self.
$target_id = $_GET['id'] ?? $my_id;

$admin_roles = ['admin', 'principal', 'dean', 'dean_academics', 'hod'];
$is_admin = in_array($my_role, $admin_roles);
$is_self = ($my_id === $target_id);

// If trying to view someone else and NOT an admin/HOD -> Access Denied
if (!$is_self && !$is_admin) {
    die("<div style='padding:50px;text-align:center;'>Access Denied. You can only view your own profile.</div>");
}

// --- HELPER: SMART LOCK ---
// Returns 'readonly_perm' if data exists AND user is not super-admin
// Super admins might want to force-edit later, but for now we follow the "Fill Once" logic for self.
function getLockStatus($val) {
    global $is_admin;
    // If Admin, maybe allow edit? For now let's stick to "Lock if filled" for everyone to prevent accidental wipes
    // OR: Allow Admin to always edit.
    if ($is_admin) return ''; 
    if (empty($val) || $val === '0' || $val === 'N/A') return ''; // Editable if empty
    return 'readonly_perm'; // Locked
}

// --- DATA ENGINE ---
function get_faculty_profile($mysqli, $id) {
    $stmt = $mysqli->prepare("SELECT * FROM employee_details1 WHERE ID_NO = ?");
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    
    if ($row = $res->fetch_assoc()) {
        return $row;
    }
    return null;
}

$user = get_faculty_profile($mysqli, $target_id);
if (!$user) die("<div style='padding:50px;text-align:center;'>Faculty not found.</div>");

// --- HANDLE SAVE ---
$msg = ""; $msg_type = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_profile'])) {
    
    // 1. Photo Upload
    $photo_path = $user['photovarchar'];
    if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['profile_photo']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png'])) {
            $new_name = "fac_" . $target_id . "_" . time() . "." . $ext;
            $dir = "../uploads/faculty_photos/"; // Different folder for faculty
            if (!is_dir($dir)) mkdir($dir, 0777, true);
            
            if (move_uploaded_file($_FILES['profile_photo']['tmp_name'], $dir . $new_name)) {
                $photo_path = $new_name; // Update path variable
            }
        }
    }

    // 2. Inputs (Use existing if locked/not sent)
    $email = $_POST['EMAIL'] ?? $user['EMAIL'];
    $phone = $_POST['PHONE_NO'] ?? $user['PHONE_NO'];
    $dob = $_POST['date_of_birth'] ?? $user['date_of_birth'];
    $desig = $_POST['DESIGNATION'] ?? $user['DESIGNATION'];
    $qual = $_POST['QUALIFICATION'] ?? $user['QUALIFICATION'];
    $addr = $_POST['STAFF_ADD1'] ?? $user['STAFF_ADD1'];
    
    // 3. Update DB
    // Note: We update photo path here too
    $sql = "UPDATE employee_details1 SET 
            EMAIL=?, PHONE_NO=?, date_of_birth=?, DESIGNATION=?, 
            QUALIFICATION=?, STAFF_ADD1=?, photovarchar=? 
            WHERE ID_NO=?";
            
    $stmt = $mysqli->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("ssssssss", $email, $phone, $dob, $desig, $qual, $addr, $photo_path, $target_id);
        
        if ($stmt->execute()) {
            $msg = "Profile Updated Successfully!";
            $msg_type = "success";
            $user = get_faculty_profile($mysqli, $target_id); // Reload
        } else {
            $msg = "Update Failed: " . $stmt->error;
            $msg_type = "error";
        }
    }
}

include '../includes/header.php';
?>

<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
    :root { 
        --brand: #bc1888; 
        --insta-grad: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%); 
        --bg-soft: #f8fafc; 
        --card-shadow: 0 10px 40px -10px rgba(0,0,0,0.08);
    }
    body { background-color: var(--bg-soft); font-family: 'Outfit', sans-serif; }
    .profile-container { max-width: 900px; margin: 20px auto; padding: 0 15px 80px; }

    /* CARD */
    .profile-card { background: #fff; border-radius: 24px; overflow: hidden; box-shadow: var(--card-shadow); margin-bottom: 25px; border: 1px solid rgba(0,0,0,0.03); }
    .cover-photo { height: 140px; background: var(--insta-grad); position: relative; }
    .profile-content { padding: 0 30px 40px; text-align: center; margin-top: -70px; position: relative; }
    
    /* AVATAR */
    .avatar-wrapper { width: 140px; height: 140px; border-radius: 50%; background: #fff; padding: 5px; margin: 0 auto 15px; position: relative; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
    .avatar-img { 
        width: 100%; height: 100%; border-radius: 50%; background: #f1f5f9; 
        display: flex; align-items: center; justify-content: center; 
        font-size: 3.5rem; color: #cc2366; background-size: cover; background-position: center; font-weight: 800; 
    }
    
    .upload-trigger { position: absolute; bottom: 5px; right: 5px; background: #1e293b; color: #fff; width: 40px; height: 40px; border-radius: 50%; display: none; align-items: center; justify-content: center; cursor: pointer; border: 3px solid #fff; transition: transform 0.2s; }
    body.editing .upload-trigger { display: flex; animation: popIn 0.3s; }

    .fac-name { margin: 0; font-size: 1.8rem; font-weight: 700; color: #1e293b; }
    .fac-meta { color: #64748b; font-size: 0.95rem; margin-top: 5px; font-weight: 500; text-transform: uppercase; letter-spacing: 1px; }

    /* FORMS */
    .section-title { font-size: 1.1rem; font-weight: 800; color: #334155; margin: 35px 0 20px; display: flex; align-items: center; gap: 10px; }
    .section-title::after { content: ''; flex: 1; height: 1px; background: #e2e8f0; margin-left: 15px; }
    
    .form-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; }
    .input-group { background: #fff; padding: 5px; border-radius: 12px; }
    .input-label { display: block; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; color: #94a3b8; margin-bottom: 6px; }
    
    .input-field { width: 100%; border: 1px solid #e2e8f0; background: #f8fafc; border-radius: 10px; padding: 12px 15px; font-weight: 600; outline: none; transition: all 0.2s; }
    .input-field:read-only:not(.edit-mode) { background: transparent; border-color: transparent; padding-left: 0; cursor: default; }
    .input-field.edit-mode { background: #fff; border-color: #cbd5e1; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
    .input-field.edit-mode:focus { border-color: #cc2366; box-shadow: 0 0 0 3px rgba(204, 35, 102, 0.1); }
    
    .req-tag { background: #fee2e2; color: #b91c1c; font-size: 0.65rem; padding: 2px 6px; border-radius: 4px; display: none; float: right; }
    body.editing .req-tag { display: inline-block; }

    /* ACTION BUTTONS */
    .fab-edit { position: fixed; bottom: 30px; right: 30px; width: 60px; height: 60px; background: var(--insta-grad); color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; cursor: pointer; border: none; box-shadow: 0 10px 30px rgba(220, 39, 67, 0.4); z-index: 100; transition: transform 0.2s; }
    .fab-edit:hover { transform: scale(1.1); }

    .save-bar { position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%) translateY(100px); background: #fff; padding: 10px 25px; border-radius: 50px; box-shadow: 0 10px 30px rgba(0,0,0,0.15); display: flex; gap: 15px; z-index: 101; transition: 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); border: 1px solid #e2e8f0; }
    body.editing .save-bar { transform: translateX(-50%) translateY(0); }
    .btn-main { background: #10b981; color: #fff; border: none; padding: 10px 20px; border-radius: 30px; font-weight: 700; cursor: pointer; }
    .btn-sec { background: transparent; color: #64748b; border: none; font-weight: 600; cursor: pointer; }

    @keyframes popIn { from { transform: scale(0); } to { transform: scale(1); } }
</style>

<div class="profile-container">

    <form method="POST" enctype="multipart/form-data" id="profileForm">
        <input type="hidden" name="save_profile" value="1">
        
        <div class="profile-card">
            <div class="cover-photo"></div>
            <div class="profile-content">
                <div class="avatar-wrapper">
                    <?php 
                        // Handle photo path. If just filename, prepend path. If empty, show initial.
                        $photo = $user['photovarchar'] ?? '';
                        // Logic: Does it start with uploads/? If not, assume it's just filename.
                        if($photo && strpos($photo, '/') === false) $photo = "../uploads/faculty_photos/" . $photo;
                        // Fallback if not set
                    ?>
                    <div class="avatar-img" style="<?= $photo ? "background-image:url('$photo');" : "" ?>">
                        <?= !$photo ? strtoupper(substr($user['NAME'], 0, 1)) : '' ?>
                    </div>
                    <label class="upload-trigger" for="pic"><i class="fas fa-camera"></i></label>
                    <input type="file" id="pic" name="profile_photo" style="display:none" onchange="preview(this)">
                </div>
                
                <h1 class="fac-name"><?= htmlspecialchars($user['NAME']) ?></h1>
                <div class="fac-meta">
                    <?= htmlspecialchars($user['ID_NO']) ?> • <?= htmlspecialchars($user['DEPARTMENT']) ?>
                </div>
            </div>
        </div>

        <?php if($msg): ?>
            <div class="alert alert-<?= ($msg_type=='success')?'success':'danger' ?> mb-4" style="text-align:center; padding:15px; border-radius:10px; background:<?= ($msg_type=='success')?'#ecfdf5':'#fef2f2' ?>; color:<?= ($msg_type=='success')?'#047857':'#b91c1c' ?>;">
                <?= $msg ?>
            </div>
        <?php endif; ?>

        <div class="section-title"><i class="fas fa-briefcase"></i> Professional Details</div>
        <div class="form-grid">
            <div class="input-group">
                <label class="input-label">Designation <?= empty($user['DESIGNATION']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <input type="text" name="DESIGNATION" class="input-field" value="<?= htmlspecialchars($user['DESIGNATION']) ?>" <?= getLockStatus($user['DESIGNATION']) ?> readonly>
            </div>
            <div class="input-group">
                <label class="input-label">Qualification <?= empty($user['QUALIFICATION']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <input type="text" name="QUALIFICATION" class="input-field" value="<?= htmlspecialchars($user['QUALIFICATION']) ?>" <?= getLockStatus($user['QUALIFICATION']) ?> readonly>
            </div>
            <div class="input-group">
                <label class="input-label">Department</label>
                <input type="text" class="input-field" value="<?= htmlspecialchars($user['DEPARTMENT']) ?>" readonly_perm readonly>
            </div>
             <div class="input-group">
                <label class="input-label">Role</label>
                <input type="text" class="input-field" value="<?= htmlspecialchars($user['role']) ?>" readonly_perm readonly>
            </div>
        </div>

        <div class="section-title"><i class="fas fa-address-book"></i> Contact & Personal</div>
        <div class="form-grid">
            <div class="input-group">
                <label class="input-label">Official Email <?= empty($user['EMAIL']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <input type="email" name="EMAIL" class="input-field" value="<?= htmlspecialchars($user['EMAIL']) ?>" <?= getLockStatus($user['EMAIL']) ?> readonly>
            </div>
            <div class="input-group">
                <label class="input-label">Phone Number <?= empty($user['PHONE_NO']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <input type="text" name="PHONE_NO" class="input-field" value="<?= htmlspecialchars($user['PHONE_NO']) ?>" <?= getLockStatus($user['PHONE_NO']) ?> readonly>
            </div>
            <div class="input-group">
                <label class="input-label">Date of Birth <?= empty($user['date_of_birth']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <input type="date" name="date_of_birth" class="input-field" value="<?= htmlspecialchars($user['date_of_birth']) ?>" <?= getLockStatus($user['date_of_birth']) ?> readonly>
            </div>
            <div class="input-group" style="grid-column: 1/-1;">
                <label class="input-label">Mailing Address <?= empty($user['STAFF_ADD1']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <input type="text" name="STAFF_ADD1" class="input-field" value="<?= htmlspecialchars($user['STAFF_ADD1']) ?>" <?= getLockStatus($user['STAFF_ADD1']) ?> readonly>
            </div>
        </div>

        <div class="save-bar">
            <button type="button" class="btn-sec" onclick="location.reload()">Cancel</button>
            <button type="submit" class="btn-main"><i class="fas fa-check"></i> Save Changes</button>
        </div>

    </form>
    
    <button class="fab-edit" id="editBtn" onclick="enableEdit()"><i class="fas fa-pen"></i></button>

</div>

<script>
function enableEdit() {
    document.body.classList.add('editing');
    
    const inputs = document.querySelectorAll('.input-field');
    inputs.forEach(el => {
        // Unlock if not permanently locked
        if(!el.hasAttribute('readonly_perm')) {
            el.removeAttribute('readonly');
            el.classList.add('edit-mode');
        }
    });
    
    document.getElementById('editBtn').style.transform = 'scale(0)';
}

function preview(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            document.querySelector('.avatar-img').style.backgroundImage = 'url('+e.target.result+')';
            document.querySelector('.avatar-img').innerHTML = '';
        }
        reader.readAsDataURL(input.files[0]);
    }
}
</script>

<?php include '../includes/footer.php'; ?>