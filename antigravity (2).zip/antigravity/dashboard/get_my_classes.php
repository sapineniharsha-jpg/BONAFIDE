<?php
// dashboard/get_my_classes.php
session_start();
require_once '../includes/db.php';

header('Content-Type: application/json');

if(!isset($_SESSION['user_id'])) {
    echo json_encode(['status'=>'error', 'message'=>'Session Expired']);
    exit;
}

$fac_id = $_SESSION['ID_NO'] ?? $_SESSION['user_id']; // Use your session variable for ID
$day_order = intval($_POST['day_order']);

// 1. Query the Matrix Table we just fixed
$sql = "SELECT * FROM timetable_matrix 
        WHERE faculty_id = ? AND day_order = ? 
        ORDER BY hour_slot ASC";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("si", $fac_id, $day_order);
$stmt->execute();
$res = $stmt->get_result();

$classes = [];
while($row = $res->fetch_assoc()) {
    $classes[] = [
        'hour' => $row['hour_slot'],
        'sub_code' => $row['subject_code'],
        'sub_name' => $row['subject_name'],
        'unique_code' => $row['unique_code'], // Contains Dept/Batch/Sem/Sec
        'type' => $row['type']
    ];
}

echo json_encode(['status'=>'success', 'data'=>$classes]);
?>