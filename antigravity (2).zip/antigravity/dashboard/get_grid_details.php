<?php
// get_grid_details.php
header('Content-Type: application/json');
require_once '../includes/db.php';

if (!isset($_GET['id'])) { echo json_encode([]); exit; }

$master_id = intval($_GET['id']);
$grid = [];

$sql = "SELECT day, hour, subject_code, faculty_id, faculty_name, type FROM timetable_details WHERE master_id = $master_id";
$result = $mysqli->query($sql);

while($row = $result->fetch_assoc()) {
    $grid[$row['day']][$row['hour']] = $row;
}

echo json_encode($grid);
?>