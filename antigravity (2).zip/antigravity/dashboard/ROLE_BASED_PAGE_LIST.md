# Role-Based Page List (for header/sidebar menu)

Use `dashboard/role_page_map.php` in `includes/header.php` to render menu items by role.

## Student
- `/dashboard/dashboard.php`
- `/attendance_selection.php`
- `/dashboard/topic_coverage.php`
- `/bonafide.php`
- `/profile.php`

## Faculty
- `/dashboard/dashboard.php`
- `/attendance_selection.php`
- `/dashboard/topic_coverage.php`
- `/dashboard/seminar_hall_booking.php`
- `/mentor_hub.php`
- `/admin/view_circular.php`
- `/profile.php`

## HOD
- `/dashboard/dashboard.php`
- `/attendance_selection.php`
- `/dashboard/topic_coverage.php`
- `/dashboard/seminar_hall_booking.php`
- `/class_advisor_manager.php`
- `/mentor_hub.php`
- `/dashboard/timetable.php?tab=institutional`
- `/profile.php`

## Counsellor
- `/dashboard/dashboard.php`
- `/counselor/counseling_dashboard.php`
- `/profile.php`

## Dean / Dean Academics
- `/dashboard/dashboard.php`
- `/attendance_selection.php`
- `/dashboard/topic_coverage.php`
- `/dashboard/timetable.php?tab=institutional`
- `/admin/manage_circulars.php`
- `/dashboard/seminar_hall_booking.php`
- `/profile.php`

## Principal
- `/dashboard/dashboard.php`
- `/dashboard/analytics.php`
- `/attendance_selection.php`
- `/dashboard/topic_coverage.php`
- `/admin/manage_circulars.php`
- `/dashboard/seminar_hall_booking.php`
- `/bonafide.php`
- `/profile.php`

## Admin
- `/dashboard/dashboard.php`
- `/dashboard/analytics.php`
- `/attendance_selection.php`
- `/dashboard/topic_coverage.php`
- `/admin/manage_circulars.php`
- `/dashboard/seminar_hall_booking.php`
- `/dashboard/fix_seminar_hall_db.php`
- `/dashboard/fix_topic_coverage_db.php`
- `/dashboard/fix_attendance_db.php`
- `/profile.php`

## AO
- `/dashboard/dashboard.php`
- `/dashboard/seminar_hall_booking.php`
- `/dashboard/fix_seminar_hall_db.php`
- `/profile.php`
