<?php
// =========================================================
// 1. BACKEND LOGIC
// =========================================================
ini_set('display_errors', 0);
if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../includes/db.php';

// Auth Check
if (!isset($_SESSION['user_id'])) { header('Location: /login.php'); exit(); }

$role = strtolower($_SESSION['role'] ?? '');
$my_dept = $_SESSION['DEPARTMENT'] ?? '';

// Access Control
if (!in_array($role, ['admin', 'principal', 'dean', 'hod'])) {
    die("Access Denied. This page is for HODs and Admins only.");
}

// ---------------------------------------------------------
// AJAX HANDLERS
// ---------------------------------------------------------
if (isset($_GET['ajax']) && $_GET['ajax'] == '1') {
    header('Content-Type: application/json');
    $action = $_GET['action'] ?? '';

    // 1. SEARCH FACULTY
    if ($action == 'search_faculty') {
        $term = $mysqli->real_escape_string($_GET['term']);
        $sql = "SELECT ID_NO, NAME, DEPARTMENT, DESIGNATION FROM employee_details1 
                WHERE (NAME LIKE '%$term%' OR ID_NO LIKE '%$term%')";
        if ($role == 'hod') { $sql .= " AND DEPARTMENT = '$my_dept'"; }
        $sql .= " LIMIT 10";
        $res = $mysqli->query($sql);
        echo json_encode($res->fetch_all(MYSQLI_ASSOC));
        exit;
    }

    // 2. GET CURRENT MENTEES
    if ($action == 'get_mentees') {
        $fid = $mysqli->real_escape_string($_GET['fid']);
        $sql = "
        SELECT m.id as map_id, s.IDNo as sid, s.Name as name, s.Batch as batch, s.Dept as dept, 'Senior' as type
        FROM mentor_mentee m
        JOIN students_login_master s ON m.Student_ID_No = s.IDNo
        WHERE m.Employee_ID_No = '$fid'
        UNION ALL
        SELECT m.id as map_id, s.id_no as sid, s.student_name as name, s.batch as batch, s.department as dept, 'Fresher' as type
        FROM mentor_mentee m
        JOIN students_batch_25_26 s ON (m.Student_ID_No = s.id_no OR m.Student_ID_No = s.register_no)
        WHERE m.Employee_ID_No = '$fid'";
        $res = $mysqli->query($sql);
        echo json_encode(['data' => $res->fetch_all(MYSQLI_ASSOC)]);
        exit;
    }

    // 3. SEARCH STUDENTS (For manual search in Add Modal)
    if ($action == 'search_students') {
        $term = $mysqli->real_escape_string($_GET['term']);
        $results = [];

        // Search Seniors
        $q1 = "SELECT IDNo as id, Name as name, Batch as batch, Dept as dept, 'Senior' as type FROM students_login_master 
               WHERE IDNo LIKE '%$term%' OR Name LIKE '%$term%' LIMIT 5";
        $r1 = $mysqli->query($q1);
        while($row = $r1->fetch_assoc()) $results[] = $row;

        // Search Freshers
        $q2 = "SELECT id_no as id, student_name as name, batch as batch, department as dept, 'Fresher' as type FROM students_batch_25_26 
               WHERE id_no LIKE '%$term%' OR student_name LIKE '%$term%' LIMIT 5";
        $r2 = $mysqli->query($q2);
        while($row = $r2->fetch_assoc()) $results[] = $row;

        // Check Allocation Status
        foreach ($results as &$stu) {
            $sid = $stu['id'];
            $chk = $mysqli->query("SELECT m.Employee_ID_No, e.NAME as mentor_name 
                                   FROM mentor_mentee m 
                                   JOIN employee_details1 e ON m.Employee_ID_No = e.ID_NO 
                                   WHERE m.Student_ID_No = '$sid' LIMIT 1");
            if ($chk && $chk->num_rows > 0) {
                $m = $chk->fetch_assoc();
                $stu['status'] = 'assigned';
                $stu['mentor_id'] = $m['Employee_ID_No'];
                $stu['mentor_name'] = $m['mentor_name'];
            } else {
                $stu['status'] = 'free';
            }
        }
        echo json_encode($results);
        exit;
    }

    // 4. GET SUGGESTED UNMAPPED (Auto-load for Faculty's Dept)
    if ($action == 'get_dept_suggestions') {
        $fac_dept = $mysqli->real_escape_string($_GET['dept']);
        $results = [];

        // Seniors Unmapped in Dept
        $sql1 = "SELECT s.IDNo as id, s.Name as name, s.Batch as batch, s.Dept as dept, 'Senior' as type 
                 FROM students_login_master s
                 LEFT JOIN mentor_mentee m ON s.IDNo = m.Student_ID_No
                 WHERE m.Student_ID_No IS NULL AND s.Dept = '$fac_dept' LIMIT 100";
        
        // Freshers Unmapped in Dept
        $sql2 = "SELECT s.id_no as id, s.student_name as name, s.batch as batch, s.department as dept, 'Fresher' as type 
                 FROM students_batch_25_26 s
                 LEFT JOIN mentor_mentee m ON s.id_no = m.Student_ID_No
                 WHERE m.Student_ID_No IS NULL AND s.department = '$fac_dept' LIMIT 100";

        $r1 = $mysqli->query($sql1);
        if($r1) while($row = $r1->fetch_assoc()) { $row['status']='free'; $results[] = $row; }

        $r2 = $mysqli->query($sql2);
        if($r2) while($row = $r2->fetch_assoc()) { $row['status']='free'; $results[] = $row; }

        echo json_encode(['data' => $results]);
        exit;
    }

    // 5. BULK ASSIGN
    if ($action == 'assign_bulk') {
        $fid = $mysqli->real_escape_string($_POST['fid']);
        $sids = explode(',', $_POST['sids']);
        $count = 0;
        foreach ($sids as $sid) {
            $sid = trim($sid);
            if(empty($sid)) continue;
            // Get Meta
            $dept = ''; $batch = '';
            $q = $mysqli->query("SELECT Dept, Batch FROM students_login_master WHERE IDNo='$sid'");
            if($q->num_rows){ $d=$q->fetch_assoc(); $dept=$d['Dept']; $batch=$d['Batch']; }
            else {
                $q = $mysqli->query("SELECT department, batch FROM students_batch_25_26 WHERE id_no='$sid'");
                if($q->num_rows){ $d=$q->fetch_assoc(); $dept=$d['department']; $batch=$d['batch']; }
            }
            // Upsert
            $chk = $mysqli->query("SELECT id FROM mentor_mentee WHERE Student_ID_No='$sid'");
            if($chk->num_rows > 0) $mysqli->query("UPDATE mentor_mentee SET Employee_ID_No='$fid' WHERE Student_ID_No='$sid'");
            else {
                $stmt = $mysqli->prepare("INSERT INTO mentor_mentee (Student_ID_No, Employee_ID_No, department, batch) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssss", $sid, $fid, $dept, $batch);
                $stmt->execute();
            }
            $count++;
        }
        echo json_encode(['success' => true, 'count' => $count]);
        exit;
    }

    // 6. REMOVE BULK
    if ($action == 'remove_bulk') {
        $sids = explode(',', $_POST['sids']);
        $sids_str = "'" . implode("','", array_map([$mysqli, 'real_escape_string'], $sids)) . "'";
        $mysqli->query("DELETE FROM mentor_mentee WHERE Student_ID_No IN ($sids_str)");
        echo json_encode(['success' => true]);
        exit;
    }
}

// =========================================================
// 2. UI INTEGRATION
// =========================================================
$dept_options = [];
if ($role == 'admin' || $role == 'principal') {
    $dres = $mysqli->query("SELECT DISTINCT Dept FROM students_login_master ORDER BY Dept");
    while($r = $dres->fetch_assoc()) $dept_options[] = $r['Dept'];
}

include '../includes/header.php';
?>

<style>
    .pwa-container { max-width: 1400px; margin: 0 auto; padding: 25px; min-height: 85vh; }
    .dash-banner {
        background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.5); border-radius: 24px; padding: 25px;
        display: flex; justify-content: space-between; align-items: center;
        box-shadow: 0 10px 40px -10px rgba(0,0,0,0.08); margin-bottom: 30px;
    }
    .insta-gradient-text {
        background: -webkit-linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888);
        -webkit-background-clip: text; -webkit-text-fill-color: transparent; font-weight: 800;
    }
    .manager-grid { display: grid; grid-template-columns: 1fr 2fr; gap: 30px; align-items: start; }
    .saas-card {
        background: white; border-radius: 20px; padding: 0; 
        box-shadow: 0 5px 20px rgba(0,0,0,0.03); border: 1px solid rgba(0,0,0,0.03);
        overflow: hidden; display: flex; flex-direction: column;
    }
    .card-head { padding: 20px; border-bottom: 1px solid #f1f5f9; background: #fafafa; font-weight: 700; color: #475569; display: flex; justify-content: space-between; align-items: center; }
    .card-body { padding: 20px; flex: 1; position: relative; }
    .fac-item {
        padding: 12px; border-radius: 12px; cursor: pointer; transition: 0.2s;
        display: flex; align-items: center; gap: 12px; border: 1px solid transparent; margin-bottom: 5px;
    }
    .fac-item:hover { background: #fdf2f8; }
    .fac-item.active { background: #fdf2f8; border-color: #bc1888; }
    .fac-av { width: 40px; height: 40px; border-radius: 50%; background: #ddd; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #555; }
    .stu-list { max-height: 500px; overflow-y: auto; }
    .stu-row { display: flex; align-items: center; justify-content: space-between; padding: 10px; border-bottom: 1px solid #f1f5f9; }
    .chk-custom { width: 18px; height: 18px; cursor: pointer; accent-color: #bc1888; }
    .badge-soft { padding: 4px 10px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; }
    .bg-green { background: #dcfce7; color: #166534; }
    .bg-red { background: #fee2e2; color: #991b1b; }
    .bg-blue { background: #e0f2fe; color: #0284c7; }
    .bg-purple { background: #f3e8ff; color: #7e22ce; }
    .bg-orange { background: #ffedd5; color: #c2410c; }
    .search-inp { width: 100%; padding: 10px 15px; border-radius: 10px; border: 1px solid #e2e8f0; background: #f8fafc; outline: none; }
    .search-inp:focus { border-color: #bc1888; background: white; }
    .btn-insta { background: var(--inst-grad); color: white; border: none; padding: 8px 20px; border-radius: 50px; font-weight: 600; cursor: pointer; }
    .btn-danger-soft { background: #fee2e2; color: #dc2626; border: none; padding: 8px 16px; border-radius: 50px; font-weight: 600; cursor: pointer; }
    .loader-ol { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(255,255,255,0.8); display: none; align-items: center; justify-content: center; z-index: 10; }
    @media(max-width: 900px) { .manager-grid { grid-template-columns: 1fr; } }
</style>

<main class="pwa-container">

    <div class="dash-banner">
        <div>
            <h1 style="margin:0; font-size:1.8rem;" class="insta-gradient-text">Mentor Allocation</h1>
            <p style="margin:5px 0 0; color:#64748b;">Manage Faculty-Student Mapping</p>
        </div>
        <div>
            <span class="badge-soft bg-green">Scope: <?= ($role=='admin') ? 'Global' : $_SESSION['DEPARTMENT'] ?></span>
        </div>
    </div>

    <div class="manager-grid">
        <div class="saas-card" style="height: 650px;">
            <div class="card-head">
                <span>Select Faculty</span>
                <?php if($role == 'admin'): ?>
                <select id="adminFacDeptFilter" class="form-select form-select-sm" style="width:120px;" onchange="searchFaculty()">
                    <option value="all">All Depts</option>
                    <?php foreach($dept_options as $d) echo "<option value='$d'>$d</option>"; ?>
                </select>
                <?php endif; ?>
            </div>
            <div style="padding: 15px; border-bottom: 1px solid #f1f5f9;">
                <input type="text" id="facSearch" class="search-inp" placeholder="Search Faculty Name/ID..." onkeyup="searchFaculty()">
            </div>
            <div class="card-body" style="overflow-y: auto; padding: 10px;" id="facList">
                <div style="text-align: center; color: #94a3b8; padding-top: 50px;">
                    <i class="fas fa-chalkboard-teacher" style="font-size: 2rem; margin-bottom: 10px; opacity: 0.3;"></i>
                    <p>Search faculty to manage</p>
                </div>
            </div>
        </div>

        <div class="saas-card" style="height: 650px;">
            <div id="loader" class="loader-ol"><div class="spinner-border text-primary"></div></div>
            <div class="card-head">
                <div id="selectedFacName" style="font-size: 1.1rem; color: #1e293b;">Select a faculty first</div>
                <div id="facActions" style="display:none; gap: 10px;">
                    <button class="btn-danger-soft" onclick="removeSelected()">Remove</button>
                    <button class="btn-insta" onclick="openAddModal()">+ Add</button>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="stu-list" id="menteeList">
                    <div style="text-align: center; color: #94a3b8; padding-top: 100px;">
                        <i class="fas fa-users" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.3;"></i>
                        <p>Mentee list will appear here</p>
                    </div>
                </div>
            </div>
            <div style="padding: 15px; background: #fafafa; border-top: 1px solid #eee; font-size: 0.85rem; font-weight: 600; color: #64748b;">
                <span id="countDisplay">0 Mentees</span>
            </div>
        </div>
    </div>

</main>

<div class="modal fade" id="addModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content" style="border-radius: 20px; border:none;">
      <div class="modal-header border-0">
        <h5 class="modal-title fw-bold">Add Mentees to <span id="addModalFacName" class="text-primary"></span></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
          <div class="d-flex gap-2 mb-3">
              <?php if($role == 'admin'): ?>
              <select id="adminStuDeptFilter" class="form-select form-select-sm" style="max-width:150px;" onchange="autoLoadAddSuggestions()">
                  <option value="">All Depts</option>
                  <?php foreach($dept_options as $d) echo "<option value='$d'>$d</option>"; ?>
              </select>
              <?php endif; ?>
              <input type="text" id="stuSearch" class="search-inp" placeholder="Search other specific Student ID..." onkeyup="searchStudents()">
          </div>
          
          <div class="alert alert-info border-0 bg-blue text-dark small mb-2">
              <i class="fas fa-magic me-2"></i> Showing unmapped students from <strong><span id="suggestionDept">...</span></strong>
          </div>

          <div id="stuResults" style="max-height: 300px; overflow-y: auto; border: 1px solid #eee; border-radius: 10px;">
              </div>
          
          <div class="mt-3 p-3 bg-light rounded-3">
              <strong>Selected:</strong> <span id="selCount">0</span>
              <div id="selTags" style="margin-top: 10px; display: flex; flex-wrap: wrap; gap: 5px;"></div>
          </div>
      </div>
      <div class="modal-footer border-0">
        <button class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
        <button class="btn-insta" onclick="commitAdd()">Confirm Allocation</button>
      </div>
    </div>
  </div>
</div>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    let currentFacId = null;
    let currentFacDept = '';
    let selectedToAdd = new Set(); 

    function getYearTag(batch) {
        if(!batch) return '';
        const startYear = parseInt(batch.split('-')[0]);
        const currentYear = new Date().getFullYear();
        const currentMonth = new Date().getMonth() + 1; 
        const acadYear = (currentMonth < 6) ? currentYear - 1 : currentYear;
        const diff = acadYear - startYear + 1;
        if(diff === 1) return '<span class="badge-soft bg-purple">I Year</span>';
        if(diff === 2) return '<span class="badge-soft bg-blue">II Year</span>';
        if(diff === 3) return '<span class="badge-soft bg-orange">III Year</span>';
        if(diff === 4) return '<span class="badge-soft bg-green">IV Year</span>';
        return '<span class="badge-soft bg-light">' + diff + ' Year</span>';
    }

    // --- MANAGE ---
    document.addEventListener("DOMContentLoaded", () => {
        searchFaculty();
    });

    function searchFaculty() {
        const term = document.getElementById('facSearch').value;
        let deptFilter = 'all';
        const dDrp = document.getElementById('adminFacDeptFilter');
        if(dDrp) deptFilter = dDrp.value;

        fetch(`?ajax=1&action=search_faculty&term=${term}&dept=${deptFilter}`)
        .then(r => r.json()).then(data => {
            const list = document.getElementById('facList');
            list.innerHTML = '';
            if(data.length === 0) list.innerHTML = '<div style="text-align:center; padding:20px; color:#ccc;">No faculty found.</div>';
            data.forEach(f => {
                list.innerHTML += `<div class="fac-item" onclick="selectFaculty('${f.ID_NO}', '${f.NAME}', '${f.DEPARTMENT}')">
                    <div class="fac-av">${f.NAME[0]}</div>
                    <div><div style="font-weight:700;">${f.NAME}</div><div style="font-size:0.75rem; color:#64748b;">${f.ID_NO} • ${f.DEPARTMENT}</div></div>
                </div>`;
            });
        });
    }

    function selectFaculty(fid, name, dept) {
        currentFacId = fid;
        currentFacDept = dept;
        document.getElementById('selectedFacName').innerText = name;
        document.getElementById('facActions').style.display = 'flex';
        loadMentees();
    }

    function loadMentees() {
        document.getElementById('loader').style.display = 'flex';
        fetch(`?ajax=1&action=get_mentees&fid=${currentFacId}`).then(r=>r.json()).then(res=>{
            const list = document.getElementById('menteeList');
            list.innerHTML = '';
            if(res.data.length === 0) list.innerHTML = '<div style="text-align:center; padding:40px; color:#ccc;">No mentees assigned.</div>';
            else res.data.forEach(s => {
                list.innerHTML += `<div class="stu-row"><div style="display:flex; align-items:center; gap:10px;">
                    <input type="checkbox" class="chk-custom remove-chk" value="${s.sid}">
                    <div><div style="font-weight:600;">${s.name} ${getYearTag(s.batch)}</div><div style="font-size:0.8rem; color:#64748b;">${s.sid} • ${s.batch}</div></div>
                </div><span class="badge-soft bg-green">${s.dept}</span></div>`;
            });
            document.getElementById('countDisplay').innerText = res.data.length + ' Mentees';
            document.getElementById('loader').style.display = 'none';
        });
    }

    // --- ADD MODAL ---
    const addModal = new bootstrap.Modal(document.getElementById('addModal'));
    function openAddModal() {
        if(!currentFacId) return alert("Select a faculty first!");
        selectedToAdd.clear(); updateSelUI();
        document.getElementById('stuSearch').value = '';
        document.getElementById('addModalFacName').innerText = document.getElementById('selectedFacName').innerText;
        
        // Auto-select filter to faculty's dept
        const adminFilter = document.getElementById('adminStuDeptFilter');
        if(adminFilter) adminFilter.value = currentFacDept;
        
        autoLoadAddSuggestions();
        addModal.show();
    }

    function autoLoadAddSuggestions() {
        let targetDept = currentFacDept;
        const adminFilter = document.getElementById('adminStuDeptFilter');
        if(adminFilter && adminFilter.value) targetDept = adminFilter.value;

        document.getElementById('suggestionDept').innerText = targetDept || 'All';
        document.getElementById('stuResults').innerHTML = '<div class="text-center p-4"><div class="spinner-border text-primary"></div></div>';
        
        fetch(`?ajax=1&action=get_dept_suggestions&dept=${targetDept}`)
        .then(r => r.json())
        .then(data => renderAddList(data.data));
    }

    function searchStudents() {
        const term = document.getElementById('stuSearch').value;
        let targetDept = 'all';
        const adminFilter = document.getElementById('adminStuDeptFilter');
        if(adminFilter) targetDept = adminFilter.value;

        if(term.length < 3) return; // Wait for input
        
        fetch(`?ajax=1&action=search_students&term=${term}&dept=${targetDept}`)
        .then(r => r.json())
        .then(data => renderAddList(data));
    }

    function renderAddList(data) {
        const box = document.getElementById('stuResults');
        box.innerHTML = '';
        if(!data || data.length === 0) {
            box.innerHTML = '<div class="p-3 text-muted text-center">No unmapped students found.</div>';
            return;
        }
        data.forEach(s => {
            let statusHtml = (s.status === 'assigned') 
                ? (s.mentor_id === currentFacId ? '<span class="badge-soft bg-green">Mapped</span>' : `<span class="badge-soft bg-red">To: ${s.mentor_name}</span>`) 
                : '<span class="badge-soft bg-blue">Free</span>';
            const isChecked = selectedToAdd.has(s.id) ? 'checked' : '';
            box.innerHTML += `<div class="stu-row p-2"><div style="display:flex; align-items:center; gap:10px;">
                <input type="checkbox" class="chk-custom" onchange="toggleAdd('${s.id}')" ${isChecked}>
                <div><div style="font-weight:600;">${s.name} ${getYearTag(s.batch)}</div><div style="font-size:0.75rem; color:#64748b;">${s.id}</div></div>
            </div>${statusHtml}</div>`;
        });
    }

    function toggleAdd(sid) {
        if(selectedToAdd.has(sid)) selectedToAdd.delete(sid); else selectedToAdd.add(sid);
        updateSelUI();
    }

    function updateSelUI() {
        document.getElementById('selCount').innerText = selectedToAdd.size;
        const tagBox = document.getElementById('selTags');
        tagBox.innerHTML = '';
        selectedToAdd.forEach(id => tagBox.innerHTML += `<span class="badge-soft bg-blue">${id}</span>`);
    }

    function commitAdd() {
        if(selectedToAdd.size === 0) return;
        const fd = new FormData(); fd.append('fid', currentFacId); fd.append('sids', Array.from(selectedToAdd).join(','));
        fetch('?ajax=1&action=assign_bulk', {method:'POST', body:fd}).then(r=>r.json()).then(res=>{
            addModal.hide(); loadMentees();
        });
    }

    function removeSelected() {
        const chks = document.querySelectorAll('.remove-chk:checked');
        if(chks.length === 0) return alert("Select students to remove.");
        if(!confirm(`Remove ${chks.length} students?`)) return;
        const ids = Array.from(chks).map(c => c.value).join(',');
        const fd = new FormData(); fd.append('sids', ids);
        fetch('?ajax=1&action=remove_bulk', {method:'POST', body:fd}).then(r=>r.json()).then(res=>{ loadMentees(); });
    }
</script>

<?php 
include '../assets/ui/floating_chat_widget.php';
include '../includes/footer.php'; 
?>