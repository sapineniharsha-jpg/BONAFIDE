<?php
// admin_day_order.php - DEDICATED DAY ORDER MANAGER
// Features: Batch-wise, UG/PG, Overwrite Capability
session_start();
require_once '../includes/db.php';

// 1. SECURITY CHECK
$role = strtoupper($_SESSION['role'] ?? '');
if (!in_array($role, ['ADMIN', 'PRINCIPAL', 'DEAN'])) {
    die("<h2 style='font-family:sans-serif; text-align:center; margin-top:50px;'>⛔ Access Denied. Admin Only.</h2>");
}

// 2. HANDLE FORM SUBMISSION
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['date'];
    $day_order = $_POST['day_order'];
    $program = $_POST['program']; // UG, PG, or ALL
    $batch = $_POST['batch'];     // 2023, 2024, or ALL
    $overwrite = isset($_POST['overwrite']); // Checkbox

    if ($overwrite) {
        // UPSERT LOGIC: Insert or Update if exists
        $stmt = $mysqli->prepare("INSERT INTO academic_calendar 
            (calendar_date, day_order, program_type, target_batch, updated_by) 
            VALUES (?, ?, ?, ?, ?) 
            ON DUPLICATE KEY UPDATE day_order = ?, updated_by = ?");
        
        $admin_id = $_SESSION['ID_NO'] ?? 'ADMIN';
        $stmt->bind_param("sisssis", $date, $day_order, $program, $batch, $admin_id, $day_order, $admin_id);
        
        if ($stmt->execute()) {
            $message = "<div class='alert success'>✅ Day Order Updated Successfully!</div>";
        } else {
            $message = "<div class='alert error'>❌ Error: " . $stmt->error . "</div>";
        }
    } else {
        // SAFE INSERT: Fail if rule exists
        $check = $mysqli->query("SELECT id FROM academic_calendar WHERE calendar_date='$date' AND program_type='$program' AND target_batch='$batch'");
        if ($check->num_rows > 0) {
            $message = "<div class='alert warning'>⚠️ Rule already exists for this Date/Batch. Check 'Overwrite' to update it.</div>";
        } else {
            // Insert
            $stmt = $mysqli->prepare("INSERT INTO academic_calendar (calendar_date, day_order, program_type, target_batch, updated_by) VALUES (?, ?, ?, ?, ?)");
            $admin_id = $_SESSION['ID_NO'] ?? 'ADMIN';
            $stmt->bind_param("sisss", $date, $day_order, $program, $batch, $admin_id);
            if ($stmt->execute()) $message = "<div class='alert success'>✅ Saved Successfully!</div>";
            else $message = "<div class='alert error'>❌ Error: " . $stmt->error . "</div>";
        }
    }
}

// 3. FETCH EXISTING RULES FOR DISPLAY
$history = $mysqli->query("SELECT * FROM academic_calendar ORDER BY calendar_date DESC, updated_at DESC LIMIT 20");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Day Orders</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#bc1888">
    <script src="/assets/js/pwa-init.js" defer></script>
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="VTHT Portal">
    <link rel="apple-touch-icon" href="assets/images/icon-192.png">
       <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <style>
        :root { --insta: linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888); --bg: #f8fafc; --text: #1e293b; }
        body { font-family: 'Outfit', sans-serif; background: var(--bg); color: var(--text); margin: 0; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; }
        
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .back-btn { text-decoration: none; color: #64748b; font-weight: 600; display: flex; align-items: center; gap: 5px; }
        
        .card { background: white; border-radius: 20px; padding: 30px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }
        .card-title { margin-top: 0; background: var(--insta); -webkit-background-clip: text; -webkit-text-fill-color: transparent; font-size: 1.8rem; font-weight: 900; }
        
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 20px; }
        .form-group label { display: block; font-weight: 700; color: #64748b; margin-bottom: 8px; font-size: 0.9rem; }
        .form-control { width: 100%; padding: 12px; border-radius: 10px; border: 2px solid #e2e8f0; font-family: inherit; font-size: 1rem; outline: none; transition: 0.3s; }
        .form-control:focus { border-color: #e1306c; box-shadow: 0 0 0 3px rgba(225, 48, 108, 0.1); }
        
        .checkbox-wrapper { display: flex; align-items: center; gap: 10px; margin-top: 20px; padding: 15px; background: #fff1f2; border-radius: 10px; border: 1px solid #fecdd3; color: #be123c; font-weight: 600; }
        input[type="checkbox"] { width: 20px; height: 20px; accent-color: #e1306c; }
        
        .btn-submit { width: 100%; margin-top: 25px; padding: 15px; background: var(--insta); color: white; border: none; border-radius: 12px; font-size: 1.1rem; font-weight: 800; cursor: pointer; transition: 0.3s; }
        .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 10px 20px rgba(220, 39, 67, 0.3); }
        
        .alert { padding: 15px; border-radius: 10px; margin-bottom: 20px; font-weight: 600; }
        .alert.success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .alert.error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        .alert.warning { background: #fef9c3; color: #854d0e; border: 1px solid #fde047; }
        
        .history-list { margin-top: 40px; }
        .rule-item { background: white; padding: 15px; border-radius: 12px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center; border: 1px solid #f1f5f9; }
        .badge { padding: 4px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; }
        .badge-ug { background: #dbeafe; color: #1e40af; }
        .badge-pg { background: #fae8ff; color: #86198f; }
        .badge-all { background: #f1f5f9; color: #475569; }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <a href="attendance_selection.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        <div style="font-weight:700; color:#64748b;">Admin: <?= $_SESSION['ID_NO'] ?? 'Unknown' ?></div>
    </div>

    <?= $message ?>

    <div class="card">
        <h2 class="card-title"><i class="fas fa-calendar-alt"></i> Set Day Order Rules</h2>
        <p style="color:#64748b; margin-bottom:20px;">Configure specific day orders for different batches or programs.</p>
        
        <form method="POST">
            <div class="form-grid">
                <div class="form-group">
                    <label>Select Date</label>
                    <input type="date" name="date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Program Type</label>
                    <select name="program" class="form-control">
                        <option value="ALL">ALL Programs (Default)</option>
                        <option value="UG">UG (Undergraduate)</option>
                        <option value="PG">PG (Postgraduate)</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Target Batch</label>
                    <select name="batch" class="form-control">
                        <option value="ALL">ALL Batches (Default)</option>
                        <option value="2022">2022</option>
                        <option value="2023">2023</option>
                        <option value="2024">2024</option>
                        <option value="2025">2025</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Day Order</label>
                    <select name="day_order" class="form-control" required>
                        <option value="1">Day Order 1</option>
                        <option value="2">Day Order 2</option>
                        <option value="3">Day Order 3</option>
                        <option value="4">Day Order 4</option>
                        <option value="5">Day Order 5</option>
                    </select>
                </div>
            </div>

            <div class="checkbox-wrapper">
                <input type="checkbox" name="overwrite" id="ovr">
                <label for="ovr" style="margin:0; cursor:pointer;">Overwrite existing rule if found?</label>
            </div>

            <button type="submit" class="btn-submit">Save Day Order Rule</button>
        </form>
    </div>

    <div class="history-list">
        <h3 style="color:#334155;">Recent Rules Set</h3>
        <?php while($row = $history->fetch_assoc()): ?>
        <div class="rule-item">
            <div>
                <div style="font-weight:800; font-size:1.1rem; color:#1e293b;">
                    <?= date('d M Y', strtotime($row['calendar_date'])) ?>
                    <span style="color:#e1306c; margin-left:10px;">Day Order <?= $row['day_order'] ?></span>
                </div>
                <div style="margin-top:5px; display:flex; gap:5px;">
                    <span class="badge badge-<?= strtolower($row['program_type']) ?>"><?= $row['program_type'] ?></span>
                    <span class="badge badge-all">Batch: <?= $row['target_batch'] ?></span>
                </div>
            </div>
            <div style="text-align:right; font-size:0.8rem; color:#94a3b8;">
                Updated by <b><?= $row['updated_by'] ?></b><br>
                <?= date('h:i A', strtotime($row['updated_at'])) ?>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

</body>
</html>