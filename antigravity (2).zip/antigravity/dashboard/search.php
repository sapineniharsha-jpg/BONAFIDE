<?php
// =========================================================
// 1. BUSINESS LOGIC (PRESERVED)
// =========================================================
if (session_status() === PHP_SESSION_NONE) session_start();
$root = $_SERVER['DOCUMENT_ROOT'];
require_once '../includes/db.php';

// Auth Check (Adjusted to match your portal's session keys)
if (!isset($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit();
}

// ---------------------------------------------------------
// AJAX HANDLER
// ---------------------------------------------------------
if (isset($_GET['ajax']) && $_GET['ajax'] == '1') {
    header('Content-Type: application/json');
    
    $action = $_GET['action'] ?? 'search';
    
    // ACTION 1: SEARCH MAIN RECORDS
    if ($action == 'search') {
        $type = $_GET['type'] ?? 'all';
        $dept = $_GET['dept'] ?? 'all';
        $term = trim($_GET['q'] ?? '');
        $results = [];

        // 1. SEARCH FACULTY
        if ($type == 'all' || $type == 'faculty') {
            $sql = "SELECT ID_NO as id, NAME as name, DEPARTMENT as dept, DESIGNATION as role, 'faculty' as type, college_email as email 
                    FROM employee_details WHERE 1=1";
            if ($dept != 'all') $sql .= " AND DEPARTMENT LIKE '%$dept%'";
            if ($term) $sql .= " AND (NAME LIKE '%$term%' OR ID_NO LIKE '%$term%')";
            $sql .= " LIMIT 20";
            
            $res = $mysqli->query($sql);
            if($res) $results = array_merge($results, $res->fetch_all(MYSQLI_ASSOC));
        }

        // 2. SEARCH STUDENTS
        if ($type == 'all' || $type == 'student') {
            $sql = "SELECT IDNo as id, NAME as name, Dept as dept, Batch as batch, 'Student' as role, 'student' as type 
                    FROM students_login_master WHERE 1=1";
            
            if ($dept != 'all') $sql .= " AND Dept LIKE '%$dept%'";
            if ($term) {
                $sql .= " AND (NAME LIKE '%$term%' OR IDNo LIKE '%$term%' OR Batch LIKE '%$term%')";
            }
            $sql .= " LIMIT 20";

            $res = $mysqli->query($sql);
            if($res) $results = array_merge($results, $res->fetch_all(MYSQLI_ASSOC));
        }

        // 3. SEARCH MENTORS
        if ($type == 'mentor') {
            $sql = "SELECT e.ID_NO as id, e.NAME as name, e.DEPARTMENT as dept, 'Mentor' as role, 'mentor' as type,
                    (SELECT COUNT(*) FROM students_login_master s WHERE s.counsellor_id = e.ID_NO) as student_count,
                    (SELECT NAME FROM employee_details h WHERE h.DEPARTMENT = e.DEPARTMENT AND h.DESIGNATION LIKE '%HOD%' LIMIT 1) as hod_name
                    FROM employee_details e WHERE 1=1";
            
            if ($dept != 'all') $sql .= " AND e.DEPARTMENT LIKE '%$dept%'";
            if ($term) $sql .= " AND (e.NAME LIKE '%$term%' OR e.ID_NO LIKE '%$term%')";
            
            $sql .= " HAVING student_count > 0 LIMIT 20";

            $res = $mysqli->query($sql);
            if($res) $results = array_merge($results, $res->fetch_all(MYSQLI_ASSOC));
        }

        echo json_encode(['success' => true, 'data' => $results]);
        exit;
    }

    // ACTION 2: GET MENTEE LIST
    if ($action == 'get_mentees') {
        $mentor_id = $mysqli->real_escape_string($_GET['mentor_id']);
        
        $sql = "SELECT s.IDNo, s.NAME, s.Batch, s.VH_No, s.Dept,
                c.NAME as class_advisor_name
                FROM students_login_master s
                LEFT JOIN employee_details c ON s.class_advisor_id = c.ID_NO
                WHERE s.counsellor_id = '$mentor_id'";
        
        $res = $mysqli->query($sql);
        $students = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
        
        echo json_encode(['success' => true, 'students' => $students]);
        exit;
    }
}

// INITIAL DATA
$depts = $mysqli->query("SELECT DISTINCT Dept FROM students_login_master ORDER BY Dept")->fetch_all(MYSQLI_ASSOC);
$initial_term = $_GET['q'] ?? '';

// =========================================================
// 2. PORTAL INTEGRATION
// =========================================================
include '../includes/header.php';
?>

<style>
    .pwa-container { max-width: 1200px; margin: 0 auto; padding: 25px; min-height: 80vh; }

    /* Search Controls */
    .search-card {
        background: white; border-radius: 24px; padding: 30px;
        box-shadow: 0 10px 40px -10px rgba(0,0,0,0.08); margin-bottom: 30px;
        border: 1px solid rgba(0,0,0,0.02);
    }
    
    .search-grid { display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 20px; align-items: end; }
    
    .f-label { font-size: 0.75rem; font-weight: 700; text-transform: uppercase; color: #64748b; margin-bottom: 8px; display: block; }
    .f-input, .f-select {
        width: 100%; padding: 12px 20px; border-radius: 12px; border: 1px solid #e2e8f0;
        background: #f8fafc; font-size: 0.95rem; outline: none; transition: 0.2s;
    }
    .f-input:focus, .f-select:focus { border-color: #bc1888; background: white; box-shadow: 0 0 0 3px rgba(188, 24, 136, 0.1); }

    .btn-search {
        background: var(--inst-grad); color: white; border: none; padding: 12px 30px;
        border-radius: 12px; font-weight: 700; cursor: pointer; transition: 0.3s; height: 46px;
    }
    .btn-search:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(188, 24, 136, 0.3); color: white; }

    /* Results Grid */
    .results-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
    
    .res-card {
        background: white; border-radius: 16px; padding: 20px; border: 1px solid #f1f5f9;
        transition: 0.2s; cursor: pointer; position: relative; overflow: hidden;
        display: flex; align-items: center; gap: 15px;
    }
    .res-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.05); border-color: #bc1888; }
    
    .res-av {
        width: 50px; height: 50px; border-radius: 12px; background: #fdf2f8; 
        color: #bc1888; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; font-weight: 800;
    }
    .res-info h4 { margin: 0 0 3px 0; font-size: 1rem; color: #1e293b; }
    .res-info p { margin: 0; font-size: 0.8rem; color: #64748b; }
    .res-badge { 
        position: absolute; top: 15px; right: 15px; font-size: 0.65rem; 
        padding: 4px 10px; border-radius: 20px; text-transform: uppercase; font-weight: 700;
    }
    .bg-student { background: #dcfce7; color: #166534; }
    .bg-faculty { background: #e0f2fe; color: #0369a1; }
    .bg-mentor { background: #fce7f3; color: #9d174d; }

    /* Modal */
    .modal-content { border-radius: 24px; border: none; overflow: hidden; }
    .modal-header { background: var(--inst-grad); color: white; border: none; padding: 20px 30px; }
    .table th { font-size: 0.75rem; text-transform: uppercase; color: #64748b; font-weight: 700; background: #f8fafc; }
    
    @media(max-width: 900px) {
        .search-grid { grid-template-columns: 1fr; }
        .btn-search { width: 100%; }
    }
</style>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<main class="pwa-container">

    <div class="search-card">
        <h2 style="margin:0 0 20px 0; font-weight:800; color:#1e293b;">Global Search</h2>
        <form id="searchForm" onsubmit="event.preventDefault(); doSearch();">
            <div class="search-grid">
                <div>
                    <label class="f-label">Search Term</label>
                    <input type="text" id="q" class="f-input" value="<?= htmlspecialchars($initial_term) ?>" placeholder="Name, ID, or Batch (e.g. 2025)...">
                </div>
                <div>
                    <label class="f-label">Category</label>
                    <select id="type" class="f-select">
                        <option value="all">All Records</option>
                        <option value="faculty">Faculty</option>
                        <option value="student">Students</option>
                        <option value="mentor">Mentor Groups</option>
                    </select>
                </div>
                <div>
                    <label class="f-label">Department</label>
                    <select id="dept" class="f-select">
                        <option value="all">All Depts</option>
                        <?php foreach($depts as $d): ?>
                            <option value="<?= $d['Dept'] ?>"><?= $d['Dept'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <button type="submit" class="btn-search"><i class="fas fa-search me-2"></i> Find</button>
                </div>
            </div>
        </form>
    </div>

    <div id="resultsArea" class="results-grid">
        <div style="grid-column:1/-1; text-align:center; padding:40px; color:#94a3b8;">
            <i class="fas fa-search" style="font-size:3rem; margin-bottom:15px; opacity:0.3;"></i>
            <p>Enter a term to start searching</p>
        </div>
    </div>

</main>

<div class="modal fade" id="mentorModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold" id="mName">Mentor Details</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead>
                    <tr>
                        <th class="ps-4">ID</th>
                        <th>Name</th>
                        <th>Batch</th>
                        <th>Class Advisor</th>
                    </tr>
                </thead>
                <tbody id="mList"></tbody>
            </table>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function doSearch() {
        const q = document.getElementById('q').value;
        const type = document.getElementById('type').value;
        const dept = document.getElementById('dept').value;
        const area = document.getElementById('resultsArea');
        
        area.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:40px;"><div class="spinner-border text-primary"></div></div>';

        fetch(`search.php?ajax=1&action=search&q=${q}&type=${type}&dept=${dept}`)
        .then(r => r.json())
        .then(d => {
            if(!d.data.length) {
                area.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:40px; color:#94a3b8;">No records found</div>';
                return;
            }
            
            let h = '';
            d.data.forEach(item => {
                let badge = item.type;
                let click = '';
                let extra = item.dept;
                
                if(item.type === 'student') click = `location.href='../student_profile.php?id=${item.id}'`;
                if(item.type === 'faculty') click = `alert('Faculty Profile: ${item.name}')`; // Placeholder
                if(item.type === 'mentor') {
                    click = `openMentor('${item.id}', '${item.name}')`;
                    extra += ` • ${item.student_count} Students`;
                }

                h += `
                <div class="res-card" onclick="${click}">
                    <div class="res-av">${item.name[0]}</div>
                    <div class="res-info">
                        <h4>${item.name}</h4>
                        <p>${item.id} • ${extra}</p>
                    </div>
                    <span class="res-badge bg-${item.type}">${item.type}</span>
                </div>`;
            });
            area.innerHTML = h;
        });
    }

    const mModal = new bootstrap.Modal(document.getElementById('mentorModal'));

    function openMentor(mid, name) {
        document.getElementById('mName').innerText = name + "'s Mentees";
        document.getElementById('mList').innerHTML = '<tr><td colspan="4" class="text-center p-4">Loading...</td></tr>';
        mModal.show();

        fetch(`search.php?ajax=1&action=get_mentees&mentor_id=${mid}`)
        .then(r => r.json())
        .then(d => {
            let h = '';
            d.students.forEach(s => {
                h += `
                <tr onclick="location.href='../student_profile.php?id=${s.IDNo}'" style="cursor:pointer;">
                    <td class="ps-4 fw-bold text-primary">${s.IDNo}</td>
                    <td>${s.NAME}</td>
                    <td>${s.Batch}</td>
                    <td class="text-muted small">${s.class_advisor_name || '-'}</td>
                </tr>`;
            });
            document.getElementById('mList').innerHTML = h;
        });
    }

    // Auto-search if term present
    if(document.getElementById('q').value) doSearch();
</script>

<?php 
include '../assets/ui/floating_chat_widget.php';
include '../includes/footer.php'; 
?>