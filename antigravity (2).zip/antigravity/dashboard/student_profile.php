<?php
// student_profile.php - ENTERPRISE v21.3 (Smart Fill-Only-Empty + Live Hostel/Transport)
session_start();
require_once '../includes/db.php';

// 1. CONFIGURATION
ini_set('display_errors', 0);
error_reporting(E_ALL);
date_default_timezone_set('Asia/Kolkata');

// 2. SECURITY & AUTHENTICATION
$my_role = strtolower($_SESSION['role'] ?? 'student'); 
$my_id = $_SESSION['ID_NO'] ?? $_SESSION['user_id'] ?? '';

// Determine Target ID
// If Student: FORCE target to be themselves (Security)
// If Admin/Faculty: Allow URL parameter 'id'
if ($my_role === 'student') {
    $target_id = $my_id;
} else {
    $target_id = $_GET['id'] ?? '';
}

// Access Control Logic
$admin_roles = ['admin', 'principal', 'dean', 'dean_academics', 'hod'];
$is_mentor = ($my_role == 'faculty'); 
$is_admin = in_array($my_role, $admin_roles);
$is_student = ($my_role === 'student');

// If Admin/Faculty and no ID selected, just show search
$show_search = ($is_admin || $is_mentor) && empty($target_id);

// 3. AJAX SEARCH (For Admins/Faculty)
if (isset($_GET['ajax_search']) && ($is_admin || $is_mentor)) {
    header('Content-Type: application/json');
    $term = $mysqli->real_escape_string($_GET['term']);
    $results = [];
    
    // Search Login Master (Seniors)
    $q1 = "SELECT IDNo as id, Name as name, 'Senior' as batch FROM students_login_master WHERE IDNo LIKE '%$term%' OR Name LIKE '%$term%' LIMIT 5";
    $r1 = $mysqli->query($q1);
    while($r = $r1->fetch_assoc()) $results[] = $r;

    // Search Batch Table (Freshers)
    $q2 = "SELECT id_no as id, student_name as name, '1st Year' as batch FROM students_batch_25_26 WHERE id_no LIKE '%$term%' OR student_name LIKE '%$term%' LIMIT 5";
    $r2 = $mysqli->query($q2);
    while($r = $r2->fetch_assoc()) $results[] = $r;

    echo json_encode($results);
    exit;
}

// --- HELPER FUNCTIONS ---
function formatName($name) {
    $name = trim($name ?? '');
    $name = str_replace('.', ' ', $name);
    $parts = explode(' ', $name);
    $parts = array_filter($parts); 
    if (count($parts) > 1) {
        $first = array_shift($parts);
        if (strlen($first) == 1) return implode(' ', $parts) . ' ' . $first;
    }
    return $name;
}

function calculateYear($batch) {
    if (empty($batch) || $batch == 'Senior') return 'Senior';
    $start_year = intval(substr($batch, 0, 4));
    if($start_year == 0) return $batch;
    $current_month = intval(date('m'));
    $current_year = intval(date('Y'));
    $diff = $current_year - $start_year;
    $year = ($current_month < 6) ? $diff : $diff + 1;
    if ($year == 1) return 'I Year';
    if ($year == 2) return 'II Year';
    if ($year == 3) return 'III Year';
    if ($year == 4) return 'IV Year';
    return $year . ' Year';
}

function log_change($mysqli, $sid, $field, $old, $new) {
    global $my_id, $my_role;
    if(trim((string)$old) === trim((string)$new)) return;
    $stmt = $mysqli->prepare("INSERT INTO profile_edit_log (student_id, changed_by, role, field_changed, old_value, new_value) VALUES (?, ?, ?, ?, ?, ?)");
    if($stmt) {
        $stmt->bind_param("ssssss", $sid, $my_id, $my_role, $field, $old, $new);
        $stmt->execute();
    }
}

// --- SMART LOCK LOGIC ---
// Returns 'readonly_perm' if data exists and user is Student.
// Returns '' (Editable) if data is EMPTY or user is Admin.
function getLockStatus($val) {
    global $is_admin, $is_mentor;
    if ($is_admin || $is_mentor) return ''; // Admins can edit everything
    if (empty($val) || $val === '0' || $val === 'N/A' || $val === '-') return ''; // Student can edit if empty
    return 'readonly_perm'; // Locked otherwise
}

function getDisabledStatus($val) {
    global $is_admin, $is_mentor;
    if ($is_admin || $is_mentor) return '';
    if (empty($val) || $val === '0' || $val === 'N/A' || $val === '-') return '';
    return 'disabled_perm';
}

// --- DATA ENGINE ---
function get_student_profile($mysqli, $id) {
    if(empty($id)) return null;

    $profile = [
        'source_table' => '',
        'data' => [],
        'missing_fields' => [],
        'completeness' => 0,
        'transport' => ['route' => 'Not Allocated', 'point' => ''],
        'hostel' => 'Day Scholar'
    ];

    // 1. Fetch Basic Info (Try Freshers first, then Seniors)
    $stmt = $mysqli->prepare("SELECT * FROM students_batch_25_26 WHERE id_no = ?");
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    
    if ($res->num_rows > 0) {
        $profile['source_table'] = 'students_batch_25_26';
        $row = $res->fetch_assoc();
        $profile['data'] = [
            'id_no' => $row['id_no'], 'register_no' => $row['register_no'], 'name' => $row['student_name'],
            'dob' => $row['dob'], 'gender' => $row['gender'], 'mobile' => $row['student_mobile'],
            'email' => $row['college_email'], 'father_name' => $row['parent_name'], 'father_mobile' => $row['father_mobile'],
            'mother_name' => '', 'mother_mobile' => $row['mother_mobile'], 'address' => $row['address'],
            'pincode' => $row['pincode'], 'aadhaar' => $row['aadhaar_no'], 'community' => $row['community'],
            'scholarship' => $row['scholarship'], 'quota' => $row['quota'], 'mode' => $row['mode'],
            'dept' => $row['department'], 'batch' => $row['batch'], 'section' => $row['section'], 'photo' => $row['profile_photo']
        ];
    } else {
        $stmt = $mysqli->prepare("SELECT * FROM students_login_master WHERE IDNo = ?");
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows > 0) {
            $profile['source_table'] = 'students_login_master';
            $row = $res->fetch_assoc();
            $profile['data'] = [
                'id_no' => $row['IDNo'], 'register_no' => $row['RegisterNo'], 'name' => $row['Name'],
                'dob' => $row['DateofBirth'], 'gender' => $row['Gender'], 'mobile' => $row['Student_contact'],
                'email' => $row['college_email'], 'father_name' => $row['fathername'], 'father_mobile' => $row['parent_contact'],
                'mother_name' => $row['mothername'], 'mother_mobile' => '', 'address' => $row['address'] ?? '', 
                'pincode' => $row['pincode'] ?? '', 'aadhaar' => $row['aadhaar_no'] ?? '', 'community' => $row['community'] ?? '',
                'scholarship' => 'N/A', 'quota' => $row['typeofadmission'] ?? 'N/A', 'mode' => 'N/A',
                'dept' => $row['Dept'], 'batch' => $row['Batch'], 'section' => $row['Section'], 'photo' => $row['profile_photo']
            ];
        } else { return null; }
    }

    // 2. Fetch Transport
    $t_stmt = $mysqli->prepare("SELECT route_no, pickup_point FROM transport_allocation WHERE id_no = ?");
    if ($t_stmt) { 
        $t_stmt->bind_param("s", $id); 
        $t_stmt->execute(); 
        $t_res = $t_stmt->get_result();
        if ($t_row = $t_res->fetch_assoc()) { 
            $profile['transport'] = ['route' => $t_row['route_no'], 'point' => $t_row['pickup_point']]; 
        }
    }

    // 3. Fetch Hostel (Check Boys then Girls)
    $hb = $mysqli->query("SELECT room_no FROM hostel_boys_titans WHERE id_no = '$id'");
    if ($hb && $hb->num_rows > 0) { 
        $profile['hostel'] = "Titans Hostel (Room " . $hb->fetch_assoc()['room_no'] . ")"; 
    } else { 
        $hg = $mysqli->query("SELECT room_no FROM hostel_girls_padmavathy WHERE id_no = '$id'"); 
        if ($hg && $hg->num_rows > 0) { 
            $profile['hostel'] = "Padmavathy Hostel (Room " . $hg->fetch_assoc()['room_no'] . ")"; 
        } 
    }

    // 4. Calculate Profile Completeness
    $critical = ['aadhaar', 'register_no', 'father_name', 'mobile', 'address', 'community', 'pincode', 'photo', 'scholarship'];
    $filled = 0;
    foreach ($profile['data'] as $k => $v) {
        if (!empty($v) && $v != 'NULL' && $v != 'N/A') $filled++;
        if (in_array($k, $critical) && (empty($v) || $v == 'NULL')) {
            $label = ucwords(str_replace('_', ' ', $k));
            if($k=='aadhaar') $label = "Aadhaar No";
            if($k=='photo') $label = "Profile Photo";
            $profile['missing_fields'][] = $label;
        }
    }
    $profile['completeness'] = min(100, round(($filled / 23) * 100));
    return $profile;
}

// --- LOAD STUDENT DATA ---
$sp = null;
$st = null;
$student_found = false;

if (!empty($target_id)) {
    $sp = get_student_profile($mysqli, $target_id);
    if ($sp) { $st = $sp['data']; $student_found = true; }
}

// --- HANDLE SAVE ---
$msg = ""; $msg_type = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_profile']) && $student_found) {
    
    // Photo Handling
    $photo_path = $st['photo'];
    if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['profile_photo']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png'])) {
            $new_name = "stu_" . $target_id . "_" . time() . "." . $ext;
            $dir = "../uploads/profiles/";
            if (!is_dir($dir)) mkdir($dir, 0777, true);
            if (move_uploaded_file($_FILES['profile_photo']['tmp_name'], $dir . $new_name)) {
                // Log photo change if overwriting
                if (!empty($st['photo'])) log_change($mysqli, $target_id, 'profile_photo', $st['photo'], $new_name);
                $photo_path = $new_name;
            }
        }
    }

    // Inputs
    $reg = $_POST['register_no'] ?? $st['register_no']; 
    $dob = $_POST['dob'] ?? $st['dob']; 
    $aadh = $_POST['aadhaar'] ?? $st['aadhaar'];
    $mob = $_POST['mobile'] ?? $st['mobile']; 
    $addr = $_POST['address'] ?? $st['address']; 
    $pin = $_POST['pincode'] ?? $st['pincode'];
    $comm = $_POST['community'] ?? $st['community']; 
    $dad = formatName($_POST['father_name'] ?? $st['father_name']);
    $quota = $_POST['quota'] ?? $st['quota']; 
    $schol = $_POST['scholarship'] ?? $st['scholarship'];
    $mom = formatName($_POST['mother_name'] ?? $st['mother_name']);

    // Log Critical Changes (Aadhaar, Mobile)
    log_change($mysqli, $target_id, 'aadhaar_no', $st['aadhaar'], $aadh);
    log_change($mysqli, $target_id, 'mobile', $st['mobile'], $mob);

    // Update DB
    if ($sp['source_table'] == 'students_batch_25_26') {
        $stmt = $mysqli->prepare("UPDATE students_batch_25_26 SET register_no=?, aadhaar_no=?, parent_name=?, student_mobile=?, address=?, pincode=?, community=?, profile_photo=?, dob=?, quota=?, scholarship=? WHERE id_no=?");
        $stmt->bind_param("ssssssssssss", $reg, $aadh, $dad, $mob, $addr, $pin, $comm, $photo_path, $dob, $quota, $schol, $target_id);
    } else {
        $stmt = $mysqli->prepare("UPDATE students_login_master SET RegisterNo=?, fathername=?, mothername=?, Student_contact=?, address=?, pincode=?, aadhaar_no=?, community=?, profile_photo=?, DateofBirth=? WHERE IDNo=?");
        $stmt->bind_param("sssssssssss", $reg, $dad, $mom, $mob, $addr, $pin, $aadh, $comm, $photo_path, $dob, $target_id);
    }

    if ($stmt->execute()) {
        $msg = "Profile Updated Successfully!"; $msg_type = "success";
        $sp = get_student_profile($mysqli, $target_id); $st = $sp['data']; // Refresh Data
    } else {
        $msg = "Error Updating: " . $stmt->error; $msg_type = "error";
    }
}

include '../includes/header.php';
?>

<style>
    :root { --brand: #bc1888; --insta-grad: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%); --bg-soft: #f8fafc; }
    body { background-color: var(--bg-soft); font-family: 'Outfit', sans-serif; }
    .profile-container { max-width: 900px; margin: 20px auto; padding: 0 15px 80px; }
    
    /* Search Box */
    .search-wrap { position: relative; margin-bottom: 20px; }
    .search-box { width: 100%; padding: 12px 20px; border-radius: 50px; border: 2px solid #e2e8f0; outline: none; transition: 0.2s; }
    .search-box:focus { border-color: #cc2366; box-shadow: 0 0 0 4px rgba(204, 35, 102, 0.1); }
    .search-res { position: absolute; top: 100%; left: 0; width: 100%; background: white; z-index: 100; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); max-height: 200px; overflow-y: auto; display: none; }
    .res-item { padding: 10px 20px; border-bottom: 1px solid #f1f5f9; cursor: pointer; }
    .res-item:hover { background: #f8fafc; color: #cc2366; }

    /* Profile Card */
    .profile-card { background: #fff; border-radius: 24px; overflow: hidden; box-shadow: 0 10px 40px -10px rgba(0,0,0,0.08); margin-bottom: 25px; border: 1px solid rgba(0,0,0,0.03); }
    .cover-photo { height: 140px; background: var(--insta-grad); position: relative; }
    .profile-content { padding: 0 30px 40px; text-align: center; margin-top: -70px; position: relative; }
    .avatar-wrapper { width: 140px; height: 140px; border-radius: 50%; background: #fff; padding: 5px; margin: 0 auto 15px; position: relative; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
    .avatar-img { width: 100%; height: 100%; border-radius: 50%; background: #f1f5f9; display: flex; align-items: center; justify-content: center; font-size: 3.5rem; color: #cc2366; background-size: cover; background-position: center; font-weight: 800; }
    .upload-trigger { position: absolute; bottom: 5px; right: 5px; background: #1e293b; color: #fff; width: 40px; height: 40px; border-radius: 50%; display: none; align-items: center; justify-content: center; cursor: pointer; border: 3px solid #fff; transition: transform 0.2s; }
    body.editing .upload-trigger { display: flex; animation: popIn 0.3s; }

    .student-name { margin: 0; font-size: 1.8rem; font-weight: 700; color: #1e293b; }
    .student-meta { color: #64748b; font-size: 0.95rem; margin-top: 5px; font-weight: 500; }
    .progress-wrapper { max-width: 350px; margin: 25px auto 0; text-align: left; }
    .progress-info { display: flex; justify-content: space-between; font-size: 0.8rem; font-weight: 700; color: #94a3b8; margin-bottom: 5px; }
    .progress-track { height: 8px; background: #f1f5f9; border-radius: 10px; overflow: hidden; }
    .progress-fill { height: 100%; background: var(--insta-grad); width: <?= $sp['completeness'] ?? 0 ?>%; transition: width 1s ease; }

    /* Forms */
    .section-title { font-size: 1.1rem; font-weight: 800; color: #334155; margin: 35px 0 20px; display: flex; align-items: center; gap: 10px; }
    .section-title::after { content: ''; flex: 1; height: 1px; background: #e2e8f0; margin-left: 15px; }
    .form-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; }
    .input-group { background: #fff; padding: 5px; border-radius: 12px; }
    .input-label { display: flex; justify-content: space-between; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; color: #94a3b8; margin-bottom: 6px; }
    
    .input-field { width: 100%; border: 1px solid #e2e8f0; background: #f8fafc; border-radius: 10px; padding: 12px 15px; font-weight: 600; outline: none; transition: all 0.2s; }
    .input-field:read-only:not(.edit-mode) { background: transparent; border-color: transparent; padding-left: 0; cursor: default; }
    .input-field.edit-mode { background: #fff; border-color: #cbd5e1; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
    .input-field.edit-mode:focus { border-color: #cc2366; box-shadow: 0 0 0 3px rgba(204, 35, 102, 0.1); }
    
    /* Smart Edit Indicators */
    .req-tag { background: #fee2e2; color: #b91c1c; font-size: 0.65rem; padding: 2px 6px; border-radius: 4px; display: none; }
    body.editing .req-tag { display: inline-block; }
    .input-field.missing { border: 1px dashed #fda4af; background: #fff1f2; }

    /* FAB */
    .fab-edit { position: fixed; bottom: 30px; right: 30px; width: 60px; height: 60px; background: var(--insta-grad); color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; cursor: pointer; border: none; box-shadow: 0 10px 30px rgba(220, 39, 67, 0.4); z-index: 100; transition: transform 0.2s; }
    .fab-edit:hover { transform: scale(1.1); }
    
    .save-bar { position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%) translateY(100px); background: #fff; padding: 10px 25px; border-radius: 50px; box-shadow: 0 10px 30px rgba(0,0,0,0.15); display: flex; gap: 15px; z-index: 101; transition: 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); border: 1px solid #e2e8f0; }
    body.editing .save-bar { transform: translateX(-50%) translateY(0); }
    .btn-main { background: #10b981; color: #fff; border: none; padding: 10px 20px; border-radius: 30px; font-weight: 700; cursor: pointer; }
    .btn-sec { background: transparent; color: #64748b; border: none; font-weight: 600; cursor: pointer; }
    
    @keyframes popIn { from { transform: scale(0); } to { transform: scale(1); } }
</style>

<div class="profile-container">

    <?php if($show_search): ?>
    <div class="search-wrap">
        <input type="text" class="search-box" id="search" placeholder="Search Student Name or ID..." autocomplete="off">
        <div class="search-res" id="searchResults"></div>
    </div>
    <?php endif; ?>

    <?php if(!$student_found && $show_search): ?>
        <div class="text-center text-muted mt-5">
            <i class="fas fa-search fa-3x mb-3 text-secondary"></i>
            <h3>Find a Student</h3>
            <p>Use the search bar above to view and edit student profiles.</p>
        </div>
    <?php elseif($student_found): ?>

    <form method="POST" enctype="multipart/form-data" id="profileForm">
        <input type="hidden" name="save_profile" value="1">
        
        <div class="profile-card">
            <div class="cover-photo"></div>
            <div class="profile-content">
                <div class="avatar-wrapper">
                    <div class="avatar-img" style="<?= $st['photo'] ? "background-image:url('../uploads/profiles/".$st['photo']."');" : "" ?>">
                        <?= !$st['photo'] ? strtoupper(substr($st['name'], 0, 1)) : '' ?>
                    </div>
                    <label class="upload-trigger" for="pic"><i class="fas fa-camera"></i></label>
                    <input type="file" id="pic" name="profile_photo" style="display:none" onchange="preview(this)">
                </div>
                <h1 class="student-name"><?= htmlspecialchars($st['name']) ?></h1>
                <div class="student-meta"><?= htmlspecialchars($st['id_no']) ?> • <?= htmlspecialchars($st['dept']) ?> • <?= calculateYear($st['batch']) ?></div>
                <div class="progress-wrapper">
                    <div class="progress-info"><span>Profile Completeness</span> <span><?= $sp['completeness'] ?>%</span></div>
                    <div class="progress-track"><div class="progress-fill"></div></div>
                </div>
            </div>
        </div>

        <?php if($msg): ?>
            <div class="alert alert-<?= ($msg_type=='success')?'success':'danger' ?> mb-4"><?= $msg ?></div>
        <?php endif; ?>

        <?php if(!empty($sp['missing_fields'])): ?>
            <div class="alert alert-warning d-flex align-items-center mb-4" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i>
                <div>
                    <strong>Action Required:</strong> Please fill the following details: 
                    <?= implode(', ', $sp['missing_fields']) ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="section-title"><i class="fas fa-user-circle"></i> Personal & Community</div>
        <div class="form-grid">
            <div class="input-group">
                <label class="input-label">Register No <?= empty($st['register_no']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <input type="text" name="register_no" class="input-field <?= empty($st['register_no'])?'missing':'' ?>" value="<?= htmlspecialchars($st['register_no']) ?>" <?= getLockStatus($st['register_no']) ?> readonly>
            </div>
            <div class="input-group">
                <label class="input-label">Date of Birth</label>
                <input type="text" name="dob" class="input-field" value="<?= htmlspecialchars($st['dob']) ?>" readonly>
            </div>
            <div class="input-group">
                <label class="input-label">Community <?= empty($st['community']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <select name="community" class="input-field <?= empty($st['community'])?'missing':'' ?>" disabled <?= getDisabledStatus($st['community']) ?>>
                    <option value="">Select</option>
                    <?php foreach(['OC','BC','BCM','MBC','DNC','SC','SCA','ST'] as $c) { echo "<option value='$c' ".($st['community']==$c?'selected':'').">$c</option>"; } ?>
                </select>
            </div>
        </div>

        <div class="section-title"><i class="fas fa-address-card"></i> Contact & Address</div>
        <div class="form-grid">
            <div class="input-group">
                <label class="input-label">Mobile <?= empty($st['mobile']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <input type="text" name="mobile" class="input-field <?= empty($st['mobile'])?'missing':'' ?>" value="<?= htmlspecialchars($st['mobile']) ?>" <?= getLockStatus($st['mobile']) ?> readonly>
            </div>
            <div class="input-group">
                <label class="input-label">Aadhaar No <?= empty($st['aadhaar']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <input type="text" name="aadhaar" class="input-field <?= empty($st['aadhaar'])?'missing':'' ?>" value="<?= htmlspecialchars($st['aadhaar']) ?>" <?= getLockStatus($st['aadhaar']) ?> readonly>
            </div>
            <div class="input-group" style="grid-column: 1/-1;">
                <label class="input-label">Address <?= empty($st['address']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <input type="text" name="address" class="input-field <?= empty($st['address'])?'missing':'' ?>" value="<?= htmlspecialchars($st['address']) ?>" <?= getLockStatus($st['address']) ?> readonly>
            </div>
            <div class="input-group">
                <label class="input-label">Pincode <?= empty($st['pincode']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <input type="text" name="pincode" class="input-field <?= empty($st['pincode'])?'missing':'' ?>" value="<?= htmlspecialchars($st['pincode']) ?>" <?= getLockStatus($st['pincode']) ?> readonly>
            </div>
        </div>

        <div class="section-title"><i class="fas fa-users"></i> Family Details</div>
        <div class="form-grid">
            <div class="input-group">
                <label class="input-label">Father Name <?= empty($st['father_name']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <input type="text" name="father_name" class="input-field <?= empty($st['father_name'])?'missing':'' ?>" value="<?= htmlspecialchars($st['father_name']) ?>" <?= getLockStatus($st['father_name']) ?> readonly>
            </div>
            <div class="input-group">
                <label class="input-label">Mother Name <?= empty($st['mother_name']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <input type="text" name="mother_name" class="input-field <?= empty($st['mother_name'])?'missing':'' ?>" value="<?= htmlspecialchars($st['mother_name']) ?>" <?= getLockStatus($st['mother_name']) ?> readonly>
            </div>
        </div>

        <div class="section-title"><i class="fas fa-university"></i> Institutional Details</div>
        <div class="form-grid">
            <div class="input-group">
                <label class="input-label">Quota</label>
                <input type="text" name="quota" class="input-field" value="<?= htmlspecialchars($st['quota']) ?>" readonly>
            </div>
            <div class="input-group">
                <label class="input-label">Scholarship <?= empty($st['scholarship']) ? '<span class="req-tag">REQUIRED</span>' : '' ?></label>
                <select name="scholarship" class="input-field <?= empty($st['scholarship'])?'missing':'' ?>" disabled <?= getDisabledStatus($st['scholarship']) ?>>
                    <option value="">None / Not Availed</option>
                    <?php foreach(['7.5% Govt School', 'BC/MBC Scholarship', 'PMSS', 'FG (First Graduate)', 'Tamil Penn / Pudhalvan (7.5%)', 'Merit'] as $s) { echo "<option value='$s' ".($st['scholarship']==$s?'selected':'').">$s</option>"; } ?>
                </select>
            </div>
            <div class="input-group">
                <label class="input-label">Hostel </label>
                <div class="input-field" style="color:#7c3aed; background:#f5f3ff; border-color:#ddd6fe;"><?= htmlspecialchars($sp['hostel']) ?></div>
            </div>
            <div class="input-group">
                <label class="input-label">Transport Route 

[Image of bus icon]
</label>
                <div class="input-field" style="color:#d97706; background:#fffbeb; border-color:#fde68a;"><?= htmlspecialchars($sp['transport']['route']) ?></div>
            </div>
            <div class="input-group">
                <label class="input-label">Boarding Point</label>
                <input type="text" name="boarding_point" class="input-field" value="<?= htmlspecialchars($sp['transport']['point']) ?>" readonly>
            </div>
        </div>

        <div class="save-bar">
            <button type="button" class="btn-sec" onclick="location.reload()">Cancel</button>
            <button type="submit" class="btn-main" id="saveBtn"><i class="fas fa-check"></i> Save Changes</button>
        </div>

    </form>
    
    <button class="fab-edit" id="editBtn" onclick="enableEdit()"><i class="fas fa-pen"></i></button>

    <?php endif; // End if student_found ?>

</div>

<script>
// Search (For Admins)
const searchInput = document.getElementById('search');
if(searchInput) {
    searchInput.addEventListener('keyup', function() {
        const val = this.value;
        const res = document.getElementById('searchResults');
        if(val.length < 2) { res.style.display='none'; return; }
        
        fetch(`student_profile.php?ajax_search=1&term=${val}`)
        .then(r => r.json())
        .then(data => {
            res.innerHTML = '';
            if(data.length > 0) {
                res.style.display = 'block';
                data.forEach(s => {
                    const div = document.createElement('div');
                    div.className = 'res-item';
                    div.innerHTML = `<strong>${s.name}</strong> <span class="text-muted small">(${s.id})</span>`;
                    div.onclick = () => window.location.href = `student_profile.php?id=${s.id}`;
                    res.appendChild(div);
                });
            } else {
                res.style.display = 'none';
            }
        });
    });
}

function enableEdit() {
    document.body.classList.add('editing');
    
    // Unlock only fields that are NOT permanently locked
    const inputs = document.querySelectorAll('.input-field');
    inputs.forEach(el => {
        if(!el.hasAttribute('readonly_perm') && !el.hasAttribute('disabled_perm')) {
            el.removeAttribute('readonly');
            el.removeAttribute('disabled');
            el.classList.add('edit-mode');
        }
    });
    
    document.getElementById('editBtn').style.transform = 'scale(0)';
}

function preview(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            document.querySelector('.avatar-img').style.backgroundImage = 'url('+e.target.result+')';
            document.querySelector('.avatar-img').innerHTML = '';
        }
        reader.readAsDataURL(input.files[0]);
    }
}
</script>

<?php include '../includes/footer.php'; ?>