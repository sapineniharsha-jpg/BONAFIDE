<?php
// =========================================================
// 1. BUSINESS LOGIC (PRESERVED)
// =========================================================
if (session_status() === PHP_SESSION_NONE) session_start();
$root = $_SERVER['DOCUMENT_ROOT'];
require_once '../includes/db.php';

// Compatibility Check (Ensure $conn exists if your DB file uses $mysqli)
if (!isset($conn) && isset($mysqli)) { $conn = $mysqli; }

// Auth Check
if (!isset($_SESSION['user_id'])) {
    header('Location: /index.php');
    exit();
}

// 1. Search Logic
$search_query = "";
$sql_list = "SELECT * FROM mentees"; // Default query
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']);
    $search_query = $search;
    // Adjust column names to match your DB exactly
    $sql_list .= " WHERE name LIKE '%$search%' OR vh_number LIKE '%$search%' OR batch LIKE '%$search%'";
}
$result_list = $conn->query($sql_list);

// 2. Analytics: Department Wise Count
$dept_sql = "SELECT department, COUNT(*) as count FROM mentees GROUP BY department";
$dept_res = $conn->query($dept_sql);

// 3. Analytics: Batch Wise Count
$batch_sql = "SELECT batch, COUNT(*) as count FROM mentees GROUP BY batch";
$batch_res = $conn->query($batch_sql);

// 4. Analytics: Unmapped Mentees (No Mentor Assigned)
$unmapped_sql = "SELECT COUNT(*) as count FROM mentees WHERE mentor_id IS NULL OR mentor_id = '' OR mentor_id = 0";
$unmapped_res = $conn->query($unmapped_sql);
$unmapped_row = $unmapped_res->fetch_assoc();
$unmapped_count = $unmapped_row['count'];

// =========================================================
// 2. PORTAL INTEGRATION
// =========================================================
include '../includes/header.php';
?>

<style>
    .pwa-container { max-width: 1200px; margin: 0 auto; padding: 25px; min-height: 80vh; }

    /* Dashboard Banner */
    .dash-banner {
        background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.5); border-radius: 24px; padding: 25px;
        display: flex; justify-content: space-between; align-items: center;
        box-shadow: 0 10px 40px -10px rgba(0,0,0,0.08); margin-bottom: 30px;
    }
    .insta-gradient-text {
        background: -webkit-linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888);
        -webkit-background-clip: text; -webkit-text-fill-color: transparent; font-weight: 800;
    }

    /* Stats Grid */
    .stats-grid { 
        display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; 
    }
    .stat-card {
        background: white; padding: 25px; border-radius: 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05); border: 1px solid rgba(0,0,0,0.03);
        position: relative; overflow: hidden; transition: 0.3s;
    }
    .stat-card:hover { transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0,0,0,0.1); }
    
    .stat-card h3 { margin: 0 0 10px 0; font-size: 0.85rem; text-transform: uppercase; color: #64748b; font-weight: 700; letter-spacing: 0.5px; }
    .stat-card .value { font-size: 2rem; font-weight: 800; color: #1e293b; line-height: 1; }
    .stat-card .sub { font-size: 0.8rem; color: #94a3b8; margin-top: 5px; }
    
    /* Variant Styles */
    .card-danger { border-left: 5px solid #ef4444; }
    .card-info { border-left: 5px solid #3b82f6; }
    .card-success { border-left: 5px solid #10b981; }

    /* Table Card */
    .saas-card {
        background: #fff; border-radius: 20px; overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.03); border: 1px solid rgba(0,0,0,0.04);
    }
    .card-header {
        padding: 20px 25px; background: #fff; border-bottom: 1px solid #f1f5f9;
        display: flex; justify-content: space-between; align-items: center;
    }
    .search-inp {
        border: 1px solid #e2e8f0; border-radius: 50px; padding: 8px 20px; width: 250px;
        font-size: 0.9rem; outline: none; background: #f8fafc; transition: 0.3s;
    }
    .search-inp:focus { background: #fff; border-color: #bc1888; box-shadow: 0 0 0 3px rgba(188, 24, 136, 0.1); }

    /* Table Styles */
    .table thead { background: #f8f9fa; }
    .table th { 
        font-weight: 700; color: #64748b; text-transform: uppercase; font-size: 0.75rem; 
        padding: 15px 25px; border-bottom: 1px solid #eee; 
    }
    .table td { vertical-align: middle; padding: 15px 25px; border-bottom: 1px solid #f1f5f9; font-size: 0.9rem; }
    .table-hover tbody tr:hover { background-color: #fff0f5; }

    /* Badges */
    .badge-soft { padding: 5px 12px; border-radius: 20px; font-weight: 600; font-size: 0.7rem; text-transform: uppercase; }
    .bg-mapped { background: #dcfce7; color: #166534; }
    .bg-pending { background: #fee2e2; color: #991b1b; }

    /* Scrollable Data Lists inside Cards */
    .data-list { max-height: 100px; overflow-y: auto; margin-top: 10px; font-size: 0.85rem; }
    .data-row { display: flex; justify-content: space-between; padding: 4px 0; border-bottom: 1px dashed #eee; }

    @media(max-width: 768px) {
        .dash-banner { flex-direction: column; text-align: center; gap: 15px; }
        .card-header { flex-direction: column; gap: 15px; }
        .search-inp { width: 100%; }
        .pwa-container { padding: 15px; padding-bottom: 100px; }
    }
</style>

<main class="pwa-container">

    <div class="dash-banner">
        <div>
            <h1 style="margin:0; font-size:1.8rem;" class="insta-gradient-text">Mentee Management</h1>
            <p style="margin:5px 0 0; color:#64748b;">Overview & Allocation</p>
        </div>
        <div style="display:flex; gap:10px;">
            <a href="#" class="btn btn-light rounded-pill fw-bold" style="color:#64748b;"><i class="fas fa-file-export me-1"></i> Report</a>
            <a href="#" class="btn text-white rounded-pill fw-bold" style="background:var(--inst-grad);"><i class="fas fa-user-plus me-1"></i> Add Mentee</a>
        </div>
    </div>

    <div class="stats-grid">
        
        <div class="stat-card card-danger">
            <h3>Action Required</h3>
            <div class="value" style="color:#ef4444;"><?php echo $unmapped_count; ?></div>
            <div class="sub">Unmapped Mentees</div>
            <i class="fas fa-exclamation-triangle" style="position: absolute; right: 20px; top: 20px; font-size: 40px; opacity: 0.1; color:#ef4444;"></i>
        </div>

        <div class="stat-card card-info">
            <h3>By Department</h3>
            <div class="data-list">
                <?php 
                if($dept_res->num_rows > 0) {
                    while($row = $dept_res->fetch_assoc()) {
                        echo "<div class='data-row'><span>" . htmlspecialchars($row['department']) . "</span> <strong>" . $row['count'] . "</strong></div>";
                    }
                } else { echo "<span class='text-muted'>No Data</span>"; }
                ?>
            </div>
        </div>

        <div class="stat-card card-success">
            <h3>By Batch</h3>
            <div class="data-list">
                <?php 
                if($batch_res->num_rows > 0) {
                    while($row = $batch_res->fetch_assoc()) {
                        echo "<div class='data-row'><span>" . htmlspecialchars($row['batch']) . "</span> <strong>" . $row['count'] . "</strong></div>";
                    }
                } else { echo "<span class='text-muted'>No Data</span>"; }
                ?>
            </div>
        </div>

    </div>

    <div class="saas-card">
        <div class="card-header">
            <h5 style="margin:0; font-weight:700; color:#1e293b;"><i class="fas fa-users me-2 text-muted"></i> Student List</h5>
            <form method="GET" action="">
                <input type="text" name="search" class="search-inp" placeholder="Search VH No or Name..." value="<?php echo htmlspecialchars($search_query); ?>">
            </form>
        </div>
        
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th class="ps-4">VH Number</th>
                        <th>Name</th>
                        <th>Batch</th>
                        <th>Department</th>
                        <th>Status</th>
                        <th class="text-end pe-4">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result_list && $result_list->num_rows > 0): ?>
                        <?php while($row = $result_list->fetch_assoc()): 
                            $is_mapped = (!empty($row['mentor_id']) && $row['mentor_id'] != 0);
                        ?>
                        <tr>
                            <td class="ps-4 fw-bold text-primary"><?= htmlspecialchars($row['vh_number']) ?></td>
                            <td>
                                <div class="fw-bold text-dark"><?= htmlspecialchars($row['name']) ?></div>
                            </td>
                            <td><?= htmlspecialchars($row['batch']) ?></td>
                            <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($row['department']) ?></span></td>
                            <td>
                                <?php if($is_mapped): ?>
                                    <span class="badge-soft bg-mapped">Mapped</span>
                                <?php else: ?>
                                    <span class="badge-soft bg-pending">Pending</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end pe-4">
                                <a href="edit_mentee.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-light text-primary border fw-bold rounded-pill px-3">Edit</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="text-center py-5 text-muted">No students found matching your criteria.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</main>

<?php 
include '../assets/ui/floating_chat_widget.php';
include '../includes/footer.php'; 
?>