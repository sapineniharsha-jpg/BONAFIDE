<?php
// reset_table.php
// PURPOSE: Drop the broken table and recreate it with ALL columns.
// WARNING: This deletes existing attendance data!

session_start();
require_once '../includes/db.php';

ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<h2>🔧 Database Reset Tool</h2>";

if ($mysqli->connect_error) {
    die("<h3 style='color:red'>❌ Connection Failed: " . $mysqli->connect_error . "</h3>");
}

// 1. DROP THE EXISTING (BROKEN) TABLE
$tableName = 'attendance_logs';
$dropSql = "DROP TABLE IF EXISTS `$tableName`";

if ($mysqli->query($dropSql)) {
    echo "<p style='color:orange'>🗑️ Old table dropped (if it existed).</p>";
} else {
    echo "<p style='color:red'>❌ Could not drop table: " . $mysqli->error . "</p>";
    echo "<p><strong>Stop!</strong> You likely need to ask your hosting provider to grant 'DROP' and 'CREATE' permissions, or use phpMyAdmin.</p>";
    exit; // Stop if we can't drop
}

// 2. CREATE THE TABLE WITH CORRECT STRUCTURE (All columns included)
$createSql = "CREATE TABLE `$tableName` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `unique_code` varchar(100) NOT NULL,
    `date` date NOT NULL,
    `day_order` int(11) NOT NULL,
    `hour` int(11) NOT NULL,
    `student_id` varchar(50) NOT NULL,
    `subject_code` varchar(50) NOT NULL,
    `faculty_id` varchar(50) NOT NULL,
    `marked_by` varchar(50) NOT NULL,
    `status` varchar(5) NOT NULL DEFAULT 'P',
    `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
    PRIMARY KEY (`id`),
    KEY `idx_main` (`date`,`hour`,`subject_code`),
    KEY `idx_student` (`student_id`),
    KEY `idx_unique` (`unique_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

if ($mysqli->query($createSql)) {
    echo "<h3 style='color:green'>✅ Success! Table recreated with all correct columns.</h3>";
    echo "<p>You can now delete this file and start using the Attendance module.</p>";
    echo "<br><a href='attendance_selection.php' style='padding:10px 20px; background:#22c55e; color:white; text-decoration:none; border-radius:5px;'>Go to Attendance</a>";
} else {
    echo "<h3 style='color:red'>❌ Error Creating Table: " . $mysqli->error . "</h3>";
}
?>