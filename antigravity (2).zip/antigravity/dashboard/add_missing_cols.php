<?php
// add_missing_cols.php
require_once '../includes/db.php';

if ($mysqli->connect_error) die("Connection failed: " . $mysqli->connect_error);

// 1. Add unique_code (Crucial for identifying Batch/Section in reports)
try {
    $mysqli->query("ALTER TABLE attendance_logs ADD COLUMN unique_code VARCHAR(100) AFTER id");
    $mysqli->query("ALTER TABLE attendance_logs ADD INDEX (unique_code)");
    echo "Added 'unique_code' successfully.<br>";
} catch (Exception $e) { echo "unique_code already exists or error: " . $e->getMessage() . "<br>"; }

// 2. Add marked_by (To track who took attendance)
try {
    $mysqli->query("ALTER TABLE attendance_logs ADD COLUMN marked_by VARCHAR(50) AFTER status");
    echo "Added 'marked_by' successfully.<br>";
} catch (Exception $e) { echo "marked_by already exists or error: " . $e->getMessage() . "<br>"; }

echo "<h3>Database Fixed! You can now take attendance.</h3>";
?>