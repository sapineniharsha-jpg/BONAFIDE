<?php
// debug_system.php - System Health Check
session_start();
ini_set('display_errors', 1); 
error_reporting(E_ALL);

echo "<h1>🛠️ System Diagnostic Tool</h1>";

// 1. CHECK DB CONNECTION
echo "<h3>1. Database Connection</h3>";
if (!file_exists('../includes/db.php')) {
    die("<span style='color:red'>❌ Critical: '../includes/db.php' file not found. Check your file structure.</span>");
}

require_once '../includes/db.php';

if (isset($mysqli) && !$mysqli->connect_error) {
    echo "<span style='color:green'>✅ Database Connected Successfully!</span>";
    echo "<br>Host: " . $mysqli->host_info;
} else {
    die("<span style='color:red'>❌ Database Connection Failed: " . $mysqli->connect_error . "</span>");
}

// 2. CHECK CRITICAL TABLES
echo "<h3>2. Table Status</h3>";
$tables = ['attendance_logs', 'timetable_matrix', 'students_login_master', 'students_batch_25_26'];

echo "<table border='1' cellpadding='10' style='border-collapse:collapse;'>
        <tr style='background:#eee'><th>Table Name</th><th>Status</th><th>Rows</th><th>Columns</th></tr>";

foreach ($tables as $table) {
    $check = $mysqli->query("SHOW TABLES LIKE '$table'");
    if ($check->num_rows > 0) {
        // Count Rows
        $count = $mysqli->query("SELECT COUNT(*) as c FROM `$table`")->fetch_assoc()['c'];
        
        // Get Columns
        $cols = [];
        $colQ = $mysqli->query("SHOW COLUMNS FROM `$table`");
        while($r = $colQ->fetch_assoc()) $cols[] = $r['Field'];
        $colStr = implode(", ", $cols);

        echo "<tr>
                <td><b>$table</b></td>
                <td style='color:green'>✅ Exists</td>
                <td><b>$count</b></td>
                <td style='font-size:0.8rem'>$colStr</td>
              </tr>";
    } else {
        echo "<tr>
                <td><b>$table</b></td>
                <td style='color:red'>❌ MISSING</td>
                <td>-</td>
                <td>-</td>
              </tr>";
    }
}
echo "</table>";

// 3. CHECK USER ROLE (Session)
echo "<h3>3. Session Status</h3>";
echo "User ID: " . ($_SESSION['ID_NO'] ?? 'Not Set') . "<br>";
echo "Role: " . ($_SESSION['role'] ?? 'Not Set') . "<br>";

echo "<br><hr><b>Diagnostics Complete.</b> If any table shows '❌ MISSING', the system will crash (500 Error).";
?>