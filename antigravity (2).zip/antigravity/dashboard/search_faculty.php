<?php
// search_faculty.php
// 1. CLEAR ANY PREVIOUS OUTPUT to prevent JSON errors
ob_start();

session_start();
require_once '../includes/db.php'; // <--- CHECK THIS PATH

header('Content-Type: application/json');

// 2. CHECK CONNECTION
if (!isset($mysqli) && isset($conn)) { $mysqli = $conn; } // Compatibility fix
if ($mysqli->connect_error) {
    echo json_encode([['value' => 'Error: DB Connection Failed', 'id' => '']]);
    exit;
}

// 3. GET TERM
$term = isset($_GET['term']) ? trim($_GET['term']) : '';

if (strlen($term) < 1) {
    echo json_encode([]);
    exit;
}

$likeTerm = "%" . $term . "%";

// 4. QUERY (Matches your Employee Table)
// We search both Name and ID
$sql = "SELECT ID_NO, NAME, DEPARTMENT FROM employee_details1 
        WHERE ID_NO LIKE ? OR NAME LIKE ? 
        LIMIT 15";

$stmt = $mysqli->prepare($sql);

if(!$stmt) {
    // Output SQL error for debugging
    echo json_encode([['value' => 'SQL Error: ' . $mysqli->error, 'id' => '']]);
    exit;
}

$stmt->bind_param("ss", $likeTerm, $likeTerm);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [
        'label' => $row['NAME'] . " (" . $row['ID_NO'] . ") - " . $row['DEPARTMENT'], // Display in dropdown
        'value' => $row['NAME'], // Fills the Name box
        'id'    => $row['ID_NO'] // Fills the Hidden ID
    ];
}

// 5. OUTPUT JSON
ob_end_clean(); // Clear buffer
echo json_encode($data);
?>