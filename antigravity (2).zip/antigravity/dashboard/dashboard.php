<?php 
// 1. SETUP & CONFIG - Mandatory Error Handling
ini_set('display_errors', 0); 
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', '../logs/dept_errors.log');
// 1. Session & Path Setup
if (session_status() === PHP_SESSION_NONE) session_start();
$root = $_SERVER['DOCUMENT_ROOT']; // Get the server root folder

// 2. Auth Check
if (!isset($_SESSION['user_id'])) { header("Location: /index.php"); exit; }

// 3. User Context
$role = strtolower($_SESSION['role'] ?? 'public');
$name = $_SESSION['NAME'] ?? 'User';
$dept = $_SESSION['dept'] ?? 'General';
$profileInit = strtoupper(substr($name, 0, 1));

// 4. Time Greeting
$h = date('H');
$greet = ($h < 12) ? "Good Morning" : (($h < 18) ? "Good Afternoon" : "Good Evening");

// 5. Include Header (Absolute Path)
include $root . '/includes/header.php'; 
?>

<style>
    /* PWA Container */
    .pwa-container { max-width: 1200px; margin: 0 auto; padding: 25px; min-height: 85vh; }

    /* Welcome Banner */
    .dash-banner {
        background: rgba(255, 255, 255, 0.9);
        backdrop-filter: blur(15px);
        -webkit-backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.5);
        border-radius: 24px; padding: 30px;
        display: flex; align-items: center; gap: 25px;
        box-shadow: 0 10px 40px -10px rgba(0,0,0,0.08);
        margin-bottom: 35px;
        animation: slideDown 0.6s cubic-bezier(0.2, 0.8, 0.2, 1);
    }
    .db-avatar {
        width: 75px; height: 75px; border-radius: 22px;
        background: var(--inst-grad); color: white;
        display: flex; align-items: center; justify-content: center;
        font-size: 2.2rem; font-weight: 800; 
        box-shadow: 0 12px 25px rgba(188, 24, 136, 0.25);
    }

    /* Grid System */
    .grid-box { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px; }

    /* Cards */
    .card-btn {
        background: #fff; border-radius: 24px; padding: 25px;
        border: 1px solid rgba(0,0,0,0.04); transition: 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        cursor: pointer; text-decoration: none; color: inherit;
        display: flex; flex-direction: column; justify-content: space-between;
        min-height: 180px; position: relative; overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.03);
    }
    .card-btn:hover { transform: translateY(-8px); box-shadow: 0 20px 40px rgba(0,0,0,0.08); border-color: #bc1888; }
    
    .card-icon {
        width: 60px; height: 60px; border-radius: 18px;
        display: flex; align-items: center; justify-content: center;
        font-size: 1.8rem; margin-bottom: 20px; transition: 0.3s;
    }
    .card-btn:hover .card-icon { transform: scale(1.1) rotate(5deg); }

    /* Chat Card */
    .chat-card { background: linear-gradient(135deg, #1a1a1a 0%, #000 100%); color: white; border: none; }
    .chat-card h3 { color: white; }
    .chat-card p { color: #888; }
    .chat-card:hover { transform: translateY(-5px) scale(1.02); box-shadow: 0 25px 50px rgba(0,0,0,0.4); }

    @keyframes slideDown { from { opacity:0; transform:translateY(-20px); } to { opacity:1; transform:translateY(0); } }
    @media(max-width: 768px) {
        .pwa-container { padding: 15px; padding-bottom: 100px; }
        .dash-banner { flex-direction: column; text-align: center; }
    }
</style>

<main class="pwa-container">

    <div class="dash-banner">
        <div class="db-avatar"><?= $profileInit ?></div>
        <div style="flex:1;">
            <h1 style="margin:0; font-size:1.8rem; font-weight:800; color:#1e293b; letter-spacing:-0.5px;">
                <?= $greet ?>, <span style="background:var(--inst-grad); -webkit-background-clip:text; -webkit-text-fill-color:transparent;"><?= htmlspecialchars($name) ?></span>
            </h1>
            <p style="margin:8px 0 0 0; color:#64748b; font-weight:600;">
                <i class="fas fa-id-badge" style="color:#bc1888;"></i> <?= ucfirst($role) ?> • <?= htmlspecialchars($dept) ?>
            </p>
        </div>
        <div style="text-align:right; font-weight:700; color:#bc1888; background:#fff0f5; padding:8px 16px; border-radius:20px; font-size:0.9rem;">
            <?= date('l, d M') ?>
        </div>
    </div>

    <div class="grid-box">

        <div class="card-btn chat-card" onclick="if(window.toggleWidget) window.toggleWidget();">
            <div style="display:flex; justify-content:space-between;">
                <div>
                    <h3 style="margin:0 0 5px 0;">SocialChat</h3>
                    <p style="font-size:0.9rem; margin:0;">Dept & Faculty Connect</p>
                </div>
                <i class="fas fa-comment-dots" style="font-size:3rem; opacity:0.2;"></i>
            </div>
            <div style="margin-top:auto;">
                <span style="font-size:0.85rem; font-weight:700; color:#bc1888; letter-spacing:0.5px;">OPEN CONSOLE <i class="fas fa-arrow-right"></i></span>
            </div>
        </div>

        <?php if($role == 'student'): ?>
            <a href="attendance.php" class="card-btn">
                <div class="card-icon" style="background:#dcfce7; color:#16a34a;"><i class="fas fa-clipboard-check"></i></div>
                <div>
                    <h3 style="margin:0; font-size:1.2rem;">Attendance</h3>
                    <p style="margin:5px 0 0 0; color:#94a3b8;">Check Log</p>
                </div>
            </a>
            <a href="marks.php" class="card-btn">
                <div class="card-icon" style="background:#e0f2fe; color:#0284c7;"><i class="fas fa-chart-bar"></i></div>
                <div>
                    <h3 style="margin:0; font-size:1.2rem;">Marks</h3>
                    <p style="margin:5px 0 0 0; color:#94a3b8;">Exam Results</p>
                </div>
            </a>
            <a href="bonafide.php" class="card-btn">
                <div class="card-icon" style="background:#fef9c3; color:#ca8a04;"><i class="fas fa-certificate"></i></div>
                <div>
                    <h3 style="margin:0; font-size:1.2rem;">Bonafide</h3>
                    <p style="margin:5px 0 0 0; color:#94a3b8;">Request Certs</p>
                </div>
            </a>
        <?php endif; ?>

        <?php if(in_array($role, ['faculty', 'hod', 'dean', 'principal', 'admin'])): ?>
            <a href="attendance_post.php" class="card-btn">
                <div class="card-icon" style="background:#dcfce7; color:#16a34a;"><i class="fas fa-user-edit"></i></div>
                <div>
                    <h3 style="margin:0; font-size:1.2rem;">Post Attendance</h3>
                    <p style="margin:5px 0 0 0; color:#94a3b8;">Daily Updates</p>
                </div>
            </a>
            <a href="circular.php" class="card-btn">
                <div class="card-icon" style="background:#f3e8ff; color:#9333ea;"><i class="fas fa-bullhorn"></i></div>
                <div>
                    <h3 style="margin:0; font-size:1.2rem;">Circulars</h3>
                    <p style="margin:5px 0 0 0; color:#94a3b8;">Announcements</p>
                </div>
            </a>
        <?php endif; ?>

        <?php if(in_array($role, ['admin', 'principal', 'dean'])): ?>
            <a href="admin/ai_console.php" class="card-btn">
                <div class="card-icon" style="background:#fee2e2; color:#dc2626;"><i class="fas fa-brain"></i></div>
                <div>
                    <h3 style="margin:0; font-size:1.2rem;">AI Console</h3>
                    <p style="margin:5px 0 0 0; color:#94a3b8;">Knowledge Base</p>
                </div>
            </a>
        <?php endif; ?>

    </div>
</main>

<?php include $root . '/assets/ui/floating_chat_widget.php'; ?>

<?php include $root . '/includes/footer.php'; ?>