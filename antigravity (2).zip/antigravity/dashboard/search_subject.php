<?php
// search_subject.php - Returns Uppercase Data
require_once '../includes/db.php';

$term = $_GET['term'] ?? '';

if (!empty($term)) {
    // Search logic remains the same
    $sql = "SELECT * FROM course_master 
            WHERE course_name LIKE ? OR course_code LIKE ? 
            LIMIT 20";
    
    $stmt = $mysqli->prepare($sql);
    $searchTerm = "%" . $term . "%";
    $stmt->bind_param("ss", $searchTerm, $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();

    $data = [];
    while ($row = $result->fetch_assoc()) {
        // FORCE UPPERCASE ON OUTPUT
        $data[] = [
            'label' => strtoupper($row['course_code'] . ' - ' . $row['course_name']), 
            'value' => strtoupper($row['course_name']), 
            'code'  => strtoupper($row['course_code']), 
            'cat'   => strtoupper($row['category']),
            'l'     => $row['l'],
            't'     => $row['t'],
            'p'     => $row['p'],
            'c'     => $row['c']
        ];
    }
    echo json_encode($data);
}
?>