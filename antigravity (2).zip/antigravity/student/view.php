<?php
// student/view.php - Instagram Themed Student Portal
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student') {
    header("Location: ../login.php");
    exit();
}

require_once '../includes/db.php';
require_once '../includes/functions.php';

$student_id = $_SESSION['user_id'];
$student_name = $_SESSION['name'];

// Get student data
$student = getCompleteStudentProfile($student_id);
$profile_complete = checkProfileCompletion($student);
$missing_fields = getMissingFields($student);

// First-login profile completion redirect
// If student has critical missing fields and hasn't been redirected yet in this session
if ($student && !isset($_SESSION['profile_check_done'])) {
    $critical_fields = ['fathername', 'parent_name', 'Student_contact', 'student_mobile', 'address', 'profile_photo'];
    $has_critical_missing = false;
    foreach ($critical_fields as $cf) {
        if (isset($student[$cf]) && (empty(trim($student[$cf])) || $student[$cf] === 'N/A' || $student[$cf] === '-' || $student[$cf] === '0')) {
            $has_critical_missing = true;
            break;
        }
        if (!isset($student[$cf])) {
            $has_critical_missing = true;
            break;
        }
    }
    $_SESSION['profile_check_done'] = true;
    if ($has_critical_missing) {
        header("Location: ../dashboard/student_profile.php");
        exit;
    }
}

// Handle form submissions
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['submit_request'])) {
        $bonafide_type = sanitize($_POST['bonafide_type']);
        $purpose = sanitize($_POST['purpose']);
        $additional_info = sanitize($_POST['additional_info'] ?? '');

        // Check fee blocking
        if (in_array($bonafide_type, ['Fee Paid Certificate', 'Fee Structure'])) {
            $fee_details = getFeeInfo($student_id);
            if (isset($fee_details['scholarship_type']) &&
            strpos($fee_details['scholarship_type'], '7.5') !== false) {
                $message = "Fee certificates blocked due to 7.5% scholarship. Contact admin.";
                $message_type = 'error';
            }
            else {
                $request_id = createBonafideRequest($student_id, $bonafide_type, $purpose, $additional_info);
                if ($request_id) {
                    $message = "Request submitted! Tracking ID: BON-$request_id";
                    $message_type = 'success';
                }
            }
        }
        else {
            $request_id = createBonafideRequest($student_id, $bonafide_type, $purpose, $additional_info);
            if ($request_id) {
                $message = "Request submitted! Tracking ID: BON-$request_id";
                $message_type = 'success';
            }
        }
    }

    if (isset($_POST['revoke_request'])) {
        $revoke_id = intval($_POST['revoke_id']);
        if (revokeRequest($student_id, $revoke_id)) {
            $message = "Request revoked successfully!";
            $message_type = 'success';
        }
    }

    if (isset($_POST['update_profile'])) {
        // Update profile logic
        foreach ($_POST as $key => $value) {
            if (strpos($key, 'update_') === 0) {
                $field = str_replace('update_', '', $key);
                $value = sanitize($value);

                if (isset($student['IDNo'])) {
                    $query = "UPDATE students_login_master SET $field = ? WHERE IDNo = ?";
                }
                else {
                    $query = "UPDATE students_batch_25_26 SET $field = ? WHERE id_no = ?";
                }

                $stmt = $mysqli->prepare($query);
                $stmt->bind_param("ss", $value, $student_id);
                $stmt->execute();
            }
        }

        $message = "Profile updated successfully!";
        $message_type = 'success';
        $student = getCompleteStudentProfile($student_id);
        $profile_complete = checkProfileCompletion($student);
    }
}

// Get student data
$requests = getStudentRequests($student_id);
$certificates = getStudentCertificates($student_id);
$hostel_info = getHostelInfo($student_id);
$transport_info = getTransportInfo($student_id);
$fee_info = getFeeInfo($student_id);

// For live preview
$demo_data = null;
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['preview'])) {
    $demo_data = [
        'type' => $_POST['bonafide_type'] ?? 'General',
        'purpose' => $_POST['purpose'] ?? 'General Purpose',
        'student_name' => $student_name,
        'register_no' => $student['RegisterNo'] ?? $student['id_no'],
        'department' => $student['Dept'] ?? $student['department'],
        'batch' => $student['Batch'] ?? $student['batch'],
        'date' => date('d-m-Y'),
        'additional_info' => $_POST['additional_info'] ?? ''
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bonafide Portal - Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* INSTAGRAM GRADIENT THEME - Matching Admin */
        :root {
            --insta-gradient: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
            --gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --gradient-success: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            --gradient-warning: linear-gradient(135deg, #f6d365 0%, #fda085 100%);
            --gradient-danger: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }
        
        .glass-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 25px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
            margin: 20px;
        }
        
        .gradient-header {
            background: var(--insta-gradient);
            color: white;
            padding: 30px;
            position: relative;
            overflow: hidden;
        }
        
        .gradient-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><path d="M0,0 L100,0 L100,100 Z" fill="rgba(255,255,255,0.1)"/></svg>');
            background-size: cover;
        }
        
        .insta-gradient-text {
            background: var(--insta-gradient);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            font-weight: 800;
        }
        
        .card-glass {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
        }
        
        .card-glass:hover {
            transform: translateY(-5px);
            box-shadow: 0 25px 50px rgba(0,0,0,0.15);
        }
        
        .btn-insta {
            background: var(--insta-gradient);
            border: none;
            color: white;
            padding: 12px 30px;
            border-radius: 25px;
            font-weight: 700;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        
        .btn-insta::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: 0.5s;
        }
        
        .btn-insta:hover::before {
            left: 100%;
        }
        
        .btn-insta:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(220, 39, 67, 0.4);
        }
        
        .gradient-badge {
            background: var(--insta-gradient);
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
        }
        
        .status-tracker {
            display: flex;
            justify-content: space-between;
            position: relative;
            padding: 20px 0;
        }
        
        .status-tracker::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 2px;
            background: #e0e0e0;
            z-index: 1;
        }
        
        .status-step {
            position: relative;
            z-index: 2;
            text-align: center;
            flex: 1;
        }
        
        .step-dot {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: white;
            border: 3px solid #e0e0e0;
            margin: 0 auto 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #999;
        }
        
        .step-active .step-dot {
            background: var(--insta-gradient);
            border-color: transparent;
            color: white;
        }
        
        .step-completed .step-dot {
            background: var(--gradient-success);
            border-color: transparent;
            color: white;
        }
        
        .certificate-preview {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
            min-height: 400px;
            position: relative;
            overflow: hidden;
        }
        
        .certificate-preview::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: var(--insta-gradient);
        }
        
        .certificate-template {
            border: 2px dashed #dc2743;
            padding: 25px;
            background: #f8f9fa;
            font-family: 'Times New Roman', serif;
            position: relative;
        }
        
        .certificate-watermark {
            position: absolute;
            opacity: 0.1;
            font-size: 120px;
            transform: rotate(-45deg);
            color: #dc2743;
            z-index: 1;
        }
        
        .qr-preview {
            width: 120px;
            height: 120px;
            background: white;
            border-radius: 10px;
            padding: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin: 0 auto;
        }
        
        .floating-action-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: var(--insta-gradient);
            color: white;
            border: none;
            box-shadow: 0 10px 25px rgba(220, 39, 67, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            cursor: pointer;
            z-index: 1000;
            transition: all 0.3s;
        }
        
        .floating-action-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 15px 35px rgba(220, 39, 67, 0.6);
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--gradient-danger);
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .form-control, .form-select {
            border-radius: 15px;
            border: 2px solid #e2e8f0;
            padding: 12px 15px;
            font-size: 14px;
            transition: all 0.3s;
            background: rgba(255, 255, 255, 0.9);
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #bc1888;
            box-shadow: 0 0 0 3px rgba(188, 24, 136, 0.1);
            background: white;
        }
        
        .nav-tabs-instagram .nav-link {
            border: none;
            color: #666;
            font-weight: 600;
            padding: 15px 25px;
            border-radius: 15px 15px 0 0;
            background: rgba(255, 255, 255, 0.5);
        }
        
        .nav-tabs-instagram .nav-link.active {
            background: white;
            color: #bc1888;
            border-bottom: 3px solid #bc1888;
        }
        
        @media (max-width: 768px) {
            .glass-container {
                margin: 10px;
                border-radius: 15px;
            }
            
            .gradient-header {
                padding: 20px;
            }
            
            .floating-action-btn {
                bottom: 20px;
                right: 20px;
                width: 50px;
                height: 50px;
            }
        }
    </style>
</head>
<body>
    <div class="glass-container">
        <!-- Header -->
        <div class="gradient-header">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="display-5 fw-bold mb-3">
                        <i class="fas fa-certificate"></i> Bonafide Certificate Portal
                    </h1>
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <h4 class="mb-1 text-white"><?php echo htmlspecialchars($student_name); ?></h4>
                            <p class="mb-0 opacity-90">ID: <?php echo htmlspecialchars($student_id); ?></p>
                        </div>
                        <?php if ($profile_complete): ?>
                            <span class="gradient-badge">
                                <i class="fas fa-check-circle"></i> Profile Complete
                            </span>
                        <?php
else: ?>
                            <span class="badge bg-warning">
                                <i class="fas fa-exclamation-circle"></i> Complete Profile
                            </span>
                        <?php
endif; ?>
                    </div>
                </div>
                <div class="col-md-4 text-end">
                    <a href="logout.php" class="btn btn-outline-light">
                        <i class="fas fa-sign-out-alt me-1"></i> Logout
                    </a>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="container-fluid p-4">
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type == 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php
endif; ?>

            <?php if (!$profile_complete): ?>
                <!-- Profile Completion Section -->
                <div class="card-glass p-4 mb-4">
                    <div class="alert alert-warning">
                        <h4><i class="fas fa-user-edit me-2"></i> Complete Your Profile</h4>
                        <p>Please complete your profile to submit bonafide requests.</p>
                    </div>
                    
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Father's Name *</label>
                                <input type="text" name="update_fathername" class="form-control" 
                                       value="<?php echo htmlspecialchars($student['fathername'] ?? $student['parent_name'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Gender *</label>
                                <select name="update_Gender" class="form-select" required>
                                    <option value="">Select Gender</option>
                                    <option value="Male" <?php echo(($student['Gender'] ?? $student['gender'] ?? '') == 'Male') ? 'selected' : ''; ?>>Male</option>
                                    <option value="Female" <?php echo(($student['Gender'] ?? $student['gender'] ?? '') == 'Female') ? 'selected' : ''; ?>>Female</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Batch *</label>
                                <input type="text" name="update_Batch" class="form-control" 
                                       value="<?php echo htmlspecialchars($student['Batch'] ?? $student['batch'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Department *</label>
                                <input type="text" name="update_Dept" class="form-control" 
                                       value="<?php echo htmlspecialchars($student['Dept'] ?? $student['department'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Mobile Number *</label>
                                <input type="tel" name="update_student_mobile" class="form-control" 
                                       value="<?php echo htmlspecialchars($student['student_mobile'] ?? $student['Student_contact'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email *</label>
                                <input type="email" name="update_college_email" class="form-control" 
                                       value="<?php echo htmlspecialchars($student['college_email'] ?? ''); ?>" required>
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Address *</label>
                                <textarea name="update_Address" class="form-control" rows="3" required><?php echo htmlspecialchars($student['Address'] ?? $student['address'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" name="update_profile" class="btn-insta">
                                <i class="fas fa-save me-2"></i> Save Profile
                            </button>
                        </div>
                    </form>
                </div>
            <?php
else: ?>
            
            <!-- Quick Stats -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="card-glass p-3 text-center">
                        <div class="h2 mb-0 insta-gradient-text"><?php echo count($requests); ?></div>
                        <small class="text-muted">Total Requests</small>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card-glass p-3 text-center">
                        <div class="h2 mb-0 insta-gradient-text"><?php echo count($certificates); ?></div>
                        <small class="text-muted">Certificates</small>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card-glass p-3 text-center">
                        <div class="h2 mb-0 insta-gradient-text">
                            <?php
    $pending = 0;
    foreach ($requests as $req) {
        if ($req['status'] == 'pending' || $req['advisor_status'] == 'pending') {
            $pending++;
        }
    }
    echo $pending;
?>
                        </div>
                        <small class="text-muted">Pending</small>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card-glass p-3 text-center">
                        <div class="h2 mb-0 insta-gradient-text">
                            <?php
    $approved = 0;
    foreach ($requests as $req) {
        if ($req['status'] == 'approved' || $req['admin_status'] == 'approved') {
            $approved++;
        }
    }
    echo $approved;
?>
                        </div>
                        <small class="text-muted">Approved</small>
                    </div>
                </div>
            </div>

            <!-- Two Column Layout -->
            <div class="row">
                <!-- Left Column - Request Form -->
                <div class="col-lg-6 mb-4">
                    <div class="card-glass p-4 h-100">
                        <h4 class="mb-4 insta-gradient-text">
                            <i class="fas fa-file-alt me-2"></i> New Bonafide Request
                        </h4>
                        
                        <form method="POST" id="requestForm">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Certificate Type</label>
                                <select name="bonafide_type" class="form-select" onchange="updatePreview()" required>
                                    <option value="">Select Type</option>
                                    <option value="Study Certificate">Study Certificate</option>
                                    <option value="Fee Paid Certificate">Fee Paid Certificate</option>
                                    <option value="Fee Structure">Fee Structure</option>
                                    <option value="Conduct Certificate">Conduct Certificate</option>
                                    <option value="Course Completion">Course Completion</option>
                                    <option value="Internship">Internship</option>
                                    <option value="Bonafide">General Bonafide</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label fw-bold">Purpose</label>
                                <select name="purpose" class="form-select" onchange="updatePreview()" required>
                                    <option value="">Select Purpose</option>
                                    <option value="Passport Application">Passport Application</option>
                                    <option value="Visa Application">Visa Application</option>
                                    <option value="Bank Loan">Bank Loan</option>
                                    <option value="Scholarship">Scholarship</option>
                                    <option value="Higher Studies">Higher Studies</option>
                                    <option value="Internship">Internship Requirement</option>
                                    <option value="Competition">Competition</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label fw-bold">Additional Information</label>
                                <textarea name="additional_info" class="form-control" rows="3" 
                                          placeholder="Any specific requirements..." 
                                          oninput="updatePreview()"></textarea>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" name="preview" class="btn btn-outline-primary">
                                    <i class="fas fa-eye me-2"></i> Preview Certificate
                                </button>
                                <button type="submit" name="submit_request" class="btn-insta">
                                    <i class="fas fa-paper-plane me-2"></i> Submit Request
                                </button>
                            </div>
                        </form>
                        
                        <!-- Student Info -->
                        <div class="mt-4 pt-4 border-top">
                            <h6 class="fw-bold mb-3">Student Information</h6>
                            <div class="row small">
                                <div class="col-6">
                                    <p class="mb-1"><strong>Register No:</strong></p>
                                    <p class="mb-1"><strong>Department:</strong></p>
                                    <p class="mb-1"><strong>Batch:</strong></p>
                                </div>
                                <div class="col-6">
                                    <p class="mb-1"><?php echo htmlspecialchars($student['RegisterNo'] ?? $student['id_no']); ?></p>
                                    <p class="mb-1"><?php echo htmlspecialchars($student['Dept'] ?? $student['department']); ?></p>
                                    <p class="mb-1"><?php echo htmlspecialchars($student['Batch'] ?? $student['batch']); ?></p>
                                </div>
                            </div>
                            
                            <?php if ($hostel_info): ?>
                                <div class="alert alert-info mt-2 p-2 small">
                                    <i class="fas fa-bed me-1"></i> 
                                    Hostel: <?php echo $hostel_info['hostel_name']; ?> - Room <?php echo $hostel_info['room_no']; ?>
                                </div>
                            <?php
    endif; ?>
                            
                            <?php if ($transport_info): ?>
                                <div class="alert alert-warning mt-2 p-2 small">
                                    <i class="fas fa-bus me-1"></i> 
                                    Transport: Route <?php echo $transport_info['route_no']; ?>
                                </div>
                            <?php
    endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Right Column - Live Preview -->
                <div class="col-lg-6 mb-4">
                    <div class="certificate-preview">
                        <h4 class="mb-4 insta-gradient-text">
                            <i class="fas fa-tv me-2"></i> Live Certificate Preview
                        </h4>
                        
                        <div id="previewContent">
                            <?php if ($demo_data): ?>
                                <div class="certificate-template">
                                    <div class="certificate-watermark">DRAFT</div>
                                    
                                    <div class="text-center mb-4">
                                        <h3 class="fw-bold text-primary">VEL TECH HIGH TECH</h3>
                                        <h5>Dr. Rangarajan Dr. Sakunthala Engineering College</h5>
                                        <h4 class="mt-3 fw-bold">BONAFIDE CERTIFICATE</h4>
                                    </div>
                                    
                                    <div class="certificate-body">
                                        <p>This is to certify that <strong><?php echo htmlspecialchars($demo_data['student_name']); ?></strong>
                                        (Reg. No: <strong><?php echo htmlspecialchars($demo_data['register_no']); ?></strong>) is a bonafide student of 
                                        Vel Tech High Tech Dr. Rangarajan Dr. Sakunthala Engineering College.</p>
                                        
                                        <p>The student is pursuing <?php echo htmlspecialchars($demo_data['batch']); ?> batch in the Department of 
                                        <?php echo htmlspecialchars($demo_data['department']); ?>.</p>
                                        
                                        <p>This certificate is issued for the purpose of <strong><?php echo htmlspecialchars($demo_data['purpose']); ?></strong> 
                                        and is valid for official use.</p>
                                        
                                        <?php if (!empty($demo_data['additional_info'])): ?>
                                        <p><strong>Additional Information:</strong> <?php echo htmlspecialchars($demo_data['additional_info']); ?></p>
                                        <?php
        endif; ?>
                                        
                                        <div class="mt-5 pt-4 text-end">
                                            <p>Date: <?php echo htmlspecialchars($demo_data['date']); ?></p>
                                            <p><strong>PRINCIPAL</strong></p>
                                        </div>
                                    </div>
                                </div>
                            <?php
    else: ?>
                                <div class="text-center py-5">
                                    <i class="fas fa-file-alt fa-4x text-muted mb-3"></i>
                                    <h5 class="text-muted">Preview Area</h5>
                                    <p class="text-muted">Fill the form to see certificate preview</p>
                                </div>
                            <?php
    endif; ?>
                        </div>
                        
                        <!-- Approval Status Tracker -->
                        <div class="mt-4">
                            <h6 class="fw-bold mb-3">Approval Flow</h6>
                            <div class="status-tracker">
                                <div class="status-step step-active">
                                    <div class="step-dot"><i class="fas fa-user"></i></div>
                                    <small>Class Advisor</small>
                                </div>
                                <div class="status-step">
                                    <div class="step-dot"><i class="fas fa-user-tie"></i></div>
                                    <small>HOD</small>
                                </div>
                                <div class="status-step">
                                    <div class="step-dot"><i class="fas fa-user-graduate"></i></div>
                                    <small>Dean</small>
                                </div>
                                <div class="status-step">
                                    <div class="step-dot"><i class="fas fa-user-cog"></i></div>
                                    <small>Admin</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabs for Requests & Certificates -->
            <div class="card-glass p-4 mt-4">
                <ul class="nav nav-tabs-instagram mb-3" id="myTab">
                    <li class="nav-item">
                        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#requests-tab">
                            <i class="fas fa-list me-2"></i> My Requests
                            <span class="badge bg-primary ms-1"><?php echo count($requests); ?></span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#certificates-tab">
                            <i class="fas fa-certificate me-2"></i> My Certificates
                            <span class="badge bg-success ms-1"><?php echo count($certificates); ?></span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-tab">
                            <i class="fas fa-user me-2"></i> My Profile
                        </button>
                    </li>
                </ul>
                
                <div class="tab-content">
                    <!-- Requests Tab -->
                    <div class="tab-pane fade show active" id="requests-tab">
                        <?php if (empty($requests)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                <h5>No Requests Found</h5>
                                <p class="text-muted">Submit your first bonafide request above.</p>
                            </div>
                        <?php
    else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Type</th>
                                            <th>Purpose</th>
                                            <th>Date</th>
                                            <th>Current Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($requests as $request): ?>
                                        <tr>
                                            <td><strong>BON-<?php echo $request['id']; ?></strong></td>
                                            <td><?php echo htmlspecialchars($request['bonafide_type']); ?></td>
                                            <td><?php echo htmlspecialchars(substr($request['purpose'], 0, 25)); ?>...</td>
                                            <td><?php echo date('d M Y', strtotime($request['request_date'])); ?></td>
                                            <td>
                                                <?php
            $status = getRequestStatus($request);
?>
                                                <span class="badge bg-<?php echo $status['color']; ?>">
                                                    <?php echo $status['text']; ?>
                                                </span>
                                                <br>
                                                <small class="text-muted">
                                                    <?php
            if ($request['advisor_status'] == 'pending')
                echo 'With Class Advisor';
            elseif ($request['hod_status'] == 'pending')
                echo 'With HOD';
            elseif ($request['dean_status'] == 'pending')
                echo 'With Dean';
            elseif ($request['admin_status'] == 'pending')
                echo 'With Admin';
            else
                echo 'Completed';
?>
                                                </small>
                                            </td>
                                            <td>
                                                <?php if ($request['advisor_status'] == 'pending'): ?>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="revoke_id" value="<?php echo $request['id']; ?>">
                                                    <button type="submit" name="revoke_request" 
                                                            class="btn btn-sm btn-outline-danger" 
                                                            onclick="return confirm('Are you sure you want to revoke this request?');">
                                                        <i class="fas fa-times"></i> Revoke
                                                    </button>
                                                </form>
                                                <?php
            endif; ?>
                                                <button class="btn btn-sm btn-outline-primary" 
                                                        onclick="viewRequestDetails(<?php echo $request['id']; ?>)">
                                                    <i class="fas fa-eye"></i> View
                                                </button>
                                            </td>
                                        </tr>
                                        <?php
        endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php
    endif; ?>
                    </div>
                    
                    <!-- Certificates Tab -->
                    <div class="tab-pane fade" id="certificates-tab">
                        <?php if (empty($certificates)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-certificate fa-3x text-muted mb-3"></i>
                                <h5>No Certificates Found</h5>
                                <p class="text-muted">Your approved certificates will appear here.</p>
                            </div>
                        <?php
    else: ?>
                            <div class="row">
                                <?php foreach ($certificates as $cert): ?>
                                <div class="col-md-6 col-lg-4 mb-4">
                                    <div class="card-glass p-3">
                                        <div class="d-flex justify-content-between align-items-start mb-3">
                                            <div>
                                                <h6 class="fw-bold mb-0"><?php echo htmlspecialchars($cert['certificate_type']); ?></h6>
                                                <small class="text-muted">Ref: <?php echo htmlspecialchars($cert['ref_number']); ?></small>
                                            </div>
                                            <span class="gradient-badge">Approved</span>
                                        </div>
                                        
                                        <div class="qr-preview mb-3">
                                            <?php if ($cert['qr_code_path']): ?>
                                                <img src="../<?php echo htmlspecialchars($cert['qr_code_path']); ?>" alt="QR Code" class="w-100">
                                            <?php
            else: ?>
                                                <div class="text-center text-muted small">
                                                    <i class="fas fa-qrcode fa-2x mb-2"></i><br>
                                                    QR Code
                                                </div>
                                            <?php
            endif; ?>
                                        </div>
                                        
                                        <p class="small mb-2">
                                            <i class="fas fa-calendar me-2"></i>
                                            <?php echo date('d M Y', strtotime($cert['bonafide_date'])); ?>
                                        </p>
                                        
                                        <div class="d-grid gap-2">
                                            <a href="../print_bonafide.php?id=<?php echo $cert['id']; ?>" 
                                               class="btn-insta btn-sm" target="_blank">
                                                <i class="fas fa-print me-1"></i> Print Certificate
                                            </a>
                                            <a href="../verify.php?ref=<?php echo urlencode($cert['ref_number']); ?>" 
                                               class="btn btn-outline-secondary btn-sm" target="_blank">
                                                <i class="fas fa-shield-alt me-1"></i> Verify Online
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <?php
        endforeach; ?>
                            </div>
                        <?php
    endif; ?>
                    </div>
                    
                    <!-- Profile Tab -->
                    <div class="tab-pane fade" id="profile-tab">
                        <div class="row">
                            <div class="col-md-6">
                                <h5 class="mb-3">Personal Details</h5>
                                <table class="table table-sm">
                                    <tr><th>Name:</th><td><?php echo htmlspecialchars($student_name); ?></td></tr>
                                    <tr><th>Register No:</th><td><?php echo htmlspecialchars($student['RegisterNo'] ?? $student['id_no']); ?></td></tr>
                                    <tr><th>Department:</th><td><?php echo htmlspecialchars($student['Dept'] ?? $student['department']); ?></td></tr>
                                    <tr><th>Batch:</th><td><?php echo htmlspecialchars($student['Batch'] ?? $student['batch']); ?></td></tr>
                                    <tr><th>Gender:</th><td><?php echo htmlspecialchars($student['Gender'] ?? $student['gender']); ?></td></tr>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <h5 class="mb-3">Contact Information</h5>
                                <table class="table table-sm">
                                    <tr><th>Email:</th><td><?php echo htmlspecialchars($student['college_email'] ?? 'Not set'); ?></td></tr>
                                    <tr><th>Mobile:</th><td><?php echo htmlspecialchars($student['student_mobile'] ?? $student['Student_contact'] ?? 'Not set'); ?></td></tr>
                                    <tr><th>Father's Name:</th><td><?php echo htmlspecialchars($student['fathername'] ?? $student['parent_name'] ?? 'Not set'); ?></td></tr>
                                    <tr><th>Address:</th><td><?php echo htmlspecialchars($student['Address'] ?? $student['address'] ?? 'Not set'); ?></td></tr>
                                </table>
                                
                                <div class="text-end">
                                    <a href="?action=edit_profile" class="btn-insta">
                                        <i class="fas fa-edit me-2"></i> Edit Profile
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
endif; ?>
        </div>
        
        <!-- Footer -->
        <div class="border-top p-4 text-center text-muted bg-light">
            <p class="mb-0">
                <i class="fas fa-shield-alt me-1"></i> Bonafide Management System v2.0
                <br>
                <small>© <?php echo date('Y'); ?> Vel Tech High Tech - Student Portal</small>
            </p>
        </div>
    </div>

    <!-- Floating Action Button -->
    <button class="floating-action-btn" onclick="scrollToForm()">
        <i class="fas fa-plus"></i>
    </button>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Update preview function
        function updatePreview() {
            const form = document.getElementById('requestForm');
            const formData = new FormData(form);
            
            // AJAX call for live preview
            fetch('preview_ajax.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(html => {
                document.getElementById('previewContent').innerHTML = html;
            });
        }
        
        // View request details
        function viewRequestDetails(requestId) {
            window.location.href = `request_details.php?id=${requestId}`;
        }
        
        // Scroll to form
        function scrollToForm() {
            document.getElementById('requestForm').scrollIntoView({ behavior: 'smooth' });
        }
        
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
        
        // Auto-refresh every 30 seconds
        setInterval(() => {
            const activeTab = document.querySelector('#myTab .nav-link.active');
            if (activeTab && activeTab.getAttribute('data-bs-target') === '#requests-tab') {
                // Only refresh if on requests tab
                window.location.reload();
            }
        }, 30000);
    </script>
</body>
</html>